#!/bin/bash

./sb21.sh &
./sb21-0.sh &
./sb21-1.sh &
./sb21-2.sh &
./sb21-3.sh &
./sb21-4.sh &
./sb21-5.sh &
./sb21-6.sh &
./sb21-7.sh &
./sb21-8.sh &
./sb21-9.sh &
./sb21-10.sh &
./sb21-11.sh &
./sb21-12.sh &
./sb21-13.sh &
./sb21-14.sh &
./sb21-15.sh &
./sb21-16.sh &
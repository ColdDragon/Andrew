#!/bin/bash

./sb6.sh &
./sb6-0.sh &
./sb6-1.sh &
./sb6-2.sh &
./sb7.sh &
./sb7-0.sh &
./sb7-1.sh &
./sb7-2.sh &
./sb8.sh &
./sb8-0.sh &
./sb8-1.sh &
./sb8-2.sh &
./sb9.sh &
./sb9-0.sh &
./sb9-1.sh &
./sb9-2.sh &
./sb10.sh &
./sb10-0.sh &
./sb10-1.sh &
./sb10-2.sh &

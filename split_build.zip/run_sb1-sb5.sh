#!/bin/bash

./sb1.sh &
./sb1-0.sh &
./sb1-1.sh &
./sb1-2.sh &
./sb2.sh &
./sb2-0.sh &
./sb2-1.sh &
./sb2-2.sh &
./sb3.sh &
./sb3-0.sh &
./sb3-1.sh &
./sb3-2.sh &
./sb4.sh &
./sb4-0.sh &
./sb4-1.sh &
./sb4-2.sh &
./sb5.sh &
./sb5-0.sh &
./sb5-1.sh &
./sb5-2.sh &

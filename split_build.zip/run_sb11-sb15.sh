#!/bin/bash

./sb11.sh &
./sb11-0.sh &
./sb11-1.sh &
./sb11-2.sh &
./sb12.sh &
./sb12-0.sh &
./sb12-1.sh &
./sb12-2.sh &
./sb13.sh &
./sb13-0.sh &
./sb13-1.sh &
./sb13-2.sh &
./sb14.sh &
./sb14-0.sh &
./sb14-1.sh &
./sb14-2.sh &
./sb15.sh &
./sb15-0.sh &
./sb15-1.sh &
./sb15-2.sh &

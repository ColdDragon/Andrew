#!/bin/bash

./sb16.sh &
./sb16-0.sh &
./sb16-1.sh &
./sb16-2.sh &
./sb17.sh &
./sb17-0.sh &
./sb17-1.sh &
./sb17-2.sh &
./sb18.sh &
./sb18-0.sh &
./sb18-1.sh &
./sb18-2.sh &
./sb19.sh &
./sb19-0.sh &
./sb19-1.sh &
./sb19-2.sh &
./sb20.sh &
./sb20-0.sh &
./sb20-1.sh &
./sb20-2.sh &
./sb20-3.sh &
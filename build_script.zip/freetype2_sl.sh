cd freetype2
ar   -r libPOfreetype2.a autofit.o ftbase.o ftbbox.o ftbdf.o ftbitmap.o ftcid.o ftdebug.o ftfstype.o ftgasp.o ftglyph.o ftgxval.o ftinit.o ftmm.o ftotval.o ftpatent.o ftpfr.o ftstroke.o ftsynth.o ftsystem.o fttype1.o ftwinfnt.o bdf.o ftbzip2.o ftcache.o cff.o type1cid.o dlgwrap.o gxvalid.o ftgzip.o ftlzw.o otvalid.o pcf.o pfr.o psaux.o pshinter.o psnames.o raster.o sdf.o sfnt.o smooth.o svg.o truetype.o type1.o type42.o winfnt.o
cp -f libPOfreetype2.a ../../../../../../../../../sdks/linux/lib/x64/freetype2.a
cd ..
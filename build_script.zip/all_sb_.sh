
./all_sb_00.sh &  
./all_sb_06.sh &  
./all_sb_12.sh &  
./all_sb_18.sh &  
./all_sb_24.sh &  
./all_sb_30.sh &  
./all_sb_36.sh &

./all_sb_01.sh &  
./all_sb_07.sh &  
./all_sb_13.sh &  
./all_sb_19.sh &  
./all_sb_25.sh &  
./all_sb_31.sh &  
./all_sb_37.sh &

./all_sb_02.sh &  
./all_sb_08.sh &  
./all_sb_14.sh &  
./all_sb_20.sh &  
./all_sb_26.sh &  
./all_sb_32.sh &  
./all_sb_38.sh &

./all_sb_03.sh &  
./all_sb_09.sh &  
./all_sb_15.sh &  
./all_sb_21.sh &  
./all_sb_27.sh &  
./all_sb_33.sh &  
./all_sb_39.sh &

./all_sb_04.sh &  
./all_sb_10.sh &  
./all_sb_16.sh &  
./all_sb_22.sh &  
./all_sb_28.sh &  
./all_sb_34.sh &  

./all_sb_05.sh &  
./all_sb_11.sh &  
./all_sb_17.sh &  
./all_sb_23.sh &  
./all_sb_29.sh &  
./all_sb_35.sh &  

cd libeot
ar   -r libPOlibeot.a EOT.o libeot.o triplet_encodings.o writeFontFile.o parseCTF.o parseTTF.o SFNTContainer.o ahuff.o bitio.o liblzcomp.o lzcomp.o mtxmem.o libeot_stream.o
cd ..
ar   -r googletest/libPOgoogletest.a gtest_main.o gtest-all.o

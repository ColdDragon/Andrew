cd harfbuzz
ar   -r libPOharfbuzz.a harfbuzz.o hb-gobject-structs.o hb-icu.o
cd ..
cd harfbuzz
ar   -r libPOharfbuzz.a harfbuzz.o hb-gobject-structs.o hb-icu.o
cp -f libPOharfbuzz.a ../../../../../../../../../sdks/linux/lib/x64/harfbuzz.a
cd ..
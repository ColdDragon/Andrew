cd brotli
ar   -r libPObrotli.a constants.o context.o dictionary.o platform.o transform.o bit_reader.o decode.o huffman.o state.o backward_references.o backward_references_hq.o bit_cost.o block_splitter.o brotli_bit_stream.o cluster.o command.o compress_fragment.o compress_fragment_two_pass.o dictionary_hash.o encode.o encoder_dict.o entropy_encode.o fast_log.o histogram.o literal_cost.o memory.o metablock.o static_dict.o utf8_util.o
cp -f libPObrotli.a ../../../../../../../../../sdks/linux/lib/x64/brotli.a
cd ..
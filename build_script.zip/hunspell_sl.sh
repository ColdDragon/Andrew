cd hunspell
ar   -r libPOhunspell.a affentry.o affixmgr.o csutil.o filemgr.o hashmgr.o hunspell.o hunzip.o phonet.o replist.o suggestmgr.o
cp -f libPOhunspell.a ../../../../../../../../../sdks/linux/lib/x64/hunspell.a
cd ..
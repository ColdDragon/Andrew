cd hunspell
ar   -r libPOhunspell.a affentry.o affixmgr.o csutil.o filemgr.o hashmgr.o hunspell.o hunzip.o phonet.o replist.o suggestmgr.o
cd ..
cd pugixml
ar   -r libPOpugixml.a pugixml.o
cd ..
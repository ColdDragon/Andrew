cd pugixml
ar   -r libPOpugixml.a pugixml.o
cp -f libPOpugixml.a ../../../../../../../../../sdks/linux/lib/x64/pugixml.a
cd ..
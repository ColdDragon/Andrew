cd libjpegxr
ar   -r libPOlibjpegxr.a br_adapthuff.o br_decode.o br_encode.o br_image.o br_JXRGlue.o br_JXRGlueJxr.o br_JXRGluePFC.o br_JXRMeta.o br_JXRTest.o br_JXRTranscode.o br_postprocess.o br_segdec.o br_segenc.o br_strcodec.o br_strdec.o br_strdec_x86.o br_strenc.o br_strenc_x86.o br_strFwdTransform.o br_strInvTransform.o br_strPredQuant.o br_strPredQuantDec.o br_strPredQuantEnc.o br_strTransform.o
cp -f libPOlibjpegxr.a ../../../../../../../../../sdks/linux/lib/x64/libjpegxr.a
cd ..
cd openjpeg
ar   -r libPOopenjpeg.a bio.o cio.o dwt.o event.o function_list.o ht_dec.o image.o invert.o j2k.o jp2.o mct.o mqc.o openjpeg.o opj_clock.o opj_malloc.o pi.o sparse_array.o t1.o t2.o tcd.o tgt.o thread.o
cp -f libPOopenjpeg.a ../../../../../../../../../sdks/linux/lib/x64/openjpeg.a
cd ..
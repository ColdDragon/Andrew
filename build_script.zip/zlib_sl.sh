cd zlib
ar   -r libPOzlib.a po_additional_zlib.o zlibmain.o adler32.o compress.o crc32.o deflate.o gzclose.o gzlib.o gzread.o gzwrite.o infback.o inffast.o inflate.o inftrees.o trees.o uncompr.o zutil.o
cp -f libPOzlib.a ../../../../../../../../../sdks/linux/lib/x64/zlib.a
cd ..
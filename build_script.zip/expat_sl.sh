cd expat
ar   -r libPOexpat.a xmlparse.o xmlrole.o xmltok.o xmltok_impl.o xmltok_ns.o
cp -f libPOexpat.a ../../../../../../../../../sdks/linux/lib/x64/expat.a
cd ..
cd expat
ar   -r libPOexpat.a xmlparse.o xmlrole.o xmltok.o xmltok_impl.o xmltok_ns.o
cd ..
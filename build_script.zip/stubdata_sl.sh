cd stubdata
ar   -r libPOstubdata.a stubdata.o
cp -f libPOstubdata.a ../../../../../../../../../sdks/linux/lib/x64/stubdata.a
cd ..
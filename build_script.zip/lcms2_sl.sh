cd lcms2
ar   -r libPOlcms2.a lcms2PreCompile.o cmsalpha.o cmscam02.o cmscgats.o cmscnvrt.o cmserr.o cmsgamma.o cmsgmt.o cmshalf.o cmsintrp.o cmsio0.o cmsio1.o cmslut.o cmsmd5.o cmsmtrx.o cmsnamed.o cmsopt.o cmspack.o cmspcs.o cmsplugin.o cmsps2.o cmssamp.o cmssm.o cmstypes.o cmsvirt.o cmswtpnt.o cmsxform.o
cd ..
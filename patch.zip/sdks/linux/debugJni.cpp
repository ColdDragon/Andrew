//#include "bmvStdAfx.h"
#include "debugJni.h"

static char gTraceLogFile[LOG_FILENAME_MAX] = "";

#include <jni.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

void ui_debug_2_file(char* str)
{
#ifdef UI_DEBUG
	if(NULL == str && NULL == str[0])
		return;
	FILE *p = NULL;
	p = fopen("./pomsg.log", "a+");
	if(NULL == p)
		return;
	fwrite(str, sizeof(char), strlen(str), p);
	fclose(p);
#endif
}

void ui_debug(const char* s ,...)
{
#ifdef UI_DEBUG
	char str[LOG_CONTENTS_LENGTH];
	va_list ap;

	va_start(ap, s);
	if(s)
	{
		vsprintf(str, s, ap); 
		strncat(str, "\n", LOG_CONTENTS_LENGTH);

		ui_debug_2_file(str);
#ifdef BASED_WINDOWS_SYSTEM
		OutputDebugString(str);
#endif
#if defined(__linux__)
		printf(str);
#endif
	}
	va_end(ap);
#endif	
}

void ui_debug_setLogFileName(char* s)
{
#if 0//def UI_DEBUG
	strncpy(gTraceLogFile, s, LOG_FILENAME_MAX);
#endif
}

#include "com_infraware_office_evengine_EvNative.h"
#include "implementNative.h"
#include "nativeCallback.h"
#include "nativeStringUtil.h" 
#include "debugJni.h"
#include "jniHeader.h"
#include "loadUcnv.h"
#include "POOcxInterface.h"
#include "POOcxInterfaceStruct.h"
//#include "bmvfuncinterface.h"
#include <string.h>
#include <stdlib.h>

const static char* JNI_ENGINE_VERSION = "P7_2015.03.25"; // ������ ��¥�� ������ ����.
static void* gZlibOpenMemory = NULL;
static unsigned long gnBufferSize = 0;

extern void	BEventProcess(void * pEvent);

#define BR_BGR(_a,_r,_g,_b)               ((long) ((0x00<<24) | ((_b)<<16) | ((_g)<<8) | (_r) ))
#define BR_RGB(_a,_b,_g,_r)               ((long) ((0xff<<24) | ((_r)<<16) | ((_g)<<8) | (_b) ))

long changeBGRColor(long argb) //rgb  -> bgr
{
	if (argb == 0x00)
		return 0xffffffff;

	return BR_BGR((char)(argb>>24),(char)(argb>>16), (char)(argb>>8), (char)argb);
}

long changeRGBColor(long abgr)
{
	if ((abgr & 0xffffffff) == 0xffffffff)
		return 0x00000000;

	return BR_RGB((char)(abgr>>24),(char)(abgr>>16), (char)(abgr>>8), (char)abgr);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IBeginNative(JNIEnv *env, jobject obj,  jobject iconv)
{
	registerResultCallBack(env, obj);
	registerConversionCallBack(env, iconv);
#if defined(_DLOPEN_UCNV_)
	loadUCNVlib();
#endif
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetHeapSize(JNIEnv *env, jobject obj, jint a_nHeapSize)
{
	impNativeSetHeapSize(a_nHeapSize);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetLocale(JNIEnv *env, jobject obj, jint a_nLocale)
{
	impNativeSetLocale(a_nLocale);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IInitialize
(JNIEnv *env, jobject obj, jint a_nWidth, jint a_nHeight, jint a_nScrollModeType, jint a_nBookmarkType, jint a_bUseAutoBookmark, jint a_nBits, jint a_bFrameBufferSwap, jint a_nDpi)
{
	printf("%s %s\n", __DATE__, __TIME__);
	gZlibOpenMemory = NULL;
	ui_debug_setLogFileName(JNI_DEBUG_TRACE_FILE);

	BrGuiInitEvent sGuiEvent = {0};
	sGuiEvent.nType = BRGUI_INIT_EVENT;
	sGuiEvent.nWidth = a_nWidth;
	sGuiEvent.nHeight = a_nHeight;
	//sGuiEvent.nBits = a_nBits;
	sGuiEvent.nBits = 32;
	sGuiEvent.nUseBookmark = a_bUseAutoBookmark;
	sGuiEvent.nBookmarkType = a_nBookmarkType;
	sGuiEvent.nScrollType = a_nScrollModeType;
	sGuiEvent.bFrameBufferSwap = a_bFrameBufferSwap;
	sGuiEvent.nDpi = a_nDpi;
	sGuiEvent.bSyncMode = true;

	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IFinalize(JNIEnv *env, jobject obj)
{
	if(NULL != gZlibOpenMemory)
	{
		free(gZlibOpenMemory);
		gZlibOpenMemory  = NULL;
		gnBufferSize = 0;
	}

	BrGuiFinalizeEvent boraEvent = {0}; 
	boraEvent.nType = BRGUI_FINALIZE_EVENT;
	boraEvent.nMode = 1;

	BrSetGUIEvent(&boraEvent, BEventProcess);
}

extern int gCBbitmap;

void FillUpOpenEvent(LPBrGuiOpenEvent pOpenEvent, JNIEnv *env, jstring a_sFilePath, jint a_nWidth, jint a_nHeight, jint a_eLoadType, jint a_nPageBgColor, jint a_nTextColor,
 jint a_nOpenPageNum, jint a_nOpenScale, jint a_nOpenRotateAngle, jint a_nOpenStartX, jint a_nOpenStartY, jint a_nLocale, jint a_bLandScape, jstring a_sTempPath, jstring a_sFileExt)
{
	gCBbitmap = 0;
	impNativeSetLocale((BR_LOCALE_TYPE)a_nLocale);	
	impNativeSetTempPath(env, a_sTempPath);
	impNativeSetFileExt(env, a_sFileExt);

	pOpenEvent->nType = BRGUI_OPEN_EVENT;
	if(NULL != a_sFilePath)
		CopyJstring2Utf8(env, pOpenEvent->szFilePath, a_sFilePath, BORA_FULLPATH_LENGTH);
	else
		strcpy(pOpenEvent->szFilePath, "1");
	pOpenEvent->nLoadType = a_eLoadType;
	pOpenEvent->nOpenPageNum = a_nOpenPageNum;
	pOpenEvent->nOpenScale = a_nOpenScale;
	pOpenEvent->nOpenRotateAngle = a_nOpenRotateAngle;
	pOpenEvent->nOpenStartX = a_nOpenStartX;
	pOpenEvent->nOpenStartY = a_nOpenStartY;			
	pOpenEvent->nScreenWidth = a_nWidth;
	pOpenEvent->nScreenHeight = a_nHeight;
	pOpenEvent->bLandScape = a_bLandScape;

	//if(true == IsTextFile(pOpenEvent->szFilePath))
	//{
	//	BoraViewerProperties a_Info = {0,};
	//	BrGetViewerProperties(&a_Info);
	//	a_Info.dwBgColor = a_nPageBgColor;
	//	if(0 == a_Info.dwBgColor)
	//		a_Info.dwBgColor = 0x00FFFFFF;
	//	BrSetViewerProperties(&a_Info);
	//}
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IOpen
(JNIEnv *env, jobject obj, jstring a_sFilePath, jint a_nWidth, jint a_nHeight, jint a_eLoadType, jint a_nPageBgColor, jint a_nTextColor,
 jint a_nOpenPageNum, jint a_nOpenScale, jint a_nOpenRotateAngle, jint a_nOpenStartX, jint a_nOpenStartY, jint a_nLocale, jint a_bLandScape, jstring a_sTempPath, jstring a_sFileExt)
{
	BrGuiOpenEvent sGuiEvent = {0,};
	FillUpOpenEvent(&sGuiEvent, env, a_sFilePath, a_nWidth, a_nHeight, a_eLoadType, a_nPageBgColor, a_nTextColor, a_nOpenPageNum, a_nOpenScale, a_nOpenRotateAngle, a_nOpenStartX, 
					a_nOpenStartY, a_nLocale, a_bLandScape, a_sTempPath, a_sFileExt);

	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IOpen4Uncompress
(JNIEnv *env, jobject obj, jstring a_sFilePath, jint a_nWidth, jint a_nHeight, jint a_eLoadType, jint a_nPageBgColor, jint a_nTextColor,
 jint a_nOpenPageNum, jint a_nOpenScale, jint a_nOpenRotateAngle, jint a_nOpenStartX, jint a_nOpenStartY, jint a_nLocale, jint a_bLandScape, jstring a_sTempPath, jstring a_sFileExt)
{
	int nResult = -7;
#ifdef SUPPORT_ZLIB_MEMORY_OPEN
	BrGuiOpenEvent sGuiEvent = {0,};
	FillUpOpenEvent(&sGuiEvent, env, a_sFilePath, a_nWidth, a_nHeight, a_eLoadType, a_nPageBgColor, a_nTextColor, a_nOpenPageNum, a_nOpenScale, a_nOpenRotateAngle, a_nOpenStartX, 
					a_nOpenStartY, a_nLocale, a_bLandScape, a_sTempPath, a_sFileExt);

	if(NULL != gZlibOpenMemory)
	{
		free(gZlibOpenMemory);
		gZlibOpenMemory = NULL;
	}

	gnBufferSize = 0;
	gZlibOpenMemory = GetZlibBuffer(sGuiEvent.szFilePath, &nResult, &gnBufferSize);
	if(NULL != gZlibOpenMemory)
	{
		sGuiEvent.nLoadType = BORA_LOAD_VIEWMODE | BORA_LOAD_MEMORY;
		sGuiEvent.pStrBuf = (char*)gZlibOpenMemory;
		sGuiEvent.nBufferSize = gnBufferSize;
		BrSetGUIEvent(&sGuiEvent, BEventProcess);
	}

#endif
	return nResult;
}

JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IOpenEx(JNIEnv *env, jobject obj, jstring a_sFilePath, jstring a_sPassword)
{
	BrGuiOpenExEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_OPENEX_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_sFilePath, BORA_FULLPATH_LENGTH);
	CopyJstring2Utf8(env, sGuiEvent.szPassword, a_sPassword, BORA_FULLPATH_LENGTH);
	if (strlen(sGuiEvent.szPassword) == 0) {
		sGuiEvent.bProtectDocumentReadMode = 0x03;
	}
#ifdef SUPPORT_OPEN_DOC_IN_MEMORY
	if(NULL != gZlibOpenMemory)
	{
		sGuiEvent.pStrBuf = (char*)gZlibOpenMemory;
		sGuiEvent.nBufferSize = gnBufferSize;
	}

	// in memory�� ��쿡 free�� ���� �ȿ��� �Ѵ�. 
	gZlibOpenMemory = NULL;
	gnBufferSize = 0;
#endif 
	BrSetGUIEvent(&sGuiEvent, BEventProcess);
	return 1;
}


JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IOpen4Stream
(JNIEnv *env, jobject obj, jbyteArray a_bFileStream, jint a_nWidth, jint a_nHeight, jint a_eLoadType, jint a_nPageBgColor, jint a_nTextColor,
 jint a_nOpenPageNum, jint a_nOpenScale, jint a_nOpenRotateAngle, jint a_nOpenStartX, jint a_nOpenStartY, jint a_nLocale, jint a_bLandScape, jstring a_sTempPath, jstring a_sFileExt)
{
	int nResult = -7;
	BrGuiOpenEvent sGuiEvent = {0,};
	FillUpOpenEvent(&sGuiEvent, env, (jstring)NULL, a_nWidth, a_nHeight, a_eLoadType, a_nPageBgColor, a_nTextColor, a_nOpenPageNum, a_nOpenScale, a_nOpenRotateAngle, a_nOpenStartX, 
					a_nOpenStartY, a_nLocale, a_bLandScape, a_sTempPath, a_sFileExt);

	if(NULL != gZlibOpenMemory)
	{
		free(gZlibOpenMemory);
		gZlibOpenMemory = NULL;
	}

	gnBufferSize = env->GetArrayLength(a_bFileStream);
	jbyte *nativeBytes = env->GetByteArrayElements(a_bFileStream, 0);
	gZlibOpenMemory = (char*)malloc(gnBufferSize);
	memcpy(gZlibOpenMemory, (const char*)nativeBytes, gnBufferSize);
	
	env->ReleaseByteArrayElements(a_bFileStream, nativeBytes, JNI_ABORT);

	if(NULL != gZlibOpenMemory)
	{
		sGuiEvent.nLoadType = BORA_LOAD_VIEWMODE | BORA_LOAD_MEMORY;
		if  ((a_eLoadType & BORA_LOAD_FORCED ) == BORA_LOAD_FORCED )
			sGuiEvent.nLoadType |= BORA_LOAD_FORCED;
		sGuiEvent.pStrBuf = (char*)gZlibOpenMemory;
		sGuiEvent.nBufferSize = gnBufferSize;
		BrSetGUIEvent(&sGuiEvent, BEventProcess);
	}

	return nResult;
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IClose(JNIEnv *env, jobject obj)
{
	BrGuiBaseEvent boraEvent = {0}; 
	boraEvent.nType = BRGUI_BRCLOSEDOC_EVENT;
	BrSetGUIEvent(&boraEvent, BEventProcess);
	
	if(NULL != gZlibOpenMemory)
	{
		free(gZlibOpenMemory);
		gZlibOpenMemory  = NULL;
		gnBufferSize = 0;
	}
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetImgToPDF(JNIEnv *env, jobject obj, jobjectArray srcStringArray, jstring path_dst)
{
    //size get. 
    int cnt_src = env->GetArrayLength(srcStringArray);
    //jchar* p_jchar = env->GetCharArrayElements(path_src,0);
    
    char** srcList = (char**)malloc(cnt_src * sizeof(char*)); 
    const char* dst = env->GetStringUTFChars(path_dst, 0); 
    
    //encoding 
    if(srcList)
    {
              for(int i=0; i < cnt_src; i++)
              {
                         //Get string from srcArray 
                         jstring src = (jstring)env->GetObjectArrayElement(srcStringArray,i); 
                         const char* c = env->GetStringUTFChars(src, 0);                          
                         //LOGW("IConvertImgToPDF src[%d]= %s\n", i, c);   
                         srcList[i] = (char*)c;                              
              }
    }
    
    BoraFilePath* pImages = (BoraFilePath*)malloc(sizeof(BoraFilePath)*cnt_src);
    
    //src img list setting. 
    for(int j=0; j < cnt_src; j++)
              sprintf(pImages[j].szPath , srcList[j]);

    BrGuiImageToPdfEvent sEvent = {0};
    sEvent.nType = BRGUI_IMAGETOPDF_EVENT;
    sEvent.nImageCount = cnt_src;
    sEvent.pImagePaths = pImages;
    
    strcpy( sEvent.szFilePath, dst );
    BrSetGUIEvent(&sEvent, BEventProcess);
    
    free(pImages);
    free(srcList);
              
    //LOGW("IConvertImgToPDF dst = %s\n",dst);        
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetImgToPDFWithWaterMark(JNIEnv *env, jobject obj, jobjectArray srcStringArray, jstring path_dst, jstring a_pszMarkFilePath )
{
    //size get. 
    int cnt_src = env->GetArrayLength(srcStringArray);
    //jchar* p_jchar = env->GetCharArrayElements(path_src,0);
    
    char** srcList = (char**)malloc(cnt_src * sizeof(char*)); 
    const char* dst = env->GetStringUTFChars(path_dst, 0); 	

    //encoding 
    if(srcList)
    {
              for(int i=0; i < cnt_src; i++)
              {
                         //Get string from srcArray 
                         jstring src = (jstring)env->GetObjectArrayElement(srcStringArray,i); 
                         const char* c = env->GetStringUTFChars(src, 0);                          
                         //LOGW("IConvertImgToPDF src[%d]= %s\n", i, c);   
                         srcList[i] = (char*)c;                              
              }
    }
    
    BoraFilePath* pImages = (BoraFilePath*)malloc(sizeof(BoraFilePath)*cnt_src);
    
    //src img list setting. 
    for(int j=0; j < cnt_src; j++)
              sprintf(pImages[j].szPath , srcList[j]);

    BrGuiImageToPdfEvent sEvent = {0};
    sEvent.nType = BRGUI_IMAGETOPDF_EVENT;
    sEvent.nImageCount = cnt_src;
    sEvent.pImagePaths = pImages;
	sEvent.nExportWaterMarkAlpha = 128;
	sEvent.bBottomWaterMark = false;

	CopyJstring2Utf8(env, sEvent.szExportWaterMarkPath, a_pszMarkFilePath, BORA_FULLPATH_LENGTH);
	//CopyJstring2Utf8(env, sEvent.szFilePath, path_dst, BORA_FULLPATH_LENGTH );

    //CopyJstring2Utf8(env, sEvent.szFilePath, dst, BORA_FULLPATH_LENGTH );
    strcpy( sEvent.szFilePath, dst );
	//CopyJstring2Utf8(env, sEvent.szFilePath, path_dst, BORA_FULLPATH_LENGTH );
    BrSetGUIEvent(&sEvent, BEventProcess);
    
    free(pImages);
    free(srcList);
              
    //LOGW("IConvertImgToPDF dst = %s\n",dst);        
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveDocument
(JNIEnv *env, jobject obj, jstring  a_pszFilePath, jint nSaveOption)	//[2013.01.04][MID:20297][������] save option ���� �߰�
{
	BrGuiSaveEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);

	sGuiEvent.bBackUp = true;
	sGuiEvent.bNeedDraw = false;
	sGuiEvent.bPDFAExport = true;
	sGuiEvent.nPageAreaMode = XLS_PRINT_ENTIRE_WORKBOOK;

	if( nSaveOption & BR_SAVE_OPTION_TEMP_SAVE )
		sGuiEvent.bTempSave = true;

	if( nSaveOption & BR_SAVE_OPTION_INFRA_PENDRAW_SAVE )
		sGuiEvent.bInfraPenDrawSave	= true;

	if( nSaveOption & BR_SAVE_OPTION_BOOKMARK_TOC)
		sGuiEvent.bBookMarkTOCSave = true;

	//PDF/PDFA ���� �ɼ�. �Լ� ���� Ȯ��� ȣȯ�� ������ �־, ���� �ɼǿ� ���� �߰��ؼ� ������.
	int UI_SAVE_OPTION_NOMAL_PDF = 0x1000;
	if (nSaveOption & UI_SAVE_OPTION_NOMAL_PDF)
		sGuiEvent.bPDFAExport = false;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;

	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveViewerDocument
(JNIEnv* env, jobject obj, jstring  a_pszFilePath, jint nSaveOption)	//[2013.01.04][MID:20297][������] save option ���� �߰�
{
	BrGuiSaveEvent sGuiEvent = { 0, };
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);

	sGuiEvent.bBackUp = true;
	sGuiEvent.bNeedDraw = false;
	sGuiEvent.bPDFAExport = true;
	sGuiEvent.nPageAreaMode = XLS_PRINT_ENTIRE_WORKBOOK;

	if (nSaveOption & BR_SAVE_OPTION_TEMP_SAVE)
		sGuiEvent.bTempSave = true;

	if (nSaveOption & BR_SAVE_OPTION_INFRA_PENDRAW_SAVE)
		sGuiEvent.bInfraPenDrawSave = true;

	if (nSaveOption & BR_SAVE_OPTION_BOOKMARK_TOC)
		sGuiEvent.bBookMarkTOCSave = true;

	//PDF/PDFA ���� �ɼ�. �Լ� ���� Ȯ��� ȣȯ�� ������ �־, ���� �ɼǿ� ���� �߰��ؼ� ������.
	int UI_SAVE_OPTION_NOMAL_PDF = 0x1000;
	if (nSaveOption & UI_SAVE_OPTION_NOMAL_PDF)
		sGuiEvent.bPDFAExport = false;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;
	BrSetSheetFitPageScale(1, 1);
	BrSetSheetFitAuto(true);
	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveDivisionDocument
(JNIEnv* env, jobject obj, jstring  a_pszFilePath, jint nSaveOption, jint curNumber, jint curPages)	//[2022.07.07][Eva] PDF ���� ��ȯ API �߰�
{
	BrGuiSaveEvent sGuiEvent = { 0, };
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);

	sGuiEvent.bBackUp = true;
	sGuiEvent.bNeedDraw = false;
	sGuiEvent.bPDFAExport = true;
	sGuiEvent.nPageAreaMode = XLS_PRINT_ENTIRE_WORKBOOK;

	if (nSaveOption & BR_SAVE_OPTION_TEMP_SAVE)
		sGuiEvent.bTempSave = true;

	if (nSaveOption & BR_SAVE_OPTION_INFRA_PENDRAW_SAVE)
		sGuiEvent.bInfraPenDrawSave = true;

	if (nSaveOption & BR_SAVE_OPTION_BOOKMARK_TOC)
		sGuiEvent.bBookMarkTOCSave = true;

	//PDF/PDFA ���� �ɼ�. �Լ� ���� Ȯ��� ȣȯ�� ������ �־, ���� �ɼǿ� ���� �߰��ؼ� ������.
	int UI_SAVE_OPTION_NOMAL_PDF = 0x1000;
	if (nSaveOption & UI_SAVE_OPTION_NOMAL_PDF)
		sGuiEvent.bPDFAExport = false;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;

	sGuiEvent.nPageCnt = curPages;
	int startPage = 1 + (10 * curNumber);

	for (int i = 0; i < curPages; i++)
		sGuiEvent.pPageArray[i] = startPage+i;

	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveDocumentWithWaterMark
(JNIEnv *env, jobject obj, jstring  a_pszFilePath, jstring a_pszMarkFilePath, jint nSaveOption, jboolean bBottomWaterMark, jint nWaterMarkAlpha)	//[2013.01.04][MID:20297][������] save option ���� �߰�
{
	BrGuiSaveEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);
	CopyJstring2Utf8(env, sGuiEvent.szExportWaterMarkPath, a_pszMarkFilePath, BORA_FULLPATH_LENGTH);

	sGuiEvent.bBackUp = true;
	sGuiEvent.bNeedDraw = false;
	sGuiEvent.bPDFAExport = true;
	sGuiEvent.nPageAreaMode = XLS_PRINT_ENTIRE_WORKBOOK;
	sGuiEvent.nExportWaterMarkAlpha = nWaterMarkAlpha;
	sGuiEvent.bBottomWaterMark = bBottomWaterMark;

	if( nSaveOption & BR_SAVE_OPTION_TEMP_SAVE )
		sGuiEvent.bTempSave = true;

	if( nSaveOption & BR_SAVE_OPTION_INFRA_PENDRAW_SAVE )
		sGuiEvent.bInfraPenDrawSave	= true;

	if( nSaveOption & BR_SAVE_OPTION_BOOKMARK_TOC)
		sGuiEvent.bBookMarkTOCSave = true;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;
	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveViewerDocumentWithWaterMark
(JNIEnv* env, jobject obj, jstring  a_pszFilePath, jstring a_pszMarkFilePath, jint nSaveOption, jboolean bBottomWaterMark, jint nWaterMarkAlpha)	//[2013.01.04][MID:20297][������] save option ���� �߰�
{
	BrGuiSaveEvent sGuiEvent = { 0, };
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);
	CopyJstring2Utf8(env, sGuiEvent.szExportWaterMarkPath, a_pszMarkFilePath, BORA_FULLPATH_LENGTH);

	sGuiEvent.bBackUp = true;
	sGuiEvent.bNeedDraw = false;
	sGuiEvent.bPDFAExport = true;
	sGuiEvent.nPageAreaMode = XLS_PRINT_ENTIRE_WORKBOOK;
	sGuiEvent.nExportWaterMarkAlpha = nWaterMarkAlpha;
	sGuiEvent.bBottomWaterMark = bBottomWaterMark;

	if (nSaveOption & BR_SAVE_OPTION_TEMP_SAVE)
		sGuiEvent.bTempSave = true;

	if (nSaveOption & BR_SAVE_OPTION_INFRA_PENDRAW_SAVE)
		sGuiEvent.bInfraPenDrawSave = true;

	if (nSaveOption & BR_SAVE_OPTION_BOOKMARK_TOC)
		sGuiEvent.bBookMarkTOCSave = true;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;
	BrSetSheetFitPageScale(1, 1);
	BrSetSheetFitAuto(true);
	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveDivisionDocumentWithWaterMark
(JNIEnv* env, jobject obj, jstring  a_pszFilePath, jstring a_pszMarkFilePath, jint nSaveOption, jboolean bBottomWaterMark, jint nWaterMarkAlpha, jint curNumber, jint curPages)//[2022.07.07][Eva] PDF ���� ��ȯ API �߰�
{
	BrGuiSaveEvent sGuiEvent = { 0, };
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	CopyJstring2Utf8(env, sGuiEvent.szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);
	CopyJstring2Utf8(env, sGuiEvent.szExportWaterMarkPath, a_pszMarkFilePath, BORA_FULLPATH_LENGTH);

	sGuiEvent.bBackUp = true;
	sGuiEvent.bNeedDraw = false;
	sGuiEvent.bPDFAExport = true;
	sGuiEvent.nPageAreaMode = XLS_PRINT_ENTIRE_WORKBOOK;
	sGuiEvent.nExportWaterMarkAlpha = nWaterMarkAlpha;
	sGuiEvent.bBottomWaterMark = bBottomWaterMark;

	if (nSaveOption & BR_SAVE_OPTION_TEMP_SAVE)
		sGuiEvent.bTempSave = true;

	if (nSaveOption & BR_SAVE_OPTION_INFRA_PENDRAW_SAVE)
		sGuiEvent.bInfraPenDrawSave = true;

	if (nSaveOption & BR_SAVE_OPTION_BOOKMARK_TOC)
		sGuiEvent.bBookMarkTOCSave = true;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;
	printf(" %d\n", curNumber);
	sGuiEvent.nPageCnt = curPages;
	int startPage = 1 + (10 * curNumber);

	for (int i = 0; i < curPages; i++)
		sGuiEvent.pPageArray[i] = startPage + i;

	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

//for hwp
JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISyncOpen
(JNIEnv *env, jobject obj, jstring  a_pszFilePath)
{
	char szFilePath[BORA_FULLPATH_LENGTH];
	CopyJstring2Utf8(env, szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);
	BrHWPViewProperties pro = {0,};
	BrSyncOpenDocument(szFilePath, "HWP", "", &pro, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISaveDocumentAsXhtml
(JNIEnv *env, jobject obj, jstring  a_pszFilePath)
{
	char szFilePath[BORA_FULLPATH_LENGTH];
	CopyJstring2Utf8(env, szFilePath, a_pszFilePath, BORA_FULLPATH_LENGTH);
	BrSyncSaveDocument(szFilePath,"PUBDOCBODY","",false, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetPageThumbnail(JNIEnv *env, jobject obj, jint a_nSaveMode, jint a_nPageNum, jint a_nWidth, jint a_nHeight, jint a_nZoomRatio, jstring a_sOutputPath)
{
	int nRet;
	BrGuiGetPageThumbnailEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_BWP_GET_PAGE_THUMBNAIL_EVENT;
	sGuiEvent.nPageNum = a_nPageNum;
	sGuiEvent.nWidth = a_nWidth;
	sGuiEvent.nHeight = a_nHeight;
	sGuiEvent.nSaveMode = a_nSaveMode;		// 0:raw, 1:png, 2:jpeg, 3:bitmap
	sGuiEvent.nZoomRatio = a_nZoomRatio * 100;
	CopyJstring2Utf8(env, sGuiEvent.szOutputPath, a_sOutputPath, BORA_FULLPATH_LENGTH);

	//no draw pen on thumbnail image
	//sGuiEvent.nOption = (BrPageThumbnailOption)(BR_THUMBNAIL_OPTION_DEFAULT | BR_THUMBNAIL_OPTION_NO_DRAW_PENDRAW);
	sGuiEvent.nOption = (BrPageThumbnailOption)(BR_THUMBNAIL_OPTION_DEFAULT);

	nRet = BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetPrint(JNIEnv *env, jobject obj,jint a_PaperSize, jint a_nWidth, jint a_nHeight, jint a_StartPage, jint a_EndPage, jstring a_szOutPath, jint a_RetrunType, jint a_DivideHeight, jint a_nPrintAreaMode)
{
	BrGuiPrintEvent boraEvent = {0,};
	boraEvent.nType = BRGUI_BRPRINT_EVENT;
	boraEvent.nPaperSize = a_PaperSize;
	boraEvent.nWidth = a_nWidth;
	boraEvent.nHeight = a_nHeight;
	boraEvent.nStartPage = a_StartPage;
	boraEvent.nEndPage = a_EndPage;
	boraEvent.nPrintOptions = a_RetrunType;	// PRINT_RETURN_TYPE
	//Andrew
	//���� �������̽��� �ٸ� �κ��� ������ �ڵ�� ui���� IntH�̻��� ������ ����ϰ� �Ǹ� ����
	if ( (a_RetrunType & 0xf) == 0x0 ) //PRINT_JPG_IMG
		boraEvent.nPrintOptions |= PRINT_JPG_IMG;	//0x01
	else if ( (a_RetrunType & 0xf) == 0x2 ) //PRINT_PNG_IMG
		boraEvent.nPrintOptions |= PRINT_PNG_IMG;	//0x03
	boraEvent.nPrintAreaMode = a_nPrintAreaMode;	// PRINT_XLS_MODE_AREA | PRINT_XLS_MODE_SCALE
	impNativeSetDividePrintImageHeight(a_DivideHeight);
	CopyJstring2Utf8(env, boraEvent.szOutputPath, a_szOutPath, BORA_FULLPATH_LENGTH);
	BrSetGUIEvent(&boraEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IChangeViewMode(JNIEnv *env, jobject obj, jint a_Mode, jint a_nWidth, jint a_nHeight, jint a_bCanSelection, jint a_bDraw)
{
	BrGuiSetModeChangeEvent sGuiEvent = {0};
	switch(a_Mode)
	{
	case BR_VIEW_MODE: 
		sGuiEvent.nType = BRGUI_VIEW_MODE_EVENT; 
		break;
	case BR_TEXT_MODE: 
		sGuiEvent.nType = BRGUI_TEXT_MODE_EVENT; 
		break;
	default:
		sGuiEvent.nType = BRGUI_EDIT_MODE_EVENT; 
		break;
	}
	sGuiEvent.nWidth = a_nWidth;
	sGuiEvent.nHeight = a_nHeight;
	sGuiEvent.bCanSelection = a_bCanSelection;
	sGuiEvent.bDraw = a_bDraw;

	BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT jobjectArray JNICALL Java_com_infraware_office_evengine_EvNative_IGetSheetNameList(JNIEnv* env, jobject obj)
{
	return IGetSheetNameList(env);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetPageText(JNIEnv *env, jobject obj, jint a_nPageNum)
{
	BrGuiGetPageTextEvent sGuiPageTextEvent;
	sGuiPageTextEvent.nType = BRGUI_GET_PAGETEXT_EVENT;
	sGuiPageTextEvent.nPageNum= a_nPageNum;
	BrSetGUIEvent(&sGuiPageTextEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ICancel(JNIEnv *env, jobject obj)
{
	int nRet;
	BrGuiBaseEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_BRCANCEL_EVENT;

	nRet = BrSetGUIEvent(&sGuiEvent, BEventProcess);
}


JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ITimer(JNIEnv *env, jobject obj)
{
	int nRet;
	BrGuiTimerEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_BRTIMER;
	sGuiEvent.nID = BR_DEFAULT_TIMER;

	nRet = BrSetGUIEvent(&sGuiEvent, BEventProcess);
}


JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetConfig(JNIEnv *env, jobject obj, jobject tempobj)
{
	jclass clazz = env->GetObjectClass(tempobj); 

	jfieldID nCurPage = env->GetFieldID(clazz, "nCurPage", "I"); 
	jfieldID nTotalPages = env->GetFieldID(clazz, "nTotalPages", "I"); 
	jfieldID bBGLoad = env->GetFieldID( clazz, "bBGLoad","I"); 
	jfieldID nZoomRatio = env->GetFieldID(clazz, "nZoomRatio", "I"); 
	//	jfieldID nZoomInfo = env->GetFieldID( clazz, "nZoomInfo", "I");  zoom info ����

	jfieldID scrollInfo = env->GetFieldID(clazz, "scrollInfo", "Lcom/infraware/office/evengine/EV$CONFIG_INFO$SCROLLINFO;");
	jobject scrollInfoObj = env->GetObjectField(tempobj, scrollInfo);
	jclass scrollInfo_clazz = env->GetObjectClass(scrollInfoObj);
	jfieldID possibleScrollLeft = env->GetFieldID(scrollInfo_clazz, "possibleScrollLeft", "Z"); 		
	jfieldID possibleScrollUp = env->GetFieldID(scrollInfo_clazz, "possibleScrollUp", "Z");
	jfieldID possibleScrollRight = env->GetFieldID(scrollInfo_clazz, "possibleScrollRight", "Z");		
	jfieldID possibleScrollDown = env->GetFieldID(scrollInfo_clazz, "possibleScrollDown", "Z");
	jfieldID possibleScrollPrevPage = env->GetFieldID(scrollInfo_clazz, "possibleScrollPrevPage", "Z");
	jfieldID possibleScrollNextPage = env->GetFieldID(scrollInfo_clazz, "possibleScrollNextPage", "Z");

	jfieldID nRotateAngle = env->GetFieldID(clazz, "nRotateAngle", "I"); 		
	//	jfieldID bUseMemo = env->GetFieldID(clazz, "bUseMemo", "I"); use memo ����
	jfieldID nMinZoom = env->GetFieldID(clazz, "nMinZoom", "I");		
	jfieldID nMaxZoom = env->GetFieldID(clazz, "nMaxZoom", "I");
	jfieldID nReflowState = env->GetFieldID(clazz, "nReflowState", "I");
	jfieldID nZoomLevel = env->GetFieldID(clazz, "nZoomLevel", "I");	
	jfieldID bContinuousMode = env->GetFieldID(clazz, "bContinuousMode", "I");
	jfieldID nFitToWidthZoomValue = env->GetFieldID(clazz, "nFitToWidthZoomValue", "I");
	jfieldID nFitToHeightZoomValue = env->GetFieldID(clazz, "nFitToHeightZoomValue", "I");
	jfieldID nDocExtType = env->GetFieldID(clazz, "nDocExtType", "I");			
	jfieldID nOnlyOnePage = env->GetFieldID(clazz, "nOnlyOnePage", "I");		

	BrConfigInfo a_Config = {0,};
	BrGetConfig(&a_Config);

	// set the new values of the member fields in the object 
	env->SetIntField(tempobj, nCurPage, a_Config.nCurPage); 
	env->SetIntField(tempobj, nTotalPages, a_Config.nTotalPages); 
	env->SetIntField(tempobj, bBGLoad, a_Config.bBGLoad); 
	env->SetIntField(tempobj, nZoomRatio, a_Config.nZoomRatio); 

	env->SetBooleanField(scrollInfoObj, possibleScrollLeft, a_Config.nScrollInfo&0x01);
	env->SetBooleanField(scrollInfoObj, possibleScrollUp, a_Config.nScrollInfo&0x02);
	env->SetBooleanField(scrollInfoObj, possibleScrollRight, a_Config.nScrollInfo&0x04);
	env->SetBooleanField(scrollInfoObj, possibleScrollDown, a_Config.nScrollInfo&0x08);
	env->SetBooleanField(scrollInfoObj, possibleScrollPrevPage, a_Config.nScrollInfo&0x10);
	env->SetBooleanField(scrollInfoObj, possibleScrollNextPage, a_Config.nScrollInfo&0x20);

	env->SetIntField(tempobj, nRotateAngle, a_Config.nRotateAngle); 
	env->SetIntField(tempobj, nMinZoom, a_Config.nMinZoom); 
	env->SetIntField(tempobj, nMaxZoom, a_Config.nMaxZoom); 
	env->SetIntField(tempobj, nReflowState, a_Config.nReflowState); 
	env->SetIntField(tempobj, nZoomLevel, a_Config.nZoomLevel); 
	env->SetIntField(tempobj, bContinuousMode, a_Config.bContinuousMode); 
	env->SetIntField(tempobj, nFitToWidthZoomValue, a_Config.nFitToWidthZoomValue); 
	env->SetIntField(tempobj, nFitToHeightZoomValue, a_Config.nFitToHeightZoomValue); 
	env->SetIntField(tempobj, nDocExtType, a_Config.nDocExtType); 
	env->SetIntField(tempobj, nOnlyOnePage, a_Config.nOnlyOnePage); 

	/* The local reference is no longer useful */
	env->DeleteLocalRef(scrollInfo_clazz);
	env->DeleteLocalRef(clazz);
}



JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetProperties(JNIEnv *env, jobject obj, jobject tempobj)
{
	jclass cls = env->GetObjectClass(tempobj); 

	jfieldID byPageEdgeWidth = env->GetFieldID(cls, "byPageEdgeWidth", "I");
	jfieldID byPageEdgePosition = env->GetFieldID(cls, "byPageEdgePosition", "I");
	jfieldID bPageOutline = env->GetFieldID(cls, "bPageOutline", "I");
	jfieldID dwBgColor = env->GetFieldID(cls, "dwBgColor", "I");  
	jfieldID dwEdgeColor = env->GetFieldID(cls, "dwEdgeColor", "I");	
	jfieldID dwOutlineColor = env->GetFieldID(cls, "dwOutlineColor", "I");	
	jfieldID dwPageMapColor = env->GetFieldID(cls, "dwPageMapColor", "I");
	jfieldID dwPageMapViewColor = env->GetFieldID(cls, "dwPageMapViewColor", "I");
	jfieldID nUseBookmark = env->GetFieldID(cls, "nUseBookmark", "I");	
	jfieldID nBookmarkType = env->GetFieldID(cls, "nBookmarkType", "I");
	jfieldID nScrollType = env->GetFieldID(cls, "nScrollType", "I");
	jfieldID bFrameBufferSwap = env->GetFieldID(cls, "nFrameBufferSwap", "I");
	jfieldID bMakeThumbnailImage = env->GetFieldID(cls, "bMakeThumbnailImage", "I");
	jfieldID nMakeThumbnailPages = env->GetFieldID(cls, "nMakeThumbnailPages", "I");
	//        jfieldID pMemoList = env->GetFieldID(cls, "pMemoList", "I");		����
	jfieldID bVariableScale = env->GetFieldID(cls, "bVariableScale", "I");
	jfieldID bFixedWidth = env->GetFieldID(cls, "bFixedWidth", "I");		
	jfieldID nThumbnailPercent = env->GetFieldID(cls, "nThumbnailPercent", "I");
	jfieldID nSearchMarkingMode = env->GetFieldID(cls, "nSearchMarkingMode", "I");		
	jfieldID bDrawDirtyBitmap = env->GetFieldID(cls, "bDrawDirtyBitmap", "I");	  

	jfieldID pagemapProperties = env->GetFieldID(cls, "pagemapProperties", "Lcom/infraware/office/evengine/EV$PROPERTIES$PAGEMAPPROPERTIES;");
	jobject pagemapPropertiesObj = env->GetObjectField(tempobj, pagemapProperties);
	jclass pagemapProperties_clazz = env->GetObjectClass(pagemapPropertiesObj);
	jfieldID bExternalPagemap = env->GetFieldID(pagemapProperties_clazz, "bExternalPagemap", "I"); 		
	jfieldID bBluringPagemap = env->GetFieldID(pagemapProperties_clazz, "bBluringPagemap", "I");
	jfieldID nPagemapWidth = env->GetFieldID(pagemapProperties_clazz, "nPagemapWidth", "I");		
	jfieldID nPagemapHeight = env->GetFieldID(pagemapProperties_clazz, "nPagemapHeight", "I");

	jfieldID bDualDisplay = env->GetFieldID(cls, "bDualDisplay", "I");		
	jfieldID nZoomPhase = env->GetFieldID(cls, "nZoomPhase", "I");
	jfieldID nGrayLevelForImage = env->GetFieldID(cls, "nGrayLevelForImage", "I");	
	jfieldID nDefLineSpace = env->GetFieldID(cls, "nDefLineSpace", "I");	
	jfieldID nDefAlignment = env->GetFieldID(cls, "nDefAlignment", "I");	
	jfieldID nDefCharSpace = env->GetFieldID(cls, "nDefCharSpace", "I");	
#if 0 // do not use
	jfieldID pEBookBackImg;
	jfieldID nEBookLeftMargin;
	jfieldID nEBookTopMargin;	
	jfieldID nEBookRightMargin;
	jfieldID nEBookBottomMargin;
#endif		
	jfieldID nMaxBookclipValue = env->GetFieldID(cls, "nMaxBookclipValue", "I");	
	jfieldID nPageMargin = env->GetFieldID(cls, "nPageMargin", "I");			
	jfieldID nSeperateModeAtComics = env->GetFieldID(cls, "nSeperateModeAtComics", "I");	
	jfieldID bUseOriginImageAtComics = env->GetFieldID(cls, "bUseOriginImageAtComics", "I");	
	jfieldID nDirectionAtComics = env->GetFieldID(cls, "nDirectionAtComics", "I");	
	jfieldID dwSearchMarkSelectColor = env->GetFieldID(cls, "dwSearchMarkSelectColor", "I");

	// do whatever
	BoraViewerProperties a_Info = {0,};
	BrGetViewerProperties(&a_Info);

	// set the new values of the member fields in the object 
	env->SetIntField(tempobj, byPageEdgeWidth, a_Info.byPageEdgeWidth); 
	env->SetIntField(tempobj, byPageEdgePosition, a_Info.byPageEdgePosition); 
	env->SetIntField(tempobj, bPageOutline, a_Info.bPageOutline);
	env->SetIntField(tempobj, dwBgColor, changeRGBColor(a_Info.dwBgColor));
	env->SetIntField(tempobj, dwEdgeColor, changeRGBColor(a_Info.dwEdgeColor));
	env->SetIntField(tempobj, dwOutlineColor, changeRGBColor(a_Info.dwOutlineColor));
	env->SetIntField(tempobj, dwPageMapColor, changeRGBColor(a_Info.dwPageMapColor));
	env->SetIntField(tempobj, dwPageMapViewColor, changeRGBColor(a_Info.dwPageMapViewColor));
	env->SetIntField(tempobj, nUseBookmark, a_Info.nUseBookmark);
	env->SetIntField(tempobj, nBookmarkType, a_Info.nBookmarkType);
	env->SetIntField(tempobj, nScrollType, a_Info.nScrollType);		
	env->SetIntField(tempobj, bFrameBufferSwap, a_Info.bFrameBufferSwap);
	env->SetIntField(tempobj, bMakeThumbnailImage, a_Info.bMakeThumbnailImage);
	env->SetIntField(tempobj, nMakeThumbnailPages, a_Info.nMakeThumbnailPages);
	env->SetIntField(tempobj, bVariableScale, a_Info.bVariableScale);
	env->SetIntField(tempobj, bFixedWidth, a_Info.bFixedWidth);
	env->SetIntField(tempobj, nThumbnailPercent, a_Info.nThumbnailPercent); 
	env->SetIntField(tempobj, nSearchMarkingMode, a_Info.nSearchMarkingMode); 
	env->SetIntField(tempobj, bDrawDirtyBitmap, a_Info.bDrawDirtyBitmap);

	env->SetIntField(pagemapPropertiesObj, bExternalPagemap, a_Info.pPagemapProperties.bExternalPagemap);
	env->SetIntField(pagemapPropertiesObj, bBluringPagemap, a_Info.pPagemapProperties.bBluringPagemap);
	env->SetIntField(pagemapPropertiesObj, nPagemapWidth, a_Info.pPagemapProperties.nPagemapWidth);
	env->SetIntField(pagemapPropertiesObj, nPagemapHeight,a_Info.pPagemapProperties.nPagemapHeight);

	env->SetIntField(tempobj, bDualDisplay, a_Info.bDualDisplay);
	env->SetIntField(tempobj, nZoomPhase, a_Info.nZoomPhase);		
	env->SetIntField(tempobj, nGrayLevelForImage, a_Info.nGrayLevelForImage);
	env->SetIntField(tempobj, nDefLineSpace, a_Info.nDefLineSpace);
	env->SetIntField(tempobj, nDefAlignment, a_Info.nDefAlignment);
	env->SetIntField(tempobj, nDefCharSpace, a_Info.nDefCharSpace);
#if 0	// do not use
	env->SetIntField(tempobj, pEBookBackImg, a_Info.pEBookBackImg);
	env->SetIntField(tempobj, nEBookLeftMargin, a_Info.nEBookLeftMargin);		
	env->SetIntField(tempobj, nEBookTopMargin, a_Info.nEBookTopMargin);
	env->SetIntField(tempobj, nEBookRightMargin, a_Info.nEBookRightMargin);
	env->SetIntField(tempobj, nEBookBottomMargin, a_Info.nEBookBottomMargin);	
#endif	
	env->SetIntField(tempobj, nMaxBookclipValue, a_Info.nMaxBookclipValue);
	env->SetIntField(tempobj, nPageMargin, a_Info.nPageMargin);		
	env->SetIntField(tempobj, nSeperateModeAtComics, a_Info.nSeperateModeAtComics);
	env->SetIntField(tempobj, bUseOriginImageAtComics, a_Info.bUseOriginImageAtComics);
	env->SetIntField(tempobj, nDirectionAtComics, a_Info.nDirectionAtComics);	
	env->SetIntField(tempobj, dwSearchMarkSelectColor, changeRGBColor(a_Info.dwSearchMarkSelectColor));


	/* The local reference is no longer useful */
	env->DeleteLocalRef(pagemapProperties_clazz);
	env->DeleteLocalRef(cls);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetProperties(JNIEnv *env, jobject obj, jobject tempobj)
{
	jclass cls = env->GetObjectClass(tempobj); 

	jfieldID byPageEdgeWidth = env->GetFieldID(cls, "byPageEdgeWidth", "I");
	jfieldID byPageEdgePosition = env->GetFieldID(cls, "byPageEdgePosition", "I");
	jfieldID bPageOutline = env->GetFieldID(cls, "bPageOutline", "I");
	jfieldID dwBgColor = env->GetFieldID(cls, "dwBgColor", "I");  
	jfieldID dwEdgeColor = env->GetFieldID(cls, "dwEdgeColor", "I");	
	jfieldID dwOutlineColor = env->GetFieldID(cls, "dwOutlineColor", "I");	
	jfieldID dwPageMapColor = env->GetFieldID(cls, "dwPageMapColor", "I");
	jfieldID dwPageMapViewColor = env->GetFieldID(cls, "dwPageMapViewColor", "I");
	jfieldID nUseBookmark = env->GetFieldID(cls, "nUseBookmark", "I");	
	jfieldID nBookmarkType = env->GetFieldID(cls, "nBookmarkType", "I");
	jfieldID nScrollType = env->GetFieldID(cls, "nScrollType", "I");
	jfieldID bFrameBufferSwap = env->GetFieldID(cls, "nFrameBufferSwap", "I");
	jfieldID bMakeThumbnailImage = env->GetFieldID(cls, "bMakeThumbnailImage", "I");
	jfieldID nMakeThumbnailPages = env->GetFieldID(cls, "nMakeThumbnailPages", "I");
	//        jfieldID pMemoList = env->GetFieldID(cls, "pMemoList", "I");		����
	jfieldID bVariableScale = env->GetFieldID(cls, "bVariableScale", "I");
	jfieldID bFixedWidth = env->GetFieldID(cls, "bFixedWidth", "I");		
	jfieldID nThumbnailPercent = env->GetFieldID(cls, "nThumbnailPercent", "I");
	jfieldID nSearchMarkingMode = env->GetFieldID(cls, "nSearchMarkingMode", "I");		
	jfieldID bDrawDirtyBitmap = env->GetFieldID(cls, "bDrawDirtyBitmap", "I");	  

	jfieldID pagemapProperties = env->GetFieldID(cls, "pagemapProperties", "Lcom/infraware/office/evengine/EV$PROPERTIES$PAGEMAPPROPERTIES;");
	jobject pagemapPropertiesObj = env->GetObjectField(tempobj, pagemapProperties);
	jclass pagemapProperties_clazz = env->GetObjectClass(pagemapPropertiesObj);
	jfieldID bExternalPagemap = env->GetFieldID(pagemapProperties_clazz, "bExternalPagemap", "I"); 		
	jfieldID bBluringPagemap = env->GetFieldID(pagemapProperties_clazz, "bBluringPagemap", "I");
	jfieldID nPagemapWidth = env->GetFieldID(pagemapProperties_clazz, "nPagemapWidth", "I");		
	jfieldID nPagemapHeight = env->GetFieldID(pagemapProperties_clazz, "nPagemapHeight", "I");

	jfieldID bDualDisplay = env->GetFieldID(cls, "bDualDisplay", "I");		
	jfieldID nZoomPhase = env->GetFieldID(cls, "nZoomPhase", "I");
	jfieldID nGrayLevelForImage = env->GetFieldID(cls, "nGrayLevelForImage", "I");	
	jfieldID nDefLineSpace = env->GetFieldID(cls, "nDefLineSpace", "I");	
	jfieldID nDefAlignment = env->GetFieldID(cls, "nDefAlignment", "I");	
	jfieldID nDefCharSpace = env->GetFieldID(cls, "nDefCharSpace", "I");	
#if 0 // do not use
	jfieldID pEBookBackImg;
	jfieldID nEBookLeftMargin;
	jfieldID nEBookTopMargin;	
	jfieldID nEBookRightMargin;
	jfieldID nEBookBottomMargin;
#endif	
	jfieldID nMaxBookclipValue = env->GetFieldID(cls, "nMaxBookclipValue", "I");	
	jfieldID nPageMargin = env->GetFieldID(cls, "nPageMargin", "I");			
	jfieldID nSeperateModeAtComics = env->GetFieldID(cls, "nSeperateModeAtComics", "I");	
	jfieldID bUseOriginImageAtComics = env->GetFieldID(cls, "bUseOriginImageAtComics", "I");	
	jfieldID nDirectionAtComics = env->GetFieldID(cls, "nDirectionAtComics", "I");	
	jfieldID dwSearchMarkSelectColor = env->GetFieldID(cls, "dwSearchMarkSelectColor", "I");	

	BoraViewerProperties a_Info = {0,};

	a_Info.byPageEdgeWidth = env->GetIntField(tempobj, byPageEdgeWidth);
	a_Info.byPageEdgePosition = env->GetIntField(tempobj, byPageEdgePosition);
	a_Info.bPageOutline = env->GetIntField(tempobj, bPageOutline);
	a_Info.dwBgColor = changeBGRColor(env->GetIntField(tempobj, dwBgColor));
	a_Info.dwEdgeColor = changeBGRColor(env->GetIntField(tempobj, dwEdgeColor));
	a_Info.dwOutlineColor = changeBGRColor(env->GetIntField(tempobj,dwOutlineColor));
	a_Info.dwPageMapColor = changeBGRColor(env->GetIntField(tempobj, dwPageMapColor));		
	a_Info.dwPageMapViewColor = changeBGRColor(env->GetIntField(tempobj, dwPageMapViewColor));
	a_Info.nUseBookmark = env->GetIntField(tempobj, nUseBookmark);
	a_Info.nBookmarkType = env->GetIntField(tempobj, nBookmarkType);
	a_Info.nScrollType = env->GetIntField(tempobj, nScrollType);
	a_Info.bFrameBufferSwap = env->GetIntField(tempobj, bFrameBufferSwap);
	a_Info.bMakeThumbnailImage = env->GetIntField(tempobj, bMakeThumbnailImage);		
	a_Info.nMakeThumbnailPages = env->GetIntField(tempobj, nMakeThumbnailPages);	
	//	a_Info.pMemoList = env->GetIntField(tempobj, pMemoList);		
	a_Info.bVariableScale = env->GetIntField(tempobj, bVariableScale);
	a_Info.bFixedWidth = env->GetIntField(tempobj, bFixedWidth);
	a_Info.nThumbnailPercent = env->GetIntField(tempobj, nThumbnailPercent);
	a_Info.nSearchMarkingMode = env->GetIntField(tempobj, nSearchMarkingMode);
	a_Info.bDrawDirtyBitmap = env->GetIntField(tempobj, bDrawDirtyBitmap);

	a_Info.pPagemapProperties.bExternalPagemap = env->GetIntField(pagemapPropertiesObj, bExternalPagemap);
	a_Info.pPagemapProperties.bBluringPagemap = env->GetIntField(pagemapPropertiesObj, bBluringPagemap);
	a_Info.pPagemapProperties.nPagemapWidth = env->GetIntField(pagemapPropertiesObj, nPagemapWidth);
	a_Info.pPagemapProperties.nPagemapHeight = env->GetIntField(pagemapPropertiesObj, nPagemapHeight);		

	a_Info.bDualDisplay = env->GetIntField(tempobj, bDualDisplay);
	a_Info.nZoomPhase = env->GetIntField(tempobj, nZoomPhase);
	a_Info.nGrayLevelForImage = env->GetIntField(tempobj, nGrayLevelForImage);
	a_Info.nDefLineSpace = env->GetIntField(tempobj, nDefLineSpace);
	a_Info.nDefAlignment = env->GetIntField(tempobj, nDefAlignment);
	a_Info.nDefCharSpace = env->GetIntField(tempobj, nDefCharSpace);
#if 0 // do not use
	a_Info.pEBookBackImg = env->GetIntField(tempobj, pEBookBackImg);
	a_Info.nEBookLeftMargin = env->GetIntField(tempobj, nEBookLeftMargin);
	a_Info.nEBookTopMargin = env->GetIntField(tempobj, nEBookTopMargin);
	a_Info.nEBookRightMargin = env->GetIntField(tempobj, nEBookRightMargin);
	a_Info.nEBookBottomMargin = env->GetIntField(tempobj, nEBookBottomMargin);
#endif		
	a_Info.nMaxBookclipValue = env->GetIntField(tempobj, nMaxBookclipValue);
	a_Info.nPageMargin = env->GetIntField(tempobj, nPageMargin);
	a_Info.nSeperateModeAtComics = env->GetIntField(tempobj, nSeperateModeAtComics);
	a_Info.bUseOriginImageAtComics = env->GetIntField(tempobj, bUseOriginImageAtComics);
	a_Info.nDirectionAtComics = env->GetIntField(tempobj, nDirectionAtComics);
	a_Info.dwSearchMarkSelectColor = changeBGRColor(env->GetIntField(tempobj, dwSearchMarkSelectColor));

	//ui_debug("BrSetViewerProperties byPageEdgeWidth = %d\n", a_Info.byPageEdgeWidth);
	//ui_debug("BrSetViewerProperties dwBgColor = 0x%x\n", a_Info.dwBgColor);
	//ui_debug("BrSetViewerProperties dwEdgeColor = 0x%x\n", a_Info.dwEdgeColor);
	//ui_debug("BrSetViewerProperties dwOutlineColor = 0x%x\n", a_Info.dwOutlineColor);	
	//ui_debug("BrSetViewerProperties bMakeThumbnailImage = 0x%x\n", a_Info.bMakeThumbnailImage);
	//ui_debug("BrSetViewerProperties nMakeThumbnailPages = 0x%x\n", a_Info.nMakeThumbnailPages);		

	BrSetViewerProperties(&a_Info);

	/* The local reference is no longer useful */
	env->DeleteLocalRef(pagemapProperties_clazz);
	env->DeleteLocalRef(cls);
}

JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IGetEditorMode_Editor(JNIEnv *env, jobject obj)
{
	return BrGetEditorMode_Editor();
}


JNIEXPORT jstring JNICALL Java_com_infraware_office_evengine_EvNative_IGetVersion(JNIEnv *env, jobject obj)
{
	jstring jsVersion = env->NewStringUTF(JNI_ENGINE_VERSION);
	return jsVersion;
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IPenShowHide(JNIEnv *env, jobject obj, jint show)
{
	BrGuiInfraPenShowEvent	BoraPenEvent = {0,};
	BoraPenEvent.nType = BRGUI_INFRAPENSHOW_EVENT;	
	BoraPenEvent.bShow = show;		
	BrSetGUIEvent( &BoraPenEvent, &BEventProcess );
}

JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IGetTransitionEffectInfo(JNIEnv *env, jobject obj, jint a_nPage, jobject tempobj)
{
	BrGuiTrancsitionEffect effect = {0,};
	int ret = BrGetTransitionEffectInfo(a_nPage, &effect);
	if(0 == ret)
	{
		jclass cls = env->GetObjectClass(tempobj); 
		jfieldID nType = env->GetFieldID(cls, "nType", "I");
		jfieldID nDuration = env->GetFieldID(cls, "nDuration", "I");
		jfieldID bMouseClick = env->GetFieldID(cls, "bMouseClick", "I");
		jfieldID nAfterTime = env->GetFieldID(cls, "nAfterTime", "I");
		jfieldID bAfterTime = env->GetFieldID(cls, "bAfterTime", "I");
	
		env->SetIntField(tempobj, nType, effect.nType); 
		env->SetIntField(tempobj, nDuration, effect.nDuration); 
		if(true == effect.bMouseClick)
			env->SetIntField(tempobj, bMouseClick, 1); 
		else
			env->SetIntField(tempobj, bMouseClick, 0); 
		env->SetIntField(tempobj, nAfterTime, effect.nAfterTime); 

		if(true == effect.bAfterTime)
			env->SetIntField(tempobj, bAfterTime, 1); 
		else
			env->SetIntField(tempobj, bAfterTime, 0); 
		
		/* The local reference is no longer useful */
		env->DeleteLocalRef(cls);
	}

	return ret;
}

JNIEXPORT jstring JNICALL Java_com_infraware_office_evengine_EvNative_IGetSlideNoteString(JNIEnv *env, jobject obj, jint a_nPageNum)
{
	int nLen = BrGetSlideNoteString(a_nPageNum , NULL , 0 );

	if (nLen < 1)
		return NULL;

	jchar* a_pszSlideNote = new jchar[nLen+1];
	memset( a_pszSlideNote, 0, (nLen+1)*sizeof(jchar) );

	if (a_pszSlideNote == NULL)
		return NULL;

	BrGetSlideNoteString( a_nPageNum, a_pszSlideNote , nLen+1 );

	jstring wideString = env->NewString((jchar*)a_pszSlideNote, nLen );

	if(a_pszSlideNote != NULL)
		delete[] a_pszSlideNote;

	return wideString;
}

JNIEXPORT jboolean JNICALL Java_com_infraware_office_evengine_EvNative_IGetInfraDrawData(JNIEnv *env, jobject obj)
{
	return BrExistInfraPenDrawData();
}

#ifndef SCROLL_BY_TO_POS
	#define SCROLL_BY_TO_POS 3 // common.h
#endif

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IScrollByToPos(JNIEnv *env, jobject obj, jint x, jint y)
{
#if 0
	B_Scroll(SCROLL_BY_TO_POS, 0, 0, x, y, NULL);
#endif
}

JNIEXPORT jboolean JNICALL Java_com_infraware_office_evengine_EvNative_ISetLogFilePath(JNIEnv *env, jobject obj, jstring a_sLogPath)
{
#ifdef UI_DEBUG
	char szLogPath[LOG_FILENAME_MAX] = {0};
	CopyJstring2Utf8(env, szLogPath, a_sLogPath, LOG_FILENAME_MAX);
	ui_debug_setLogFileName(szLogPath);
	return true;
#endif
	return false;
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetNumOfAvailableCores(JNIEnv *env, jobject obj, jint core)
{
	impNativeSetExternNumOfAvailableCores(core);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetXlsPageMaxRow(JNIEnv *env, jobject obj, jint max)
{
	impNativeSetXlsPageToBitmapMaxRow(max);
}


JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetAutoFilterImage(JNIEnv *env, jobject obj, jstring releasePath, jstring pressPath, jint rightMargin, jint bottomMargin)
{
	char normalPath[BORA_FULLPATH_LENGTH] = {0,};
	CopyJstring2Utf8 ( env, normalPath, releasePath, BORA_FULLPATH_LENGTH );

	char preseedPath[BORA_FULLPATH_LENGTH] = {0,};
	CopyJstring2Utf8 ( env, preseedPath, pressPath, BORA_FULLPATH_LENGTH);	

	bool bPaintImageButtonFromEngine = true;
	bool bPaintDefaultButtonFromEngine = false;
	bool bPaintListControlFromEngine = true;
	bool bPaintButtonFromUI = false;
	bool bDynamicResizable = false;
	int nMarginRight = rightMargin;
	int nMarginBottom = bottomMargin;
	char** pImagePathArray = NULL;
	int nImagePathCount=0;										
	BrSetAutofilterButtonConfiguration(normalPath, 
										preseedPath, 
										bPaintImageButtonFromEngine,
										bPaintDefaultButtonFromEngine,
										bPaintListControlFromEngine,
										bPaintButtonFromUI,
										bDynamicResizable,
										nMarginRight, 
										nMarginBottom,
										pImagePathArray, 
										nImagePathCount);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetOutputImagePDFWithAnnotaion(JNIEnv *env, jobject obj, jint bWith)
{
	impNativeSetPDFWithAnnotation(bWith);
}

JNIEXPORT jboolean JNICALL Java_com_infraware_office_evengine_EvNative_IGetOutputImagePDFWithAnnotaion(JNIEnv *env, jobject obj)
{
#ifdef SUPPORT_PDF_OUTPUT_IMAGE_WITH_ANNOTATION
	if(0 == BGetPDFOutputWithAnnotation())
		return false;
	return true;
#else
	return false;
#endif
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IGetPDFAnnotationCount(JNIEnv *env, jobject obj)
{
	//BrGUiAnnotationOnOff sEvent = {0};
	//sEvent.nType = BRGUI_ANNOTATION_ONOFF_EVENT;
	//sEvent.bOn = true;
	//BrSetGUIEvent(&sEvent, &BEventProcess);

	BrGuiAnnotationCount sAnnotEvent = {0,};
	sAnnotEvent.nType = BRGUI_ANNOTATION_COUNT_EVENT;
	BrSetGUIEvent(&sAnnotEvent, BEventProcess);
}

JNIEXPORT jboolean JNICALL Java_com_infraware_office_evengine_EvNative_IGetSheetProtected(JNIEnv *env, jobject obj, jint index)
{
	BoraSheetInfo info={0,};
	BrGetSheetInfo(&info, index);	

	return (info.bProtectSheet == 0) ? false : true;
}

JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IGetSheetTotalPages(JNIEnv *env, jobject obj,jint a_PaperSize, jint a_nWidth, jint a_nHeight, jint a_StartPage, jint a_EndPage, jstring a_szOutPath, jint a_RetrunType)
{
	//BrGuiPrintEvent boraEvent = {0,};
	//boraEvent.nType = BRGUI_BRPRINT_EVENT;
	//boraEvent.nPaperSize = a_PaperSize;
	//boraEvent.nWidth = a_nWidth;
	//boraEvent.nHeight = a_nHeight;
	//boraEvent.nStartPage = a_StartPage;
	//boraEvent.nEndPage = a_EndPage;
	//boraEvent.nPrintOptions = a_RetrunType;	// PRINT_RETURN_TYPE
	//CopyJstring2Utf8(env, boraEvent.szOutputPath, a_szOutPath, BORA_FULLPATH_LENGTH);
	//unsigned int nSheetTotalPages = BrGetSheetPrintTotalPages(&boraEvent);
	//return (jint)nSheetTotalPages;
	return 0;
}

JNIEXPORT jint JNICALL Java_com_infraware_office_evengine_EvNative_IGetSheetPageWidth(JNIEnv *env, jobject obj)
{
	int nHeight = 0;
	int nWidth = 0;
#ifdef USE_POLARIS_LINK
	if(true == BGetCurrentSheetPageSize(&nWidth,  &nHeight))
		return nWidth;
#endif
	return 0;
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetPage(JNIEnv *env, jobject obj, jint nPage)
{
	BrGuiSetPageEvent boraEvent = {0};
	boraEvent.nType = BRGUI_BRSETPAGE_EVENT;
	boraEvent.nPage = nPage;

	BrConfigInfo pConfig;
	BrGetConfig(&pConfig);
	
	if (nPage > pConfig.nTotalPages)
		return;

	BrSetGUIEvent(&boraEvent, BEventProcess);	
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IConvertingDocuments
	(JNIEnv *env, jobject object, jstring strSource, jstring strDestination, jstring strTempFolder, jint a_nLocale, jstring a_sPassword)
{
           gCBbitmap = 0;
           impNativeSetLocale((BR_LOCALE_TYPE)a_nLocale);      
           impNativeSetTempPath(env, strTempFolder);

     BrGuiConvertEvent sGuiEvent = {BRGUI_BWP_CONVERT_EVENT, };
	 sGuiEvent.bPDFAExport = 1; 

	 if(NULL != a_sPassword) {
		printf("password set");
		CopyJstring2Utf8(env, sGuiEvent.szOpenPassword, a_sPassword, BORA_FULLPATH_LENGTH);	
	 }
     CopyJstring2Utf8(env, sGuiEvent.szSourceFilePath, strSource, BORA_FULLPATH_LENGTH);
     CopyJstring2Utf8(env, sGuiEvent.szDestFilePath, strDestination, BORA_FULLPATH_LENGTH);

     BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISavePDF(JNIEnv *env, jobject obj, jbyteArray javaBytes)
{
	size_t len = env->GetArrayLength(javaBytes); 
	jbyte *nativeBytes = env->GetByteArrayElements(javaBytes, 0); 
	char *nativeStr = (char*)malloc(len+1); 
	strncpy( nativeStr, (char*)nativeBytes, len ); 
	nativeStr[len] = '\0'; 
	env->ReleaseByteArrayElements(javaBytes, nativeBytes, JNI_ABORT); 

	BrGuiSaveEvent sGuiEvent = {0,};
	sGuiEvent.nType = BRGUI_SAVE_EVENT;
	strcpy(sGuiEvent.szFilePath, nativeStr);

	free(nativeStr);
	nativeStr = NULL;

	//sGuiEvent.bBackUp = true;
	//sGuiEvent.bNeedDraw = false;

	BrSetExportPdfResolution_Editor(300);
	sGuiEvent.fExportPDFImageScale = 1000.0;
	int ret = BrSetGUIEvent(&sGuiEvent, BEventProcess);
}

JNIEXPORT jboolean JNICALL Java_com_infraware_office_evengine_EvNative_StartPDFExport(JNIEnv *env, jobject obj, jstring path, jint expectedTotalPage)
{
	char szFilePath[BORA_FULLPATH_LENGTH];
	CopyJstring2Utf8(env, szFilePath, path, BORA_FULLPATH_LENGTH);
	return BrOpenExportPdf((char*)szFilePath, expectedTotalPage, true);	
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_EndPDFExport(JNIEnv *env, jobject obj)
{
	BrCloseExportPdf(true);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISheetShowGrid(JNIEnv* env, jobject obj, jboolean bShow)
{
	BrGuiSheetHeaderGridEvent boraEvent = { 0, };
	boraEvent.nType = BRGUI_SHEET_SHOW_GRID_EVENT;
	boraEvent.bShow = bShow;
	BrSetGUIEvent(&boraEvent, &BEventProcess);
}

// Validation Filter ���� �ű� interface
JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_setDocumentValidationMode(JNIEnv* env, jobject obj, jboolean mode)
{
	POSetDocumentValidationMode(mode);
}

JNIEXPORT jintArray JNICALL Java_com_infraware_office_evengine_EvNative_getErrorList(JNIEnv* env, jobject obj)
{
	BoraErrorResult er = { 0, };
	POExportErrorList(er);
//	printf("Java_com_infraware_office_evengine_EvNative_getErrorList nErrorObejctListCount[%d]\n", er.nErrorObejctListCount);
	if (er.nErrorObejctListCount > 0) {
		const int count = er.nErrorObejctListCount;
		jintArray retArray = env->NewIntArray(count);
		jint* errors = new jint[count];
		for (int i = 0; i < count; i++) {
//			printf("er.pErrorObejctList[%d]->m_nPoErrorValue:%d\n", i, er.pErrorObejctList[i]->m_nPoErrorValue);
			errors[i] = er.pErrorObejctList[i]->m_nPoErrorValue;
			free(er.pErrorObejctList[i]);
		}
		env->SetIntArrayRegion(retArray, 0, count, errors);
		delete[] errors;
		return retArray;
	}
	else {
//		printf("Java_com_infraware_office_evengine_EvNative_getErrorList count 0 !!");
	}
	return NULL;
}

char** convertPoStringArray(PoStringArray* org)
{
	int count = org->poStringArraySize;
	//char** buffer = (char**)malloc(count * sizeof(char*));
	char** buffer = new char* [count];
	for (int i = 0; i < count; i++) {
		//			printf("font[%d]:%s\n", i, fr.poStringArray[i]->poString);
		buffer[i] = new char[org->poStringArray[i]->poStringSize + 1];
		strcpy(buffer[i], org->poStringArray[i]->poString);
	}
	return buffer;
}

void freePoStringArrayAndBuffer(PoStringArray* org, char** buffer) {
	int count = org->poStringArraySize;
	for (int i = 0; i < count; i++) {
		free(org->poStringArray[i]->poString);
		delete[] buffer[i];
	}
	free(org->poStringArray);
	delete[] buffer;
}

jobjectArray toStringArray(JNIEnv* env, PoStringArray* org)
{
	int count = org->poStringArraySize;
	//	printf("toStringArray poStringArraySize[%d]\n", count);
	if (count > 0) {
		char** buffer = convertPoStringArray(org);
		jobjectArray ret = MakeStringArray(env, buffer, count);
		freePoStringArrayAndBuffer(org, buffer);
		return ret;
	}
	else {
		//		printf("toStringArray count 0 !!");
	}
	return NULL;
}

JNIEXPORT jobjectArray JNICALL Java_com_infraware_office_evengine_EvNative_getFontList(JNIEnv* env, jobject obj)
{
	PoStringArray fr = { 0, };
	POExportDocumentUsedFontArray(&fr);
	return toStringArray(env, &fr);
}

JNIEXPORT jobjectArray JNICALL Java_com_infraware_office_evengine_EvNative_getLinkedImageUrlList(JNIEnv* env, jobject obj)
{
	PoStringArray fr = { 0, };
	POExportLinkedImageURLArray(&fr);
	return toStringArray(env, &fr);
}

JNIEXPORT jobjectArray JNICALL Java_com_infraware_office_evengine_EvNative_getCorruptedImageList(JNIEnv* env, jobject obj)
{
	PoStringArray fr = { 0, };
	POExportCorruptedImageArray(&fr);
	return toStringArray(env, &fr);
}

JNIEXPORT jobjectArray JNICALL Java_com_infraware_office_evengine_EvNative_getOleList(JNIEnv* env, jobject obj)
{
	PoStringArray fr = { 0, };
	POExportOleNameArray(&fr);
	return toStringArray(env, &fr);
}

JNIEXPORT jboolean JNICALL Java_com_infraware_office_evengine_EvNative_ISetInterfaceHandle(JNIEnv *env, jobject obj, jlong address)
{
	if(BrSetInterfaceHandle((void*)address, BEventProcess) != 0 )
		return true;
	return false;
}

JNIEXPORT jlong JNICALL Java_com_infraware_office_evengine_EvNative_IInitInterfaceHandle(JNIEnv *env, jobject obj)
{
	return (jlong)BrCreateBMVHandle();
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_IDeleteInterfaceHandle(JNIEnv *env, jobject obj,  jlong address)
{
	BrDeleteBMVHandle((void*)address, NULL);
}

JNIEXPORT void JNICALL Java_com_infraware_office_evengine_EvNative_ISetTempPath(JNIEnv *env, jobject obj, jstring a_sTempPath)
{
	impNativeSetTempPath(env, a_sTempPath);
}

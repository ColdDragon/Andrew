#include <stdlib.h> 
#include <string.h> 
#include "nativeStringUtil.h" 
#include "debugJni.h"

// For effcient
jclass getStringClass(JNIEnv *env){
	static jclass string_clazz = NULL; 
	
	if(string_clazz == NULL){
		jclass string_clazz_local = env->FindClass("java/lang/String");

		/* Create a global reference */
		if(string_clazz_local){
 	        	string_clazz = (jclass)env->NewGlobalRef(string_clazz_local);

			/* The local reference is no longer useful */
	     		env->DeleteLocalRef(string_clazz_local);
		}
	}

	return string_clazz;
}

int toLower(int character){
	if ((character >= 'A') && (character <= 'Z'))
		return character + 'a' - 'A';

	return character;
}

int u16len(const unsigned short* string)
{
	if (!string || !string[0])
		return 0;

	const unsigned short* p = string;
	while( *p++ );

	return p - string -1;
}

#include "bmvdefine.h";
jbyteArray getEncodedString(jstring);
int CopyJByteArray2CharArray(JNIEnv* env, char* dest, jbyteArray src, jint maxlen)
{
	if(dest && src && maxlen)
	{
		jint nLen = env->GetArrayLength(src);
		if (nLen)
		{
			jboolean copy;
			jbyte* str = env->GetByteArrayElements(src, &copy);
			
			if (nLen > maxlen-1)
				nLen = maxlen-1;

			memcpy(dest, str, nLen);

			dest[nLen] = '\0';

			env->ReleaseByteArrayElements(src, str, 0);
			env->DeleteLocalRef(src);
			return nLen;
		}
	}
	return 0;
}

int CopyJstring2Utf8(JNIEnv* env, char* dest, jstring src, jint maxlen)
{
	if(dest && src && maxlen)
	{
#if 0//ndef LINUX_LIB
#ifdef SUPPORT_HANGUL_PATH
		return CopyJByteArray2CharArray(env, dest, getEncodedString(src), maxlen);
#endif
#endif
		jint nLen = env->GetStringUTFLength(src);
		if (nLen)
		{
			const char* str = env->GetStringUTFChars(src, NULL);
			
			if (nLen > maxlen-1)
				nLen = maxlen-1;

			strncpy(dest, str, nLen);

			dest[nLen] = '\0';

			// ui_debug("%s(%d) %s dest[%s]", __FILE__, __LINE__, __FUNCTION__, dest);

			env->ReleaseStringUTFChars(src, str);

			return nLen;
		}
	}
	
	return 0;
}

jobjectArray MakeStringArray(JNIEnv* env, char** nameList, jint count)
{
	jstring str = NULL;
	jobjectArray strArray = env->NewObjectArray(count, getStringClass(env), NULL);
	for(int i=0; i<count; i++)
	{
		str = env->NewStringUTF(nameList[i]);
		env->SetObjectArrayElement(strArray,i,str);
		env->DeleteLocalRef(str);
	}

	return strArray;
}




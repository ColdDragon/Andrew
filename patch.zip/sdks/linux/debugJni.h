#ifndef _Included_com_infraware_evengine_debugjni
#define _Included_com_infraware_evengine_debugjni

#include "jniHeader.h"

#define LOG_FILENAME_MAX	512
#define LOG_CONTENTS_LENGTH	1024*5

//#define UI_DEBUG

void ui_debug(const char* s ,...);
void ui_debug_setLogFileName(char* s);

#ifdef BASED_WINDOWS_SYSTEM
#define JNI_DEBUG_TRACE_FILE "D:\\office_dll_debug.txt"
#else
#define JNI_DEBUG_TRACE_FILE "./office_dll_debug.txt"
#endif

#endif // !_Included_com_infraware_evengine_debugjni


#include <OfficePreCompBWP.hpp>

#ifdef BWP_EDITOR

#include "cmnFunc.h"
#include "Conv2Filter.h"

#include "bwFontArray.h"
#include "bwAppConfig.h"
#include "bwTextProc.h"
#include "bwLine.h"
#include "bmvstruct.h"

#include "b2bmv/BMVExport.h"
#include "bmvinterface.h"
#include "bmvinterface_tool.h"
#ifdef BWP_EDITOR
#include "brglsupport.h"
#endif
#if defined(FOR_BMV)
#include "../b2bmv/BMVExport.h"
#endif //defined(FOR_BMV)
#include "HtmlStatic.h"
#include "ci_validator_interface.h"
#include "bwPage.h"
#include "ThreadDefines_i.h"
#include "Frame/text/FrameTextLayout.h"


//#define _TIME_CHECK
//#define _PART_TIME_CHECK
//#define _FULL_TIME_CHECK
#ifdef _TIME_CHECK
void toDefTimeMessageBox(CTime cSTime, CString strMsg)
{
	CTime cETime;
	CString strTime;
	BrLONG sS, eS, imS;

	cETime = CTime::GetCurrentTime();

	sS = cSTime.GetMinute()*60 + cSTime.GetSecond();
	eS = cETime.GetMinute()*60 + cETime.GetSecond();
	imS = eS - sS;

	strTime.Format(_T("%s : %ld sec \n SM: %ld SS: %ld, EM: %ld, ES: %ld"), strMsg, imS,
		cSTime.GetMinute(), cSTime.GetSecond(),
		cETime.GetMinute(), cETime.GetSecond());
	MessageBox(BrNULL,strTime, _T("Time Check") , MB_OK);
}

#endif //_TIME_CHECK

CConv2XFilter::CConv2XFilter()
{
	m_strOrgFile = "";
	m_strConvFile = "";

	m_bRead		   = BrFALSE;
	m_pSysFontInfo = BrNULL;
	m_pAppStatic    = BrNULL;
	m_pConfig	   = BrNULL;
	m_pDoc		   = BrNULL;

//#if defined(FOR_BMV)
	m_pBMVExport   = BrNULL;
//#endif	// defined(FOR_BMV)
}

CConv2XFilter::~CConv2XFilter()
{
	if(m_pSysFontInfo)
	{		

		BrDELETE m_pSysFontInfo;
		g_pSysFontInfo = BrNULL;
		m_pSysFontInfo = BrNULL;
	}

	if(m_pAppStatic)
	{
		BrDELETE m_pAppStatic;
		g_pAppStatic = BrNULL;
	}

	if( g_pHtml )
	{
		BrDELETE g_pHtml;
		g_pHtml = BrNULL;
	}

	if(m_pConfig)
	{		
		BrDELETE m_pConfig;
		g_pAppConfig = BrNULL; 
		m_pConfig = BrNULL;
	}

	// CTextProc::FreeStatic();

	if(m_pDoc)
	{	
#ifdef	NORMAL_RELEASE_DOCUMENT
		BrDELETE m_pDoc;
#else
		m_pDoc->closeForSpecialRelease();
#endif	// NORMAL_RELEASE_DOCUMENT
		m_pDoc = BrNULL;
		theBWordDoc = BrNULL;
	}
	

//#if defined(FOR_BMV)
	if(m_pBMVExport)
	{
		BrDELETE m_pBMVExport;
		m_pBMVExport = BrNULL;
	}
//#endif	//defined(FOR_BMV)
}

#if defined(_WIN32_WCE) && defined(_FOR_FILTER_ACTION)
void CConv2XFilter::initGlobal()
{
	if(g_pAppStatic->m_hDC == BrNULL)
	{
		g_pAppStatic->m_hDC = ::GetDC(BrNULL);
	}
}

void CConv2XFilter::freeGlobal()
{
	if(g_pAppStatic->m_hDC)
	{
		::ReleaseDC(BrNULL, g_pAppStatic->m_hDC);
		g_pAppStatic->m_hDC = BrNULL;
	}
}
#endif //defined(_WIN32_WCE) && defined(_FOR_FILTER_ACTION)

BrBOOL CConv2XFilter::init()
{
	m_bRead = BrFALSE;

	m_strOrgFile = "";
	m_strConvFile = "";


	if(!m_pSysFontInfo)
	{
		//m_pSysFontInfo = (CSysFontInfo*)BrMalloc(BrSizeOf(CSysFontInfo));	
		//if(m_pSysFontInfo)
		//{
		//	g_pSysFontInfo = m_pSysFontInfo;
		//	m_pSysFontInfo->_Init();
		//}
		m_pSysFontInfo = BrNEW CSysFontInfo;	
		if(m_pSysFontInfo)
			g_pSysFontInfo = m_pSysFontInfo;
		else
			return BrFALSE;
	}
	
	if(!m_pAppStatic)
	{
		m_pAppStatic = BrNEW CAppStatic;
		if(m_pAppStatic)
			g_pAppStatic = m_pAppStatic;
		else
			return BrFALSE;
	}
#ifdef IMPORT_HTML
	if( !g_pHtml )
	{
		g_pHtml = (CHtmlStaticBase*)BrNEW CHtmlStatic();
		if( g_pHtml == BrNULL )
			return BrFALSE;
	}
#endif // IMPORT_HTML

	if(!m_pConfig)
	{	
		//m_pConfig = (CAppConfig*)BrMalloc(BrSizeOf(CAppConfig));	
		//if(m_pConfig)
		//{
		//	g_pAppConfig = m_pConfig;
		//	m_pConfig->_Init();
		//}
		m_pConfig = BrNEW CAppConfig;
		if(m_pConfig)
			g_pAppConfig = m_pConfig;
		else
			return BrFALSE;
	}

	// if(!CTextProc::InitStatic())
	//	return BrFALSE;

	if(!m_pDoc)
	{
		//m_pDoc = (BoraDoc*)BrMalloc(BrSizeOf(BoraDoc));
		//m_pDoc->_Init();
		m_pDoc = BrNEW BoraDoc;
		if(m_pDoc)
			theBWordDoc = m_pDoc;
		else
			return BrFALSE;
	}
	else
	{
		m_pDoc->ClearAll();
		m_pDoc->Init();
	}
	

//#if defined(FOR_BMV)
	if(!m_pBMVExport)
	{
		m_pBMVExport = BrNEW CBMVExport;
		if(!m_pBMVExport)
			return BrFALSE;
	}
	else
	{
		m_pBMVExport->Reset();
	}
//#endif	// defined(FOR_BMV)
		
	return BrTRUE;
}

#ifdef BWP_EDITOR
//Test �ϱ� ���ؼ� ���� ����
BrBOOL CConv2XFilter::doNewXDoc(Painter *pPainter, BrCHAR bDocType, BRPPTPaperType ePPTPaperType, BrSlideTemplateType eTemplatePPT)
{
#ifdef _DEBUG
	if (BORA_DOCTYPE_PPT == bDocType || BORA_DOCTYPE_PPTX == bDocType || BORA_DOCTYPE_ODP == bDocType)
		BTrace("ppt TemplatePPT = %d \n" ,eTemplatePPT, __FILE__ );
#endif
	if(bDocType == BORA_DOCTYPE_ASCI && g_pBInterfaceHandle->IsOpenTextInWordLayout() )
	{
		bDocType = BORA_DOCTYPE_DOCX;
		setDocType(BORA_DOCTYPE_DOCX);
		m_pDoc->setFromTxt(BrTRUE);
	}
    if ( !m_pDoc->doNewDoc(pPainter, bDocType, ePPTPaperType, eTemplatePPT) )
		return BrFALSE;

	return BrTRUE;
}
#endif


BrBOOL CConv2XFilter::doOpenXDoc(Painter *pPainter, int nPage)
{
	if(m_strOrgFile.isEmpty())
		return BrFALSE;

#if defined(_TIME_CHECK) && defined(_PART_TIME_CHECK)
	BrBOOL bOrgDel = BrFALSE;

	CTime cSTime = CTime::GetCurrentTime();
	m_bRead = m_pDoc->doOpenDoc(pPainter, m_strOrgFile, bOrgDel, false);
	toDefTimeMessageBox(cSTime, "Import Time");
#else //defined(_TIME_CHECK) && defined(_PART_TIME_CHECK)
	INT16 iRef = 0;
	m_bRead = m_pDoc->doOpenDoc(pPainter, m_strOrgFile, iRef, nPage);
#endif //defined(_TIME_CHECK) && defined(_PART_TIME_CHECK)

	return m_bRead;
}


BrBOOL CConv2XFilter::setDocumentPath(char* strOrg)
{
#if 1//defined( _DEBUG )
	BTrace("CheckFileName %s strOrg[%s]", __FUNCTION__, strOrg);
#endif
	if(!strOrg)
		return BrFALSE;

	BString tmpName = CUtil::UTF8ToBString(strOrg);
	
	if(m_strOrgFile.isEmpty())
	{
		m_strOrgFile = CUtil::UTF8ToBString(strOrg);
	}
	else
	{
		if(m_strOrgFile.compare(tmpName) != 0)
		{
			if(!init())
				return BrFALSE;
			m_strOrgFile = CUtil::UTF8ToBString(strOrg);
		}
	}

	m_strConvFile = tmpName + ".bmv";
	
	return BrTRUE;
}

BrBOOL CConv2XFilter::setDocumentPathOnly(char* strOrg)
{
#if defined( _DEBUG )
	BTrace("CheckFileName %s strOrg[%s]", __FUNCTION__, strOrg);
#endif
	if(!strOrg)
		return BrFALSE;

	BString tmpName = CUtil::UTF8ToBString(strOrg);

	if(m_strOrgFile.isEmpty())
	{
		m_strOrgFile = CUtil::UTF8ToBString(strOrg);
	}
	else
	{
		m_strOrgFile = CUtil::UTF8ToBString(strOrg);
	}

	m_strConvFile = tmpName + ".bmv";

	return BrTRUE;
}

/*
BrBOOL CConv2XFilter::toBMVConvertXFile()
{
	if(m_strConvFile.isEmpty() )
		return BrFALSE;

	BrBOOL bRet = doOpenXDoc(1);

#ifndef	BWP_EDITOR	// for Viewer
	if( bRet )
	{
		CBMVExport	BMVExport;

		bRet = BMVExport.DoSaveFile(m_strConvFile, m_pDoc->getDocTypeFromName(m_strOrgFile), BrFALSE, BrFALSE);
	}
#else				// for Editor
	if( bRet )
	{
		CLine *pLine = m_pDoc->getFirstLine();
		CTextProc::arrangeMarkingLines(m_pDoc,pLine,BrNULL);
	}
#endif	// BWP_EDITOR

	return bRet;
}
*/

BrBOOL CConv2XFilter::toBWPConvertXFile(Painter *pPainter, int nPage)
{
	if( m_strConvFile.isEmpty() )
		return BrFALSE;

	m_pDoc->setIgnoreFootnoteArrange(BrTRUE);

	BrBOOL bRet = doOpenXDoc(pPainter, nPage);

#ifdef SUPPORT_SECTION_DEBUG
	//[2012.09.25][TID:7609][��ȸ��]Section Debugging - Before Arrange
	BTrace("\n");
	BTrace("====================================================================================== \n");
	BTrace("Before Arrange \n");
	BTrace("====================================================================================== \n");
	m_pDoc->showDocInfo();
#endif//SUPPORT_SECTION_DEBUG

	if( bRet && !g_pBInterfaceHandle->getDocumentValidattionMode())
	{
		frame::text::post_import_t::get()->reset();

		BrINT	nPrevTotalPage = m_pDoc->getTotalPage();
		m_pDoc->ArrangeAllPage();

		// [11/29/2012 swseo] table arrange test
		// CTableEngine *pTableEngine = m_pDoc->getTableEngine();
		// pTableEngine->setDirtyPage(nPage + 5);

		if (m_pDoc->isFinishLoading())
			m_pDoc->setIgnoreFootnoteArrange(BrFALSE);

		// 2011.4.3 finish loading �̸� ������ arrange ����
		m_pDoc->setArrangeDuringImport(BrTRUE);		// ESD-13
		CLine *pLine = CTextProc::arrangeMarkingLines(m_pDoc, m_pDoc->getFirstLine(), BrNULL, (m_pDoc->getDocType()==BORA_DOCTYPE_HTML || m_pDoc->getDocType()==BORA_DOCTYPE_MHT ), 0/*(m_pDoc->isFinishLoading())?0:nPage+8*/ );	// 2010.2.2 doImport()���� (nPage+5) ��ŭ �� �б� ������ ����. // iOS #3449
		m_pDoc->setArrangeDuringImport(BrFALSE);

		frame::text::post_import_t::get()->post_arrange(); // POD-5001

		if ( nPage && pLine && pLine->getPage()->getPageNum()>nPage ) {
			m_pDoc->setCurLastReadPage(nPage);
			m_pDoc->setFinishArrange(BrFALSE);
		}
		else
		{
			m_pDoc->setFinishArrange(BrTRUE);
		}

		if ( nPrevTotalPage < m_pDoc->getTotalPage() )
			m_pDoc->ArrangeTypesetFrameList(nPrevTotalPage);
	}
	return bRet;
}

BrBOOL CConv2XFilter::toBWPChangedWidth()
{
	return m_pDoc->changePageWidth();
}
BrBOOL CConv2XFilter::toPageConvertXFile(Painter *pPainter, int nPageNum, void* pFilterInterface)
{
	if ( !m_pDoc || !m_pBMVExport )	return BrFALSE;

	BrBOOL bRet;
#ifdef BWP_IMG_VIEWER
	if (m_pDoc->getDocType() == BORA_DOCTYPE_IMAGE_BWP)
	{
		if (m_pBMVExport->DoPageSaveFile(m_pDoc->getDocType(), 1, pFilterInterface))
		{
			((BMVFilterInterfaceType*)pFilterInterface)->pDoc->m_DocProperty.m_nPageCount = 1;
			((BMVFilterInterfaceType*)pFilterInterface)->pDoc->m_DocProperty.m_nDocType = BORA_DOCTYPE_IMAGE_BWP;
			((BMVFilterInterfaceType*)pFilterInterface)->pMasterPage = BrNULL;
			return BrTRUE;
		}
		return BrFALSE;
	}
#endif
#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
	// html ������ �������� ���ļ� �д� ���
	if ( m_pDoc->getDocType()==BORA_DOCTYPE_HTML || m_pDoc->getDocType()==BORA_DOCTYPE_MHT )	{
		// ó�� �д� ���
		if ( nPageNum==1 )	{
			//Ȯ���ڰ� ���� ���˰� �ٸ� ��츦 ����ϱ� ���� ���� 2011-04-06 hnsong
			bRet = m_pBMVExport->DoPageSaveFile(m_pDoc->getDocType()/*m_pDoc->getDocTypeFromName(m_strOrgFile)*/, nPageNum, pFilterInterface);
		}
		// ������ �̹� ������ �� ���� ���
		else if ( m_pDoc->isFinishLoading() )	{
#ifdef BWP_EDITOR
			if ( !m_pDoc->isFinishArrangeForWeb() )	{
				m_pDoc->backgroundRearrange();
			}
#endif // BWP_EDITOR
			return BrTRUE;
		}
		// �ι�°���� �д� ���...
		else	{
			m_pDoc->doImportOnePage(nPageNum);
			bRet = m_pBMVExport->DoNextPageSaveFileForHtml();
		}

#ifdef	BWP_EDITOR			// For Editor
		// In case operating only Viewer
		if ( !IsEditorMode(pPainter) )	{
			// ��� ������ �� �а� m_bDoneBmv Flag Reset
			if ( m_pDoc->isFinishLoading() )	{
				if ( m_pDoc->isSetDoneBMV() )	{
					m_pDoc->SetDoneBMVFlag(BrFALSE);
				}
			}
			// ������ �Ϻθ� �а� ���� ���� �ִ� ��� ���� ���� �Ϳ� ���Ͽ� m_bDoneBMV Flag setting
			else	{
				m_pDoc->SetDoneBMVFlag(BrTRUE);
			}
		}
#else						// For Viewer
		// sms ������ delete���� ����. bwp data�� ������ width�� �����ؼ� ����ϰ� ����...
		if ( !m_pDoc->isSMSDoc() && !IsFixedWidthView(pPainter))	{
			// ��� ������ �� �а� bmv�� ��ȯ�� ��...
			if ( m_pDoc->isFinishLoading() )	{
				m_pDoc->ClearAll(BrFALSE);
				// m_pDoc->Init();
			}
			// ������ �Ϻθ� �а� ���� ���� �ִ� ��� ���� ���� �͸� delete
			else	{
				m_pDoc->ClearBasicLines();
			}
		}
#endif	//BWP_EDITOR
		return bRet;
	}
#endif	// LOAD_ONE_PAGE_HTML

//#if !defined(RENDERING_WITH_BORATHREAD) // RENDERING_WITH_BORATHREAD������ Load�� ���������� �о�� �ϴ� �������� ũ�� �ȵ�.
	// G-zero �ܸ����� ��� ������ �̵� UI �� Ư���ؼ� ���� ������ ���� �ּ� 6 ������ �� ������ �� �� �־�� �ϴ� ��찡 �߻�....
	int		nPgNumForImport = nPageNum;
	if ( nPgNumForImport != 0x7FFFFFFF )	nPgNumForImport += m_pDoc->getIncPageNum();

	if ( !m_pDoc->isFinishLoading() && nPgNumForImport>m_pDoc->getCurLastReadPage() && nPgNumForImport>m_pDoc->getTotalPage())	
	{
		BrINT	nPrevTotalPage = m_pDoc->getTotalPage();
		m_pDoc->doImportOnePage(nPgNumForImport);
		if ( nPrevTotalPage < m_pDoc->getTotalPage() )
			m_pDoc->ArrangeTypesetFrameList(nPrevTotalPage);
	}
//#endif


	// html ������ �ʿ� ����.
#ifndef	BWP_EDITOR		// For Viewer
	if ( m_pDoc->getDocType()!=BORA_DOCTYPE_HTML && m_pDoc->getDocType()!=BORA_DOCTYPE_MHT && m_pDoc->getDocType()!=BORA_DOCTYPE_ASCI )
#else
	if ( m_pDoc->getDocType()!=BORA_DOCTYPE_HTML && m_pDoc->getDocType()!=BORA_DOCTYPE_MHT && m_pDoc->getDocType() != BORA_DOCTYPE_PPTX)
#endif
		m_pDoc->ChkArrangeForCurPage(nPageNum);

	if ( nPageNum != 0x7FFFFFFF && m_pDoc->getTotalPage() < nPageNum)
	{
		nPageNum = m_pDoc->getTotalPage();//2007-05-03
		//return BrFALSE;
	}

	if ( m_pDoc->getDocType()==BORA_DOCTYPE_ASCI
#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
		&& m_pDoc->GetTxtImport()
#endif
		)	// txt file
	{
#if	defined(BWP_EDITOR)
		if ( ((BMVFilterInterfaceType*)pFilterInterface)->pDoc )
			m_pBMVExport->GetXSeComposer()->SetBmvDoc(((BMVFilterInterfaceType*)pFilterInterface)->pDoc);
		//Ȯ���ڰ� ���� ���˰� �ٸ� ��츦 ����ϱ� ���� ���� 2011-04-06 hnsong
		bRet = m_pBMVExport->DoPageSaveFile(m_pDoc->getDocType(), nPageNum, pFilterInterface);
#else
		bRet = m_pBMVExport->DoPageSaveFile(m_pDoc->getDocType()/*m_pDoc->getDocTypeFromName(m_strOrgFile)*/, nPageNum, pFilterInterface);
#endif
	}
	else
	{
#if defined(BWP_EDITOR)
		if ( ((BMVFilterInterfaceType*)pFilterInterface)->pDoc )
			m_pBMVExport->GetXSeComposer()->SetBmvDoc(((BMVFilterInterfaceType*)pFilterInterface)->pDoc);
		//Ȯ���ڰ� ���� ���˰� �ٸ� ��츦 ����ϱ� ���� ���� 2011-04-06 hnsong
		bRet = m_pBMVExport->DoPageSaveFile(m_pDoc->getDocType(), nPageNum, pFilterInterface);
#else
		bRet = m_pBMVExport->DoPageSaveFile(m_pDoc->getDocType(), nPageNum, pFilterInterface);
#endif
	}

#ifndef	BWP_EDITOR		// For Viewer
	// if html document, clear doc structure
	if ( (m_pDoc->getDocType()==BORA_DOCTYPE_HTML || m_pDoc->getDocType()==BORA_DOCTYPE_MHT) 
		&& m_pDoc->isFinishLoading() )
	{
		m_pDoc->ClearAll(BrFALSE);
		// m_pDoc->Init();
	}
#endif	// BWP_EDITOR

	return bRet;
}

BrBOOL CConv2XFilter::readOnlyPage(BMVDoc* pBMVDoc, int nPageNum)
{
	if ( !m_pDoc )	return BrFALSE;

#ifdef BWP_EDITOR
	if ( m_pDoc->isFinishLoading() && BrFALSE == m_pDoc->isViewPrintMode() )	{
		m_pDoc->backgroundRearrange();
		return BrTRUE;
	}
#endif // BWP_EDITOR

#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
	// ASCII File �� Web Mode���� import�� ���� �ֱ� ������ �и�...
	if ( m_pDoc->getDocType()==BORA_DOCTYPE_ASCI && m_pDoc->isViewWebMode() )	{
		if ( !m_pDoc->isFinishLoading() )	{
			m_pDoc->doImportOnePage(nPageNum);
			m_pBMVExport->SetPageNumInfo(pBMVDoc);
		}
		return BrTRUE;
	}
#endif  // defined(BWP_EDITOR) && defined(IMPORT_TXT)

	BrINT	nPrevTotalPage = m_pDoc->getTotalPage();

#ifdef	BWP_EDITOR
	if ( !m_pDoc->isFinishLoading() && m_pDoc->isFinishArrange()  && ((nPageNum+6)>=m_pDoc->getCurLastReadPage() || (nPageNum+6)>=m_pDoc->getTotalPage() || m_pDoc->isViewWebMode()) )
#else
	if ( !m_pDoc->isFinishLoading() && m_pDoc->isFinishArrange()  && (nPageNum+6)>=m_pDoc->getCurLastReadPage() )
#endif
	{
		BrBOOL result = m_pDoc->doImportOnePage(nPageNum);
		// ���� �̹��� ��ȯ���� ��Ȯ�� total page�� ���Ͽ� arrange ��ƾ �߰� (DGG-249)
#ifdef USE_POLARIS_LINK 
		CLine *pLine = m_pDoc->getFirstLine();
		if ( pLine )	CTextProc::arrangeMarkingLines(m_pDoc, pLine->getFirstNextDirtyLine(), BrNULL, BrFALSE);
#endif //USE_POLARIS_LINK 
		m_pBMVExport->SetPageNumInfo(pBMVDoc);
        if (result == BrFALSE)
          return BrFALSE;
	}
	else if( !m_pDoc->isFinishLoading() && !m_pDoc->isFinishArrange()  && nPageNum>=m_pDoc->getCurLastReadPage() )
	{
		int nPgNum = m_pDoc->getCurLastReadPage() +1;
		// CPage *pPage = m_pDoc->getPageArray()->getPage(m_pDoc->getCurLastReadPage());
		CLine *pLine = m_pDoc->getFirstLine();
		if( pLine )
		{
			pLine = CTextProc::arrangeMarkingLines(m_pDoc, pLine->getFirstNextDirtyLine(), BrNULL, (m_pDoc->getDocType()==BORA_DOCTYPE_HTML || m_pDoc->getDocType()==BORA_DOCTYPE_MHT ), nPgNum+6);
			if ( nPageNum && pLine && pLine->getPage()->getPageNum()>nPgNum ) {
				m_pDoc->setCurLastReadPage(nPgNum);
				m_pDoc->setFinishArrange(BrFALSE);
			}
			else
				m_pDoc->setFinishArrange(BrTRUE);
		}
		else
			m_pDoc->setFinishArrange(BrTRUE);

		m_pBMVExport->SetPageNumInfo(pBMVDoc);
	}
	else if ( m_pDoc->isFinishLoading() && !m_pDoc->isFinishArrange() )
	{
		ci_validate_during_import();
		int nArrangePgNum = m_pDoc->getDirtyPage();
		if ( nArrangePgNum==0 )
		{
			m_pDoc->setFinishArrange(BrTRUE);
			//m_pDoc->getCmdEngine()->setDocEndCoord();
		}
		else
		{
			//[M-24521] hnsong:2013-03-04 endnote, footnote, section header/footer ����� ó������ �ٽ� arrange�� �Ǹ鼭 ū ������ ��� ANR
			CANCEL_LOAD_RETURN_BOOL_EX;

			m_pDoc->ChkArrangeForCurPage(nArrangePgNum, nArrangePgNum+1);
			m_pBMVExport->SetPageNumInfo(pBMVDoc);
#ifndef SUPPORT_SCROLL_ARRANGE
			m_pDoc->getCmdEngine()->setDocEndCoord();
#endif
		}
	}

	if (nPrevTotalPage < m_pDoc->getTotalPage())
		m_pDoc->ArrangeTypesetFrameList(nPrevTotalPage);

	return BrTRUE;
}

BrBOOL  CConv2XFilter::isFinishLoading()
{
#ifdef BWP_EDITOR
	if (m_pDoc->isFinishLoading())
	{
		if (m_pDoc->isViewPrintMode())
			return m_pDoc->isFinishArrange();
		else
		{
#ifdef REFLOW_SIMPLE_TEXT_EDITOR
			return BrTRUE;
#else
			return m_pDoc->isFinishArrangeForWeb();
#endif // REFLOW_SIMPLE_TEXT_EDITOR
		}
	}
	return BrFALSE;
#else
	return m_pDoc->isFinishLoading() && m_pDoc->isFinishArrange();
#endif // BWP_EDITOR
}

BrBOOL  CConv2XFilter::isFinishOnlyLoading()
{ 
	return m_pDoc->isFinishLoading();
}

void  CConv2XFilter::setFinishLoading(BrBOOL bFinish)
{ 
	m_pDoc->setFinishLoading(bFinish); 
	if ( bFinish )	{
		// arrange�� �� �Ǿ����� �Ѳ����� ����...
		while ( !m_pDoc->isFinishArrange() )	{
			int nArrangePgNum = m_pDoc->getDirtyPage();
			if ( nArrangePgNum==0 )	{
				m_pDoc->setFinishArrange(BrTRUE);
				//m_pDoc->getCmdEngine()->setDocEndCoord();
			}
			else
			{
				m_pDoc->ChkArrangeForCurPage(nArrangePgNum, m_pDoc->getTotalPage()+1);
				m_pBMVExport->SetPageNumInfo();
			}
		}
	}
}

#ifdef IMPORT_HTML
void  CConv2XFilter::SetHtmlPageSize( BrSize size )
{
	m_pDoc->m_HtmlPageSize = size;
}
#endif //IMPORT_HTML

#ifdef PPT_EDITOR
BrBOOL CConv2XFilter::isPPTModeChange() 
{ 
	return m_pDoc->isPPTModeChange();
}

BrINT32 CConv2XFilter::GetEditTotalPageNum() 
{ 
	return m_pDoc->getEditingTotalPage(); 
}
#endif //PPT_EDITOR
#endif//#ifdef BWP_EDITOR

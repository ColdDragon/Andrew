#include <html_filterPCH.hpp>


#if defined(IMPORT_HTML) || defined(EXPORT_HTML)
#include "bwFrameSet.h"
#include "bwTableEngine.h"
#include "HtmlInterface.h"
#include "Dom/HtmlDocument.h"
#include "Dom/Data/HtmlDataKeyIdentifier.h"
#include "Dom/Data/MlDataObjBuild.hpp"

#ifdef IMPORT_HTML
#include "Import/HtmlDataImporter/HtmlImporter.h"
#include "Import/HtmlDataImporter/HtmlFileImporter.h"
#include "Import/HtmlDataImporter/HtmlClipboardImporter.h"
#include "Import/HtmlDataImporter/HtmlWebOfficeImporter.h"
#include "Import/HtmlDataImporter/HtmlPubdocImporter.h"
#include "Dom/HtmlParser/HtmlParser.h"
#include "send_to_callback.h"

#endif // IMPORT_HTML

#ifdef EXPORT_HTML
#include "Export/HtmlDataExporter/HtmlExporter.h"
#include "Export/HtmlDataExporter/HtmlClipboardExporter.h"
#include "Export/HtmlDataExporter/HtmlPubdocExporter.h"
#include "Export/HtmlDataExporter/HtmlWebOfficeExporter.h"
#include "Dom/HtmlMaker/HtmlMaker.h"
#endif // EXPORT_HTML

#include "bwAppStatic.h"
#include "bwDataTransfer.h"
#include "bwLine.h"

#ifdef HTML_RECURSIVE_TEST
#include "bwTextProc.h"
#include "Import/HtmlDataImporter/HtmlClipboardImporter.h"
#endif // HTML_RECURSIVE_TEST

#include "BFile.h"
#include "bwTextProc.h"
#include "Util/HtmlCharsetUtil.h"

#include "../../../../sources/Common/Base/types_i/BaseTypes_i.h"
#include "Util/HtmlEntityConverter.h"

#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)

#include "Dom/HtmlParser/DomBuilder.h"
#include <condex_cpp_bind.h>
#endif//#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)



namespace html {

HtmlInterface::HtmlInterface(void)
{
  data_key::InitDataKeyId();
  entity::InitEntityDecodeMap();
  entity::InitEntityEncodeMap();
  html_document_ = BrNEW HtmlDocument();
#ifdef USE_COLLABORATION  
  m_pArrImagePath = BrNULL;
  m_pImageInfo = BrNULL;
#endif
}
HtmlInterface::HtmlInterface(const char* file_path) : HtmlInterface()
{
  bool init_ok = InitHtmlData(file_path);
}

#ifdef USE_COLLABORATION
HtmlInterface::HtmlInterface(const char* html_data, const char* source_url, BObArray<BString>* pArrImagePath, PasteImageInfo* pImageInfo) : HtmlInterface()
#else
HtmlInterface::HtmlInterface(const char* html_data, const char* source_url) : HtmlInterface()
#endif
{
  html_byte_seq = html_data;

  html_data_.SetMultiByte(html_data, CP_UTF8);
  html_source_url_.SetMultiByte(source_url, CP_UTF8);
#ifdef USE_COLLABORATION
  m_pArrImagePath = pArrImagePath;
  m_pImageInfo = pImageInfo;
#endif
}

HtmlInterface::HtmlInterface(BrLPCWSTR utf8_html_data, BrLPCWSTR source_url): HtmlInterface()
{
  html_data_ = utf8_html_data;
  html_source_url_ = source_url;
}


HtmlInterface::~HtmlInterface(void)
{
  BR_SAFE_DELETE(html_document_);
}

#ifdef IMPORT_HTML

bool HtmlInterface::ImportHtml(HtmlDataTypes import_type)
{
  if ( html_data_.IsEmpty() )
    return false;

  HtmlImporter * html_importer = CreateHtmlImporter(import_type);
  html_importer->SetFilePath(html_path_);
  html_importer->SetSourceURL(html_source_url_);
#ifdef USE_COLLABORATION
  html_importer->SetArrImagePath(m_pArrImagePath);
  html_importer->SetImageInfo(m_pImageInfo);
#endif

#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)
  if (html_byte_seq && import_opt_html5) {

	  std::unique_ptr<condex::Dict const> dict = condex::new_dict();
	  {
		  dict->update("mso", 1.0);
		  dict->update("supportEmptyParas", 1.0);
          if (BrGetCollaborationMode() == BR_COLLABORATION_MORMAL_MODE)
          {
              dict->update("vml", 1.0);
          }
	  }

	  std::string source(html_byte_seq);
	  std::unique_ptr<condex::Condex const> condex = condex::new_condex(source);
	  std::string evaluated = condex->eval(dict.get());

	  char const* begin_position = strchr(evaluated.c_str(), '<');
	  if (begin_position) {
		  DomBuilder<MlDataObjBuild> builder(begin_position);
		  html_document_->root_element_ = builder.build();
		  html_importer->html_document_ = html_document_;
	  }
	  
  }
  else 
#endif//#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__)  && !defined(__sparc__)
  {

	  HtmlParser *parser = BrNEW HtmlParser();
	  BrBOOL is_read_comp = BrFalse;

	  while (is_read_comp == BrFALSE) {
	    is_read_comp = parser->ParseHtml(html_data_, html_document_);
	  }
	  html_data_.Empty();
  }

  bool result = html_importer->ImportDocument();

  NotifyImportComplete(html_importer);

  //BR_SAFE_DELETE(parser);
  BR_SAFE_DELETE(html_importer);

  if ( kClipboardType != import_type ) {
    CTableEngine *table_engine = theBWordDoc->getTableEngine();
    table_engine->resizeTables();
    CTextProc::arrangeMarkingLines(theBWordDoc, theBWordDoc->getFirstLine(), BrNULL, 0, 0);
  }

  return result;
}

HtmlImporter * HtmlInterface::CreateHtmlImporter(HtmlDataTypes import_type)
{
  HtmlImporter * importer = BrNULL;
  switch ( import_type ) {
  case kClipboardType:
    importer = BrNEW HtmlClipboardImporter(html_document_);
    break;
  case kDocumentType:
    importer = BrNEW HtmlFileImporter(html_document_);
    break;
  case kWebOfficeType:
    importer = BrNEW HtmlWebOfficeImporter(html_document_);
    break;
  case kPubdocType:
    importer = BrNEW HtmlPubdocImporter(html_document_);
    break;
  }

  return importer;
}

bool HtmlInterface::InitHtmlData(const char * file_path)
{
  CWString path;
  path.SetMultiByte( file_path, CP_UTF8 );
  BFile file;
  BString filePath;
  filePath = (BrLPCWSTR)path;
  if( !file.Open(filePath , BMV_READ_ONLY ) ) {
    return false;
  }

  BrDWORD file_length = file.Size();
  if ( file_length == 0 ) {
    file.Close();
    return false;
  }
  unsigned char * file_buffer = (unsigned char *) BrCalloc ( file_length + 3, sizeof(unsigned char) );
  if( !file_buffer ) {
    file.Close();
    return false;
  }

  file.Read ( file_buffer, file_length );
  file.Close();

  BrLPWSTR unicode_data = charset::convertMultiToWide(file_buffer, file_length);

  html_data_ = unicode_data;

  BR_SAFE_FREE(unicode_data);
  BR_SAFE_FREE(file_buffer);

  InitLoadImgPath(file_path);

  return true;

}

void HtmlInterface::InitLoadImgPath(const char * file_path)
{
  CWString strPath;
  strPath.SetMultiByte( file_path , CP_UTF8 );

  if( strPath.IsEmpty() )
    return;

  html_path_.Empty();
  int won = strPath.ReverseFind('\\');
  int slush = strPath.ReverseFind('/');

  if( won<slush )
    won = slush;

  html_path_ = strPath.Left(won);

}

void HtmlInterface::NotifyImportComplete(HtmlDecoderDelegate* html_importer) {

#ifdef SUPPORT_URL_IMAGE

    int urlDownloadImageCount =  html_importer->GetURLDownloadImageCount();
    SendBaseResultCallback(-1, Bora_html_complete_paste_images, 0, g_pBInterfaceHandle->m_pUIPROCESS_CBFUNC, &urlDownloadImageCount, true);
#endif

}


#endif // IMPORT_HTML


#ifdef EXPORT_HTML

void HtmlInterface::CreateHtmlData(HtmlDataTypes export_type, HtmlExportOptions export_options)
{
  CLine* first_line = BrNULL;
  CFrameList* export_frame_list = BrNULL;

  HtmlExporter* html_exporter = CreateHtmlExporter(export_type);
  __BrExitOn(!html_exporter);

  html_exporter->SetImageSavePath(html_path_);
  html_exporter->SetExportOptions(export_options);
  
  CDataTransfer * data_transfer = g_pAppStatic->m_pDataXfer;
  switch ( export_type ) {
  case kClipboardType:
    {
      CLineList * clip_linelist = data_transfer->getLineList();
      CFrameList * clip_framelist = data_transfer->getFrameList();

      if ( clip_linelist )
        first_line = clip_linelist->getFirst();

      if ( first_line == BrNULL )
        export_frame_list = clip_framelist;

      break;
    }

  case kDocumentType:
  case kWebOfficeType:
    if ( BrNULL == first_line ) {
      if ( !export_frame_list )
        first_line = theBWordDoc->getFirstLine();
    }
    
    break;
  }

  if ( first_line )
    html_exporter->ExportDocument(first_line);
  else
    html_exporter->ExportDocument(export_frame_list);

  HtmlMaker *html_maker = BrNEW HtmlMaker();
  html_maker->MakeHtml(html_document_, html_data_);
  
  BR_SAFE_DELETE(html_exporter);
  BR_SAFE_DELETE(html_maker);

  //Andrew C.Lee BrGetClipboardPath호출부 수정
  char* pUtf8 = html_path_.GetMultiByte(CP_UTF8);
  BSetPermission( pUtf8, 0777 , 1);
  BR_SAFE_FREE(pUtf8);
}

BrLPWSTR HtmlInterface::ExportHtml(HtmlDataTypes export_type, HtmlExportOptions options)
{
    InitSaveClipboardPath();
    CreateHtmlData(export_type, options);

    int html_text_size = (html_data_.GetLength() + 1) * 2;
    BrLPWSTR html_text = (BrLPWSTR)BrMalloc(html_text_size);
    memset(html_text, 0, html_text_size);
    memcpy(html_text, html_data_.GetBuffer(0), html_text_size);

    return html_text;
}

bool HtmlInterface::ExportHtml(const char * file_path, HtmlDataTypes export_type)
{
  if ( BrNULL == file_path )
    return false;

  CWString save_file;
  save_file.SetMultiByte(file_path, CP_UTF8);

  InitSaveWebofficeImgPath(file_path);
  CreateHtmlData(export_type, HtmlExportOptions::None);

  html_data_ = HTML_CONTENT_PREFIX + html_data_ + HTML_CONTENT_SUFFIX;

  BFile wFile;
  BString filePath;
  filePath = (BrLPCWSTR)save_file;
  if( wFile.Open( filePath , BMV_WRITE_ONLY ) )
  {
    wFile.Write( (BYTE*)"\xef\xbb\xbf" , 3  );    // 저장시는 무조건 CP_UTF8: //65001 로 저장합니다.

    int out_len = 0;
    BrLPSTR multibyte_str = charset::WideCharToMultiByteHtml( (BrLPWSTR)(BrLPCWSTR)html_data_ , html_data_.GetLength(), CP_UTF8 , out_len );
    if( multibyte_str )
    {
      wFile.Write( (BYTE*) multibyte_str, out_len );
      BR_SAFE_FREE( multibyte_str );
    }

    wFile.Close();

     return true;
  }

  return false;
}

HtmlInterface& HtmlInterface::import_html5(bool import_opt) {
	import_opt_html5 = true;
	return *this;
}

HtmlExporter * HtmlInterface::CreateHtmlExporter(HtmlDataTypes export_type)
{
  HtmlExporter * exporter = BrNULL;

  switch ( export_type ) {
  case kClipboardType:
    exporter = BrNEW HtmlClipboardExporter(html_document_);
    break;
  case kPubdocType:
    exporter = BrNEW HtmlPubdocExporter(html_document_);
    break;
  case kWebOfficeType:
    exporter = BrNEW HtmlWebOfficeExporter(html_document_);
    break;
  }

  return exporter;
}

void HtmlInterface::InitSaveWebofficeImgPath(const char * file_path)
{
  CWString strPath;
  strPath.SetMultiByte( file_path , CP_UTF8 );

  if( strPath.IsEmpty() )
    return;

  html_path_.Empty();
  int won = strPath.ReverseFind('\\');
  int slush = strPath.ReverseFind('/');

  if( won<slush )
    won = slush;

  int last_dot = strPath.ReverseFind('.');

  if( last_dot > won )
    html_path_ = strPath.Left(last_dot) + ".files";//이미지 저장시에 사용함.
  else
    html_path_ = strPath + ".files";
}

void HtmlInterface::InitSaveClipboardPath()
{
	html_path_.Empty();
	//Andrew C.Lee BrGetClipboardPath호출부 수정
	const char* pClipPath = BrGetClipboardPath();
	if ( pClipPath )
	{	  
		html_path_.SetMultiByte( pClipPath, CP_UTF8 );
	}
}



#endif // EXPORT_HTML





#ifdef HTML_RECURSIVE_TEST
BrBOOL HtmlInterface::RemoveAllDocumentContents()
{
#if 1
  BrBOOL bUndo = BrFALSE;
  CCaret* pCaret = theBWordDoc->getCaret();

  /* 전체 마킹 */
  CLine * first_line = theBWordDoc->getFirstLine();
  CLine * last_line = theBWordDoc->getLastLine();
  pCaret->updateMarking(first_line, 0, last_line, last_line->getCharNum() );

  /* Marking 데이터 삭제 코드 */
  BrBOOL bCaretMarking = pCaret->isCaretMarking();

  if(bCaretMarking == BrFALSE)
    return BrTRUE;

  //현재 caret이 마킹된 상태라면 마킹된 영역은 삭제후 paste시작해야함
  CTextProc::invalidateTextArea(theBWordDoc, pCaret->getSLine(), pCaret->getLine());

  //마킹된 영역 삭제전에 항상 확인(각주 미주 영역 체크해야함)
  if(pCaret->availableDelMarkData() == BrFALSE)
    return BrFALSE;

  if (!pCaret->deleteChar(BrFALSE, bUndo))
    return BrFALSE;

  //삭제된 영역이 테이블이나 셀인경우 다시 Arrange
  CFrame* pFrame = pCaret->getFrame();
  BrBOOL bCell = pFrame ? pFrame->isCell() : BrFALSE;
  //테이블 다시 Arrange
  if (bCell)
  {
    CCharPos charPos;
    charPos.setCharPos(theBWordDoc, pCaret->getFrame(), pCaret->getLine(BrTRUE), pCaret->getCol());

    CBTable* pTable = BrNULL;
    if(bCell)
      pTable = pFrame->getCell() ? pFrame->getCell()->getTable() : BrNULL;

    //스플릿된 테이블을 전체 머지후 하나의 테이블로 만든뒤 재 Arrange하는것으로 보임
    CTableEngine *pTableEngine = theBWordDoc->getTableEngine();
    pTableEngine->rearrangeTableContent(pTable, BrTRUE, BrTRUE);

    //테이블 스플릿 -> 머지 되었기 때문에 다시 얻음
    CLocation cLoc;
    BrBOOL bRet = charPos.getLocation(theBWordDoc, &cLoc);
    if(bRet)
      pCaret->updateNormalCaret(cLoc.getLine(), cLoc.getColumn());
    else
      BRTHREAD_ASSERT(0); //여기 걸리면 꼭 디버그 
  }

  return BrTRUE;
#else
  /* 모든 메모리가 초기화 되므로 Recursive 용으로 사용 불가 */
  BrGuiNewEvent BoraEvent = {0,};
  BoraEvent.nType	= BRGUI_NEW_EVENT;
  strcpy( BoraEvent.szFilePath, _T("NewDocument1.docx"));
  BrSetGUIEvent(&BoraEvent, &BEventProcess);

  return BrTRUE;

#endif
}


#endif // HTML_RECURSIVE_TEST


} // namespace html


#endif // SUPPORT_HTML

#include <html_filterPCH.hpp>

#ifdef IMPORT_HTML

#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)

#include <memory>
#include <string>
#include <unordered_map>
#include <algorithm>

#include "DomBuild.h"
#include "DomBuilder.h"

//static bool is_abandoned(std::string element_name);
//static bool is_flow_content(std::string element_name);
//static bool is_inline_element(std::string element_name);
//static std::string dedup_ws(std::string const& text_contents);

static std::string flow_contents[] = {
	"a", "abbr", "address", "area", "article", "aside", "audio",
	"b", "bdi", "bdo", "blockquote", "br", "button",
	"canvas", "cite", "code", "command",
	"datalist", "del", "details", "dfn", "div", "dl",
	"em", "embed",
	"fieldset", "figure", "footer", "form",
	"h1", "h2", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr",
	"i", "iframe", "img", "input", "ins",
	"kbd", "keygen",
	"label",
	"map", "mark", "math", "menu", "meter",
	"nav", "noscript",
	"object", "ol", "output",
	"p", "pre", "progress", "q", "ruby",
	"s", "samp", "script", "section", "select", "small", "span", "strong", "style", "sub", "sup", "svg",
	"table", "textarea", "time",
	"u", "ul",
	"var", "video",
	"wbr",
};

static std::string inline_elements[] = {
	"a", "abbr", "acronym", "audio",
	"b", "bdi", "bdo", "big", "br", "button",
	"canvas", "cite", "code",
	"data", "datalist", "del", "dfn",
	"em", "embed",
	"i", "iframe", "img", "input", "ins",
	"kbd", "label", "map", "mark", "meter", "noscript",
	"object", "output", "picture", "progress",
	"q",
	"ruby",
	"s", "samp", "script", "select", "slot", "small", "span", "strong", "sub", "sup", "svg",
	"template", "textarea", "time", "tt",
	"u",
	"var", "video",
	"wbr"
};

static std::string abandon_list[] = {
	"style", "script"
};


#include <iterator>
#include <functional>
#include <sstream>

inline bool is_whitespace(char const ch) {
	return
		ch == 0x20 ||
		ch == 0x09 ||
		ch == 0x0C ||
		ch == 0x0D ||
		ch == 0x0A;
}

bool is_flow_content(std::string element_name) {

	std::function<bool(std::string const&)> pred = [&element_name](std::string const& flow) {
		return element_name == flow;
	};

	return std::any_of(std::begin(flow_contents), std::end(flow_contents), pred);
}

bool is_abandoned(std::string element_name) {

	std::function<bool(std::string const&)> pred = [&element_name](std::string const& abandon) {
		return element_name == abandon;
	};

	return std::any_of(std::begin(abandon_list), std::end(abandon_list), pred);
}

bool is_inline_element(std::string element_name) {
	std::function<bool(std::string const&)> pred = [&element_name](std::string const& inline_elem) {
		return element_name == inline_elem;
	};

	return std::any_of(std::begin(inline_elements), std::end(inline_elements), pred);

}

std::string dedup_ws(std::string const& text_contents) {
	char const NOT_RECOGNIZED = '\0';
	char const kSPACE = '\x20';

	char last_char = NOT_RECOGNIZED;

	std::stringstream buffer;
	std::stringstream copied;
	
	for (char const& ch : text_contents)
	{
		// skip initial whitespaces.
		if (last_char == NOT_RECOGNIZED) {
			last_char = is_whitespace(ch) ? last_char : ch;
			continue;
		}

		// Deduplicate whitespace characters.
		if (is_whitespace(ch) && is_whitespace(last_char)) {
			copied << buffer.str();
			// clear buffer;
			// note that, stringstream::clear is not make empty stringstream.
			buffer.str(std::string());
			last_char = kSPACE;
		}
		else {
			buffer << (is_whitespace(last_char) ? kSPACE : last_char);
			last_char = ch;
		}
	}

	// finish: flush buffered characters.
	buffer << (is_whitespace(last_char) ? kSPACE : last_char);

	copied << buffer.str();
	return copied.str();
}

#endif//#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)

#endif // IMPORT_HTML
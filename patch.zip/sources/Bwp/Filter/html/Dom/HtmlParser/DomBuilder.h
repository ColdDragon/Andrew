#ifndef __DOM_BUILDER_H__
#define __DOM_BUILDER_H__

#ifdef IMPORT_HTML

#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)

#include <memory>
#include "Dom/HtmlParser/DomBuild.h"
#include "Dom/Data/MlDataObj.h"

#include <albtml_cpp_bind.h>

namespace albtml {
	class HtmlNodeRef;
}

template<typename dom_build_trait>
struct DomBuilder final
{
public:
	typedef DomBuild<dom_build_trait> builder_t;

public:
	explicit DomBuilder(char const* html_string);
	~DomBuilder();

public:
	typename builder_t::node_t::node_ref_t build() const;

private:
	typename builder_t::node_t::node_ref_t build_inner(std::unique_ptr <albtml::HtmlNodeRef const > parent) const;

private:
	char const* html_byte_seq;
};

template<typename dom_build_trait>
DomBuilder<dom_build_trait>::DomBuilder(char const* html_string)
{
	html_byte_seq = html_string;

	// Ctor goes here.
}


// template implementations

bool is_abandoned(std::string element_name);
bool is_flow_content(std::string element_name);
bool is_inline_element(std::string element_name);
std::string dedup_ws(std::string const& text_contents);


template<typename dom_build_trait>
DomBuilder<dom_build_trait>::~DomBuilder()
{
	// Dtor goes here.
}

template<typename dom_build_trait>
typename DomBuilder<dom_build_trait>::builder_t::node_t::node_ref_t DomBuilder<dom_build_trait>::build() const {

	std::string html_string(html_byte_seq);
	std::unique_ptr<albtml::HtmlNodeRef const> document = albtml::parse_html(html_string);
	document->apply_style(); //AOM-64951 custom style���� crash�̽��� �߻��ϳ� �󵵰� ���Ƽ� �״�� ��

	auto query = document->select("body");
	auto matched = query->next();
	if (matched) {
		return build_inner(std::move(matched));
	}
	else {
		return builder_t::unsupported_node();
	}
}

template<typename dom_build_trait>
typename DomBuilder<dom_build_trait>::builder_t::node_t::node_ref_t DomBuilder<dom_build_trait>::build_inner(std::unique_ptr<albtml::HtmlNodeRef const> parent) const {


	if (parent->is_element()) {

		typename builder_t::node_t::node_ref_t node = builder_t::create_element(parent->element_name().data());

		// attributes

		for (std::pair<std::string, std::string> const pair : parent->attributes()) {
			const char* name = pair.first.data();
			const char* value = pair.second.data();

			typename builder_t::node_t::attribute_t attr = builder_t::create_attribute(name, value);
			builder_t::append_attribute(node, attr);
		}

		// internal styles

		for (std::pair<std::string, std::string> const pair : parent->internal_styles()) {
			const char* name = pair.first.data();
			const char* value = pair.second.data();

			typename builder_t::node_t::style_attribute_t internal_style_attr = builder_t::create_style_attribute(name, value);
			builder_t::append_style_attribute(node, internal_style_attr);
		}

		// inline styles

		for (std::pair<std::string, std::string> const pair : parent->inline_styles()) {
			const char* name = pair.first.data();
			const char* value = pair.second.data();

			typename builder_t::node_t::style_attribute_t inline_style_attr = builder_t::create_style_attribute(name, value);
			builder_t::append_style_attribute(node, inline_style_attr);
		}

		// build children nodes like text, child element.

		for (auto child_iter = parent->children(); auto child_node = child_iter->next();) {
			typename builder_t::node_t::node_ref_t child = build_inner(std::move(child_node));
			if (!builder_t::is_unsupported_node(child)) {
				if (builder_t::node_t::is_element_node(child)) {
					builder_t::append_child(node, child);
				}
				else if (builder_t::node_t::is_text_node(child)) {
					if (!is_abandoned(parent->element_name()) && builder_t::node_t::has_text_value(child)) {
						builder_t::append_text(node, child);
					}
					else if (is_flow_content(parent->element_name())) {
						dom_build_trait::destroy_element(child);

						if (is_inline_element(parent->element_name())) {
							typename builder_t::node_t::text_t space = builder_t::create_text(" ");
							builder_t::append_text(node, space);
						}
					}

				}
			}

		}

		return node;
	}
	else if (parent->is_text()) {
		std::string text_contents = dedup_ws(parent->text_contents());
		typename builder_t::node_t::text_t text_node = builder_t::create_text(text_contents.data());
		return builder_t::node_t::cast_text_to_node(text_node);
	}

	// Comment is eliminated and build_inner's entry accepts only body element as root.
	return builder_t::unsupported_node();
}

#endif //#if !defined(__EMSCRIPTEN__) && !defined(__APPLE__) && !defined(__sparc__)
#endif // IMPORT_HTML

#endif // __ALBTML_DOM_BUILDER_H__

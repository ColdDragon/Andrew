#include <OfficePreComp.hpp>

#include "prmemory_manager.h"
#include "bheaptrace.h"
#include "binterfacehandle.h"
#include "painter.h"
#include "cmnFunc.h"
#include "brmcoreproc.h"
#include "BaseTypes.h"
#include "pagepainter.h"
#include "BrCommonHeapTableFacade.h"
#if !defined(NOT_USE_GLOBAL_VARIABLE)
extern BrINT32 gnBits;
#endif
 
#ifndef NOT_USE_GLOBAL_VARIABLE
BORA_MEMORY_MAP	gMemoryMap;
B_MEM_POOL*		gpMemPool=BrNULL;

#ifdef BRMEMORY_DEBUG_TRACE
BHeapTrace*		g_pHeapTrace = BrNULL;
#endif //BRMEMORY_DEBUG_TRACE

//start : memory for thread and event 
B_MEMORY*	gpBoraThreadStackMem=BrNULL; //use for greater than MIN_THREAD_STACK_SIZE
B_MEMORY*	gpBoraEventMem=BrNULL; //use for less than MIN_THREAD_STACK_SIZE

#endif //NOT_USE_GLOBAL_VARIABLE

void SetMemoryMapFlagByFileType(BrINT8 nExtType)
{
	switch(nExtType)
	{
	case BORA_EXT_DOC:
	case BORA_EXT_HWP:
	case BORA_EXT_GUL:
	case BORA_EXT_BMV:
	case BORA_EXT_HTM:
	case BORA_EXT_HTML:
	case BORA_EXT_MHT:
	case BORA_EXT_MHTML:
	case BORA_EXT_SMS:
	case BORA_EXT_TXT:
	case BORA_EXT_VCF:
	case BORA_EXT_VCD:
	case BORA_EXT_VCS:
	case BORA_EXT_VMG:
	case BORA_EXT_VNT:
	case BORA_EXT_DOCX:

	case BORA_EXT_XLS:
	case BORA_EXT_XLSX:
#ifdef IMPORT_CSV
	case BORA_EXT_CSV:
#endif
#ifdef IMPORT_TSV
	case BORA_EXT_TSV:
#endif
		gMemoryMap.MEM_MAP_FLAG = 1;	// forward
		break;

// reverse
	case BORA_EXT_PDF:
	case BORA_EXT_PPT:
//	case BORA_EXT_XLS:
	case BORA_EXT_JPG:
	case BORA_EXT_JPEG:
	case BORA_EXT_BMP:
	case BORA_EXT_GIF:
	case BORA_EXT_PNG:
	case BORA_EXT_TIF:
	case BORA_EXT_TIFF:
	case BORA_EXT_WMF:
	case BORA_EXT_EMF:
	case BORA_EXT_WMZ:
	case BORA_EXT_EMZ:
	case BORA_EXT_WBMP:
	case BORA_EXT_PPTX:
//	case BORA_EXT_XLSX:
	default:
		gMemoryMap.MEM_MAP_FLAG = 0;	// reverse
		break;
	}	
}

B_MEMORY * GetBlockByIndex(BrINT32 nIndex)
{
	if (gpMemPool == NULL)
		return BrNULL;

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	return gpMemPool->m_pBoraHeapMem[nIndex];
#else //USE_MULTI_MEMORY_BLOCK_LIST
	return gpMemPool->m_pBoraHeapMem;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
}

B_MEMORY * GetNotUseBlockByIndex(BrINT32 nIndex)
{
	if (gpMemPool == NULL)
		return BrNULL;

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	return gpMemPool->m_pNotUseBlock[nIndex];
#else //USE_MULTI_MEMORY_BLOCK_LIST
	return gpMemPool->m_pNotUseBlock;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
}

void InitMemoryMap(BrUINT64& nTotalSize)
{
	InitMemoryMap_MT(gMemoryMap, nTotalSize);
}

//Andrew
//convertBStringToChar�� ȣ�� �󵵰� �ʹ� ���� vector�� ��Ƽ� ���� ũ�⸦ ��û�ϴ� ��� free���� �ʰ� ��Ȱ���ϵ��� ����
//Ž�� �ð��� �ҿ�� �� ������ 100���� �̻� ȣ��Ǵ� Ƚ���� 70ȸ�� ����
#include <vector>
typedef struct _tagMemAllocInfo
{
	void* ptr;
	int nSize;
	bool bAlloc;
}MemAllocInfo;
std::vector<MemAllocInfo > g_memList;	
void* FindSysAllocPtr(int nSize)
{
	void* out = BrNULL;
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		out = (BrCHAR*)BrSysCalloc(nSize, sizeof(BrCHAR));
	}
	else {
	for (int n=0;n<g_memList.size();n++)
	{
		MemAllocInfo info = g_memList.at(n);
		if ( !info.bAlloc && info.nSize == nSize )
		{
			out = (BrCHAR*)info.ptr;
			memset(out, 0, info.nSize);
			info.bAlloc = true;
			g_memList[n] = info;			
			break;
		}
	}
	if ( !out )
	{
		out = (BrCHAR*)BrSysCalloc(nSize, sizeof(BrCHAR));			
		if ( out )
		{
			MemAllocInfo info = {out, nSize, true};
			g_memList.push_back(info);
			}
		}
	}
	return out;
}
bool FindSysFreePtr(void* p)
{	
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		BrSysFree(p);
		return true;
	}
	else {
		bool bFind = false;
		for (int n = 0; n < g_memList.size(); n++)
		{
		MemAllocInfo info = g_memList.at(n);
		if ( info.ptr == p )
		{
			info.bAlloc = false;
			g_memList[n] = info;
			bFind = true;
			break;
		}
	}
	if ( !bFind )
		BrSysFree(p);
	return bFind;
	}
}
void ReleaseMemList()
{
	g_memList.clear();
}

void InitMemPool()
{
	memory::common_heap_table_facade_t::purge_memory_all();
#ifdef BRMEMORY_DEBUG_TRACE
	InitMemPool_MT(&gpMemPool, (void**)&g_pHeapTrace);
#else //BRMEMORY_DEBUG_TRACE
	InitMemPool_MT(&gpMemPool, BrNULL);
#endif //BRMEMORY_DEBUG_TRACE	
}

void EndMemPool()
{		
#ifdef BRMEMORY_DEBUG_TRACE
	EndMemPool_MT(&gpMemPool, (void**)&g_pHeapTrace);
#else //BRMEMORY_DEBUG_TRACE
	EndMemPool_MT(&gpMemPool);
#endif //BRMEMORY_DEBUG_TRACE
}

#ifdef BRMEMORY_DEBUG_TRACE
void EndMemPoolEx(B_MEM_POOL** lpMemPool, void** lpHeapTracePtr)
{
	if( *lpMemPool)
		BFree(*lpMemPool);
	*lpMemPool = BrNULL;
	BHeapTrace** lpHeapTrace = (BHeapTrace**)lpHeapTracePtr;
	if(*lpHeapTrace)
		delete *lpHeapTrace;
	*lpHeapTrace = BrNULL;
}
#else //BRMEMORY_DEBUG_TRACE
void EndMemPoolEx(B_MEM_POOL** lpMemPool)
{
	if( *lpMemPool)
		BFree(*lpMemPool);
	*lpMemPool = BrNULL;
}
#endif //BRMEMORY_DEBUG_TRACE

void* BoraSysMemInit(B_MEM_POOL	*pMemPool)
{
	B_MEMORY*&	pBlock = pMemPool->m_pBoraSysMem;

	pBlock = AllocMemBlock_MT(pBlock, gMemoryMap.BORA_SYSMEM_SIZE, pMemPool);

	if(!pBlock)
		BRTERMINATE(g_BoraThreadAtom.m_nMemoryErrorCode, "", PO_PUBLIC_CLASS);

	return pMemPool->m_pBoraSysMem;
}

void* BoraEventMemInit()
{
	B_MEMORY* pBoraEventMem;
	if( !(pBoraEventMem = (B_MEMORY*)BMallocEx(EVENT_MEM_SIZE)) )
		BRTERMINATE(kPoErrMemoryInitial, "", PO_PUBLIC_CLASS);

	memset((BrCHAR*)pBoraEventMem, 0, EVENT_MEM_SIZE);


	pBoraEventMem->_memory_size = (EVENT_MEM_SIZE - BrSizeOf(B_MEMORY))&~BLOCK_MASK; // 8�� ����� ����
	pBoraEventMem->_sys_memory = ((BrCHAR*)pBoraEventMem + BrSizeOf(B_MEMORY));
	pBoraEventMem->_sys_memory_sptr = pBoraEventMem->_sys_memory;
	pBoraEventMem->_sys_memory_eptr = (BrCHAR*)pBoraEventMem->_sys_memory + pBoraEventMem->_memory_size;
	pBoraEventMem->_sys_free = (PACKET *)pBoraEventMem->_sys_memory;
	pBoraEventMem->_sys_free->packet_size = pBoraEventMem->_memory_size - BLOCK_OVERHEAD;
	pBoraEventMem->_sys_free->last_ptr_nearby = BrNULL;
	pBoraEventMem->_sys_free->last_ptr	  = BrNULL;
	pBoraEventMem->_sys_free->size_ptr	  = BrNULL;

	gpBoraEventMem = pBoraEventMem;
	return pBoraEventMem;
}

void* BoraThreadMemInit()
{
	B_MEMORY* pThreadStackMem;
	if( !(pThreadStackMem = (B_MEMORY*)BMallocEx(THREAD_MEM_SIZE)) ) // Only BoraMainThread
		BRTERMINATE(kPoErrMemoryInitial, "", PO_PUBLIC_CLASS);

	memset((BrCHAR*)pThreadStackMem, 0, THREAD_MEM_SIZE);


	pThreadStackMem->_memory_size = ((THREAD_MEM_SIZE - BrSizeOf(B_MEMORY)))&~BLOCK_MASK; // 8�� ����� ����
	pThreadStackMem->_sys_memory = ((BrCHAR*)pThreadStackMem + BrSizeOf(B_MEMORY));
	pThreadStackMem->_sys_memory_sptr = pThreadStackMem->_sys_memory;
	pThreadStackMem->_sys_memory_eptr = (BrCHAR*)pThreadStackMem->_sys_memory + pThreadStackMem->_memory_size;
	pThreadStackMem->_sys_free = (PACKET *)pThreadStackMem->_sys_memory;
	pThreadStackMem->_sys_free->packet_size = pThreadStackMem->_memory_size - BLOCK_OVERHEAD;
	pThreadStackMem->_sys_free->last_ptr_nearby = BrNULL;
	pThreadStackMem->_sys_free->last_ptr	  = BrNULL;
	pThreadStackMem->_sys_free->size_ptr	  = BrNULL;

	gpBoraThreadStackMem = pThreadStackMem;
	return pThreadStackMem;
}

void BoraThreadMemFreeEx(B_MEMORY** lpThreadMem)
{
	if( *lpThreadMem )
		BFreeEx(*lpThreadMem);

	*lpThreadMem = BrNULL;
}

void BoraThreadMemFree()
{
	BoraThreadMemFreeEx(&gpBoraThreadStackMem);
}

void BoraEventMemFreeEx(B_MEMORY** lpEventMem)
{
	if( *lpEventMem )
		BFreeEx(*lpEventMem);

	*lpEventMem = BrNULL;
}

void BoraEventMemFree()
{
	BoraEventMemFreeEx(&gpBoraEventMem);
}

void BoraSysMemFreeEx(B_MEM_POOL* pMemPool)
{
	ReleaseMemList();
	if(pMemPool->m_pBoraSysMem)
	{
		do {
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraSysMem, pMemPool->m_pBoraSysMem);
		} while(pMemPool->m_pBoraSysMem);
	}

	if(pMemPool->m_pBoraLargeSysHeap)
	{
		do {
			BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeSysHeap, pMemPool->m_pBoraLargeSysHeap, pMemPool);			
		} while(pMemPool->m_pBoraLargeSysHeap);
	}
}

void BoraSysMemFree(B_MEM_POOL* pMemPool)
{
	BoraSysMemFreeEx(pMemPool);	
}

void BoraHeapMemFreeEx(B_MEM_POOL* pMemPool)
{
	memory::common_heap_table_facade_t::purge_memory_all();
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
	{
		if(pMemPool->m_pBoraHeapMem[i])
		{
			do 
			{
				BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem[i], pMemPool->m_pBoraHeapMem[i]);
			} while(pMemPool->m_pBoraHeapMem[i]);
		}
	}
#else //USE_MULTI_MEMORY_BLOCK_LIST
	if(pMemPool->m_pBoraHeapMem)
	{
		do 
		{
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem, pMemPool->m_pBoraHeapMem);
		} while(pMemPool->m_pBoraHeapMem);
	}
#endif //USE_MULTI_MEMORY_BLOCK_LIST

	if(pMemPool->m_pBoraLargeHeap)
	{
		do 
		{
			BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeHeap, pMemPool->m_pBoraLargeHeap, pMemPool);			
		} while(pMemPool->m_pBoraLargeHeap);
	}
}

void BoraHeapMemFree()
{
	memory::common_heap_table_facade_t::purge_memory_all();
	BoraHeapMemFree_MT(gpMemPool);	
}

extern BrINT8 getDocExt();

/*
*	@author 	Andrew
*	@date  		2016.11.09
*	@params	BrUINT $nTotalMemSize : Byte������ ũ��
*	@brief  	�޸�Ǯ�� ��ü ũ��(Byte����)
*/
void SetTotalMemorySize(BrUINT64 nTotalMemSize)
{
	gpMemPool->m_available_memory_size = nTotalMemSize;
}

void GetCurrentMemoryInfo(BrUINT64 *available_memory, BrUINT64 *max_packet, bool forcedGet)
{
	*max_packet = *available_memory = 0;
	unsigned long long nTotalMemorySize = g_pBInterfaceHandle->GetTotalMemorySizes();	
	if ( nTotalMemorySize == 0 )
	{
		//���� �ý����� ������ �޸� ũ��
		//forcedGet==true�� ��� ������ ����
		if ( forcedGet )			
			gpMemPool->m_available_memory_size = PoGetAvailableMemorySizes();		
		*max_packet = *available_memory = gpMemPool->m_available_memory_size;
	}
	else
	{
		B_MEM_POOL*			pMemPool = gpMemPool;
	#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		B_MEMORY*			pBlock = BrNULL;
		B_MEMORY*			pOldBlock = BrNULL;
		//Coverity 95522
		//*available_memory = BrMAX(0, (BrUINT64)((((nTotalMemorySize - GetAllocatedMemory()) - BrSizeOf(B_MEMORY))&~BLOCK_MASK) - BLOCK_OVERHEAD));
		*available_memory = (BrUINT64)((((nTotalMemorySize - GetAllocatedMemory()) - BrSizeOf(B_MEMORY))&~BLOCK_MASK) - BLOCK_OVERHEAD);

		for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
		{
			pBlock = pMemPool->m_pBoraHeapMem[i];
	#ifdef USE_ADVANCED_BRMALLOC
			if (!pBlock) continue;
	#endif //USE_ADVANCED_BRMALLOC
			pOldBlock = pBlock;
			do
			{
				*available_memory += pBlock->_total_free_size;
				*max_packet = BrMAX(pBlock->_max_packet_size, *max_packet);
				pBlock = pBlock->_next_memory_block;
			}while(pBlock != pOldBlock);
		}
	#else //USE_MULTI_MEMORY_BLOCK_LIST
		B_MEMORY*			pBlock = pMemPool->m_pBoraHeapMem;
		B_MEMORY*			pOldBlock = pBlock;
		max_packet = available_memory = BrMAX(0, (BrUINT64)((((nTotalMemorySize - GetAllocatedMemory()) - BrSizeOf(B_MEMORY))&~BLOCK_MASK) - BLOCK_OVERHEAD));

		do
		{
			*available_memory += pBlock->_total_free_size;
			*max_packet = BrMAX(pBlock->_max_packet_size, *max_packet);
			pBlock = pBlock->_next_memory_block;
		}while(pBlock != pOldBlock);
	#endif //USE_MULTI_MEMORY_BLOCK_LIST
	}
}

BrUINT64 GetCurrentAvailableMemory(bool forcedGet)
{
	BrUINT64 available_memory = 0, max_packet = 0;
	GetCurrentMemoryInfo(&available_memory, &max_packet, forcedGet);
	return available_memory;
}

BrUINT64 GetAvailableMemorySize(void)
{
//Andrew C.Lee �÷����� ���� ������ �޸� ũ�⸦ ��� �´�.
	return gpMemPool->m_available_memory_size;
}

/*
*	@author 	Andrew
*	@date  		2016.11.09
*	@return 	BrUINT64 : alloc�� �޸� ũ��
*	@brief  	���� ���� ��ü �޸� ũ��(byte)
*/
BrUINT64 GetAllocatedMemory()
{
	return gpMemPool->m_allocated_memory_size;
}

//#include "cmnFunc.h"
BrBOOL CheckMemoryLimit(BrUINT64 *pAvailableMemory, BrUINT64 *pLimitMemory, BrUINT64 *pScreenBufferSize)
{
	BrUINT64 available_memory = 0, max_packet = 0;
	GetCurrentMemoryInfo(&available_memory, &max_packet, false);
	
	BrUINT64 nScreenBufferSize = getDeviceScreenWidth()*getDeviceScreenHeight()*(BrMAX(8, gnBits)/8);
	if( available_memory < (BrUINT64)(nScreenBufferSize + MEM_SZ_512K))
		return BrTRUE;

	// �ּ� �޸� ���� ����
	// pdf(pdf3)�� �ƴ� ��� : ��ü �޸��� * 0.25 �� 1MB �߿� ū���� 2MB�߿� ���� ��
	// pdf3�� ��� : ��ü �޸��� * 0.25 �� 1MB �߿� ū���� ȭ��ũ�� ����*2�� 2MB�߿� ���� ��
	// �߰� : ȭ�� ���� ũ���� �޸� 
	BrUINT64 nLimitMemory = BrMIN(MEM_SZ_2M + (getDocExt() == BORA_EXT_PDF?(getDeviceScreenWidth()*getDeviceScreenHeight()*(BrMAX(8, gnBits)/8)*1)*2:0), BrMAX((BrUINT64)((BrDOUBLE)available_memory*0.25f), MEM_SZ_1M));
#if defined(PAGEBITMAP_EXTEND)
	Painter* pPainter = getPainter();
	if(IsEditorMode(pPainter) || IsDirectRenderType(pPainter))
		nLimitMemory += nScreenBufferSize;
	else
	{
		BrUINT64 necessary_size = nScreenBufferSize * 10;
		BrINT32 used_size;
			used_size = pPainter->pageImg.m_pMap->UsedImageBufferSize();

		nLimitMemory += (necessary_size - used_size);

	}
#else
	nLimitMemory += nScreenBufferSize;
	//	BrTrace("MINIMUM_OPERATION_MEMSIZE[%d]", nLimitMemory);
#endif

	if (pAvailableMemory)
		*pAvailableMemory = available_memory;
	if (pLimitMemory)
		*pLimitMemory = nLimitMemory;
	if (pScreenBufferSize)
		*pScreenBufferSize = nScreenBufferSize;

	return (available_memory <  nLimitMemory);
}

BrBOOL CheckExcelMemoryLimit(BrBOOL bViewMode)
{
	BrUINT64 available_memory = 0, max_packet = 0;
	GetCurrentMemoryInfo(&available_memory, &max_packet, false);
	
	BrUINT64 nScreenBufferSize = getDeviceScreenWidth()*getDeviceScreenHeight()*(BrMAX(8, gnBits)/8);
	if( available_memory < (BrUINT64)(nScreenBufferSize + MEM_SZ_512K))
		return BrTRUE;

	// �ּ� �޸� ���� ����
	// pdf(pdf3)�� �ƴ� ��� : ��ü �޸��� * 0.25 �� 1MB �߿� ū���� 2MB�߿� ���� ��
	// pdf3�� ��� : ��ü �޸��� * 0.25 �� 1MB �߿� ū���� ȭ��ũ�� ����*2�� 2MB�߿� ���� ��
	// �߰� : ȭ�� ���� ũ���� �޸� 
	BrUINT64 nLimitMemory = BrMIN(MEM_SZ_10M, BrMAX((BrUINT64)((BrDOUBLE)available_memory*0.25f), MEM_SZ_1M));

#if defined(PAGEBITMAP_EXTEND)
	Painter* pPainter = getPainter();
	if (bViewMode)
	{
		BrUINT64 necessary_size = nScreenBufferSize * 10;
		BrINT32 used_size;
			used_size = pPainter->pageImg.m_pMap->UsedImageBufferSize();

		nLimitMemory += (necessary_size - used_size);
	}
	else
#endif

	{
		nLimitMemory += nScreenBufferSize;
	}
	//BrTrace("MINIMUM_OPERATION_MEMSIZE[%d]", nLimitMemory);

	return (available_memory <  nLimitMemory);
}

#ifdef BWP_EDITOR
BrBOOL	CheckEditorMemoryLimit()
{
	return CheckMemoryLimit();
}
#endif

BrUINT64 GetMaxFreeMemoryPacketSize(void)
{
	BrUINT64 available_memory = 0, max_packet = 0;
	GetCurrentMemoryInfo(&available_memory, &max_packet, false);
		
	return BrMAX(max_packet, available_memory);
}

#if defined(RENDERING_WITH_BORATHREAD)
void BrFreeByThreadID()
{
#if 0
	BrINT32 nThreadID = (BrGetThreadID() << 1) ;
	register PACKET*	current;
	register PACKET*	next;
	register B_MEMORY*	pBlock;
	register B_MEMORY*	pOldBlock;
	BrBOOL bMerge;

	for(int i=0; i<MEM_BLOCK_COUNT; i++)
	{
		pOldBlock = pBlock = gpMemPool->m_pBoraHeapMem[i];
		BRTHREAD_ASSERT(pBlock);

		current = (PACKET *)pBlock->_sys_memory;
		pBlock->_sys_free = BrNULL;

		do 
		{
			do
			{			
				if(  (current->packet_size&nThreadID)==nThreadID || !(current->packet_size & BLOCK_USED))
				{
					bMerge = BrFALSE;
					current->packet_size &= ~BLOCK_SIZE_MASK;
					next = (PACKET*)((char*)current + current->packet_size + BLOCK_OVERHEAD);
					while(next < (PACKET*)pBlock->_sys_memory_eptr && ( (next->packet_size&nThreadID) == nThreadID || !(next->packet_size & BLOCK_USED)))
					{
#if defined(BRTHREAD_MEMORY_DEBUG)				
						if(next->packet_size & BLOCK_USED)
							BMemoryTrace("%s(%d): next=0x%x, packet_size=0x%x, alloc_count=%d\n", 
							next->dbginfo.filename, next->dbginfo.linenumber, next, next->packet_size, next->dbginfo.alloc_count);
#endif					
						bMerge = BrTRUE;
						next->packet_size &= ~BLOCK_SIZE_MASK;
						current->packet_size+= next->packet_size + BLOCK_OVERHEAD;
						next = (PACKET*)((char*)next + (next->packet_size + BLOCK_OVERHEAD));
					}

					if(bMerge && next < (PACKET*)pBlock->_sys_memory_eptr)
					{
						next->last_ptr_nearby = current;
					}
					br_minsert(pBlock, current);
					current = next;
				}
				else
					current = (PACKET*)((char*)current + ((current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
			}while(current < (PACKET*)pBlock->_sys_memory_eptr);

			pBlock = pBlock->_next_memory_block;
		} while(pOldBlock != pBlock);
	}

	BRTHREAD_DETECT_MEM_CORRUPTION;
#endif
}

// ������ Free������ ����.
void BrFreeByThreadIDForRender()
{
#if 0
#if defined(_THREAD_DEBUG)
	BrINT32 nThreadID = (BrGetThreadID() << 1) ;
	register PACKET*	current;
	register B_MEMORY*	pBlock;
	register B_MEMORY*	pOldBlock;

	BRTHREAD_DETECT_MEM_CORRUPTION;

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
	{
		pOldBlock = pBlock = gpMemPool->m_pBoraHeapMem[i];
		if(pBlock)
		{
			do 
			{
				current = (PACKET *)pBlock->_sys_memory;
				do
				{			

					if( (current->packet_size&nThreadID)==nThreadID )
					{
						BRTHREAD_ASSERT(current->packet_size & BLOCK_USED);
#if defined(BRTHREAD_MEMORY_DEBUG)
						if( !strstr(current->dbginfo.filename, "barray.cpp") && !strstr(current->dbginfo.filename, "bmvstruct.cpp") )
						{
							char filename[512];
							strncpy(filename, current->dbginfo.filename, 512);
							filename[512-1] = BrNULL;
							//BMemoryTrace("%s(%d): current=0x%x, packet_size=0x%x, alloc_count=%d\n", filename, current->dbginfo.linenumber, current, current->packet_size, current->dbginfo.alloc_count);
						}
#endif
						current->packet_size &= ~THREADID_MASK;	// ID clear
					}
					current = (PACKET*)((char*)current + (current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD);

				}while(current < (PACKET*)pBlock->_sys_memory_eptr);
				pBlock = pBlock->_next_memory_block;

			} while(pBlock != pOldBlock);
		} //if
	}
#else //USE_MULTI_MEMORY_BLOCK_LIST
	pOldBlock = pBlock = gpMemPool->m_pBoraHeapMem;
	if(pBlock)
	{
		do 
		{
			current = (PACKET *)pBlock->_sys_memory;
			do
			{			

				if( (current->packet_size&nThreadID)==nThreadID )
				{
					BRTHREAD_ASSERT(current->packet_size & BLOCK_USED);
#if defined(BRTHREAD_MEMORY_DEBUG)
					if( !strstr(current->dbginfo.filename, "barray.cpp") && !strstr(current->dbginfo.filename, "bmvstruct.cpp") )
					{
						char filename[512];
						strncpy(filename, current->dbginfo.filename, 512);
						filename[512-1] = BrNULL;
						//BMemoryTrace("%s(%d): current=0x%x, packet_size=0x%x, alloc_count=%d\n", filename, current->dbginfo.linenumber, current, current->packet_size, current->dbginfo.alloc_count);
					}
#endif
					current->packet_size &= ~THREADID_MASK;	// ID clear
				}
				current = (PACKET*)((char*)current + (current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD);

			}while(current < (PACKET*)pBlock->_sys_memory_eptr);
			pBlock = pBlock->_next_memory_block;

		} while(pBlock != pOldBlock);
	} //if
#endif //USE_MULTI_MEMORY_BLOCK_LIST

#endif //_THREAD_DEBUG
#endif
}

void BrMemClearThreadID()
{
#if 0
#if defined(_THREAD_DEBUG)
	byte ID = BrGetThreadID() << 1;
	register PACKET*	current;
	register B_MEMORY*	pBlock;
	register B_MEMORY*	pOldBlock;

#if defined(BRTHREAD_MEMORY_DEBUG)
	BRTHREAD_PRINT_THREAD_ID(ID>>1);
#endif

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
	{
		pOldBlock = pBlock = gpMemPool->m_pBoraHeapMem[i];
		if(pBlock)
		{
			do 
			{
				current = (PACKET *)pBlock->_sys_memory;

				while(current < (PACKET*)pBlock->_sys_memory_eptr)
				{
					if( (current->packet_size&ID) == ID )
					{
						//BRTHREAD_PRINT_ALLOC_MEM(current);
						current->packet_size &= ~THREADID_MASK;
					}
					current = (PACKET*)((char*)current + ((current->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
				}

				pBlock = pBlock->_next_memory_block;
			} while(pBlock != pOldBlock);
		}
	}
#else //USE_MULTI_MEMORY_BLOCK_LIST
	pOldBlock = pBlock = gpMemPool->m_pBoraHeapMem;
	if(pBlock)
	{
		do 
		{
			current = (PACKET *)pBlock->_sys_memory;

			while(current < (PACKET*)pBlock->_sys_memory_eptr)
			{
				if( (current->packet_size&ID) == ID )
				{
					//BRTHREAD_PRINT_ALLOC_MEM(current);
					current->packet_size &= ~THREADID_MASK;
				}
				current = (PACKET*)((char*)current + ((current->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
			}

			pBlock = pBlock->_next_memory_block;
		} while(pBlock != pOldBlock);
	}
#endif //USE_MULTI_MEMORY_BLOCK_LIST

#if defined(BRTHREAD_MEMORY_DEBUG)
	THREAD_TRACE(("----- End print Alloc memory\n"));
#endif

#endif // THREAD_DEBUG
#endif
}

void BrMemClearThreadIDEx(void *packet)
{
#if defined(_THREAD_DEBUG)
	register PACKET *current;
	B_MEM_POOL* pMemPool = gpMemPool;

	if(!packet)	return;

	current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */

	// �̹� Free �ߴ� packet�̳� ������ ���� Packet�� ���.
	if(!(current->packet_size & BLOCK_USED))
	{
		// �̹� Free �ߴ� �޸𸮰ų� garbage packet �Դϴ�.
		// pointer�� �ʱ�ȭ(NULL)�� �ʿ��� ���� �ֽ��ϴ�.	
		BRTHREAD_ASSERT(BrFALSE);
		return;
	}

	current->packet_size &= ~THREADID_MASK;		/* CLEAR THREAD ID ONLY */

#if defined(BRTHREAD_MEMORY_DEBUG)
	current->dbginfo.leakcheck_id = 0;
#endif

#endif // THREAD_DEBUG
}
#endif //RENDERING_WITH_BORATHREAD


////thread memory manage
B_MEMORY * GetThreadBlockBySize(BrINT32 size)
{
	if( size >= MIN_THREAD_STACK_SIZE )
		return gpBoraThreadStackMem;
	else
		return gpBoraEventMem;
}

B_MEMORY * GetThreadBlockByPtr(void* ptr)
{
	if( gpBoraThreadStackMem && gpBoraThreadStackMem->_sys_memory_sptr <= ptr && ptr <= gpBoraThreadStackMem->_sys_memory_eptr )
		return gpBoraThreadStackMem;
	if( gpBoraEventMem && gpBoraEventMem->_sys_memory_sptr <= ptr && ptr <= gpBoraEventMem->_sys_memory_eptr )
		return gpBoraEventMem;

	return BrNULL;
}

BrLPVOID BrFileMapMalloc(BrINT32 size)
{
	return BrNULL;
}

void BrFileMapFree(BrLPVOID ptr)
{
	if( ptr )
		BFreeEx(ptr);
	gpMemPool->m_pBoraFileMem = BrNULL;
}


BrCHAR* ReplaceMemSize(BrUINT64 nMemSize, BrCHAR* str, int nSize)
{
	BrDOUBLE MB = (BrDOUBLE)nMemSize / (1024*1024);
	BrDOUBLE KB = (BrDOUBLE)nMemSize / 1024;
	if ((BrINT32)MB > 0)
		sprintf_s(str, nSize, "%.2fMByte", MB);
	else if((BrINT32)KB > 0)
		sprintf_s(str, nSize, "%.1fKByte", KB);
	else
		sprintf_s(str, nSize, "%lluByte", nMemSize);

	return str;
}

#if defined(DYNAMIC_MEMORY_BLOCK)
bool BrDetectMemCorruption()
{
#ifdef _THREAD_DEBUG
	register PACKET*	last;
	register PACKET*	current;
	register PACKET*	next;
	register B_MEMORY*	pBlock;
	B_MEMORY*			pOldBlock;
	BrUINT32			packet_max_size;
	B_MEM_POOL* pMemPool = gpMemPool;
	BrUINT32			block_max_size;
#ifdef USE_MCORE_MEMPOOL
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	const BrUINT32		block_cnt = SBLOCKLIST_COUNT*2+1;	// m_pBoraHeapMem + m_pNotUseBlock + m_pBoraSysMem
	B_MEMORY*			block[block_cnt] = {0,};
	for(int i=0; i<SBLOCKLIST_COUNT; i++)
	{
		block[i] = pMemPool->m_pBoraHeapMem[i];
		block[SBLOCKLIST_COUNT + i] = pMemPool->m_pNotUseBlock[i];
	}
	block[block_cnt-1] = pMemPool->m_pBoraSysMem;
#else //USE_MULTI_MEMORY_BLOCK_LIST
	const BrUINT32		block_cnt = 3;
	B_MEMORY*			block[block_cnt] = {pMemPool->m_pBoraHeapMem, pMemPool->m_pNotUseBlock, pMemPool->m_pBoraSysMem};
#endif //USE_MULTI_MEMORY_BLOCK_LIST

	bool bRet = false;
	for(int i=0; i<block_cnt; i++)
	{
		pOldBlock = pBlock = block[i];
		if(!pBlock)	continue;

		//check alloc block 
		do 
		{
			last = (PACKET*)BrNULL;
			current = (PACKET *)pBlock->_sys_memory;
			packet_max_size = 0;
#ifdef USE_ADVANCED_BRMALLOC
			if((i<SBLOCKLIST_COUNT*2 && i>=SBLOCKLIST_COUNT)&&(pBlock->_max_packet_size < pBlock->_small_max_packet_size))
				block_max_size = pBlock->_small_max_packet_size;
			else
				block_max_size = pBlock->_max_packet_size;
#else
			block_max_size = pBlock->_max_packet_size;
#endif
			do
			{
				bRet = (current->packet_size&~BLOCK_SIZE_MASK) && ((current->packet_size&~BLOCK_SIZE_MASK)&BLOCK_MASK) == 0;
				BRTHREAD_ASSERT( bRet ); //// 8�� ��� �˻�
				if ( !bRet )
					return true;
				next = (PACKET*)((char*)current + ((current->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));

				/*
				=======================  �Ʒ� ��Ȳ �߻� �� ���� �ϼ���.==============================

				* �޸𸮸� �����ؼ� ����� ���, �Ʒ��� ASSERT ���� �ɸ��� �˴ϴ�.

				1.	�ǽ��� ���� �ڵ� ���ķ� BRTHREAD_DETECT_MEM_CORRUPTION�� ����Ͻø�
				������ �߻� ���θ� Ȯ�� �� �� �ֽ��ϴ�.

				2.	debug.hpp�� BRTHREAD_MEMORY_DEBUG �� Ǯ�� �ٽ� ���� �� ������ ���ø�,
				packet ����� mdbginfo�� ������ filename�� linenumber�� ������ �ֽ��ϴ�.

				3.	���� �� ��Ȳ���ε� �ذ��� �ȵȴٸ� ���� ������ �����Ͻð� ������Ͻø� �˴ϴ�.
				$(ProjectRoot)/Document/�޸� ���� ����� ���.docx
				*/
				if(pBlock->_sys_memory_sptr != current && next != (PACKET*)pBlock->_sys_memory_eptr)
				{
					bRet = next->last_ptr_nearby == current;
					BRTHREAD_ASSERT(bRet);
					if ( !bRet )
						return true;
				}

				if( !(current->packet_size&BLOCK_USED) )
					packet_max_size = BrMAX(packet_max_size, current->packet_size);

				last = current;
				current = next;

				if(current < (PACKET*)pBlock->_sys_memory_eptr)
				{					
					PACKET* verify_next = (PACKET*)((char*)next + ((next->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
					if(verify_next != (PACKET*)pBlock->_sys_memory_eptr) // ������ ������ packet�� eptr�� ����.
					{
						if(verify_next->last_ptr_nearby != next)
							THREAD_TRACE(("verify_next = 0x%x, next = 0x%x", verify_next, next));

						bRet = verify_next->last_ptr_nearby == next;
						BRTHREAD_ASSERT(bRet);
						if ( !bRet )
							return true;
					}
				}				
			}while(current < (PACKET*)pBlock->_sys_memory_eptr);

			bRet = packet_max_size == block_max_size;
			BRTHREAD_ASSERT(bRet);
			if ( !bRet )
				return true;

			//check free block 
			{
				register PACKET		*current;
				if ( pBlock->_small_sys_free )
				{
					current = pBlock->_small_sys_free;			
					while (current )
					{
						bRet = current->packet_size>0;
						BRTHREAD_ASSERT(bRet);
						if ( !bRet )
							return true;
						current = current->size_ptr;			
					}
				}

				if ( pBlock->_sys_free )
				{
					current = pBlock->_sys_free;			
					while (current )
					{
						bRet = current->packet_size>0;
						BRTHREAD_ASSERT(bRet);
						if ( !bRet )
							return true;
						current = current->size_ptr;								
					}
				}
			}
			pBlock = pBlock->_next_memory_block;
		}while(pOldBlock != pBlock);		
	}
#endif//#ifdef _THREAD_DEBUG	
	return false;
}

void BrViewMemmgrStatus(BrINT32 nThreshold)
{
#ifdef _THREAD_DEBUG
	register B_MEMORY*	pBlock;
	B_MEMORY*			pOldBlock;

	BrUINT32 nSmallBlockCount = 0;
	BrUINT32 nSmallBlockSize = 0;
	BrUINT32 nLargeBlockCount = 0;
	BrUINT32 nLargeBlockSize = 0;
	BrUINT64 nFreeMemSize = 0;
	BrUINT64 nMaxFreeMemoryPacketSize = 0;

	pBlock = pOldBlock = GetBlockByIndex(0, gpMemPool);

	if(pBlock)
	{		
		nMaxFreeMemoryPacketSize = GetMaxFreeMemoryPacketSize();

		do
		{
			nFreeMemSize += pBlock->_total_free_size;
			if ((BrUINT32)pBlock->_actual_size == gMemoryMap.BORA_HEAPMEM_SIZE)
			{
				nSmallBlockCount++;
				nSmallBlockSize += pBlock->_actual_size;
			}
			else
			{
				nLargeBlockCount++;
				nLargeBlockSize += pBlock->_actual_size;
			}

			pBlock = pBlock->_next_memory_block;
		}while(pBlock != pOldBlock );

		LARGE_PACKET* pLargePacket = gpMemPool->m_pBoraLargeHeap;
		while(pLargePacket)
		{
			nLargeBlockCount++;
			nLargeBlockSize += pLargePacket->_actual_size;

			pLargePacket = pLargePacket->_next_large_pack;
		}

#if defined(DYNAMIC_FONTMEM_BLOCK)
		pLargePacket = gpMemPool->m_pBoraLargeSysHeap;
		while(pLargePacket)
		{
			nLargeBlockCount++;
			nLargeBlockSize += pLargePacket->_actual_size;

			pLargePacket = pLargePacket->_next_large_pack;
		}

		pBlock = pOldBlock = gpMemPool->m_pBoraSysMem;
		if(pBlock)
		{
			do
			{
				if ((BrUINT32)pBlock->_actual_size == gMemoryMap.BORA_SYSMEM_SIZE)
				{
					nSmallBlockCount++;
					nSmallBlockSize += pBlock->_actual_size;
				}
				else
				{
					nLargeBlockCount++;
					nLargeBlockSize += pBlock->_actual_size;
				}

				pBlock = pBlock->_next_memory_block;
			}while(pBlock != pOldBlock );
		}
#endif
	}
	nFreeMemSize += GetAvailableMemorySize();

	BrCHAR strAvailSize[32] = {0,};
	BrCHAR strAllocSize[32] = {0,};
	BrCHAR strSmallSize[32] = {0,};
	BrCHAR strLargeSize[32] = {0,};
	BrCHAR strFreeSize[32]  = {0,};
	BrCHAR strMaxFreeSize[32] = {0,};

	ReplaceMemSize(GetAvailableMemorySize(), strAvailSize, sizeof(strAvailSize));
	ReplaceMemSize(GetAllocatedMemory(), strAllocSize, sizeof(strAllocSize));
	ReplaceMemSize(nSmallBlockSize, strSmallSize, sizeof(strSmallSize));
	ReplaceMemSize(nLargeBlockSize, strLargeSize, sizeof(strLargeSize));
	ReplaceMemSize(nFreeMemSize, strFreeSize, sizeof(strFreeSize));
	ReplaceMemSize(nMaxFreeMemoryPacketSize, strMaxFreeSize, sizeof(strMaxFreeSize));

	BTrace("##### Memory manager status view start #####\n");
	BTrace("Total Memory Size : %s, Allocated Memory Size : %s\n", strAvailSize, strAllocSize);
	BTrace("SmallBlock Count(%d) Size : %s\n", nSmallBlockCount, strSmallSize);
	BTrace("LargeBlock Count(%d) Size : %s\n", nLargeBlockCount, strLargeSize);
	BTrace("Total Free Memory Size : %s, Max Free Packet Size : %s\n", strFreeSize, strMaxFreeSize);


	if(nThreshold != 0)
	{
		register PACKET*	current;
		BrINT32 packet_size;
		BrCHAR strSize[32] = { 0, };

		pBlock = pOldBlock = GetBlockByIndex(0, gpMemPool);
		if(pBlock)
		{		
			do
			{
				current = (PACKET *)pBlock->_sys_memory;
				do
				{  
					packet_size = current->packet_size&~BLOCK_USED;
					if( current->packet_size&BLOCK_USED && packet_size >= nThreshold )
					{
#if defined(BRTHREAD_MEMORY_DEBUG)
						BTrace("%s(%d) : ptr=0x%x, size=%d(%s)\n", current->dbginfo.filename, current->dbginfo.linenumber, (BrCHAR*)current + BLOCK_OVERHEAD, packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));
#else
						BTrace("ptr=0x%x : size=%d(%s)\n", (((BrCHAR*)current) - BLOCK_OVERHEAD), packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));
#endif
					}

					current = (PACKET*)((char*)current + ((current->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
				}while(current < (PACKET*)pBlock->_sys_memory_eptr);

				pBlock = pBlock->_next_memory_block;
			}while(pBlock != pOldBlock );

			LARGE_PACKET* pLargePacket = gpMemPool->m_pBoraLargeHeap;
			while(pLargePacket)
			{
				packet_size = pLargePacket->_actual_size;
				if(packet_size >= nThreshold)
				{
#if defined(BRTHREAD_MEMORY_DEBUG)
					BTrace("%s(%d) : ptr=0x%x, size=%d(%s)\n", pLargePacket->dbginfo.filename, pLargePacket->dbginfo.linenumber, (BrCHAR*)pLargePacket + LARGE_BLOCK_OVERHEAD, packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));
#else
					BTrace("ptr=0x%x, size=%d(%s)\n", (BrCHAR*)pLargePacket + LARGE_BLOCK_OVERHEAD, packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));										
#endif
				}

				pLargePacket = pLargePacket->_next_large_pack;
			}

	#if defined(DYNAMIC_FONTMEM_BLOCK)
			pLargePacket = gpMemPool->m_pBoraLargeSysHeap;
			while(pLargePacket)
			{
				packet_size = pLargePacket->_actual_size;
				if(packet_size >= nThreshold)
				{
#if defined(BRTHREAD_MEMORY_DEBUG)
					BTrace("%s(%d) : ptr=0x%x, size=%d(%s)\n", pLargePacket->dbginfo.filename, pLargePacket->dbginfo.linenumber, (BrCHAR*)pLargePacket + LARGE_BLOCK_OVERHEAD, packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));
#else
					BTrace("ptr=0x%x, size=%d(%s)\n", (BrCHAR*)pLargePacket + LARGE_BLOCK_OVERHEAD, packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));										
#endif
				}

				pLargePacket = pLargePacket->_next_large_pack;
			}

			pBlock = pOldBlock = gpMemPool->m_pBoraSysMem;
			if(pBlock)
			{
				do
				{
					current = (PACKET *)pBlock->_sys_memory;
					do
					{
						packet_size = current->packet_size&~BLOCK_USED;
						if( current->packet_size&BLOCK_USED && packet_size >= nThreshold )
						{
#if defined(BRTHREAD_MEMORY_DEBUG)
							BTrace("%s(%d) : ptr=0x%x, size=%d(%s)\n", current->dbginfo.filename, current->dbginfo.linenumber, (((BrCHAR*)current) + BLOCK_OVERHEAD), packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));
#else
							BTrace("ptr=0x%x : size=%d(%s)\n", (((BrCHAR*)current) - BLOCK_OVERHEAD), packet_size, ReplaceMemSize(packet_size, strSize, sizeof(strSize)));
#endif
						}

						current = (PACKET*)((char*)current + ((current->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
					}while(current < (PACKET*)pBlock->_sys_memory_eptr);

					pBlock = pBlock->_next_memory_block;
				}while(pBlock != pOldBlock );
			}
	#endif
		}
	}

	BTrace("##### Memory manager status view end #####\n");
#endif//#ifdef _THREAD_DEBUG	
}
#endif //DYNAMIC_MEMORY_BLOCK

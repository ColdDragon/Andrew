#include <OfficePreComp.hpp>
#include "bheaptrace.h"

#ifdef BRMEMORY_DEBUG_TRACE
#if !defined(_DEBUG) && !defined(LISTUP_LEAKFILES)
#define BRMEMORY_DEBUG_TRACE_LOCK
#endif
#define PERIODIC_THREASHOLD				1000

#include "brmcoreimpdef.h"
#include "brmcoreproc.h"
#ifdef PERIODIC_CHECK
int				malloc_cnt =0;
int				free_cnt =0;
#endif // PERIODIC_CHECK

int absMemCount = 0;

int focusSize = -1;		// Ư�� ũ���� �޸𸮸� ����͸��ϰ��� �Ҷ� ũ�� ����
BrINT wantBreakNumber = -1;	// �޸� �Ҵ� ������ ���Ծ��� ���� ��� ���������� break ����� �Ҷ� ����
extern char g_pdfName[BORA_INTERNET_MAX_URL_LENGTH];

BBaseHeapTrace::BBaseHeapTrace(EBrHEAP_LOGTYPE nLogType)
{
	m_nFlag = nLogType; 
}

BBaseHeapTrace::~BBaseHeapTrace()
{
#ifndef BRMEMORY_DEBUG_TRACE_LOCK
	printMemoryLeak();
	//clear();
#endif
}

LPBrHEAP_INFO BBaseHeapTrace::findHeapInfo(BrCHAR* pFileName, BrINT nLine)
{
	BrBOOL bFind = BrFALSE;
	BrINT i, nLen = m_oHeapInfoPool.size();
	LPBrHEAP_INFO pInfo = BrNULL;

	if (m_oHeapInfoPool.getGrowLen() == 0)	// ����ϱ� ���� �迭 �ʱ�ȭ �۾�(�⺻ �޸� Ȯ��:�ӵ� ����)
	{
		m_oHeapInfoPool.setGrowLen(10000);	// �޸� �Ҵ� ��Ұ� 2500������ �⺻ �Ҵ�
		for (int i = 0; i < BR_HEAPTRACE_MEMARRAYLEN; i++)
			m_oMemInfoPool[i].setGrowLen(40000);	// ����¥�� �޸� ��ũ 257�� = 257���������� �⺻ �Ҵ����� ���
	}
	
	for(i = nLen - 1; i >= 0; i--)		// �ֱٿ� ���� ���� ���� ����� ���̶�� ������... �ڿ��� ���� �˻�(2�谡�� ����)
	{
		pInfo = (LPBrHEAP_INFO)m_oHeapInfoPool.at(i);
		if(pInfo->pFileName == pFileName && nLine == pInfo->nLine)
		{
			bFind = BrTRUE;
			break;
		}		
	}

	if(!bFind)
		return BrNULL;

	return pInfo;
}

BrINT BBaseHeapTrace::findHeapInfo(LPBrHEAP_INFO pInfo)
{	
	BrINT nIndex = -1;
	BrINT i, nLen = m_oHeapInfoPool.size();
	
	for (i = nLen - 1; i >= 0; i--)		// �ֱٿ� ���� ���� ���� ����� ���̶�� ������... �ڿ��� ���� �˻�
	{
		if(m_oHeapInfoPool.at(i) == pInfo)
		{
			nIndex = i;
			break;
		}		
	}
	
	return nIndex;
}

LPBrMEMORY_INFO BBaseHeapTrace::findMemoryInfo (BPtrPlatMArray* pPool, void* pMem, BrINT & nIndex)
{	
	BrBOOL bFind = BrFALSE;
	BrINT i, nLen = pPool->size();
	LPBrMEMORY_INFO pInfo = BrNULL;
	nIndex = -1;
	for (i = nLen - 1; i >= 0; i--)		// �ֱٿ� ���� ���� ���� ����� ���̶�� ������... �ڿ��� ���� �˻�
	{
		pInfo = (LPBrMEMORY_INFO)pPool->at(i);
		if(pInfo->pMemory == pMem)
		{
			bFind = BrTRUE;
			nIndex = i;
			break;
		}
	}
	
	if(!bFind)
		return BrNULL;

	return pInfo;
}

void BBaseHeapTrace::removeHeapInfo(LPBrHEAP_INFO pHeapInfo)
{
	if(pHeapInfo)
	{
		BrINT nIndex = findHeapInfo(pHeapInfo);
		if(nIndex != -1)
			m_oHeapInfoPool.removeAt(nIndex);
		BFree(pHeapInfo);
	}
}

int serialBreak = -1;
//#define DUMP_MALLOC_SIZE

BrBOOL BBaseHeapTrace::addMemoryInfo (void * pMem, BrUINT nSize, BrUINT nCallNum, BrUINT nSerial, LPBrHEAP_INFO pHeapInfo)
{	
	if (nSize == 11111)	// ������ �ڵ忡 ���� �Ҵ���� ���� ���ڰ� ������ ���� �޸� ���� ��Ȳ ����
		printCurrentMemoryStatus();
	//BRTHREAD_STOPWATCH;
#ifdef DUMP_MALLOC_SIZE
	int bytes = (nSize % 1000);
	int kilo = (nSize % 1000000) / 1000;
	int mega = nSize / 1000000;
	if (mega > 0)
		BTrace("%i,%03i,%03i bytes malloc", mega, kilo, bytes);
	//else if (kilo > 0)
	//	BTrace("%i,%03i bytes malloc", kilo, bytes);
	//else
	//	BTrace("%i bytes malloc", bytes);
#endif
	LPBrMEMORY_INFO pMemInfo = (LPBrMEMORY_INFO)BMalloc(BrSizeOf(BrMEMORY_INFO));
	if(pMemInfo)
	{
		BrINT nIndex = (BrUINT)pMem%BR_HEAPTRACE_MEMARRAYLEN;
		m_oMemInfoPool[nIndex].add(pMemInfo);

		pMemInfo->pMemory		= pMem;
		pMemInfo->m_nSize		= nSize;
		pMemInfo->pHeapInfo		= pHeapInfo;
		pMemInfo->nCallNum		= nCallNum;
		pMemInfo->nSerialNum	= nSerial;
		BRTHREAD_ASSERT(nSerial != serialBreak);
		return BrTRUE;
	}
	return BrFALSE;
}


LPBrMEMORY_INFO BBaseHeapTrace::removeMemoryInfo (void * pMem)
{		
	BrINT nIndex;
	BrINT nPoolIndex = (BrUINT)pMem%BR_HEAPTRACE_MEMARRAYLEN;
	BPtrPlatMArray* pPool = &m_oMemInfoPool[nPoolIndex];
	LPBrMEMORY_INFO pRemove = findMemoryInfo (pPool, pMem, nIndex);

	if (pRemove)
	{		
		pPool->removeAt(nIndex);
		return pRemove;
	}
	else if(!BR_ISSET_STATE(m_nFlag, eBlock_HState) && focusSize == -1)
	{		
		BRTHREAD_ASSERT (0);
	}

	return BrNULL ;
}


void BBaseHeapTrace::add(void *pMem, BrCHAR* pFileName, BrINT nLine, BrINT nMemSize)
{	
	if (focusSize != -1)	// Leak�� �߻��ϴ� ũ�Ⱑ ������ �Ǿ����� Ȯ��, runtime�̶� ���� �ٲپ� ���ϴ� ũ�⸸ ������� ����
		if (focusSize != nMemSize)	// Leak �߻��ϴ� ũ�Ⱑ �ƴ� �޸𸮸� ����͸� ����
			return;
	//if (nMemSize > 1000000)
	//	BTrace("%s(%d) : Malloc size = %i", pFileName, nLine, nMemSize);
	BrLockMultiCoreImp(eMCORE_HEAP_TRACE_MUTEX);
	LPBrHEAP_INFO pInfo = findHeapInfo(pFileName, nLine);
	absMemCount++;

	BRTHREAD_ASSERT(absMemCount != wantBreakNumber);

	if (pInfo)
	{
		pInfo->nTotalSize += nMemSize;
		pInfo->nTotalCount++;
		pInfo->nCallNum++;

		if(pInfo->nTotalSize > pInfo->nMaxTotalSize)
			pInfo->nMaxTotalSize = pInfo->nTotalSize;
	}
	else
	{
		pInfo = (LPBrHEAP_INFO)BMalloc(BrSizeOf(BrHEAP_INFO));
		if(pInfo)
		{
			m_oHeapInfoPool.add(pInfo);
			
			pInfo->pMem = pMem;
			pInfo->pFileName = pFileName;
			pInfo->nLine = nLine;
			pInfo->nTotalSize = nMemSize;
			pInfo->nMaxTotalSize = nMemSize;
			pInfo->nTotalCount = 1;
			pInfo->nCallNum = 1;
		}
	}
	
	if(pInfo)
		addMemoryInfo (pMem, nMemSize, pInfo->nCallNum, absMemCount, pInfo);
	BrUnLockMultiCoreImp(eMCORE_HEAP_TRACE_MUTEX);
}

void BBaseHeapTrace::remove(void *pMem)
{
	BrLockMultiCoreImp(eMCORE_HEAP_TRACE_MUTEX);
	if (!pMem || !m_oHeapInfoPool.size())
		return;

	LPBrMEMORY_INFO pMemInfo = removeMemoryInfo (pMem);
	if(pMemInfo)
	{
		LPBrHEAP_INFO pInfo = pMemInfo->pHeapInfo;
		
		pInfo->nTotalSize -= pMemInfo->m_nSize;
		pInfo->nTotalCount--;
		if(pInfo->nTotalCount == 0)
			removeHeapInfo(pInfo);
		BFree(pMemInfo);		
	}
	BrUnLockMultiCoreImp(eMCORE_HEAP_TRACE_MUTEX);
}

void BBaseHeapTrace::clearPool(BPtrPlatMArray* pPool)
{
	BrINT i, nLen = pPool->size();
	for(i = 0; i < nLen; i++)
		BFree(pPool->at(i));
	pPool->removeAll();
}

void BBaseHeapTrace::clearMemInfoPool()
{
	BrINT i = 0;
	for(i = 0; i < BR_HEAPTRACE_MEMARRAYLEN; i++)
		clearPool(&m_oMemInfoPool[i]);
}

void BBaseHeapTrace::clear()
{
	clearPool(&m_oHeapInfoPool);
	clearMemInfoPool();
}

void BBaseHeapTrace::printMemInfoLeakByHeapAddr(void* pHeapAddr)
{
//	BTrace("\n**** Start Memory Leak Addrs\n");
	for(BrINT i = 0; i < BR_HEAPTRACE_MEMARRAYLEN; i++)
	{
		BPtrPlatMArray* pPool = &m_oMemInfoPool[i];

		BrINT nLen = pPool->size();
		for(BrINT j = 0; j < nLen; j++)
		{
			LPBrMEMORY_INFO pMemInfo = (LPBrMEMORY_INFO)pPool->at(j);
			if(pMemInfo->pHeapInfo == pHeapAddr)
				BTrace("Leak Memory Addr[0x%x] call number[%d] serial number[%d]", pMemInfo->pMemory, pMemInfo->nCallNum, pMemInfo->nSerialNum);
		}
	}
	
//	BTrace("\n**** End Memory Leak Addrs\n");
}

void BBaseHeapTrace::printMemoryLeak()
{
	BrINT i, nLen = m_oHeapInfoPool.size();
	if(nLen)
	{	
		BrINT nTotalSize = 0;
		LPBrHEAP_INFO pHeapInfo = BrNULL;
		BTrace("\n**** Memory Leak Status");

		for(i = 0; i < nLen; i++)
		{
			pHeapInfo = (LPBrHEAP_INFO)m_oHeapInfoPool.at(i);
			BTrace("%s(%d) : ( average size: %d, count: %d, %d )",pHeapInfo->pFileName,pHeapInfo->nLine,pHeapInfo->nTotalSize/pHeapInfo->nTotalCount,pHeapInfo->nTotalCount,pHeapInfo->nTotalSize);
			nTotalSize += pHeapInfo->nTotalSize;
			if(BR_GET_HEAPLOGTYPE(m_nFlag) == eMemAddr_HLType)
				printMemInfoLeakByHeapAddr(pHeapInfo);
		}

		BTrace("**** Total Mem Leak: %d bytes\n",nTotalSize);
#ifdef LISTUP_LEAKFILES
		char buf[BORA_INTERNET_MAX_URL_LENGTH];
		WCHAR name[BORA_INTERNET_MAX_URL_LENGTH];
		SYSTEMTIME time_s;
		FILE *file = NULL;
		GetLocalTime(&time_s);
		MultiByteToWideChar(CP_UTF8, 0, g_pdfName, -1, name, BORA_INTERNET_MAX_URL_LENGTH-1);
		WideCharToMultiByte(CP_ACP, 0, name, -1, g_pdfName, BORA_INTERNET_MAX_URL_LENGTH-1, NULL, NULL);
		wsprintf(buf, "%i/%i�� %i:%i = %i bytes leak - %s\n", time_s.wMonth, time_s.wDay, time_s.wHour, time_s.wMinute, nTotalSize, g_pdfName);
		errno_t err = fopen_s(&file, "d:\\LeakFiles.txt", "a+");
		if (err == 0)
		{
			fwrite(buf, strlen(buf), 1, file);
			fclose(file);
		}
#endif
	}
	else
		BTrace("**** No Memory Leak!!!!!!!!!\n");
	clear();
}

void BBaseHeapTrace::printCurrentMemoryStatus()
{
	BrINT i, nLen = m_oHeapInfoPool.size();
	if (nLen)
	{
		BrINT nTotalSize = 0;
		LPBrHEAP_INFO pHeapInfo = BrNULL;
		BTrace("\n**** Memory Status");

		for (i = 0; i < nLen; i++)
		{
			pHeapInfo = (LPBrHEAP_INFO)m_oHeapInfoPool.at(i);
			BTrace("%s(%d) : ( average size: %d, count: %d, %d )", pHeapInfo->pFileName, pHeapInfo->nLine, pHeapInfo->nTotalSize / pHeapInfo->nTotalCount, pHeapInfo->nTotalCount, pHeapInfo->nTotalSize);
			nTotalSize += pHeapInfo->nTotalSize;
		}

		BTrace("**** Memory used : %d bytes\n", nTotalSize);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////
#if defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
BBlockHeapTrace::BBlockHeapTrace(BrCHAR* pCodeFileName, BrINT nCodeLine, EBrHEAP_LOGTYPE nLogType) : BBaseHeapTrace(nLogType)
{
	if(g_pHeapTrace)
		g_pHeapTrace->regBlockHeap(this);
	m_pCodeFileName = pCodeFileName;
	m_nCodeLine = nCodeLine;
	m_nFlag |= eBlock_HState;
}

BBlockHeapTrace::~BBlockHeapTrace()
{
	if(g_pHeapTrace)
		g_pHeapTrace->unregBlockHeap(this);
	BrTrace("\n************* BlockHeapTrace *************");
	BrTrace("%s(%d) : Block Heap Strat Code", m_pCodeFileName, m_nCodeLine);
	printMemoryLeak();
	clear();
}
#endif //defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
BHeapTrace::BHeapTrace()
{
#if defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
	m_pCurBHeap = BrNULL;
#endif //defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
	m_pBaseHeap = new BBaseHeapTrace();	
}

BHeapTrace::~BHeapTrace()
{
	if(m_pBaseHeap)
		delete m_pBaseHeap;
}
#if defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
BrINT BHeapTrace::findBlockHeap(BBlockHeapTrace* pBHeap)
{
	BrINT nIndex = -1;
	BrINT i, nLen = m_oBlockHeap.size();

	for(i = 0; i < nLen; i++ )
	{
		if(pBHeap == m_oBlockHeap.at(i))
		{
			nIndex = i;
			break;
		}		
	}
	return nIndex;
}

BrBOOL BHeapTrace::regBlockHeap(BBlockHeapTrace* pBHeap)
{
	if(pBHeap)
	{
		m_oBlockHeap.add(pBHeap);
		m_pCurBHeap = pBHeap;
		return BrTRUE;
	}
	return BrFALSE;
}

void BHeapTrace::unregBlockHeap(BBlockHeapTrace* pBHeap)
{
	if(pBHeap)
	{
		BrINT nIndex = findBlockHeap(pBHeap);
		if(nIndex != -1)
			m_oBlockHeap.removeAt(nIndex);
		if(m_pCurBHeap == pBHeap)
		{
			if(m_oBlockHeap.size())
				m_pCurBHeap = (BBlockHeapTrace*)m_oBlockHeap.at(m_oBlockHeap.size()-1);
			else
				m_pCurBHeap = BrNULL;
		}
	}
}
#endif //defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)

void BHeapTrace::clear()
{
#ifndef BRMEMORY_DEBUG_TRACE_LOCK

#ifndef BRMEMORY_DEBUG_ONLYBLOCKTRACE
	if(m_pBaseHeap)
		m_pBaseHeap->clear();
#endif //!BRMEMORY_DEBUG_ONLYBLOCKTRACE

#if defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
	m_pCurBHeap = BrNULL;
	m_oBlockHeap.resize(0);
#endif //defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)

#endif //!BRMEMORY_DEBUG_TRACE_LOCK	
}

int traceSize = -1;	// runtime�� �̰��� trace�� ���ϴ� �޸� ũ�⸦ ������ �ش�ũ�⸸ Pool�� �ְ� �����Ѵ�.

void BHeapTrace::add(void *pMem, BrCHAR* pFileName, BrINT nLine, BrINT nMemSize)
{
#ifndef BRMEMORY_DEBUG_TRACE_LOCK
#if defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
	if((m_pCurBHeap && traceSize == nMemSize) || traceSize == -1)
		m_pCurBHeap->add(pMem, pFileName, nLine, nMemSize);
#endif //defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)

#ifndef BRMEMORY_DEBUG_ONLYBLOCKTRACE
	if(m_pBaseHeap)
		m_pBaseHeap->add(pMem, pFileName, nLine, nMemSize);
#endif //!BRMEMORY_DEBUG_ONLYBLOCKTRACE

#ifdef PERIODIC_CHECK
	if((++malloc_cnt % PERIODIC_THREASHOLD) == 0)
		BRTHREAD_DETECT_MEM_CORRUPTION;
#endif //PERIODIC_CHECK
#endif //!BRMEMORY_DEBUG_TRACE_LOCK	
}

void BHeapTrace::remove(void *pMem)
{
#ifndef BRMEMORY_DEBUG_TRACE_LOCK
#if defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)
	if(m_pCurBHeap)
		m_pCurBHeap->remove(pMem);
#endif //defined(BRMEMORY_DEBUG_BLOCKTRACE) || defined(BRMEMORY_DEBUG_ONLYBLOCKTRACE)

#ifndef BRMEMORY_DEBUG_ONLYBLOCKTRACE
	if(m_pBaseHeap)
		m_pBaseHeap->remove(pMem);
#endif //!BRMEMORY_DEBUG_ONLYBLOCKTRACE

#ifdef PERIODIC_CHECK
	if((++free_cnt % PERIODIC_THREASHOLD) == 0)
		BRTHREAD_DETECT_MEM_CORRUPTION;
#endif PERIODIC_CHECK

#endif //!BRMEMORY_DEBUG_TRACE_LOCK	
}
#endif //BRMEMORY_DEBUG_TRACE

#include <OfficePreComp.hpp>


#include "prpublicmem.h"
#include "prmemorytool.h"

#include "brmcoreproc.h"
#include "prmemory_manager.h"
#include "brmcoreimp.h"

PrPublicMem::	PrPublicMem()
{
	BrUINT64 nTSize = 0;
	InitMemoryMap_MT(m_Map, nTSize);
	memset(m_aMem, 0, BrSizeOf(m_aMem));
	memset(&m_sLargeMem, 0, BrSizeOf(m_sLargeMem));
	memset(&m_sFixMem, 0, BrSizeOf(m_sFixMem));
	memset(&m_sPublicMP, 0, BrSizeOf(m_sPublicMP));
	memset(&m_sSpecialMP, 0, BrSizeOf(m_sSpecialMP));
#ifdef USE_MCORE_MEMPOOL
	memset(m_aThread_Id, 0, BrSizeOf(m_aThread_Id));
	memset(&m_sMCoreMP, 0, BrSizeOf(m_sMCoreMP));
	initMutex();
#endif //USE_MCORE_MEMPOOL
}

PrPublicMem::~PrPublicMem()
{
	clear(BrTRUE);
	//freeBlockMem(&m_aMem[0]);	
}


void PrPublicMem::clear()
{
	clear(BrFALSE);
}

void PrPublicMem::clear(BrBOOL bFree)
{
	for(BrINT i = 0; i < PR_BLOCK_PMEM_MAX; i++)
		freeBlockMem(&m_aMem[i]);

	releaseFixMemPool();	
	releaseLFMemPool(m_sLargeMem, BrFALSE);
#ifdef USE_MCORE_MEMPOOL
	destroyMutex();
#endif //USE_MCORE_MEMPOOL
	if(!bFree)
	{
		memset(&m_sPublicMP, 0, BrSizeOf(m_sPublicMP));
		memset(&m_sSpecialMP, 0, BrSizeOf(m_sSpecialMP));
#ifdef USE_MCORE_MEMPOOL
		memset(m_aThread_Id, 0, BrSizeOf(m_aThread_Id));
		memset(&m_sMCoreMP, 0, BrSizeOf(m_sMCoreMP));
		initMutex();
#endif //USE_MCORE_MEMPOOL
	}
}

void PrPublicMem::freeBlockMem(B_MEM_POOL** lpMem)
{
	if(*lpMem)
	{
		BoraHeapMemFree_MT(*lpMem);
		BoraSysMemFree(*lpMem);
#ifdef BRMEMORY_DEBUG_TRACE
		EndMemPool_MT(lpMem, BrNULL);
#else //BRMEMORY_DEBUG_TRACE
		EndMemPool_MT(lpMem);
#endif //BRMEMORY_DEBUG_TRACE
		*lpMem = BrNULL;				
	}
}

BrBOOL PrPublicMem::getMemPool(BrPUBLIC_MEMPOOL & sMemPool, BrBYTE nMakeFlag, BrUINT nLen)
{
	BrBOOL bRet = BrFALSE;
	
	switch(nMakeFlag)
	{
		case eBlock_PMPFlag:
			bRet = getBlockMemPool(sMemPool);
			break;
		case eNormal_PMPFlag:
			bRet = getNormalMemPool(sMemPool, nLen);
			break;
		case eLarge_PMPFlag:
			bRet = getLargeMemPool(sMemPool, nLen);
			break;
	}
	
	return bRet;
}

void PrPublicMem::releaseBlockMemPool(LPBrPUBLIC_MEMPOOL pMemPool)
{
	if(pMemPool && pMemPool->pMem)
		freeBlockMem(&m_aMem[pMemPool->nIndex]);
	if (pMemPool)
	{
		pMemPool->pMem = BrNULL;
		pMemPool->nIndex = -1;
	}
}

void PrPublicMem::releaseLFMemPool(BrDATAINFO & sLFMem, BrBOOL bUnLock)
{
	if(sLFMem.pData)
	{
		if(bUnLock)
			sLFMem.bUse = BrFALSE;
		else
		{
			BFree(sLFMem.pData);
			memset(&sLFMem, 0, BrSizeOf(m_sLargeMem));		
		}
	}
}

void PrPublicMem::releaseLargeMemPool(LPBrPUBLIC_MEMPOOL pMemPool, BrBOOL bUnLock)
{
	if(pMemPool->pMem == m_sLargeMem.pData || (BrVLONG)pMemPool->pMem == PR_LARGEMEM_SIGNATURE)
		releaseLFMemPool(m_sLargeMem, bUnLock);
	else
		memset(pMemPool, 0, BrSizeOf(BrPUBLIC_MEMPOOL));	
}

void PrPublicMem::releaseFixMemPool(BrBOOL bUnLock)
{
	releaseLFMemPool(m_sFixMem, bUnLock);
}

void PrPublicMem::releaseNormalMemPool(LPBrPUBLIC_MEMPOOL pMemPool)
{
	if(pMemPool->pMem)
	{
		BFree(pMemPool->pMem);
		pMemPool->pMem = BrNULL;
	}	
}

void PrPublicMem::releaseLargeMemPool()
{
	releaseLFMemPool(m_sLargeMem, BrFALSE);
}

void PrPublicMem::releaseMemPool(LPBrPUBLIC_MEMPOOL pMemPool, BrBOOL bUnLock)
{
	if(pMemPool)
	{
		switch(pMemPool->nType)
		{
			case eBlockMemPMType:
				releaseBlockMemPool(pMemPool);
				break;
			case eLargeMemPMType:
				releaseLargeMemPool(pMemPool, bUnLock);
				break;
			case eNormalMemPMType:
				releaseNormalMemPool(pMemPool);
				break;
			case eFixMemPMType:
				releaseFixMemPool(BrTRUE);
				break;				
		}
	}
}

BrBOOL PrPublicMem::getBlockMemPool(BrPUBLIC_MEMPOOL & sMemPool)
{	
	BrBOOL bRet = BrFALSE;

	POMulticoreMutex;
	
	for(BrINT i = 0; i < PR_BLOCK_PMEM_MAX; i++)
	{
		if(!m_aMem[i])
		{
			InitMemPool_MT(&m_aMem[i], BrNULL);
			if (&sMemPool == &m_sSpecialMP)
				m_aMem[i]->m_available_memory_size = PR_SPECIAL_MEM_MAXSIZE;
			else
				m_aMem[i]->m_available_memory_size = PR_BLOCK_MEM_MAXSIZE;
			//������ ũ�⸦ ����ϴ� ��� ���� �޸𸮸� ������ ���� �޸𸮸� ���
			if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 )
				m_aMem[i]->m_available_memory_size = GetAvailableMemorySize() - GetAllocatedMemory();
			sMemPool.nIndex = i;
			sMemPool.pMem = m_aMem[i];
			sMemPool.nType = eBlockMemPMType;
			bRet = BrTRUE;
#ifdef USE_MCORE_MEMPOOL
			m_aMem[i]->m_MemPool_Id = i;
			pthread_t nThread_Id = pthread_self();
			m_aThread_Id[i] = nThread_Id;
#endif //USE_MCORE_MEMPOOL
			break;
		}
	}
	
	return bRet;
}

#ifdef USE_MCORE_MEMPOOL
BrBOOL PrPublicMem::allocMCoreMemPool()
{
	return getBlockMemPool(m_sMCoreMP);
}

B_MEM_POOL* PrPublicMem::getMCoreMemPool(BrINT nId, BrBOOL bMalloc)
{
	if (bMalloc)
	{
		pthread_t nTid = pthread_self();
		for(BrINT i = 0; i < PR_BLOCK_PMEM_MAX; i++)
		{
			if(pthread_equal(nTid, m_aThread_Id[i]))
				return m_aMem[i];
		}
		return BrNULL;
	}
	else
		return m_aMem[nId];
}

void PrPublicMem::lockMCoreMemPool(BrINT nIndex)
{
#if !defined(CORETHREAD_USE_SYSTHREAD) && !defined(WINDOWS_8)
	if (BrIsMCoreRunState())
#endif //!CORETHREAD_USE_SYSTHREAD && !WINDOWS_8
		pthread_mutex_lock(&m_aMutex[nIndex]);
}

void PrPublicMem::unLockMCoreMemPool(BrINT nIndex)
{
	pthread_mutex_unlock(&m_aMutex[nIndex]);
}

void PrPublicMem::initMutex()
{
	for (BrINT i=0; i<PR_BLOCK_PMEM_MAX+1; i++)
	{
		pthread_mutexattr_t attr;
		pthread_mutexattr_init(&attr);
		pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
		pthread_mutex_init(&m_aMutex[i], &attr);
	}
}

void PrPublicMem::destroyMutex()
{
	for (BrINT i=0; i<PR_BLOCK_PMEM_MAX+1; i++)
		pthread_mutex_destroy(&m_aMutex[i]);
}
#endif //USE_MCORE_MEMPOOL

void PrPublicMem::releaseSpecialMemPool()
{
	releaseBlockMemPool(&m_sSpecialMP);
}

BrBOOL PrPublicMem::needToReleaseSpecialMemPool()
{
#define SPECIAL_MEMPOOL_THRESHOLD_512MB		   536870912 //1024*1024*512(512MB)
#define SPECIAL_MEMPOOL_THRESHOLD_256MB		   268435456 //1024*1024*256(256MB)

	//  [6/18/2015 sylee0335][NPC-5767] �ܿ� �޸� ��뷮 ����� ���� ���� 
#define SPECIAL_MEMPOOL_THRESHOLD_128MB		   134217728 //1024*1024*128(128MB)
#define SPECIAL_MEMPOOL_THRESHOLD_64MB		   67108864 //1024*1024*128(64MB)


	BrBOOL bNeedToRelease = BrFALSE;
	B_MEM_POOL* pMemPool = (B_MEM_POOL*)m_sSpecialMP.pMem;
	
	if (pMemPool->m_bInitHeapMem==BrFALSE)
		return bNeedToRelease;

	BrUINT64 nTotalMemSize = pMemPool->m_available_memory_size;
	BrUINT64 nAllocatedMemSize = pMemPool->m_allocated_memory_size;
	BrUINT64 nRemainMemSize = nTotalMemSize - nAllocatedMemSize;

	bNeedToRelease = (nRemainMemSize < SPECIAL_MEMPOOL_THRESHOLD_512MB + SPECIAL_MEMPOOL_THRESHOLD_256MB + SPECIAL_MEMPOOL_THRESHOLD_128MB  + SPECIAL_MEMPOOL_THRESHOLD_64MB);

	return bNeedToRelease;
}

BrBOOL PrPublicMem::getNormalMemPool(BrPUBLIC_MEMPOOL & sMemPool, BrUINT nLen)
{	
	BrBOOL bRet = BrFALSE;

	if(nLen <= PR_FIXED_MEM_SIZE)
	{
		if(!m_sFixMem.pData)
		{
			m_sFixMem.pData = (BrBYTE*)BMalloc(PR_FIXED_MEM_SIZE);
			if(m_sFixMem.pData)
			{
				m_sFixMem.nLen = PR_FIXED_MEM_SIZE;
				m_sFixMem.bUse = BrTRUE;
				sMemPool.pMem = m_sFixMem.pData;
				sMemPool.nType = eFixMemPMType;
				return BrTRUE;
			}
		}
		else if(!m_sFixMem.bUse)
		{
			m_sFixMem.bUse = BrTRUE;
			sMemPool.pMem = m_sFixMem.pData;
			sMemPool.nType = eFixMemPMType;
			return BrTRUE;
		}
	}
	else
	{
		sMemPool.pMem = (BrBYTE*)BMalloc(nLen);
		if(sMemPool.pMem)
		{
			sMemPool.nType = eNormalMemPMType;
			return BrTRUE;
		}
	}

	return bRet;
}

BrBOOL PrPublicMem::getLargeMemPool(BrPUBLIC_MEMPOOL & sMemPool, BrUINT nLen)
{	
	if(!m_sLargeMem.pData)
	{
		m_sLargeMem.pData = (BrBYTE*)BMalloc(nLen);
		if(m_sLargeMem.pData)
		{
			m_sLargeMem.nLen = nLen;
			m_sLargeMem.bUse = BrTRUE;
			sMemPool.pMem = m_sLargeMem.pData;
			sMemPool.nType = eLargeMemPMType;
			return BrTRUE;
		}		
	}
	else
	{
		if(!m_sLargeMem.bUse)
		{
			if(m_sLargeMem.nLen < nLen)
			{
				BrBYTE* pData = (BrBYTE*)BRealloc(m_sLargeMem.pData, nLen);
				if(pData)
				{
					m_sLargeMem.pData = pData;
					m_sLargeMem.nLen = nLen;
					m_sLargeMem.bUse = BrTRUE;
					sMemPool.pMem = m_sLargeMem.pData;
					sMemPool.nType = eLargeMemPMType;
					return BrTRUE;
				}
				else
					releaseLFMemPool(m_sLargeMem, BrFALSE);
			}
			else
			{
				sMemPool.pMem = m_sLargeMem.pData;
				sMemPool.nType = eLargeMemPMType;
				m_sLargeMem.bUse = BrTRUE;
				return BrTRUE;
			}		
		}		
	}

	return BrFALSE;
}

BrLPVOID PrPublicMem::blockMalloc(LPBrPUBLIC_MEMPOOL pMemPool, BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	return Malloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, size, COMMON_HEAP_MEM, szfile, nline);
}

void PrPublicMem::blockFree(LPBrPUBLIC_MEMPOOL pMemPool, void *packet, BrCHAR* szfile, BrUINT32 nline)
{
	Free_MT((B_MEM_POOL*)pMemPool->pMem, packet, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::blockCalloc(LPBrPUBLIC_MEMPOOL pMemPool, BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	return Calloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, num, size, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::blockRealloc(LPBrPUBLIC_MEMPOOL pMemPool, BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	return Realloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, packet, size, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::publicBlockMalloc(BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sPublicMP;
	if (!pMemPool->pMem)
		getBlockMemPool(m_sPublicMP);
	return Malloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, size, COMMON_HEAP_MEM, szfile, nline);
}

void PrPublicMem::publicBlockFree(void *packet, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sPublicMP;
	Free_MT((B_MEM_POOL*)pMemPool->pMem, packet, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::publicBlockCalloc(BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sPublicMP;
	if (!pMemPool->pMem)
		getBlockMemPool(m_sPublicMP);
	return Calloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, num, size, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::publicBlockRealloc(BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sPublicMP;
	if (!pMemPool->pMem)
		getBlockMemPool(m_sPublicMP);
	return Realloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, packet, size, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::specialBlockMalloc(BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sSpecialMP;
	if(!pMemPool->pMem)
		getBlockMemPool(m_sSpecialMP);
	return Malloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, size, SPECIAL_HEAP_MEM, szfile, nline);
}

void PrPublicMem::specialBlockFree(void *packet, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sSpecialMP;
	Free_MT((B_MEM_POOL*)pMemPool->pMem, packet, SPECIAL_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::specialBlockCalloc(BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sSpecialMP;
	if(!pMemPool->pMem)
		getBlockMemPool(m_sSpecialMP);
	return Calloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, num, size, SPECIAL_HEAP_MEM, szfile, nline);
}

BrLPVOID PrPublicMem::specialBlockRealloc(BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	LPBrPUBLIC_MEMPOOL pMemPool = &m_sSpecialMP;
	if(!pMemPool->pMem)
		getBlockMemPool(m_sSpecialMP);
	return Realloc_MT(&m_Map, (B_MEM_POOL*)pMemPool->pMem, packet, size, SPECIAL_HEAP_MEM, szfile, nline);
}

BORA_MEMORY_MAP PrPublicMem::getMemoryMap()
{
	return m_Map;
}
B_MEM_POOL*		PrPublicMem::getMemoryPool(int index)
{
	if ( index < PR_BLOCK_PMEM_MAX )
		return m_aMem[index];
	return NULL;
}
int	PrPublicMem::getMemoryPoolSize()
{
	int n = 0;
	for (; n < PR_BLOCK_PMEM_MAX; n++)
	{
		if (!m_aMem[n])
			break;
	}
	return n;
}
MemPoolType PrPublicMem::getMemoryPoolType(int index)
{
	MemPoolType type = eUnset_Mem_Pool;
	if (index < PR_BLOCK_PMEM_MAX)
	{
		if (m_sPublicMP.pMem == m_aMem[index])
		{
			type = ePublic_Mem_Pool;
		}
		else if (m_sSpecialMP.pMem == m_aMem[index])
		{
			type = eSpecial_Mem_Pool;
		}
#ifdef USE_MCORE_MEMPOOL
		else if (m_sMCoreMP.pMem == m_aMem[index])
		{
			type = eMulticore_Mem_Pool;
		}
#endif
	}
	return type;
}


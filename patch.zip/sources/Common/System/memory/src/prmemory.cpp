#include <OfficePreComp.hpp>

#include "prmemory.h"
#include "prmemory_manager.h"
#include "bheaptrace.h"
#include "ThreadDefines_i.h"
#include "binterfacehandle.h"

#if defined(BRTHREAD_MEMORY_DEBUG)

void bora_set_debuginfo(B_MEM_POOL* pMemPool, PACKET* packet, BrCHAR* szfile, BrLONG nline)
{
	packet->dbginfo.filename = szfile;
	packet->dbginfo.linenumber = nline;
	packet->dbginfo.alloc_count = ++pMemPool->m_alloc_count;
	if( BrGetThreadID() == (pMemPool->m_leakID>>16) ) packet->dbginfo.leakcheck_id = pMemPool->m_leakID;

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	int packet_size = packet->packet_size & ~BLOCK_SIZE_MASK;
	*((BrINT64*)(((BrCHAR*)packet + packet_size + BLOCK_OVERHEAD) - MEM_DEBUG_TAIL_SIZE)) = MEM_DEBUG_TAIL_VALUE;
#endif

}

void bora_set_large_debuginfo(B_MEM_POOL* pMemPool, LARGE_PACKET* packet, BrCHAR* szfile, BrLONG nline)
{
	packet->dbginfo.filename = szfile;
	packet->dbginfo.linenumber = nline;
	packet->dbginfo.alloc_count = ++pMemPool->m_alloc_count;
	if( BrGetThreadID() == (pMemPool->m_leakID>>16) ) packet->dbginfo.leakcheck_id = pMemPool->m_leakID;

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	*((BrINT64*)((BrCHAR*)packet + packet->_actual_size - MEM_DEBUG_TAIL_SIZE)) = MEM_DEBUG_TAIL_VALUE;
#endif
}

void bora_large_initialize_packet(LARGE_PACKET* packet)
{
#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	BRTHREAD_ASSERT(*((BrINT64*)((BrCHAR*)packet + packet->_actual_size - MEM_DEBUG_TAIL_SIZE)) == MEM_DEBUG_TAIL_VALUE);
	if(*((BrINT64*)((BrCHAR*)packet + packet->_actual_size - MEM_DEBUG_TAIL_SIZE)) != MEM_DEBUG_TAIL_VALUE)
		THREAD_TRACE(("%s(%d) : There is corrupted packet!!\n", packet->dbginfo.filename, packet->dbginfo.linenumber));
#endif
}

void bora_initialize_packet(PACKET* packet)
{
#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	int packet_size = packet->packet_size & ~BLOCK_SIZE_MASK;
	BRTHREAD_ASSERT(*((BrINT64*)(((BrCHAR*)packet + packet_size + BLOCK_OVERHEAD) - MEM_DEBUG_TAIL_SIZE)) == MEM_DEBUG_TAIL_VALUE);
	if(*((BrINT64*)(((BrCHAR*)packet + packet_size + BLOCK_OVERHEAD) - MEM_DEBUG_TAIL_SIZE)) != MEM_DEBUG_TAIL_VALUE)
		THREAD_TRACE(("%s(%d) : There is corrupted packet!!\n", packet->dbginfo.filename, packet->dbginfo.linenumber));
#endif


#if defined(_PLAT_WINDOWS) && defined(_THREAD_DEBUG)
	packet->dbginfo.filename = (BrCHAR*)0xCCCCCCCC;
	packet->dbginfo.linenumber = 0xCCCCCCCC;
	packet->dbginfo.alloc_count = 0xCCCCCCCC;
	packet->dbginfo.leakcheck_id = 0x0;
	memset((char*)packet+BLOCK_OVERHEAD, 0xCC, packet->packet_size & ~BLOCK_SIZE_MASK);
#endif
}
#elif defined(BRMEMORY_DEBUG_TRACE)

#endif // BRTHREAD_MEMORY_DEBUG

static void br_minsert(B_MEMORY * pBlock, PACKET *ptr)
{
	register PACKET *current = NULL;
	register PACKET *last    = NULL;

	// calculate max packet, total memory
	pBlock->_max_packet_size = BrMAX(ptr->packet_size, pBlock->_max_packet_size);
	pBlock->_total_free_size += ptr->packet_size;

	if (pBlock->_sys_free == NULL)
	{
		pBlock->_sys_free	= ptr;
		ptr->size_ptr		= NULL;
		ptr->last_ptr		= NULL;
		return;
	}

	current = pBlock->_sys_free;
	while (current && current->packet_size < ptr->packet_size)
	{
		last	= current;
		current = current->size_ptr;
	}

	if (current == NULL) 	        /* PTR WILL BE LAST IN LIST          */
	{
		last->size_ptr = ptr;
		ptr->size_ptr  = NULL;
		ptr->last_ptr = last;
	}
	else if (last == NULL)	        /* PTR WILL BE FIRST IN THE LIST     */
	{
		ptr->last_ptr  = NULL;
		current->last_ptr = ptr;
		ptr->size_ptr  = current;
		pBlock->_sys_free = ptr;
	}
	else							/* PTR IS IN THE MIDDLE OF THE LIST  */
	{
		current->last_ptr = ptr;
		ptr->size_ptr  = current;
		ptr->last_ptr  = last;
		last->size_ptr = ptr;
	}
}

static void thread_minsert(PACKET* ptr)
{
	BTrace("%s(%d) %s ptr[%p]", __FILE__, __LINE__, __FUNCTION__, ptr);
	BTrace("%s(%d) %s ptr->packet_size[%d]", __FILE__, __LINE__, __FUNCTION__, ptr->packet_size);
	BTrace("%s(%d) %s ptr->last_ptr_nearby[%p]", __FILE__, __LINE__, __FUNCTION__, ptr->last_ptr_nearby);
	BTrace("%s(%d) %s ptr->last_ptr[%p]", __FILE__, __LINE__, __FUNCTION__, ptr->last_ptr);
	BTrace("%s(%d) %s ptr->size_ptr[%p]", __FILE__, __LINE__, __FUNCTION__, ptr->size_ptr);

	register PACKET* current = NULL;
	register PACKET* last = NULL;
	register B_MEMORY* pBlock = NULL;

	pBlock = GetThreadBlockByPtr(ptr);
	BTrace("%s(%d) %s pBlock[%p]", __FILE__, __LINE__, __FUNCTION__, pBlock);
	if (!pBlock) return;
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	current = pBlock->_sys_free;
	BTrace("%s(%d) %s current[%p]", __FILE__, __LINE__, __FUNCTION__, current);
	if (current == NULL)
	{
		pBlock->_sys_free = ptr;
		BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		ptr->size_ptr = NULL;
		BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	while (current && current->packet_size < ptr->packet_size)
	{
		last = current;
		current = current->size_ptr;
	}

	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	if (current == NULL)
	{
		last->size_ptr = ptr;
		ptr->size_ptr = NULL;
	}
	else if (last == NULL)
	{
		ptr->size_ptr = pBlock->_sys_free;
		pBlock->_sys_free = ptr;
	}
	else
	{
		ptr->size_ptr = current;
		last->size_ptr = ptr;
	}
}

static void thread_mremove(PACKET *ptr)
{
	register PACKET *current = NULL;
	register PACKET *last    = NULL;
	register B_MEMORY * pBlock = NULL;

	pBlock = GetThreadBlockByPtr(ptr);
	if( !pBlock ) return;
	current = pBlock->_sys_free;


	while (current && current != ptr)
	{
		last	= current;
		current = current->size_ptr;
	}


	if (current == NULL) 
		pBlock->_sys_free = NULL;        
	else if (last == NULL) 
		pBlock->_sys_free = ptr->size_ptr;
	else 
		last->size_ptr = ptr->size_ptr; 
}

BrLPVOID BrThreadMalloc(BrSIZE_T size)
{
	BTrace("%s(%d) %s size[%d]", __FILE__, __LINE__, __FUNCTION__, size);
	register PACKET *current;
	register BrUINT32  newsize;
	register BrUINT32  oldsize;
	register B_MEMORY * pBlock;

	if(!gpBoraEventMem || !gpBoraThreadStackMem)
	{
		BMemoryTrace("Error Need thread mem or Event mem init!!!\n");
		BRTHREAD_ASSERT(gpBoraEventMem && gpBoraThreadStackMem);
	}
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	CHECKNULLRET((BrINT32)size<=0);

	newsize = (size + BLOCK_MASK) & ~BLOCK_MASK;
	BTrace("%s(%d) %s newsize[%d]", __FILE__, __LINE__, __FUNCTION__, newsize);
	pBlock = GetThreadBlockBySize(size);
	BTrace("%s(%d) %s pBlock[%p]", __FILE__, __LINE__, __FUNCTION__, pBlock);
	if( !pBlock ) return BrNULL;
	current = pBlock->_sys_free;
	BTrace("%s(%d) %s current[%p]", __FILE__, __LINE__, __FUNCTION__, current);

	while (current && current->packet_size < newsize)
		current = current->size_ptr;
	BTrace("%s(%d) %s current[%p]", __FILE__, __LINE__, __FUNCTION__, current);
	if (!current) return BrNULL;

	oldsize = current->packet_size;			
	BTrace("%s(%d) %s oldsize[%d]", __FILE__, __LINE__, __FUNCTION__, oldsize);
	thread_mremove(current);				

	BTrace("%s(%d) %s current[%p]", __FILE__, __LINE__, __FUNCTION__, current);

	if (oldsize - newsize >= (MIN_BLOCK + BLOCK_OVERHEAD))
	{
		BTrace("%s(%d) %s (MIN_BLOCK + BLOCK_OVERHEAD)[%d]", __FILE__, __LINE__, __FUNCTION__, (MIN_BLOCK + BLOCK_OVERHEAD));
		register PACKET *next = 
			(PACKET *) ((char *) current + BLOCK_OVERHEAD + newsize);
		next->packet_size    = oldsize - newsize - BLOCK_OVERHEAD;
		BTrace("%s(%d) %s next[%p]", __FILE__, __LINE__, __FUNCTION__, next);
		thread_minsert(next);
		current->packet_size = newsize;
	}

	current->packet_size |= BLOCK_USED;

	return (char *)current + BLOCK_OVERHEAD;
}

void BrThreadFree(void *packet)
{
	register char   *ptr;
	register PACKET *last;	      
	register PACKET *current;	    
	register PACKET *next;	      
	register B_MEMORY * pBlock=BrNULL;

	if (packet == NULL) return;

	ptr = (char *)packet;
	last = next = NULL;		     
	ptr -= BLOCK_OVERHEAD;	     

	pBlock = GetThreadBlockByPtr(ptr);
	if( !pBlock ) return;

	current = (PACKET *)pBlock->_sys_memory;

	while (current < (PACKET *) ptr)
	{
		last    = current;
		current = (PACKET *)((char *)current + 
			(current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD);
	}


	if ((current != (PACKET *) ptr) || (!(current->packet_size & BLOCK_USED)))
	{
		// thread������ free�ϰ�� stack overflow�� �� �ֽ��ϴ�.
		// ������ �븮�� ã�� �ּ���.
		BRTHREAD_ASSERT(BrFALSE);
		return;
	}

	current->packet_size &= ~BLOCK_SIZE_MASK;   /* MARK PACKET AS FREE */

	/*-----------------------------------------------------------------------*/

	next = (PACKET *) ((char *)current + BLOCK_OVERHEAD +current->packet_size);
	if (next >= (PACKET *) pBlock->_sys_memory_eptr) 
		next = NULL;

	if (last && (last->packet_size & BLOCK_USED)) last = NULL;
	if (next && (next->packet_size & BLOCK_USED)) next = NULL;


	if (last && next)
	{
		thread_mremove(last);
		thread_mremove(next);
		last->packet_size += current->packet_size + next->packet_size + 
			BLOCK_OVERHEAD + BLOCK_OVERHEAD;
		thread_minsert(last);
		return;
	}


	if (last)
	{
		thread_mremove(last);
		last->packet_size += current->packet_size + BLOCK_OVERHEAD;
		thread_minsert(last);
		return;
	}


	if (next)
	{
		thread_mremove(next);
		current->packet_size += next->packet_size + BLOCK_OVERHEAD;
		thread_minsert(current);
		return;
	}


	thread_minsert(current);
}

//#define	MEMORY_TRACE
#ifdef MEMORY_TRACE
#include "ImageFilter.h"
BrDWORD g_dwUsed = 0, g_nCount = 0, g_nLimitSize = 0x1000;
#endif

#ifdef __cplusplus
extern "C" {
#endif

BrLPVOID _BrMalloc(BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return malloc(size);
	}

	MALLOC_TIME_CHECK;

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
#endif //USE_MCORE_MEMPOOL

	BrLPVOID pData = Malloc_MT(&gMemoryMap, pMemPool, size, COMMON_HEAP_MEM, szfile, nline);

#ifdef BRMEMORY_DEBUG_TRACE
	if(pData)	
		g_pHeapTrace->add((char *)pData, szfile, nline, size);
#endif //BRMEMORY_DEBUG_TRACE	
	return pData;
}

void _BrFree(void *packet, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		free(packet);
		return;
	}

	FREE_TIME_CHECK;

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	CHECKVOIDRET(!packet);
	BrINT nMemPool_Id = 0;
	PACKET *current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */
	if(IS_LARGE_PACKET(current))
		nMemPool_Id = (((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD))->magic_number&MEMPOOL_ID_MASK)>>30;
	else
		nMemPool_Id = (current->packet_size&MEMPOOL_ID_MASK)>>30;
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(nMemPool_Id, BrFALSE);
#endif //USE_MCORE_MEMPOOL

	// [2016.02.19] �Ϻ� �������� pMemPool�� NULL�� ��찡 �־� �ʿ�ó���� �����Ѵ�.
	if (pMemPool == BrNULL)
		return;

#ifdef BRMEMORY_DEBUG_TRACE
	if(pMemPool->m_bInitHeapMem)
		g_pHeapTrace->remove(packet);
#endif //BRMEMORY_DEBUG_TRACE

	Free_MT(pMemPool, packet, COMMON_HEAP_MEM, szfile, nline);
}

BrLPVOID _BrCalloc(BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return calloc(num, size);
	}

	MALLOC_TIME_CHECK;
	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
#endif //USE_MCORE_MEMPOOL

	BrLPVOID pData = Calloc_MT(&gMemoryMap, pMemPool, num, size, COMMON_HEAP_MEM, szfile, nline);

#ifdef BRMEMORY_DEBUG_TRACE
	if(pMemPool->m_bInitHeapMem)
		g_pHeapTrace->add((char *)pData, szfile, nline, size);
#endif //BRMEMORY_DEBUG_TRACE
	return pData;
}

BrLPVOID _BrRealloc(BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return realloc(packet, size);
	}

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	BrINT nMemPool_Id = 0;
	if (packet)
	{
		PACKET *current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */
		if(IS_LARGE_PACKET(current))
			nMemPool_Id = (((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD))->magic_number&MEMPOOL_ID_MASK)>>30;
		else
			nMemPool_Id = (current->packet_size&MEMPOOL_ID_MASK)>>30;
		pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(nMemPool_Id, BrFALSE);
	}
	else
	{
		pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
		BrLPVOID pNewPack = Malloc_MT(&gMemoryMap, pMemPool, size, COMMON_HEAP_MEM, szfile, nline);
#ifdef BRMEMORY_DEBUG_TRACE
		g_pHeapTrace->add((BrCHAR*)pNewPack, szfile, nline, size);
#endif //BRMEMORY_DEBUG_TRACE
		return pNewPack;
	}
#endif //USE_MCORE_MEMPOOL

	BrLPVOID pNewPack = Realloc_MT(&gMemoryMap, pMemPool, packet, size, COMMON_HEAP_MEM, szfile, nline);

#ifdef BRMEMORY_DEBUG_TRACE
	g_pHeapTrace->remove(packet);
	g_pHeapTrace->add((BrCHAR*)pNewPack, szfile, nline, size);
#endif //BRMEMORY_DEBUG_TRACE
	return pNewPack;
}

/////////////////////////////////////////////////////////
BrLPVOID _BrSysMalloc(BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return malloc(size);
	}

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
#endif //USE_MCORE_MEMPOOL

	if( !pMemPool->m_pBoraSysMem )
		BoraSysMemInit(pMemPool);
	
	return Malloc_MT(&gMemoryMap, pMemPool, size, SYSTEM_HEAP_MEM, szfile, nline);
}

void _BrSysFree(void *packet, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		free(packet);
		return;
	}

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	CHECKVOIDRET(!packet);
	BrINT nMemPool_Id = 0;
	PACKET *current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */
	if(IS_LARGE_PACKET(current))
		nMemPool_Id = (((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD))->magic_number&MEMPOOL_ID_MASK)>>30;
	else
		nMemPool_Id = (current->packet_size&MEMPOOL_ID_MASK)>>30;
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(nMemPool_Id, BrFALSE);
#endif //USE_MCORE_MEMPOOL
	Free_MT(pMemPool, packet, SYSTEM_HEAP_MEM, szfile, nline);
}


BrLPVOID _BrSysCalloc(BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return calloc(num, size);
	}

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
#endif //USE_MCORE_MEMPOOL

	if( !pMemPool->m_pBoraSysMem )
		BoraSysMemInit(pMemPool);
	
	return Calloc_MT(&gMemoryMap, pMemPool, num, size, SYSTEM_HEAP_MEM, szfile, nline);
}


BrLPVOID _BrSysRealloc(BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return realloc(packet, size);
	}

	B_MEM_POOL* pMemPool = gpMemPool;
#ifdef USE_MCORE_MEMPOOL
	BrINT nMemPool_Id = 0;
	if (packet)
	{
		PACKET *current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */
		if(IS_LARGE_PACKET(current))
			nMemPool_Id = (((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD))->magic_number&MEMPOOL_ID_MASK)>>30;
		else
			nMemPool_Id = (current->packet_size&MEMPOOL_ID_MASK)>>30;
		pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(nMemPool_Id, BrFALSE);
	}
	else
	{
		pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(0, BrTRUE);
		BrLPVOID pNewPack = Malloc_MT(&gMemoryMap, pMemPool, size, SYSTEM_HEAP_MEM, szfile, nline);
		return pNewPack;
	}
#endif //USE_MCORE_MEMPOOL

	return Realloc_MT(&gMemoryMap, pMemPool, packet, size, SYSTEM_HEAP_MEM, szfile, nline);
}

#ifdef __cplusplus
}
#endif



#include <OfficePreComp.hpp>

#include "prmemory.h"
#include "prmemorytool.h"
#include "bheaptrace.h"
#include "brmcoreimp.h"
#include "binterfacehandle.h"
#include "send_to_callback.h"
#include "ThreadDefines_i.h"

/****************************************************************************/
/*																			*/
/* MREMOVE - REMOVE AN ITEM FROM THE FREE LIST. 							*/
/*																			*/
/****************************************************************************/
static void br_mremove(B_MEMORY * pBlock, PACKET *ptr)
{
	register PACKET *current = NULL;
	register PACKET *last    = NULL;

	current = pBlock->_sys_free;

	// calculate max packet, total memory
	pBlock->_total_free_size -= ptr->packet_size;
	if(!ptr->size_ptr)
		pBlock->_max_packet_size = ptr->last_ptr?ptr->last_ptr->packet_size:0;

	if (current == NULL)				
		pBlock->_sys_free = NULL;
	else if(current == ptr)				
	{
		if(ptr->size_ptr != NULL)
			ptr->size_ptr->last_ptr = NULL;
		pBlock->_sys_free = ptr->size_ptr;
	}
	else if(ptr->size_ptr==NULL)		
	{
		if(ptr->last_ptr != NULL)
			ptr->last_ptr->size_ptr = NULL;
	}
	else								
	{
		ptr->last_ptr->size_ptr = ptr->size_ptr;
		ptr->size_ptr->last_ptr = ptr->last_ptr;
	}
}

static void br_minsert(B_MEMORY * pBlock, PACKET *ptr)
{
	register PACKET *current = NULL;
	register PACKET *last    = NULL;

	// calculate max packet, total memory
	pBlock->_max_packet_size = BrMAX(ptr->packet_size, pBlock->_max_packet_size);
	pBlock->_total_free_size += ptr->packet_size;

	if (pBlock->_sys_free == NULL)
	{
		pBlock->_sys_free	= ptr;
		ptr->size_ptr		= NULL;
		ptr->last_ptr		= NULL;
		return;
	}

	current = pBlock->_sys_free;
	while (current && current->packet_size < ptr->packet_size)
	{
		last	= current;
		current = current->size_ptr;
	}

	if (current == NULL) 	       
	{
		last->size_ptr = ptr;
		ptr->size_ptr  = NULL;
		ptr->last_ptr = last;
	}
	else if (last == NULL)	       
	{
		ptr->last_ptr  = NULL;
		current->last_ptr = ptr;
		ptr->size_ptr  = current;
		pBlock->_sys_free = ptr;
	}
	else							
	{
		current->last_ptr = ptr;
		ptr->size_ptr  = current;
		ptr->last_ptr  = last;
		last->size_ptr = ptr;
	}
}

#ifdef USE_ADVANCED_BRMALLOC
static void br_mremove_ex(B_MEMORY * pBlock, PACKET *ptr)
{
	register PACKET *current = NULL;
	register PACKET *last    = NULL;
	register PACKET **head	 = NULL;

	// calculate max packet, total memory
	pBlock->_total_free_size -= ptr->packet_size;
	if (ptr->packet_size < MIN_FREE_PACKET_SIZE)
	{
		if(!ptr->size_ptr)
			pBlock->_small_max_packet_size = ptr->last_ptr?ptr->last_ptr->packet_size:0;
		current = pBlock->_small_sys_free? pBlock->_small_sys_free : pBlock->_sys_free;
		head = pBlock->_small_sys_free? &pBlock->_small_sys_free : &pBlock->_sys_free;
	}
	else
	{
		if(!ptr->size_ptr)
			pBlock->_max_packet_size = ptr->last_ptr?ptr->last_ptr->packet_size:0;
		current = pBlock->_sys_free;
		head = &pBlock->_sys_free;
	}

	if (current == NULL)				
		*head = NULL;
	else if(current == ptr)				
	{
		if(ptr->size_ptr != NULL)
			ptr->size_ptr->last_ptr = NULL;
		*head = ptr->size_ptr;
	}
	else if(ptr->size_ptr==NULL)		
	{
		if(ptr->last_ptr != NULL)
			ptr->last_ptr->size_ptr = NULL;
	}
	else								
	{
		ptr->last_ptr->size_ptr = ptr->size_ptr;
		ptr->size_ptr->last_ptr = ptr->last_ptr;
	}
}

static void br_minsert_ex(B_MEMORY * pBlock, PACKET *ptr)
{
	register PACKET *current = NULL;
	register PACKET *last    = NULL;
	register PACKET **head	 = NULL;

	// calculate max packet, total memory
	if (ptr->packet_size < MIN_FREE_PACKET_SIZE)
	{
		pBlock->_small_max_packet_size = BrMAX(ptr->packet_size, pBlock->_small_max_packet_size);
		current = pBlock->_small_sys_free;
		head = &pBlock->_small_sys_free;
	}
	else
	{
		pBlock->_max_packet_size = BrMAX(ptr->packet_size, pBlock->_max_packet_size);
		current = pBlock->_sys_free;
		head = &pBlock->_sys_free;
	}
	pBlock->_total_free_size += ptr->packet_size;

	if (*head == NULL)
	{
		*head				= ptr;
		ptr->size_ptr		= NULL;
		ptr->last_ptr		= NULL;
		return;
	}

	while (current && current->packet_size < ptr->packet_size)
	{
		last	= current;
		current = current->size_ptr;
	}

	if (current == NULL) 	       
	{
		last->size_ptr = ptr;
		ptr->size_ptr  = NULL;
		ptr->last_ptr = last;
	}
	else if (last == NULL)	       
	{
		ptr->last_ptr  = NULL;
		current->last_ptr = ptr;
		ptr->size_ptr  = current;
		*head = ptr;
	}
	else							
	{
		current->last_ptr = ptr;
		ptr->size_ptr  = current;
		ptr->last_ptr  = last;
		last->size_ptr = ptr;
	}
}
#endif //USE_ADVANCED_BRMALLOC

#define MIN_FREE_BLOCK_SIZE	64		// Small Block ���� ������ MIN_FREE_BLOCK_SIZE ���� �۰� ������ ��� BlockList���� ���ܽ�Ŵ
static inline void ShrinkBlockList(B_MEM_POOL* pMemPool, BrINT nBlockListPos, B_MEMORY* pBlock)
{
#ifdef USE_ADVANCED_BRMALLOC
	if (!(pBlock->_not_use_block) && pBlock->_max_packet_size < MIN_FREE_BLOCK_SIZE) 
#else //USE_ADVANCED_BRMALLOC
	if (pBlock->_max_packet_size < MIN_FREE_BLOCK_SIZE) 
#endif  //USE_ADVANCED_BRMALLOC
	{
#ifdef USE_ADVANCED_BRMALLOC
		pBlock->_not_use_block = BrTRUE;
#endif //USE_ADVANCED_BRMALLOC
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		// BlockList���� ����
		if(pBlock->_next_memory_block == pBlock)	// only one block
		{
			pMemPool->m_pBoraHeapMem[nBlockListPos] = BrNULL;
			pBlock->_prev_memory_block = pBlock->_next_memory_block = BrNULL;
		}
		else	// remove one block
		{
			B_MEMORY* ptr = pBlock->_next_memory_block;
			pBlock->_prev_memory_block->_next_memory_block = pBlock->_next_memory_block;
			pBlock->_next_memory_block->_prev_memory_block = pBlock->_prev_memory_block;
			if (pBlock == pMemPool->m_pBoraHeapMem[nBlockListPos])
				pMemPool->m_pBoraHeapMem[nBlockListPos] = ptr;
		}

		// NotUseBlock List�� �߰�
		B_MEMORY* pNotUseBlock = pMemPool->m_pNotUseBlock[nBlockListPos];
		if(pNotUseBlock)
		{
			B_MEMORY* current	= pNotUseBlock;
			B_MEMORY* prev = current->_prev_memory_block;

			pBlock->_prev_memory_block = prev;
			pBlock->_next_memory_block = current;
			prev->_next_memory_block = current->_prev_memory_block = pBlock;

			pMemPool->m_pNotUseBlock[nBlockListPos] = pBlock;
		}
		else
		{
			pMemPool->m_pNotUseBlock[nBlockListPos] = pBlock;
			pBlock->_prev_memory_block = pBlock->_next_memory_block = pBlock;
		}
#else //USE_MULTI_MEMORY_BLOCK_LIST
		// BlockList���� ����
		if(pBlock->_next_memory_block == pBlock)	// only one block
		{
			pMemPool->m_pBoraHeapMem = BrNULL;
			pBlock->_prev_memory_block = pBlock->_next_memory_block = BrNULL;
		}
		else	// remove one block
		{
			B_MEMORY* ptr = pBlock->_next_memory_block;
			pBlock->_prev_memory_block->_next_memory_block = pBlock->_next_memory_block;
			pBlock->_next_memory_block->_prev_memory_block = pBlock->_prev_memory_block;
			if (pBlock == pMemPool->m_pBoraHeapMem)
				pMemPool->m_pBoraHeapMem = ptr;
		}

		// NotUseBlock List�� �߰�
		B_MEMORY* pNotUseBlock = pMemPool->m_pNotUseBlock;
		if(pNotUseBlock)
		{
			B_MEMORY* current	= pNotUseBlock;
			B_MEMORY* prev = current->_prev_memory_block;

			pBlock->_prev_memory_block = prev;
			pBlock->_next_memory_block = current;
			prev->_next_memory_block = current->_prev_memory_block = pBlock;
		}
		else
		{
			pMemPool->m_pNotUseBlock = pBlock;
			pBlock->_prev_memory_block = pBlock->_next_memory_block = pBlock;
		}
#endif //USE_MULTI_MEMORY_BLOCK_LIST
	}
}

#ifdef USE_ADVANCED_BRMALLOC
// NotUseBlock ���� ������ MIN_FREE_BLOCK_SIZE �̻��� ��� BlockList�� ������Ŵ
static inline void EnlargeBlockList(B_MEM_POOL* pMemPool, BrINT nBlockListPos, B_MEMORY* pNotUseBlock)
{
	if (pNotUseBlock->_max_packet_size >= MIN_FREE_BLOCK_SIZE)
	{
		pNotUseBlock->_not_use_block = BrFALSE;
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		// NotUseBlock���� ����
		if(pNotUseBlock->_next_memory_block == pNotUseBlock)	// only one block
		{
			pMemPool->m_pNotUseBlock[nBlockListPos] = BrNULL;
			pNotUseBlock->_prev_memory_block = pNotUseBlock->_next_memory_block = BrNULL;
		}
		else	// remove one block
		{
			B_MEMORY* ptr = pNotUseBlock->_next_memory_block;
			pNotUseBlock->_prev_memory_block->_next_memory_block = pNotUseBlock->_next_memory_block;
			pNotUseBlock->_next_memory_block->_prev_memory_block = pNotUseBlock->_prev_memory_block;
			if (pNotUseBlock == pMemPool->m_pNotUseBlock[nBlockListPos])
				pMemPool->m_pNotUseBlock[nBlockListPos] = ptr;
		}

		// BlockList�� �߰�
		B_MEMORY* pBlock = pMemPool->m_pBoraHeapMem[nBlockListPos];
		if(pBlock)
		{
			B_MEMORY* current	= pBlock;
			B_MEMORY* prev = current->_prev_memory_block;

			pNotUseBlock->_prev_memory_block = prev;
			pNotUseBlock->_next_memory_block = current;
			prev->_next_memory_block = current->_prev_memory_block = pNotUseBlock;

			pMemPool->m_pBoraHeapMem[nBlockListPos] = pNotUseBlock;
		}
		else
		{
			pMemPool->m_pBoraHeapMem[nBlockListPos] = pNotUseBlock;
			pNotUseBlock->_prev_memory_block = pNotUseBlock->_next_memory_block = pNotUseBlock;
		}
#else //USE_MULTI_MEMORY_BLOCK_LIST
		// NotUseBlock���� ����
		if(pNotUseBlock->_next_memory_block == pNotUseBlock)	// only one block
		{
			pMemPool->m_pNotUseBlock = BrNULL;
			pNotUseBlock->_prev_memory_block = pNotUseBlock->_next_memory_block = BrNULL;
		}
		else	// remove one block
		{
			B_MEMORY* ptr = pNotUseBlock->_next_memory_block;
			pNotUseBlock->_prev_memory_block->_next_memory_block = pNotUseBlock->_next_memory_block;
			pNotUseBlock->_next_memory_block->_prev_memory_block = pNotUseBlock->_prev_memory_block;
			if (pNotUseBlock == pMemPool->m_pNotUseBlock)
				pMemPool->m_pNotUseBlock = ptr;
		}

		// BlockList�� �߰�
		B_MEMORY* pBlock = pMemPool->m_pBoraHeapMem;
		if(pBlock)
		{
			B_MEMORY* current	= pBlock;
			B_MEMORY* prev = current->_prev_memory_block;

			pNotUseBlock->_prev_memory_block = prev;
			pNotUseBlock->_next_memory_block = current;
			prev->_next_memory_block = current->_prev_memory_block = pNotUseBlock;
		}
		else
		{
			pMemPool->m_pBoraHeapMem = pNotUseBlock;
			pNotUseBlock->_prev_memory_block = pNotUseBlock->_next_memory_block = pNotUseBlock;
		}
#endif //USE_MULTI_MEMORY_BLOCK_LIST
	}
}
#endif //USE_ADVANCED_BRMALLOC

/////////////////////////////////////////////////////////////////////////////////////
void ReInitMemoryMap_MT(BORA_MEMORY_MAP & sMap, BrUINT64 nTotalSize)
{
	sMap.BORA_SYSMEM_SIZE = MEM_SZ_64K;
	sMap.BORA_SYSMEM_THRESHOLD = MEM_SZ_10K;

	sMap.BORA_HEAPMEM_SIZE = MEM_SZ_64K;
	sMap.BORA_HEAPMEM_THRESHOLD = MEM_SZ_10K;
}

void InitMemoryMap_MT(BORA_MEMORY_MAP & sMap, BrUINT64& nTotalSize)
{
	BrINT32 font_mem_size = 0;
	memset(&sMap, 0, BrSizeOf(BORA_MEMORY_MAP));

	sMap.BORA_SYSMEM_SIZE = MEM_SZ_64K;

	/* �� ������ font memory size�� ���� �� �־�� ��. */
	nTotalSize = nTotalSize - THREAD_MEM_SIZE - EVENT_MEM_SIZE - font_mem_size - BrSizeOf(B_MEM_POOL);
	ReInitMemoryMap_MT(sMap, nTotalSize);
}

void InitMemPool_MT(B_MEM_POOL** lpMemPool, void** lpHeapTracePtr)
{
	*lpMemPool = (B_MEM_POOL*)BMalloc(BrSizeOf(B_MEM_POOL));
	B_MEM_POOL* pMemPool = *lpMemPool;
	if(!pMemPool) // Mainthread
	{
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrSystemMemory;
		BRTERMINATE(g_BoraThreadAtom.m_nMemoryErrorCode, "", PO_PUBLIC_CLASS);
	}

	memset((BrCHAR*)pMemPool, 0, BrSizeOf(B_MEM_POOL));
	pMemPool->m_bResetHeapMem = BrTRUE;
#ifdef BRMEMORY_DEBUG_TRACE
	if(lpHeapTracePtr)
	{
		BHeapTrace *pTrace = new BHeapTrace;
		*lpHeapTracePtr= (void*)pTrace;
	}
#endif //BRMEMORY_DEBUG_TRACE

}

#ifdef BRMEMORY_DEBUG_TRACE
void EndMemPool_MT(B_MEM_POOL** lpMemPool, void** lpHeapTracePtr)
{
	if( *lpMemPool)
		BFree(*lpMemPool);
	*lpMemPool = BrNULL;	
	BHeapTrace** lpHeapTrace = (BHeapTrace**)lpHeapTracePtr;
	if(lpHeapTrace && *lpHeapTrace)
	{
		delete *lpHeapTrace;
		*lpHeapTrace = BrNULL;
	}
}
#else //BRMEMORY_DEBUG_TRACE
void EndMemPool_MT(B_MEM_POOL** lpMemPool)
{
	if( *lpMemPool)
		BFree(*lpMemPool);
	*lpMemPool = BrNULL;
}
#endif //BRMEMORY_DEBUG_TRACE

B_MEMORY* AllocMemBlock_MT(B_MEMORY* pHeapMBlock, BrINT32 nSize, B_MEM_POOL* pMemPool)
{
	B_MEMORY* pBlock;

	CHECKNULLRET((BrINT32)nSize<=0 || nSize<BrSizeOf(B_MEMORY)+BLOCK_OVERHEAD+MIN_BLOCK);
#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	nSize += MEM_DEBUG_TAIL_SIZE;
#endif

	//���� �޸𸮸� ������ ��츸 ����ϰ� �ƴ� ��� ����޸𸮸����� ���
	BrUINT64 nAvailSize = pMemPool->m_available_memory_size;
	if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 )
		nAvailSize -= pMemPool->m_allocated_memory_size;
	if ( nAvailSize < nSize )
	{
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrMaxHeapSizeOver;
		return BrNULL;
	}

	if( pBlock = (B_MEMORY*)BMallocEx(nSize) )
	{
		if(pHeapMBlock)
		{
			B_MEMORY* current	= pHeapMBlock;
			B_MEMORY* prev = current->_prev_memory_block;

			pBlock->_prev_memory_block = prev;
			pBlock->_next_memory_block = current;
			prev->_next_memory_block = current->_prev_memory_block = pBlock;
		}
		else // first block
			pBlock->_prev_memory_block = pBlock->_next_memory_block = pBlock;
	}
	else
	{
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrSystemMemory;
		return BrNULL;
	}

	pMemPool->m_allocated_memory_size += nSize;
	//�ִ� ���� �޸� ũ�Ⱑ ������ ��쿡�� ��
	if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 )
		BRTHREAD_ASSERT(pMemPool->m_available_memory_size >= pMemPool->m_allocated_memory_size);
	pBlock->_actual_size	= nSize;

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	nSize -= MEM_DEBUG_TAIL_SIZE;
#endif

	pBlock->_memory_size = (nSize - BrSizeOf(B_MEMORY))&~BLOCK_MASK; // 8�� ����� ����
	pBlock->_sys_memory = ((BrCHAR*)pBlock + BrSizeOf(B_MEMORY));
	pBlock->_sys_memory_sptr = pBlock->_sys_memory;
	pBlock->_sys_memory_eptr = (BrCHAR*)pBlock->_sys_memory + pBlock->_memory_size;
	pBlock->_sys_free = (PACKET *)pBlock->_sys_memory;
	pBlock->_sys_free->packet_size = pBlock->_memory_size - BLOCK_OVERHEAD;
	pBlock->_sys_free->last_ptr_nearby = BrNULL;
	pBlock->_sys_free->last_ptr	  = BrNULL;
	pBlock->_sys_free->size_ptr	  = BrNULL;
	pBlock->_total_free_size = pBlock->_max_packet_size	= pBlock->_sys_free->packet_size;
#ifdef USE_ADVANCED_BRMALLOC
	pBlock->_not_use_block = BrFALSE;
	pBlock->_small_sys_free = BrNULL;
	pBlock->_small_max_packet_size = 0;
	pBlock->_dummy = 0;
#endif //USE_ADVANCED_BRMALLOC

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	*((BrINT64*)((BrCHAR*)pBlock + pBlock->_actual_size - MEM_DEBUG_TAIL_SIZE)) = MEM_DEBUG_TAIL_VALUE;
#endif

	return pBlock;
}

B_MEMORY* AppendMemory_MT(B_MEMORY* pHeapMBlock, BrUINT32 nSize, B_MEM_POOL* pMemPool, BORA_MEMORY_MAP* pMemoryMap)
{
	BrUINT32	nHeapMemSize = pMemPool->m_pBoraSysMem == pHeapMBlock?pMemoryMap->BORA_SYSMEM_SIZE:pMemoryMap->BORA_HEAPMEM_SIZE;
	BrUINT64	nAvailSize = pMemPool->m_available_memory_size;
	if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 )
		nAvailSize -= pMemPool->m_allocated_memory_size;
	B_MEMORY	*pBlock;

	BRTHREAD_ASSERT( (nSize&~BLOCK_MASK) && (nSize&BLOCK_MASK) == 0 ); // 8(32bit) or 16(64bit)�� ��� üũ
	
	nSize = nSize + BrSizeOf(B_MEMORY) + BLOCK_OVERHEAD;

	if(nSize > nHeapMemSize && nSize > nAvailSize)
	{
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrMaxHeapSizeOver;
		return BrNULL;
	}
	else
		nSize = BrMIN(BrMAX(nSize, nHeapMemSize), nAvailSize);

	pBlock = AllocMemBlock_MT(pHeapMBlock, nSize, pMemPool);
	return pBlock;
}

void HeapMemInit_MT(B_MEM_POOL* pMemPool, BORA_MEMORY_MAP* pMemoryMap)
{
	if (!pMemPool->m_bResetHeapMem)
		return;

	if( pMemPool->m_available_memory_size < MEM_SZ_1M )
		pMemPool->m_available_memory_size = MEM_SZ_1M;		

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	ReInitMemoryMap_MT(*pMemoryMap, pMemPool->m_available_memory_size);
	for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
	{
		do 
		{			
			pMemPool->m_pBoraHeapMem[i] = AllocMemBlock_MT(pMemPool->m_pBoraHeapMem[i], pMemoryMap->BORA_HEAPMEM_SIZE, pMemPool);
			if(!pMemPool->m_pBoraHeapMem[i])
			{
				pMemPool->m_available_memory_size -= MEM_SZ_1M;
				if( pMemPool->m_available_memory_size < MEM_SZ_2M ) 
					BRTERMINATE(kPoErrMemoryInitial, "", PO_PUBLIC_CLASS);
			}

		}
		while(!pMemPool->m_pBoraHeapMem[i]);
	}
#else //USE_MULTI_MEMORY_BLOCK_LIST
	do 
	{
		ReInitMemoryMap_MT(*pMemoryMap, pMemPool->m_available_memory_size);
		pMemPool->m_pBoraHeapMem = AllocMemBlock_MT(pMemPool->m_pBoraHeapMem, pMemoryMap->BORA_HEAPMEM_SIZE, pMemPool);

		if(!pMemPool->m_pBoraHeapMem)
		{
			pMemPool->m_available_memory_size -= MEM_SZ_1M;
			if( pMemPool->m_available_memory_size < MEM_SZ_2M ) 
				BRTERMINATE(kPoErrMemoryInitial, "", PO_PUBLIC_CLASS);
		}

	}
	while(!pMemPool->m_pBoraHeapMem);
#endif //USE_MULTI_MEMORY_BLOCK_LIST
	
	pMemPool->m_bInitHeapMem = BrTRUE;
}

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
void BoraDeleteBlock_MT(B_MEM_POOL *pMemPool, B_MEMORY*& RootBlock, B_MEMORY*& ptr, BrINT blockListPos, BrBOOL bSkipFirst)
{	
	B_MEMORY	*pBlock = ptr;

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	BRTHREAD_ASSERT(*((BrINT64*)((BrCHAR*)pBlock + pBlock->_actual_size - MEM_DEBUG_TAIL_SIZE)) == MEM_DEBUG_TAIL_VALUE);
#endif

	BrLONG nActual_size = pBlock->_actual_size;
	if(pBlock->_next_memory_block == pBlock)	// only one block
	{
		if (bSkipFirst)
			return;
		BFreeEx(pBlock);
		if(RootBlock == pMemPool->m_pBoraHeapMem[blockListPos])
		{
			BrBOOL bBlockExist = BrFALSE;
			for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
			{
				if (pMemPool->m_pBoraHeapMem[i] && blockListPos!=SBLOCKLIST_COUNT-1)
				{
					bBlockExist = BrTRUE;
					break;
				}
			}
			pMemPool->m_bInitHeapMem = bBlockExist? BrTRUE : BrFALSE;
		}

		RootBlock = ptr = BrNULL;
	}
	else	// remove one block
	{
		ptr = pBlock->_next_memory_block;
		pBlock->_prev_memory_block->_next_memory_block = pBlock->_next_memory_block;
		pBlock->_next_memory_block->_prev_memory_block = pBlock->_prev_memory_block;
		BFreeEx(pBlock);

		if(pBlock == RootBlock)
			RootBlock = ptr;
	}
	pMemPool->m_allocated_memory_size -= nActual_size;
}
#else //USE_MULTI_MEMORY_BLOCK_LIST
void BoraDeleteBlock_MT(B_MEM_POOL *pMemPool, B_MEMORY*& RootBlock, B_MEMORY*& ptr, BrBOOL bSkipFirst)
{	
	B_MEMORY	*pBlock = ptr;

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	BRTHREAD_ASSERT(*((BrINT64*)((BrCHAR*)pBlock + pBlock->_actual_size - MEM_DEBUG_TAIL_SIZE)) == MEM_DEBUG_TAIL_VALUE);
#endif

	BrLONG nActual_size = pBlock->_actual_size;
	if(pBlock->_next_memory_block == pBlock)	// only one block
	{
		if (bSkipFirst)
			return;
		BFreeEx(pBlock);
		if(RootBlock == pMemPool->m_pBoraHeapMem)
			pMemPool->m_bInitHeapMem = BrFALSE;

		RootBlock = ptr = BrNULL;
	}
	else	// remove one block
	{
		ptr = pBlock->_next_memory_block;
		pBlock->_prev_memory_block->_next_memory_block = pBlock->_next_memory_block;
		pBlock->_next_memory_block->_prev_memory_block = pBlock->_prev_memory_block;
		BFreeEx(pBlock);

		if(pBlock == RootBlock)
			RootBlock = ptr;
	}
	pMemPool->m_allocated_memory_size -= nActual_size;
}
#endif //USE_MULTI_MEMORY_BLOCK_LIST


LARGE_PACKET* BoraAllocLargeBlock_MT(B_MEM_POOL *pMemPool, LARGE_PACKET*& RootBlock, BrINT32 size)
{
	BrINT32 actual_size = size + BrSizeOf(LARGE_PACKET);
	LARGE_PACKET* packet = BrNULL;
	BrUINT64	nAvailSize = pMemPool->m_available_memory_size;
	if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 )
		nAvailSize -= pMemPool->m_allocated_memory_size;
	if( nAvailSize < actual_size )
	{
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrMaxHeapSizeOver;
		return BrNULL;
	}

	if(packet = (LARGE_PACKET*)BMallocEx(actual_size))
	{
		packet->magic_number = MEM_MAGIC_NUMBER;
#ifdef USE_MCORE_MEMPOOL
		packet->magic_number |= (pMemPool->m_MemPool_Id << 30);
#endif //USE_MCORE_MEMPOOL
		packet->_actual_size = actual_size;
		packet->_prev_large_pack = BrNULL;

		if(RootBlock)
		{
			RootBlock->_prev_large_pack = packet;
			packet->_next_large_pack = RootBlock;
			RootBlock = packet;
		}
		else
		{
			// first
			packet->_next_large_pack = BrNULL;
			RootBlock = packet;
		}

		pMemPool->m_allocated_memory_size += actual_size;
	}
	else
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrSystemMemory;
	
	return packet;
}

void BoraDeleteLargeBlock_MT(LARGE_PACKET*& pRootBlock, LARGE_PACKET* packet, B_MEM_POOL	* pMemPool)
{	
	LARGE_PACKET* current = pRootBlock;
	BRTHREAD_ASSERT(pRootBlock);

	bora_large_initialize_packet(packet);

	/*-----------------------------------------------------------------------*/
	/* REMOVE THE PACKET FROM THE LIST.   THERE ARE TWO CASES :              */
	/*   THE OLD POINTER WILL EITHER BE THE FIRST, OR NOT THE FIRST.         */
	/*-----------------------------------------------------------------------*/
	if (current == NULL)				/* EMPTY LIST */
		pRootBlock = NULL;
	else if(current == packet)							/* 1ST IN LIST */
	{
		if(packet->_next_large_pack != NULL)
			packet->_next_large_pack->_prev_large_pack = NULL;
		pRootBlock = packet->_next_large_pack;
	}
	else if(packet->_next_large_pack==NULL)				/* LAST IN LIST */
	{
		packet->_prev_large_pack->_next_large_pack = NULL;
	}
	else												/* MID OF LIST */
	{
		packet->_prev_large_pack->_next_large_pack = packet->_next_large_pack;
		packet->_next_large_pack->_prev_large_pack = packet->_prev_large_pack;
	}

	pMemPool->m_allocated_memory_size -= packet->_actual_size;
	BFreeEx(packet);
}

// large block������ �̵���.
LARGE_PACKET* BoraReallocLargeBlock_MT(LARGE_PACKET*& RootBlock, LARGE_PACKET* packet, BrUINT32 nNewSize, B_MEM_POOL	* pMemPool)
{
	LARGE_PACKET*	Oldpacket = packet;
	BrUINT32		nOldSize = packet->_actual_size;
	BrUINT32		actual_size = nNewSize + BrSizeOf(LARGE_PACKET);
	BrUINT64	nAvailSize = pMemPool->m_available_memory_size;
	if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 )
		nAvailSize -= pMemPool->m_allocated_memory_size;
	if( (nAvailSize - nOldSize ) < actual_size )
	{
		g_BoraThreadAtom.m_nMemoryErrorCode = kPoErrMaxHeapSizeOver;
		return BrNULL;
	}

	BRTHREAD_ASSERT(RootBlock);

	bora_large_initialize_packet(packet);

	if( packet = (LARGE_PACKET*)BRealloc(packet, actual_size) )
	{
		if (actual_size > nOldSize)
			pMemPool->m_allocated_memory_size += (actual_size - nOldSize);
		else
			pMemPool->m_allocated_memory_size += (nOldSize - actual_size);

		packet->_actual_size = actual_size;
		if(	packet->_prev_large_pack)
			packet->_prev_large_pack->_next_large_pack = packet;

		if( packet->_next_large_pack)
			packet->_next_large_pack->_prev_large_pack = packet;

		if( RootBlock == Oldpacket )
			RootBlock = packet;


		return packet;
	}
	else
		return BrNULL;
}

void BoraHeapMemFree_MT(B_MEM_POOL* pMemPool)
{
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	for (BrINT i=0; i<SBLOCKLIST_COUNT; i++)
	{
		if(pMemPool->m_pBoraHeapMem[i])
		{
			do {
				BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem[i], pMemPool->m_pBoraHeapMem[i], i);
			} while(pMemPool->m_pBoraHeapMem[i]);
		}
		if(pMemPool->m_pNotUseBlock[i])
		{
			do {
				BoraDeleteBlock_MT(pMemPool, pMemPool->m_pNotUseBlock[i], pMemPool->m_pNotUseBlock[i], i);
			} while(pMemPool->m_pNotUseBlock[i]);
		}
	}
#else //USE_MULTI_MEMORY_BLOCK_LIST
	if(pMemPool->m_pBoraHeapMem)
	{
		do {
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem, pMemPool->m_pBoraHeapMem);
		} while(pMemPool->m_pBoraHeapMem);
	}
	if(pMemPool->m_pNotUseBlock)
	{
		do {
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pNotUseBlock, pMemPool->m_pNotUseBlock);
		} while(pMemPool->m_pNotUseBlock);
	}
#endif //USE_MULTI_MEMORY_BLOCK_LIST

	if(pMemPool->m_pBoraLargeHeap)
	{
		do {
			BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeHeap, pMemPool->m_pBoraLargeHeap, pMemPool);			
		} while(pMemPool->m_pBoraLargeHeap);
	}
}

//���� �޸� �ܰ躰 noti
void Send_Memory_Level(B_MEM_POOL* pMemPool, BrSIZE_T size)
{	
	BRCONTEXT;
	if (Brcontext.m_GeneralValue.IsViewerTerminate())
		return;
	//�ܺ� ���ο� ���� ���� �޸𸮰� �پ��� ��츦 ������ ������ ���� �޸𸮸� Ȯ���ϵ��� ó��
	if (g_pBInterfaceHandle->checkAvailableMemory())
	{
		pMemPool->m_available_memory_size = PoGetAvailableMemorySizes();
	}
	if (g_pBInterfaceHandle->isTerminateCondition(pMemPool->m_available_memory_size))
		BRTERMINATE(kPoErrMemory, "Send_Memory_Level", PO_PUBLIC_CLASS);

	//Android�� ���� �޸� ������ ������ ���� �ɷ��� ������ ���� ���� ����Ѵ�.
	//�÷������� ���� ������ ��� ������ ������ ���� �� �־� ������?�̺�Ʈ �Ϸ� ������ �޸𸮸� �򵵷� ����
	BrUINT64 lsize = pMemPool->m_available_memory_size;//���� �޸� Ȯ��	
	BrUINT64 nAllocSize = pMemPool->m_allocated_memory_size;			//����� �޸� Ȯ��
	//������ ũ���� ��쿡 ���� �޸𸮿��� �Ҵ� �޸𸮸� ���� ����
	if ( g_pBInterfaceHandle->GetTotalMemorySizes()>0 && lsize >= nAllocSize)
		lsize -= nAllocSize;

	int level = 0;

	//��ũ�� ũ��	
	BrUINT64 nScreenBufferSize = getDeviceScreenWidth()*getDeviceScreenHeight()*(BrMAX(8, gnBits)/8);

	// �ּ� �޸� ���� ����
	// critical 4 : ��û�� ũ�⸦ alloc���� ���� �� 
	// warning 3 : �ּ� ������ ����(��ũ�� ���� 1EA + 1MB)			
	// warning 2 : ������ ������ �ּ� ũ��(��ũ�� ���� 2EA + 5MB)
	// warning 1 : ������ ������ �ּ� ũ��(���� alloc�� ũ��/2 + 5MB)
	if ( lsize < size )	//alloc�� ����� ���� ���� �ʴ� ���, ����� terminate
		level = 4;
	else if ( lsize < (nScreenBufferSize +  MEM_SZ_1M) )
		level = 3;
	else if ( lsize < (nScreenBufferSize*2 +  MEM_SZ_5M) )
		level = 2;
	else if ( lsize < (nAllocSize/2 +  MEM_SZ_5M) )
		level = 1;
	else								//����
		level = 0;	

	//���� �޸� �����ϴ� Ÿ�̹��� 10MB�� ����
	int nCheckLevel = (nAllocSize / MEM_SZ_10M);	
	if ( pMemPool->m_check_memory_level < nCheckLevel )
	{
		pMemPool->m_check_memory_level = nCheckLevel;
		pMemPool->m_available_memory_size = PoGetAvailableMemorySizes();
		//������ ����Ǵ� �������� ����� �����ϵ��� ����
		if ( level > 0 ) 
			SendBaseResultCallback(0, Bora_memory_warning_info, level, g_pBInterfaceHandle->m_pUIPROCESS_CBFUNC);
	}	
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BrLPVOID Malloc_MT(BORA_MEMORY_MAP* pMemoryMap, B_MEM_POOL* pMemPool, BrSIZE_T size, eMEMORY_TYPE type, BrCHAR* szfile, BrUINT32 nline)
{
	//thread yield? vd
	g_pBInterfaceHandle->ForceThreadYield();

	register PACKET* current = NULL; // TODO: move
	register B_MEMORY	*pBlock = NULL;
	register PACKET		*extra_block = NULL;
	register BrUINT32	newsize;
	register BrUINT32	oldsize;
	B_MEMORY* pOldBlock = NULL; // TODO: move
	BrINT nBlockListPos = 0;
		
	if( pMemPool->m_bInitHeapMem==BrFALSE )
		HeapMemInit_MT(pMemPool, pMemoryMap);

	BRTHREAD_ASSERT((BrINT32)size >= 0);	// ������ break
	CHECKNULLRET((BrINT32)size<=0);
	if ( type == SYSTEM_HEAP_MEM )
	{
		CHECKNULLRET(!pMemPool->m_pBoraSysMem);
	}
	else
	{
		CHECKNULLRET(!pMemPool->m_bInitHeapMem || !pMemPool->m_bResetHeapMem);
	}	
	newsize = (size + BLOCK_MASK) & ~BLOCK_MASK;
#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	newsize += MEM_DEBUG_TAIL_SIZE;
#endif
	Send_Memory_Level(pMemPool, newsize);

	BRLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
	if ( type == SYSTEM_HEAP_MEM )
	{
		if(newsize >= pMemoryMap->BORA_SYSMEM_THRESHOLD)
		{
			LARGE_PACKET* large_packet;
			PoError nErrorBackup = g_BoraThreadAtom.m_nMemoryErrorCode;

			if( large_packet = BoraAllocLargeBlock_MT(pMemPool, pMemPool->m_pBoraLargeSysHeap, newsize) )
			{
				bora_set_large_debuginfo(pMemPool, large_packet, szfile, nline);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return (BrCHAR*)large_packet + LARGE_BLOCK_OVERHEAD;
			}

			// �ý��� �޸� �Ҵ�(malloc) ����, �Ǵ� MaxHeapSize �ʰ��� ���
			if (newsize > SMALL_PACKET_MAX_SIZE || g_BoraThreadAtom.m_nMemoryErrorCode == kPoErrMaxHeapSizeOver)
			{
				// Ư�� ũ��(small packet �ִ� ������) �̻��� ���, �Ǵ� MaxHeapSize �ʰ��� ��� => ���� ó��
				goto alloc_fail;
			}
			else
			{
				// Small Block���� �޸� �Ҵ� �õ�
				g_BoraThreadAtom.m_nMemoryErrorCode = nErrorBackup;
			}
		}

		if( !(pBlock = GetFontBlockBySize(newsize, pMemPool)) )
			goto alloc_fail;
	}
	else
	{
		if(newsize >= pMemoryMap->BORA_HEAPMEM_THRESHOLD)
		{
			LARGE_PACKET* large_packet;
			PoError nErrorBackup = g_BoraThreadAtom.m_nMemoryErrorCode;

			if( large_packet = BoraAllocLargeBlock_MT(pMemPool, pMemPool->m_pBoraLargeHeap, newsize) )
			{
				bora_set_large_debuginfo(pMemPool, large_packet, szfile, nline);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return (BrCHAR*)large_packet + LARGE_BLOCK_OVERHEAD;
			}

			// �ý��� �޸� �Ҵ�(malloc) ����, �Ǵ� MaxHeapSize �ʰ��� ���
			if (newsize > SMALL_PACKET_MAX_SIZE || g_BoraThreadAtom.m_nMemoryErrorCode == kPoErrMaxHeapSizeOver)
			{
				// Ư�� ũ��(small packet �ִ� ������) �̻��� ���, �Ǵ� MaxHeapSize �ʰ��� ��� => ���� ó��
				goto alloc_fail;
			}
			else
			{
				// Small Block���� �޸� �Ҵ� �õ�
				g_BoraThreadAtom.m_nMemoryErrorCode = nErrorBackup;
			}
		}

	#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		nBlockListPos = GetBlockListPos(pMemPool, BrTRUE);
		if( !(pBlock = GetBlockByIndex(nBlockListPos, pMemPool)) )
		{
	#ifdef USE_ADVANCED_BRMALLOC
			// BlockList�� ����ִ� ���, ������ NotUseBlock List�� �Ű����� ���ɼ��� �����Ƿ� �޸� ���� �Ҵ��� �õ���
			if(pBlock = AppendMemory_MT(pBlock, newsize, pMemPool, pMemoryMap))
				pMemPool->m_pBoraHeapMem[nBlockListPos] = pBlock;
			else
				goto alloc_fail;
	#else //USE_ADVANCED_BRMALLOC
			goto alloc_fail;
	#endif //USE_ADVANCED_BRMALLOC
		}
	#else //USE_MULTI_MEMORY_BLOCK_LIST
		if ( type == COMMON_HEAP_MEM )
		{
			if( !(pBlock = GetBlockBySize(newsize, pMemPool)) )
				pBlock = pMemPool->m_pBoraHeapMem;
		}
		else if ( type == SPECIAL_HEAP_MEM )
		{
			if( !(pBlock = GetBlockBySize(newsize, pMemPool)) )
			{
				// SpecialMalloc ��� �� BlockList�� ����ִ� ���, ������ NotUseBlock List�� �Ű����� ���ɼ��� �����Ƿ� �޸� ���� �Ҵ��� �õ���
				if(pBlock = AppendMemory_MT(pBlock, newsize, pMemPool, pMemoryMap))
					pMemPool->m_pBoraHeapMem = pBlock;
				else
					goto alloc_fail;
			}

		}
	#endif //USE_MULTI_MEMORY_BLOCK_LIST

		if ( type == COMMON_HEAP_MEM )
		{
			if (!pBlock)
			{
				BRTHREAD_ASSERT(pBlock);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return 0;
			}
		}
	}

	// NOTE! https://confluence.infraware.net:8443/pages/viewpage.action?pageId=33390871 [memory manager] ����
	// #1 search in block(packet list)
	if( pBlock->_max_packet_size >= newsize )
	{
		if ( type == COMMON_HEAP_MEM )
			current = TryAllocEX(pBlock, newsize);
		else
			current = TryAlloc(pBlock, newsize);
		if (!current)
		{
			BRTHREAD_ASSERT("mailto://kos0120@infrawareglobal.com" == 0); // IMPORTANT!
			// https://confluence.infraware.net:8443/pages/viewpage.action?pageId=33390871
			// CSP-6837 edit error - CSP-7391 ���� fixed Ȯ��
			// CSP-7391 save error - error level ����
			SET_ERROR_LOG((int)kPoErrMemory, __FUNCTION__, false);
		}
		//Andrew current�� ������ ��찡 �߻��ϸ� ����Ʈ�� ������ ���¶� ���� ������ ������ �� ��� failó���Ѵ�.
		//if ( !current )
		//	goto alloc_fail;
	}

	if ( !current ) // search failed (in packet list)
	{
		// #2 search in block list
		pOldBlock = pBlock;
		pBlock = pBlock->_next_memory_block;
		if(pOldBlock != pBlock)
		{
			do
			{
				if( pBlock->_max_packet_size >= newsize )
				{
					if ( type == COMMON_HEAP_MEM )
						current = TryAllocEX(pBlock, newsize);
					else
						current = TryAlloc(pBlock, newsize);
					if (!current)
					{
						BRTHREAD_ASSERT("mailto://kos0120@infrawareglobal.com" == 0); // IMPORTANT!
						SET_ERROR_LOG((int)kPoErrMemory, __FUNCTION__, false);
					}
					//if ( !current )
					//	goto alloc_fail;
					break;
				}
				else
					pBlock = pBlock->_next_memory_block;
			}while(pOldBlock != pBlock);
		}

		if(!current)
		{
			if ( type == SYSTEM_HEAP_MEM )
			{
				if(pBlock = AppendMemory_MT(pBlock, newsize, pMemPool, pMemoryMap))
				{
					current = TryAlloc(pBlock, newsize);
					//				pMemPool->m_pBoraSysMem = pBlock;
				}

				if(!current)
					goto alloc_fail;
			}
			else
			{
				// #3 search in all block list
#ifdef USE_ADVANCED_BRMALLOC
				// ������ BlockList�� �Ҵ� ������ ������ ���� ���, ������ ��� BlockList������ Ž���� �õ���
	#	ifdef USE_MULTI_MEMORY_BLOCK_LIST
				BrINT nStartIdx = 0;
				if ( type == COMMON_HEAP_MEM )
					nStartIdx = nBlockListPos+1;
				for(BrINT i=0; i<SBLOCKLIST_COUNT && !current; i++)
				{
					if ( type == COMMON_HEAP_MEM )
					{
						if (nStartIdx+i >= SBLOCKLIST_COUNT)
							nStartIdx = 0;
					}
					else if ( type == SPECIAL_HEAP_MEM )
						nStartIdx = i;
					if (nStartIdx != nBlockListPos)
					{
						pBlock = GetBlockByIndex(nStartIdx, pMemPool);
						if(pBlock)
						{
							pOldBlock = pBlock;
							do
							{
								if( pBlock->_max_packet_size >= newsize )
								{
									if ( type == COMMON_HEAP_MEM )
										current = TryAllocEX(pBlock, newsize);
									else
										current = TryAlloc(pBlock, newsize);
									BRTHREAD_ASSERT(current);
									nBlockListPos = nStartIdx;
									break;
								}
								else
									pBlock = pBlock->_next_memory_block;
							}while(pOldBlock != pBlock);
						}
					}
				}
				// ��� BlockList�� �Ҵ� ������ ������ ���� ���, ���� �������� BlockList�� ���� �Ҵ��� �õ���
				if(!current)
				{
					pBlock = GetBlockByIndex(nBlockListPos, pMemPool);
					if(pBlock = AppendMemory_MT(pBlock, newsize, pMemPool, pMemoryMap))
					{
						if ( type == COMMON_HEAP_MEM )
							current = TryAllocEX(pBlock, newsize);
						else
							current = TryAlloc(pBlock, newsize);

						if(pMemoryMap->MEM_MAP_FLAG)
							pMemPool->m_pBoraHeapMem[nBlockListPos] = pBlock;
					}

					if(!current)
						goto alloc_fail;				
				}
	#	else //USE_MULTI_MEMORY_BLOCK_LIST
				if(pBlock = AppendMemory_MT(pBlock, newsize, pMemPool, pMemoryMap))
				{
					current = TryAlloc(pBlock, newsize);

					if(pMemoryMap->MEM_MAP_FLAG)
						pMemPool->m_pBoraHeapMem = pBlock;
				}

				if(!current)
					goto alloc_fail;
	#	endif //USE_MULTI_MEMORY_BLOCK_LIST
	#else //USE_ADVANCED_BRMALLOC
				if(pBlock = AppendMemory_MT(pBlock, newsize, pMemPool, pMemoryMap))
				{
					current = TryAlloc(pBlock, newsize);

					if(pMemoryMap->MEM_MAP_FLAG)
	#	ifdef USE_MULTI_MEMORY_BLOCK_LIST
						pMemPool->m_pBoraHeapMem[nBlockListPos] = pBlock;
	#	else //USE_MULTI_MEMORY_BLOCK_LIST
						pMemPool->m_pBoraHeapMem = pBlock;
	#	endif //USE_MULTI_MEMORY_BLOCK_LIST
				}

				if(!current)
					goto alloc_fail;
	#endif //USE_ADVANCED_BRMALLOC
			}
		}
	}

	oldsize = current->packet_size;					
	if ( type == COMMON_HEAP_MEM )
		br_mremove_ex(pBlock, current);
	else
		br_mremove(pBlock, current);		            

	if (oldsize - newsize >= (MIN_BLOCK + BLOCK_OVERHEAD))
	{
		PACKET* next = (PACKET *) ((char *)current + BLOCK_OVERHEAD + oldsize);
		extra_block = (PACKET *) ((char *) current + BLOCK_OVERHEAD + newsize);

		extra_block->packet_size = oldsize - newsize - BLOCK_OVERHEAD;
		extra_block->last_ptr_nearby = current;

		if ( type == COMMON_HEAP_MEM )
			br_minsert_ex(pBlock, extra_block);
		else
			br_minsert(pBlock, extra_block);

		if(next < pBlock->_sys_memory_eptr)
			next->last_ptr_nearby = extra_block;
		current->packet_size = newsize;

		BRTHREAD_ASSERT( (current->packet_size&~BLOCK_MASK) && (current->packet_size&BLOCK_MASK) == 0 ); // 8�� ����� �ƴϸ� break ��.

#ifdef USE_MCORE_MEMPOOL
		current->packet_size |= (BLOCK_USED | (pMemPool->m_MemPool_Id<<30));
#else //USE_MCORE_MEMPOOL
		current->packet_size |= BLOCK_USED;
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		if ( type != SYSTEM_HEAP_MEM )
			current->packet_size |= (nBlockListPos<<24);
#endif //USE_MULTI_MEMORY_BLOCK_LIST
		bora_set_debuginfo(pMemPool, current, szfile, nline);
#ifdef USE_ADVANCED_BRMALLOC
		if ( type != SYSTEM_HEAP_MEM )
			ShrinkBlockList(pMemPool, nBlockListPos, pBlock);
#endif //USE_ADVANCED_BRMALLOC
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		return (char *)current + BLOCK_OVERHEAD;
	}

	BRTHREAD_ASSERT( (current->packet_size&~BLOCK_MASK) && (current->packet_size&BLOCK_MASK) == 0 && ((oldsize==newsize) || !((oldsize-newsize)&BLOCK_MASK) )); // 8�� ����� �ƴϸ� break ��.
	
#ifdef USE_MCORE_MEMPOOL
	current->packet_size = current->packet_size | BLOCK_USED | (pMemPool->m_MemPool_Id<<30);
#else //USE_MCORE_MEMPOOL
	current->packet_size |= BLOCK_USED;
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	if ( type != SYSTEM_HEAP_MEM )
		current->packet_size |= (nBlockListPos<<24);
#endif //USE_MULTI_MEMORY_BLOCK_LIST

	bora_set_debuginfo(pMemPool, current, szfile, nline);
#ifdef USE_ADVANCED_BRMALLOC
	if ( type != SYSTEM_HEAP_MEM )
		ShrinkBlockList(pMemPool, nBlockListPos, pBlock);
#endif //USE_ADVANCED_BRMALLOC
	BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
	return (char *)current + BLOCK_OVERHEAD;


alloc_fail:
#if defined(BRTHREAD_MEMORY_DEBUG)
	THREAD_TRACE(("%s(%d) : [Fail BrMalloc(%d)] ************* ", szfile, nline, size));
#endif
	BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
	BrBOOL bInit = gpBoraThreadStackMem && gpBoraEventMem && gpFontManager;						// ���� �ʱ�ȭ �Ǿ����� ����
	BrBOOL bLargeMem = (size >= MEM_THRESHOLD);													// Large or Small �޸� ����
	BrBOOL bSysAllocFail = (g_BoraThreadAtom.m_nMemoryErrorCode == kPoErrSystemMemory);			// �ý��� �޸� �Ҵ�(malloc) ���� ����
	BrBOOL bMaxHeapSizeOver = (g_BoraThreadAtom.m_nMemoryErrorCode == kPoErrMaxHeapSizeOver);	// ���� MaxHeapSize(UI���� ����) ���ѿ� �ɷȴ��� ����
	BTrace("%s(%d) Malloc Fail : %s(%d) bInit[%d], bLargeMem[%d], bSysAllocFail[%d], bMaxHeapSizeOver[%d]", __FUNCTION__, size, szfile, nline, bInit, bLargeMem, bSysAllocFail, bMaxHeapSizeOver);

	//�̹� terminate�� �� ���·� �������� �� memory�� �Ҵ��� �ȵǸ� ���� ó����
	BRCONTEXT;
	if (Brcontext.m_GeneralValue.IsViewerTerminate())
		return 0;
	// ���� Terminate�� ���� : small memory(10KB �̸�) �Ҵ翡 ������ ���, ���� �ʱ�ȭ �������� �ý��� ����޸� �����Ͽ� malloc ������ ���

	if ( !bInit && bSysAllocFail )
	{
		// ���� �ʱ�ȭ �������� �ý��� ����޸� �����Ͽ� malloc ������ ��� : �޸� �Ҵ� ũ��� ������� Terminate ó��
		BRTERMINATE(kPoErrSystemMemory, "If the system is out of memory during the engine initialization process and fails", PO_PUBLIC_CLASS);
	}

	if( !bLargeMem )	// Small Memory
	{
		PoError err = kPoErrMemory;
		// small memory(10KB �̸�) �Ҵ翡 ������ ��� : �Ʒ� 2������ �����Ͽ� ErrorCode ��� ��, ���� Terminate ó��
		if (bSysAllocFail)
		{
			// malloc ������ ��� : �ý��� ����޸� ����, �ý��� �޸� ����ȭ ���� �������� �߻��� �� ����
			err = kPoErrSystemMemory;
		}
		else if (bMaxHeapSizeOver)
		{
			// ���� �ִ� Heap �޸� ũ��(UI���� ������ ũ��) ���ѿ� �ɷ� ������ ���
			err = kPoErrMaxHeapSizeOver;
		}
		else
		{
			// ���� �ɸ��� ���� ����� ��
			BRTHREAD_ASSERT(0);
		}
		BRTERMINATE(err, "", PO_PUBLIC_CLASS);
	}
	else	// Large Memory
	{
		// Large memory(10KB �̻�) �Ҵ翡 ������ ��� : �Ʒ� 2������ �����Ͽ� ErrorCode ��� ��, return 0; ó��
		if (bSysAllocFail)
		{
			// malloc ������ ��� : �ý��� ����޸� ����, �ý��� �޸� ����ȭ ���� �������� �߻��� �� ����
			ERR_TRACE(kPoErrSystemMemory);
		}
		else if (bMaxHeapSizeOver)
		{
			// ���� �ִ� Heap �޸� ũ��(UI���� ������ ũ��) ���ѿ� �ɷ� ������ ���
			ERR_TRACE(kPoErrMaxHeapSizeOver);
		}
		else
		{
			// ���� �ɸ��� ���� ����� ��
			BRTHREAD_ASSERT(0);
		}
	}

	return 0;
}

void Free_MT(B_MEM_POOL* pMemPool, void *packet, eMEMORY_TYPE type, BrCHAR* szfile, BrUINT32 nline)
{
	register PACKET *last;	      /* POINT TO PREVIOUS PACKET            */
	register PACKET *current;	  /* POINTER TO THIS PACKET			     */
	register PACKET *next;	      /* POINTER TO NEXT PACKET              */
	register PACKET *next_copy;
	register B_MEMORY * pBlock=BrNULL;

	CHECKVOIDRET(!packet);
	BRLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
	current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */

	if(IS_LARGE_PACKET(current))
	{
		if ( type == SYSTEM_HEAP_MEM )
			BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeSysHeap, (LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD), pMemPool);
		else
			BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeHeap, (LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD), pMemPool);
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		return;
	}

	BrINT nBlockListPos = 0;
	if ( type == SYSTEM_HEAP_MEM )
	{
		pBlock = GetFontBlockByPtr(current, pMemPool);
	}
	else
	{
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		nBlockListPos = (current->packet_size & BLOCK_LIST_POS_MASK) >> 24;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
		pBlock = GetBlockByPtr(current, pMemPool);
	}
	if (!pBlock)
	{
		BRTHREAD_ASSERT(pBlock);
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		return;
	}

	if ( type == SYSTEM_HEAP_MEM )
	{
		if (!pMemPool->m_pBoraSysMem) 
		{
			BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
			return;
		}
	}
	else
	{
		if (!pMemPool->m_bInitHeapMem || !pMemPool->m_bResetHeapMem) 
		{
			BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
			return;
		}
	}

	/* @ �Ʒ� ���뿡�� ���� ���� ���� �Ͻ� ���� BRTHREAD_ASSERT(BrFALSE)��   */
	/*     �ּ� ó�� �Ͻð� �����Ͻø� �˴ϴ�.								 */
	/* * ���� ������ ������ �븮�� ã���ּ���.								 */
	// �̹� Free �ߴ� packet�̳� ������ ���� Packet�� ���.
	if(!(current->packet_size & BLOCK_USED))
	{
		// �̹� Free �ߴ� �޸𸮰ų� garbage packet �Դϴ�.
		// pointer�� �ʱ�ȭ(NULL)�� �ʿ��� ���� �ֽ��ϴ�.
		// �� ���ͳ� �ش� �κ� ��� �Ͻô� ���� ���� ��Ź�մϴ�.
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		BRTHREAD_ASSERT(BrFALSE);
		return;
	}

	if(!current->last_ptr_nearby)
	{/* ������ �� ó�� packet���� last_ptr_nearby�� 0�̾�߸� �Ѵ�.*/
		if(current != pBlock->_sys_memory_sptr)
		{ 
			// �޸� Block�� �������ϴ�.
			// �� ���ͳ� �ش� �κ� ��� �Ͻô� ���� ���� ��Ź�մϴ�.
			BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
			BRTHREAD_ASSERT(BrFALSE);
			return;
		}
	}
	else if( current->last_ptr_nearby < pBlock->_sys_memory_sptr ||
		current->last_ptr_nearby > pBlock->_sys_memory_eptr)
	{/* ������ ���� packet ����(ex. Realloc) */

		// �̹� Free �ߴ� �޸𸮰ų� garbage packet �Դϴ�.
		// pointer�� �ʱ�ȭ(NULL)�� �ʿ��� ���� �ֽ��ϴ�.
		// �� ���ͳ� �ش� �κ� ��� �Ͻô� ���� ���� ��Ź�մϴ�.
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		BRTHREAD_ASSERT(BrFALSE);
		return;
	}
	else		
	{/* ������ ������ ���. �� ��쿡 Return �Ǹ� �޸𸮰� ������� */
		last = (PACKET*)((char*)current->last_ptr_nearby + (current->last_ptr_nearby->packet_size&~BLOCK_SIZE_MASK)+BLOCK_OVERHEAD);

		if(last != current)
		{
			// Memory corruption�� �߻��߽��ϴ�.
			// Critical �� ��� �Դϴ�.
			// �� ���ͳ� �ش� �κ� ��� �Ͻô� ���� ���� ��Ź�մϴ�.
			BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
			BRTHREAD_ASSERT(BrFALSE);
			return;
		}
	}
	current->packet_size &= ~BLOCK_SIZE_MASK;   /* MARK PACKET AS FREE */

	bora_initialize_packet(current);

#ifdef _DEBUG
	memset(packet, 0xdd, current->packet_size);	// Free�� �޸� ������ NULL������ ä��
#endif //_DEBUG


	if(current->last_ptr_nearby)
		last = current->last_ptr_nearby;
	else
		last = NULL;

	next = (PACKET *) ((char *)current + BLOCK_OVERHEAD +current->packet_size);
	if (next >= (PACKET *) pBlock->_sys_memory_eptr) 
		next = NULL;

	next_copy = next;

	if (last && (last->packet_size & BLOCK_USED)) last = NULL;
	if (next && (next->packet_size & BLOCK_USED)) next = NULL;


	if (last && next)
	{
		if ( type != SYSTEM_HEAP_MEM )
		{
			br_mremove_ex(pBlock, last);
			br_mremove_ex(pBlock, next);
		}
		else
		{
			br_mremove(pBlock, last);
			br_mremove(pBlock, next);
		}
		last->packet_size += current->packet_size + next->packet_size + 
			BLOCK_OVERHEAD + BLOCK_OVERHEAD;

		next_copy = (PACKET *)((char *)next+BLOCK_OVERHEAD+next->packet_size);
		if(next_copy < (PACKET *)pBlock->_sys_memory_eptr)
			next_copy->last_ptr_nearby = last;

		bora_memset_packet(current);
		bora_memset_packet(next);

		if ( type != SYSTEM_HEAP_MEM )
			br_minsert_ex(pBlock, last);
		else
			br_minsert(pBlock, last);
	}

	else if (last)
	{
		if ( type != SYSTEM_HEAP_MEM )
			br_mremove_ex(pBlock, last);
		else
			br_mremove(pBlock, last);
		last->packet_size += current->packet_size + BLOCK_OVERHEAD;

		if(next_copy && next_copy < (PACKET *)pBlock->_sys_memory_eptr)
			next_copy->last_ptr_nearby = last;

		bora_memset_packet(current);

		if ( type != SYSTEM_HEAP_MEM )
			br_minsert_ex(pBlock, last);
		else
			br_minsert(pBlock, last);
	}

	else if (next)
	{
		if ( type != SYSTEM_HEAP_MEM )
			br_mremove_ex(pBlock, next);
		else
			br_mremove(pBlock, next);
		current->packet_size += next->packet_size + BLOCK_OVERHEAD;

		next_copy = (PACKET *)((char *)next+BLOCK_OVERHEAD+next->packet_size);
		if(next_copy<(PACKET *)pBlock->_sys_memory_eptr)
			next_copy->last_ptr_nearby = current;

		bora_memset_packet(next);

		if ( type != SYSTEM_HEAP_MEM )
			br_minsert_ex(pBlock, current);
		else
			br_minsert(pBlock, current);
	}
	else
	{
		if ( type != SYSTEM_HEAP_MEM )
			br_minsert_ex(pBlock, current);
		else
			br_minsert(pBlock, current);
	}

	if ( type == SYSTEM_HEAP_MEM )
	{
#if defined(BRTHREAD_MEMORY_DEBUG)
		if(pBlock->_memory_size == pBlock->_sys_free->packet_size+BLOCK_OVERHEAD)
		{
			//		THREAD_TRACE(("%s(%d): DeleteBlock - sptr = 0x%x, eptr = 0x%x\n", szfile, nline, pBlock->_sys_memory_sptr, pBlock->_sys_memory_eptr));
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraSysMem, pBlock);
		}
#else
		if(pBlock->_memory_size == pBlock->_sys_free->packet_size+BLOCK_OVERHEAD)
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraSysMem, pBlock);
#endif
	}
	else
	{
	#ifdef USE_ADVANCED_BRMALLOC
		BrBOOL bDeleteBlock = BrFALSE;
		PACKET* pFreeHead = pBlock->_sys_free? pBlock->_sys_free : pBlock->_small_sys_free;
	#	ifdef USE_MULTI_MEMORY_BLOCK_LIST
		BrUINT32 bNotUseBlock = pBlock->_not_use_block;
		B_MEMORY*& pRootBlock = bNotUseBlock? pMemPool->m_pNotUseBlock[nBlockListPos] : pMemPool->m_pBoraHeapMem[nBlockListPos];
	#		if defined(BRTHREAD_MEMORY_DEBUG)
		if(pBlock->_memory_size == pFreeHead->packet_size+BLOCK_OVERHEAD)
		{
			//		THREAD_TRACE(("%s(%d): DeleteBlock - sptr = 0x%x, eptr = 0x%x\n", szfile, nline, pBlock->_sys_memory_sptr, pBlock->_sys_memory_eptr));
			BoraDeleteBlock_MT(pMemPool, pRootBlock, pBlock, nBlockListPos, bNotUseBlock? BrFALSE:BrTRUE);
			bDeleteBlock = BrTRUE;
		}
	#		else
		if(pBlock->_memory_size == pFreeHead->packet_size+BLOCK_OVERHEAD)
		{
			BoraDeleteBlock_MT(pMemPool, pRootBlock, pBlock, nBlockListPos, bNotUseBlock? BrFALSE:BrTRUE);
			bDeleteBlock = BrTRUE;
		}
	#		endif
	#	else //USE_MULTI_MEMORY_BLOCK_LIST
		B_MEMORY* pRootBlock = pBlock->_not_use_block? pMemPool->m_pNotUseBlock : pMemPool->m_pBoraHeapMem;
	#		if defined(BRTHREAD_MEMORY_DEBUG)
		if(pBlock->_memory_size == pFreeHead->packet_size+BLOCK_OVERHEAD)
		{
			//		THREAD_TRACE(("%s(%d): DeleteBlock - sptr = 0x%x, eptr = 0x%x\n", szfile, nline, pBlock->_sys_memory_sptr, pBlock->_sys_memory_eptr));
			BoraDeleteBlock_MT(pMemPool, pRootBlock, pBlock, bNotUseBlock? BrFALSE:BrTRUE);
			bDeleteBlock = BrTRUE;
		}
	#		else
		if(pBlock->_memory_size == pFreeHead->packet_size+BLOCK_OVERHEAD)
		{
			BoraDeleteBlock_MT(pMemPool, pRootBlock, pBlock, bNotUseBlock? BrFALSE:BrTRUE);
			bDeleteBlock = BrTRUE;
		}
	#		endif
	#	endif //USE_MULTI_MEMORY_BLOCK_LIST

		if (bNotUseBlock && !bDeleteBlock)
			EnlargeBlockList(pMemPool, nBlockListPos, pBlock);
	#else //USE_ADVANCED_BRMALLOC
	#	ifdef USE_MULTI_MEMORY_BLOCK_LIST
	#		if defined(BRTHREAD_MEMORY_DEBUG)
		if(pBlock->_memory_size == pBlock->_sys_free->packet_size+BLOCK_OVERHEAD)
		{
			//		THREAD_TRACE(("%s(%d): DeleteBlock - sptr = 0x%x, eptr = 0x%x\n", szfile, nline, pBlock->_sys_memory_sptr, pBlock->_sys_memory_eptr));
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem[nBlockListPos], pBlock, nBlockListPos, BrTRUE);
		}
	#		else
		if(pBlock->_memory_size == pBlock->_sys_free->packet_size+BLOCK_OVERHEAD)
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem[nBlockListPos], pBlock, nBlockListPos, BrTRUE);
	#		endif
	#	else //USE_MULTI_MEMORY_BLOCK_LIST
	#		if defined(BRTHREAD_MEMORY_DEBUG)
		if(pBlock->_memory_size == pBlock->_sys_free->packet_size+BLOCK_OVERHEAD)
		{
			//		THREAD_TRACE(("%s(%d): DeleteBlock - sptr = 0x%x, eptr = 0x%x\n", szfile, nline, pBlock->_sys_memory_sptr, pBlock->_sys_memory_eptr));
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem, pBlock, BrTRUE);
		}
	#		else
		if(pBlock->_memory_size == pBlock->_sys_free->packet_size+BLOCK_OVERHEAD)
			BoraDeleteBlock_MT(pMemPool, pMemPool->m_pBoraHeapMem, pBlock, BrTRUE);
	#		endif
	#	endif //USE_MULTI_MEMORY_BLOCK_LIST
	#endif //USE_ADVANCED_BRMALLOC
	}

	BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
	return;
}

BrLPVOID Calloc_MT(BORA_MEMORY_MAP* pMemoryMap, B_MEM_POOL* pMemPool, BrINT32 num, BrINT32 size, eMEMORY_TYPE type, BrCHAR* szfile, BrUINT32 nline)
{
	register BrUINT32      i	 = size * num;
	register BrUINT32   newSize = (i + BLOCK_MASK) & ~BLOCK_MASK;
	register LARGE_TYPE *current = (LARGE_TYPE *)Malloc_MT(pMemoryMap, pMemPool, newSize, type, szfile, nline);

	CHECKNULLRET(current==0);

	memset((BrCHAR*)current, 0, newSize);

	return current;
}

BrLPVOID Realloc_MT(BORA_MEMORY_MAP* pMemoryMap, B_MEM_POOL* pMemPool, BrLPVOID packet, BrINT32 size, eMEMORY_TYPE type, BrCHAR* szfile, BrUINT32 nline)
{
	register B_MEMORY * pBlock=BrNULL;
	register char    *pptr    = (char *) packet - BLOCK_OVERHEAD;
	register BrSIZE_T   newsize = (size + BLOCK_MASK) & ~BLOCK_MASK;
	register BrSIZE_T   oldsize;

#if (defined(BRTHREAD_MEMORY_DEBUG) && defined(VERIFY_MEMORY_PACKET)) || defined(BRTHREAD_MEMORY_TAIL)
	newsize += MEM_DEBUG_TAIL_SIZE;
#endif

	if (packet == 0)  {
		return Malloc_MT(pMemoryMap, pMemPool, size, type, szfile, nline);
	}
	if (size == 0)  { 
		if ( type != SPECIAL_HEAP_MEM )
			Free_MT(pMemPool, packet, type, szfile, nline); 
		return NULL; 
	}
	BRLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);

	oldsize = ((PACKET *)pptr)->packet_size;

	BrINT nBlockListPos = 0;
	if ( type != SYSTEM_HEAP_MEM )
	{
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		nBlockListPos = (oldsize & BLOCK_LIST_POS_MASK) >> 24;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
	}

	if ( type == SYSTEM_HEAP_MEM )
	{
		if( (oldsize&MEM_MAGIC_NUMBER_MASK) == MEM_USED_MAGIC_NUMBER )
		{

			LARGE_PACKET* large_packet = (LARGE_PACKET*)((BrCHAR*)packet - LARGE_BLOCK_OVERHEAD);

			if(newsize < pMemoryMap->BORA_SYSMEM_THRESHOLD)
			{
				// large block -> small block
				register char *new_packet = BrNULL;
				new_packet = (char *)Malloc_MT(pMemoryMap, pMemPool, size, type, szfile, nline);
				if (new_packet == 0) retnull();
				memcpy(new_packet, (BrCHAR*)large_packet+LARGE_BLOCK_OVERHEAD, newsize);
				bora_set_debuginfo(pMemPool, (PACKET*)(new_packet-BLOCK_OVERHEAD), szfile, nline);
				BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeSysHeap, large_packet, pMemPool);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return new_packet;
			}
			else
			{
				// large block -> large block
				LARGE_PACKET* new_large_packet;
				if( new_large_packet = BoraReallocLargeBlock_MT(pMemPool->m_pBoraLargeSysHeap, large_packet, newsize, pMemPool) )
				{
					bora_set_large_debuginfo(pMemPool, (LARGE_PACKET*)new_large_packet, szfile, nline);
					BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
					return (BrCHAR*)new_large_packet + LARGE_BLOCK_OVERHEAD;
				}

				// fail
				oldsize = large_packet->_actual_size - BrSizeOf(LARGE_PACKET);
				goto alloc_new_packet;
			}
		}
		else if(newsize >= pMemoryMap->BORA_SYSMEM_THRESHOLD)
		{
			// small block -> large block
			BRTHREAD_ASSERT((oldsize&MEM_MAGIC_NUMBER_MASK) != MEM_USED_MAGIC_NUMBER);
			LARGE_PACKET* new_packet;
			if( new_packet = BoraAllocLargeBlock_MT(pMemPool, pMemPool->m_pBoraLargeSysHeap, newsize) )
			{
				memcpy((BrCHAR*)new_packet+LARGE_BLOCK_OVERHEAD, packet, oldsize&~BLOCK_SIZE_MASK);
				bora_set_large_debuginfo(pMemPool, (LARGE_PACKET*)new_packet, szfile, nline);

				if ( type != SPECIAL_HEAP_MEM )
					Free_MT(pMemPool, packet, type, szfile, nline);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return (BrCHAR*)new_packet+LARGE_BLOCK_OVERHEAD;
			}

			goto alloc_new_packet;
		}
	}
	else
	{
		if( (oldsize&MEM_MAGIC_NUMBER_MASK) == MEM_USED_MAGIC_NUMBER )
		{

			LARGE_PACKET* large_packet = (LARGE_PACKET*)((BrCHAR*)packet - LARGE_BLOCK_OVERHEAD);

			if(newsize < pMemoryMap->BORA_HEAPMEM_THRESHOLD)
			{
				// large block -> small block
				register char *new_packet = BrNULL;
				new_packet = (char *)Malloc_MT(pMemoryMap, pMemPool, size, type, szfile, nline);
				if (new_packet == 0) retnull();
				memcpy(new_packet, (BrCHAR*)large_packet+LARGE_BLOCK_OVERHEAD, newsize);
				bora_set_debuginfo(pMemPool, (PACKET*)(new_packet-BLOCK_OVERHEAD), szfile, nline);
				BoraDeleteLargeBlock_MT(pMemPool->m_pBoraLargeHeap, large_packet, pMemPool);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return new_packet;
			}
			else
			{
				// large block -> large block
				LARGE_PACKET* new_large_packet;
				if( new_large_packet = BoraReallocLargeBlock_MT(pMemPool->m_pBoraLargeHeap, large_packet, newsize, pMemPool) )
				{
					bora_set_large_debuginfo(pMemPool, (LARGE_PACKET*)new_large_packet, szfile, nline);
					BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
					return (BrCHAR*)new_large_packet + LARGE_BLOCK_OVERHEAD;
				}

				// fail
				oldsize = large_packet->_actual_size - BrSizeOf(LARGE_PACKET);
				goto alloc_new_packet;
			}
		}
		else if(newsize >= pMemoryMap->BORA_HEAPMEM_THRESHOLD)
		{
			// small block -> large block
			BRTHREAD_ASSERT((oldsize&MEM_MAGIC_NUMBER_MASK) != MEM_USED_MAGIC_NUMBER);
			LARGE_PACKET* new_packet;
			if( new_packet = BoraAllocLargeBlock_MT(pMemPool, pMemPool->m_pBoraLargeHeap, newsize) )
			{
				memcpy((BrCHAR*)new_packet+LARGE_BLOCK_OVERHEAD, packet, oldsize&~BLOCK_SIZE_MASK);
				bora_set_large_debuginfo(pMemPool, (LARGE_PACKET*)new_packet, szfile, nline);
				if ( type != SPECIAL_HEAP_MEM )
					Free_MT(pMemPool, packet, type, szfile, nline);
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				return (BrCHAR*)new_packet+LARGE_BLOCK_OVERHEAD;
			}

			goto alloc_new_packet;
		}
	}

	if (!(oldsize & BLOCK_USED)) {BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id); retnull();}

	oldsize &= ~BLOCK_SIZE_MASK;

	if (newsize == oldsize)
	{
		bora_set_debuginfo(pMemPool, (PACKET*)pptr, szfile, nline);
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		return packet;
	}

	if ( type == SYSTEM_HEAP_MEM )
	{
		pBlock = GetFontBlockByPtr((PACKET*)pptr, pMemPool);
	}
	else if ( type == COMMON_HEAP_MEM )
	{
		pBlock = GetBlockByPtr((PACKET*)pptr, pMemPool);
	}
	else
	{
		if (GetBlockByIndex(nBlockListPos, pMemPool))
			pBlock = GetBlockByPtr((PACKET*)pptr, pMemPool);
		if (!pBlock)
			goto alloc_new_packet;
	}
	BRTHREAD_ASSERT(pBlock);


	if (newsize < oldsize)
	{
		if (oldsize - newsize < (MIN_BLOCK + BLOCK_OVERHEAD))
		{
			BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
			return packet;
		}

		PACKET* saved_pkt = (PACKET*)pptr;
#ifdef USE_MCORE_MEMPOOL
		((PACKET *)pptr)->packet_size = newsize | BLOCK_USED | (pMemPool->m_MemPool_Id<<30);
#else //USE_MCORE_MEMPOOL
		((PACKET *)pptr)->packet_size = newsize | BLOCK_USED;
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		if ( type != SYSTEM_HEAP_MEM )
			((PACKET *)pptr)->packet_size |= (nBlockListPos<<24);
#endif //USE_MULTI_MEMORY_BLOCK_LIST

		bora_set_debuginfo(pMemPool, (PACKET*)pptr, szfile, nline);

		oldsize -= newsize + BLOCK_OVERHEAD;
		pptr    += newsize + BLOCK_OVERHEAD;

#ifdef USE_MCORE_MEMPOOL
		((PACKET *)pptr)->packet_size = oldsize | BLOCK_USED | (pMemPool->m_MemPool_Id<<30);
#else //USE_MCORE_MEMPOOL
		((PACKET *)pptr)->packet_size = oldsize | BLOCK_USED;
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		if ( type != SYSTEM_HEAP_MEM )
			((PACKET *)pptr)->packet_size |= (nBlockListPos<<24);
#endif //USE_MULTI_MEMORY_BLOCK_LIST
		((PACKET*)pptr)->last_ptr_nearby = saved_pkt;

		PACKET* next_copy = (PACKET*)(pptr+BLOCK_OVERHEAD+oldsize);
		if(next_copy<(PACKET *)pBlock->_sys_memory_eptr)
			next_copy->last_ptr_nearby = (PACKET*)pptr;

		if ( type != SPECIAL_HEAP_MEM )
			Free_MT(pMemPool, pptr + BLOCK_OVERHEAD, type, szfile, nline);
		BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
		return packet;
	}

	else
	{
		PACKET *next = (PACKET *)(pptr + oldsize + BLOCK_OVERHEAD);
		int     temp;

		if (next < pBlock->_sys_memory_eptr && !(next->packet_size & BLOCK_USED) 
			&& ((temp = oldsize + next->packet_size + BLOCK_OVERHEAD - newsize) >= 0)
			)
		{
			if ( type == COMMON_HEAP_MEM )
				br_mremove_ex(pBlock, next);
			else
				br_mremove(pBlock, next);
			PACKET* next_copy = (PACKET*)((char*)next+BLOCK_OVERHEAD+next->packet_size);

			if (temp < MIN_BLOCK + BLOCK_OVERHEAD)
			{
				if(next_copy < (PACKET *)pBlock->_sys_memory_eptr)
					next_copy->last_ptr_nearby = (PACKET*)pptr;

#ifdef USE_MCORE_MEMPOOL
				((PACKET *)pptr)->packet_size = newsize + temp | BLOCK_USED | (pMemPool->m_MemPool_Id<<30);
#else //USE_MCORE_MEMPOOL
				((PACKET *)pptr)->packet_size = newsize + temp | BLOCK_USED;
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
				if ( type != SYSTEM_HEAP_MEM )
					((PACKET *)pptr)->packet_size |= (nBlockListPos<<24);
#endif //USE_MULTI_MEMORY_BLOCK_LIST

				bora_set_debuginfo(pMemPool, (PACKET*)pptr, szfile, nline);
				
				if ( type != SYSTEM_HEAP_MEM )
				{
#ifdef USE_ADVANCED_BRMALLOC
					ShrinkBlockList(pMemPool, nBlockListPos, pBlock);
#endif //USE_ADVANCED_BRMALLOC
					BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
				}
				return packet;
			}

			PACKET* saved_pkt = (PACKET*)pptr;

#ifdef USE_MCORE_MEMPOOL
			((PACKET *)pptr)->packet_size = newsize | BLOCK_USED | (pMemPool->m_MemPool_Id<<30);
#else //USE_MCORE_MEMPOOL
			((PACKET *)pptr)->packet_size = newsize | BLOCK_USED;
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
			if ( type != SYSTEM_HEAP_MEM )
				((PACKET *)pptr)->packet_size |= (nBlockListPos<<24);
#endif //USE_MULTI_MEMORY_BLOCK_LIST

			bora_set_debuginfo(pMemPool, (PACKET*)pptr, szfile, nline);

			pptr += newsize + BLOCK_OVERHEAD;
			((PACKET *)pptr)->packet_size = temp - BLOCK_OVERHEAD;
			((PACKET *)pptr)->last_ptr_nearby = saved_pkt;

			if(next_copy < (PACKET *)pBlock->_sys_memory_eptr)
				next_copy->last_ptr_nearby = (PACKET*)pptr;

			if ( type == COMMON_HEAP_MEM )
				br_minsert_ex(pBlock, (PACKET *)pptr);
			else
				br_minsert(pBlock, (PACKET *)pptr);
			if ( type != SYSTEM_HEAP_MEM )
			{
#ifdef USE_ADVANCED_BRMALLOC
				ShrinkBlockList(pMemPool, nBlockListPos, pBlock);
#endif //USE_ADVANCED_BRMALLOC
				BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
			}
			return packet;
		}
	}

alloc_new_packet:

	register char *new_packet = BrNULL;
	new_packet = (char *)Malloc_MT(pMemoryMap, pMemPool, size, type, szfile, nline);
	if (new_packet == 0) {BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id); retnull();}
	memcpy(new_packet, packet, BrMIN(newsize, oldsize));

	if ( type != SPECIAL_HEAP_MEM )
		Free_MT(pMemPool, packet, type, szfile, nline);
	BRUNLOCKMULTICOREIMP(eMCORE_MEM_MUTEX, pMemPool->m_MemPool_Id);
	return new_packet;
}


#ifdef MEMORY_OVERRUN_CHECK
BrBOOL CheckNormalMemBlock(PACKET* ptr, B_MEMORY* pMemBlock)
{
	B_MEMORY *pBlock, *pOldBlock;

	if (!pMemBlock)
		return BrFALSE;

	pOldBlock = pBlock = pMemBlock;
	do 
	{
		if (ptr >= pBlock->_sys_memory_sptr && ptr < pBlock->_sys_memory_eptr)
		{
			PACKET* current = (PACKET*)pBlock->_sys_memory;
			do
			{
				if (current == ptr)
					return BrTRUE;
				current = (PACKET*)((char*)current + ((current->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD));
			} while(current < (PACKET*)pBlock->_sys_memory_eptr);
		}

		pBlock = pBlock->_next_memory_block;
	} while(pBlock != pOldBlock);

	return BrFALSE;
}

BrBOOL CheckLargeMemBlock(LARGE_PACKET* ptr, LARGE_PACKET* pMemBlock)
{
	LARGE_PACKET* pBlock = pMemBlock;

	if (!pMemBlock)
		return BrFALSE;

	while (pBlock)
	{
		if (pBlock == ptr)
			return BrTRUE;
		pBlock = pBlock->_next_large_pack;
	}

	return BrFALSE;
}

BR_MEM_TYPE GetMemoryType(BrLPVOID packet)
{
	// Null üũ
	if (!packet)
		return MEM_TYPE_NONE;

	// �޸�Ǯ �ʱ�ȭ ���� �˻�
	if (!g_pBInterfaceHandle || !gpMemPool || gpMemPool->m_bResetHeapMem!=BrTRUE)
		return MEM_TYPE_NONE;

	// LARGEHEAP TYPE���� üũ
	PACKET *current = (PACKET*)((char *)packet - BLOCK_OVERHEAD);	/* ADJUST POINT TO BEGINNING OF PACKET */
	BrBOOL bIsLargePacket = IS_LARGE_PACKET(current);

	// SYS �޸� �˻� (LARGESYSHEAP, SYSHEAP)
	if (bIsLargePacket)
	{
		if (CheckLargeMemBlock((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD), gpMemPool->m_pBoraLargeSysHeap))
			return MEM_TYPE_LARGESYSHEAP;
	}
	else
	{
		if (CheckNormalMemBlock(current, gpMemPool->m_pBoraSysMem))
			return MEM_TYPE_SYSHEAP;
	}

	// �Ϲ� �޸� �˻� (LARGEHEAP, HEAP, NOTUSE)
	B_MEM_POOL* pMemPool = gpMemPool;
	if (!pMemPool || pMemPool->m_bInitHeapMem != BrTRUE)
		return MEM_TYPE_NONE;

#ifdef USE_MCORE_MEMPOOL
	BrINT nMemPool_Id = 0;
	if(bIsLargePacket)
		nMemPool_Id = (((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD))->magic_number&MEMPOOL_ID_MASK)>>30;
	else
		nMemPool_Id = (current->packet_size&MEMPOOL_ID_MASK)>>30;
	pMemPool = (B_MEM_POOL*)BrGetMCoreMemPool(nMemPool_Id, BrFALSE);
#endif //USE_MCORE_MEMPOOL
	if (!pMemPool || pMemPool->m_bInitHeapMem != BrTRUE)
		return MEM_TYPE_NONE;

	if (bIsLargePacket)
	{
		if (CheckLargeMemBlock((LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD), pMemPool->m_pBoraLargeHeap))
			return MEM_TYPE_LARGEHEAP;
	}
	else
	{
		B_MEMORY *pBlock;
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		BrINT nBlockListPos = (current->packet_size & BLOCK_LIST_POS_MASK) >> 24;
		pBlock = pMemPool->m_pBoraHeapMem[nBlockListPos];
#else //USE_MULTI_MEMORY_BLOCK_LIST
		pBlock = pMemPool->m_pBoraHeapMem;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
		if (CheckNormalMemBlock(current, pBlock))
			return MEM_TYPE_HEAP;

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
		pBlock = pMemPool->m_pNotUseBlock[nBlockListPos];
#else //USE_MULTI_MEMORY_BLOCK_LIST
		pBlock = pMemPool->m_pNotUseBlock;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
		if (CheckNormalMemBlock(current, pBlock))
			return MEM_TYPE_NOTUSE;
	}

	return MEM_TYPE_NONE;
}


BrUINT32 GetPacketMemSize(BrLPVOID packet, BR_MEM_TYPE eMemType)
{
	// system malloc �Ǵ� stack������ �޸𸮶�� �� ��ƾ�� Ÿ�� �ȵ�

	BrUINT32 nMemorySize = 0;
	PACKET* pPacket = BrNULL;
	LARGE_PACKET* pLargePacket = BrNULL;

	switch (eMemType)
	{
	case MEM_TYPE_SYSHEAP:
	case MEM_TYPE_HEAP:
		pPacket = (PACKET*)((char *)packet - BLOCK_OVERHEAD);
		nMemorySize = pPacket->packet_size & ~BLOCK_SIZE_MASK;
		break;
	case MEM_TYPE_LARGESYSHEAP:
	case MEM_TYPE_LARGEHEAP:
		pLargePacket = (LARGE_PACKET*)((char *)packet - LARGE_BLOCK_OVERHEAD);
		nMemorySize = pLargePacket->_actual_size - BrSizeOf(LARGE_PACKET);
		break;
	}

	return nMemorySize;
}
#endif //MEMORY_OVERRUN_CHECK

#ifdef B_DEBUG
BrBOOL CheckOnlyFreeListOfNormalMemBlock(BrLPVOID ptr)
{
	PACKET* pHeader = (PACKET*)((char *)ptr - BLOCK_OVERHEAD);
	register B_MEMORY*	pBlock;
	B_MEMORY*			pOldBlock;
	B_MEM_POOL* pMemPool = gpMemPool;

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	const BrUINT32		block_cnt = SBLOCKLIST_COUNT*2+1;	// m_pBoraHeapMem + m_pNotUseBlock + m_pBoraSysMem
	B_MEMORY*			block[block_cnt] = {0,};
	for(int i=0; i<SBLOCKLIST_COUNT; i++)
	{
		block[i] = pMemPool->m_pBoraHeapMem[i];
		block[SBLOCKLIST_COUNT + i] = pMemPool->m_pNotUseBlock[i];
	}
	block[block_cnt-1] = pMemPool->m_pBoraSysMem;
#else //USE_MULTI_MEMORY_BLOCK_LIST
	const BrUINT32		block_cnt = 3;
	B_MEMORY*			block[block_cnt] = {pMemPool->m_pBoraHeapMem, pMemPool->m_pNotUseBlock, pMemPool->m_pBoraSysMem};
#endif //USE_MULTI_MEMORY_BLOCK_LIST

	for(int i=0; i<block_cnt; i++)
	{
		pOldBlock = pBlock = block[i];
		if(!pBlock)	continue;

		do 
		{
			if (pHeader >= pBlock->_sys_memory_sptr && pHeader < pBlock->_sys_memory_eptr)
			{
				register PACKET		*current;
				current = pBlock->_sys_free;

				while (current)
				{
					if (current == pHeader)
						return BrTRUE;
					current = current->size_ptr;
				}
			}

			pBlock = pBlock->_next_memory_block;
		}while(pOldBlock != pBlock);
	}

	return BrFALSE;
}
#endif //B_DEBUG

///////////////////////////////////////////////////////////////////////////////////////////////////////////


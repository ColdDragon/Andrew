#include <OfficePreComp.hpp>

#include "prmemory.h"
#include "prmemory_manager.h"
#include "bheaptrace.h"
#include "ThreadDefines_i.h"
#include "binterfacehandle.h"
#include "pomemoryinterface.h"
#include "brmcoreimp.h"
 
#include "prpublicmem.h"
#ifndef NOT_USE_GLOBAL_VARIABLE
PrPublicMem* s_pPublicMem = BrNULL;
#endif //NOT_USE_GLOBAL_VARIABLE



#ifdef USE_MEMCHECK
MEMIDHash* g_MEMIDHash = BrNULL;
#endif

void InitMemIDHash(void)
{
#ifdef USE_MEMCHECK
	init_MEMIDHash(g_MEMIDHash);
#endif
}
void EndMemIDHash(void)
{
#ifdef USE_MEMCHECK
	free_MEMIDHash(g_MEMIDHash);
#endif
}

BrLPVOID BrMemmove(BrLPVOID pDst, BrLPVOID pSrc, BrINT32 nSize)
{
	return BMmemmove(pDst, pSrc, nSize);
}


#ifdef USE_MEMCHECK
void init_MEMIDHash(MEMIDHash* pHash)
{
	BrINT32 h;

	pHash->m_size = 7;
	pHash->m_ptab = (MIDHashBucket**)BMalloc(pHash->m_size * sizeof(MIDHashBucket*));
	for (h = 0; h < pHash->m_size; ++h) {
		pHash->m_ptab[h] = BrNULL;
	}
	pHash->m_len = 0;
}

void free_MEMIDHash(MEMIDHash* pHash)
{
	MIDHashBucket* p;
	BrINT32 h;

	for (h = 0; h < pHash->m_size; ++h)
	{
		while (pHash->m_ptab[h])
		{
			p = pHash->m_ptab[h];
			pHash->m_ptab[h] = p->m_pnext;
			BFree(p);
		}
	}
	if (pHash->m_ptab)
		BFree(pHash->m_ptab);
	pHash->m_size = 0;
	pHash->m_len = 0;
	pHash->m_ptab = BrNULL;
}

void add_MEMIDHash(MEMIDHash* pHash, BrCHAR* key, BrUINT32 val)
{
	MIDHashBucket** oldTab;
	MIDHashBucket* p;
	BrINT32 oldSize, i, h;

	// expand the table if necessary
	if (pHash->m_len >= pHash->m_size)
	{
		oldSize = pHash->m_size;
		oldTab = pHash->m_ptab;
		pHash->m_size = 2 * pHash->m_size + 1;
		pHash->m_ptab = (MIDHashBucket**)BMalloc(pHash->m_size * sizeof(MIDHashBucket*));

		gHashSize -= oldSize * sizeof(MIDHashBucket*);
		gHashSize += pHash->m_size * sizeof(MIDHashBucket*);

		for (h = 0; h < pHash->m_size; ++h)
		{
			pHash->m_ptab[h] = BrNULL;
		}
		for (i = 0; i < oldSize; ++i)
		{
			while (oldTab[i])
			{
				p = oldTab[i];
				oldTab[i] = oldTab[i]->m_pnext;
				h = hash_MEMIDHash(pHash, p->m_key);
				p->m_pnext = pHash->m_ptab[h];
				pHash->m_ptab[h] = p;
			}
		}
		BFree(oldTab);
	}

	// add the new symbol
	p = (MIDHashBucket*)BMalloc(sizeof(MIDHashBucket));
	gHashSize += sizeof(MIDHashBucket*);
	strcpy(p->m_key, key);
	p->m_val = val;
	h = hash_MEMIDHash(pHash, key);
	p->m_pnext = pHash->m_ptab[h];
	pHash->m_ptab[h] = p;
	++pHash->m_len;
}

BrBOOL remove_MEMIDHash(MEMIDHash* pHash, BrCHAR* key)
{
	MIDHashBucket* p;
	BrINT32 h;

	if (pHash->m_len == 0 || pHash->m_size == 0 || pHash->m_ptab == BrNULL)
		return BrFALSE;

	if (!(p = find_MEMIDHash(pHash, key, &h)))
	{
		return BrFALSE;
	}
	strcpy(p->m_key, "");
	p->m_val = -1;
	return BrTRUE;
}

BrUINT32 lookup_MEMIDHash(MEMIDHash* pHash, BrCHAR* key)
{
	MIDHashBucket* p;
	BrINT32 h;

	if (pHash->m_len == 0 || pHash->m_size == 0 || pHash->m_ptab == BrNULL)
		return 0;

	if (!(p = find_MEMIDHash(pHash, key, &h)))
	{
		return 0;
	}
	return p->m_val;
}

BrINT32 getLength_MEMIDHash(MEMIDHash* pHash)
{
	return pHash->m_len;
}

MIDHashBucket* find_MEMIDHash(MEMIDHash* pHash, BrCHAR* key, BrINT32* h)
{
	MIDHashBucket* p;

	*h = hash_MEMIDHash(pHash, key);
	for (p = pHash->m_ptab[*h]; p; p = p->m_pnext)
	{
		if (!strcmp(p->m_key, key))
			return p;
	}
	return BrNULL;
}

BrINT32 hash_MEMIDHash(MEMIDHash* pHash, BrCHAR* key)
{
	BrCHAR* p;
	BrUINT32	h;
	h = 0;
	for (p = key; *p; ++p) {
		h = 17 * h + (BrINT32)(*p & 0xff);
	}
	return (BrINT32)(h % pHash->m_size);
}

#endif //USE_MEMCHECK

void BrInitPublicMemPool()
{
	if (!s_pPublicMem)
		s_pPublicMem = new PrPublicMem;
}

void BrFreePublicMemPool()
{
	if (s_pPublicMem)
	{
		delete s_pPublicMem;
		s_pPublicMem = BrNULL;
	}
}

void BrClearPublicMemPool()
{
	if (s_pPublicMem)
		s_pPublicMem->clear();
}

BrUINT64 POGetPublicAvailableMemorySize(void)
{
	BrUINT64 nCurrentSize = 0;
	if (s_pPublicMem)
	{
		for (int n = 0; n < PR_BLOCK_PMEM_MAX; n++)
		{
			if (s_pPublicMem->getMemoryPool(n))
				nCurrentSize += (s_pPublicMem->getMemoryPool(n)->m_available_memory_size);
		}
	}
	return nCurrentSize;
}

BrUINT64 POGetPublicAllocatedMemory(void)
{
	BrUINT64 nCurrentSize = 0;
	if (s_pPublicMem)
	{
		for (int n = 0; n < PR_BLOCK_PMEM_MAX; n++)
		{
			if (s_pPublicMem->getMemoryPool(n))
				nCurrentSize += (s_pPublicMem->getMemoryPool(n)->m_allocated_memory_size);
		}
	}
	return nCurrentSize;
}

BrBOOL BrGetPublicMemPool(BrPUBLIC_MEMPOOL& sMemPool, BrBYTE nMakeFlag, BrUINT nLen)
{
	if (s_pPublicMem)
		return s_pPublicMem->getMemPool(sMemPool, nMakeFlag, nLen);
	return BrFALSE;
}

void BrReleasePublicMemPool(LPBrPUBLIC_MEMPOOL pMemPool, BrBOOL bUnLock)
{
	if (s_pPublicMem)
		s_pPublicMem->releaseMemPool(pMemPool, bUnLock);
}

void BrReleaseLargePublicMemPool()
{
	if (s_pPublicMem)
		s_pPublicMem->releaseLargeMemPool();
}

#ifdef USE_MCORE_MEMPOOL
BrBOOL BrAllocMCoreMemPool()
{
	if (s_pPublicMem)
		return s_pPublicMem->allocMCoreMemPool();
	else
	{
		s_pPublicMem = new PrPublicMem;
		if (s_pPublicMem)
			return s_pPublicMem->allocMCoreMemPool();
		return BrFALSE;
	}
}

BrLPVOID BrGetMCoreMemPool(BrINT nId, BrBOOL bMalloc)
{
	if (bMalloc)
	{
		if (BrIsMasterThread())
		{
			gpMemPool->m_MemPool_Id = MASTER_MEMPOOL_ID;
			return gpMemPool;
		}
		else
		{
			return s_pPublicMem->getMCoreMemPool(nId, bMalloc);
		}
	}
	else
	{
		if (nId == MASTER_MEMPOOL_ID)
			return gpMemPool;
		else
			return s_pPublicMem->getMCoreMemPool(nId, bMalloc);
	}
}

void BrLockMCoreMemPool(BrINT nIndex)
{
	if (s_pPublicMem)
		s_pPublicMem->lockMCoreMemPool(nIndex);
}

void BrUnLockMCoreMemPool(BrINT nIndex)
{
	if (s_pPublicMem)
		s_pPublicMem->unLockMCoreMemPool(nIndex);
}
#endif //USE_MCORE_MEMPOOL

void BrReleaseSpecialMemPool()
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
	}
	else {
		if (s_pPublicMem)
			s_pPublicMem->releaseSpecialMemPool();
	}
}

BrBOOL BrNeedToReleaseSpecialMemPool()
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return BrFALSE;
	} 
	else {
		if (s_pPublicMem)
			return s_pPublicMem->needToReleaseSpecialMemPool();
		return BrFALSE;
	}
}

BrLPVOID _BrBlockMalloc(LPBrPUBLIC_MEMPOOL pMemPool, BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return malloc(size);
	}
	else {
		if (s_pPublicMem)
			return  s_pPublicMem->blockMalloc(pMemPool, size, szfile, nline);
		return BrNULL;
	}
}

void _BrBlockFree(LPBrPUBLIC_MEMPOOL pMemPool, void* packet, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		free(packet);
	}
	else {
		if (s_pPublicMem)
			s_pPublicMem->blockFree(pMemPool, packet, szfile, nline);
	}
}

BrLPVOID _BrBlockCalloc(LPBrPUBLIC_MEMPOOL pMemPool, BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return calloc(num, size);
	}
	else {
		if (s_pPublicMem)
			return s_pPublicMem->blockCalloc(pMemPool, num, size, szfile, nline);
		return BrNULL;
	}
}

BrLPVOID _BrBlockRealloc(LPBrPUBLIC_MEMPOOL pMemPool, BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return realloc(packet, size);
	}
	else {
		if (s_pPublicMem)
			return s_pPublicMem->blockRealloc(pMemPool, packet, size, szfile, nline);
		return BrNULL;
	}
}

BrLPVOID _BrPublicBlockMalloc(BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return malloc(size);
	}
	else {
		if (s_pPublicMem)
			return  s_pPublicMem->publicBlockMalloc(size, szfile, nline);
		return BrNULL;
	}
}

void _BrPublicBlockFree(void* packet, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		free(packet);
	}
	else {
		if (s_pPublicMem)
			s_pPublicMem->publicBlockFree(packet, szfile, nline);
	}
}

BrLPVOID _BrPublicBlockCalloc(BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return calloc(num, size);
	}
	else {
		if (s_pPublicMem)
			return s_pPublicMem->publicBlockCalloc(num, size, szfile, nline);
		return BrNULL;
	}
}

BrLPVOID _BrPublicBlockRealloc(BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return realloc(packet, size);
	}
	else {
		if (s_pPublicMem)
			return s_pPublicMem->publicBlockRealloc(packet, size, szfile, nline);
		return BrNULL;
	}
}

BrLPVOID _BrSpecialBlockMalloc(BrSIZE_T size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return malloc(size);
	}
	else {
		if (s_pPublicMem)
			return  s_pPublicMem->specialBlockMalloc(size, szfile, nline);
		return BrNULL;
	}
}

void _BrSpecialBlockFree(void* packet, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
#ifdef SPECIALBASE_STD_MEMORY_RELEASE
		free(packet);
#endif	// SPECIALBASE_STD_MEMORY_RELEASE
	}
	else {
		//if(s_pPublicMem)
		//	s_pPublicMem->specialBlockFree(packet, szfile, nline);
	}
}

BrLPVOID _BrSpecialBlockCalloc(BrINT32 num, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return calloc(num, size);
	}
	else {
		if (s_pPublicMem)
			return s_pPublicMem->specialBlockCalloc(num, size, szfile, nline);
		return BrNULL;
	}
}

BrLPVOID _BrSpecialBlockRealloc(BrLPVOID packet, BrINT32 size, BrCHAR* szfile, BrUINT32 nline)
{
	if ( g_pBInterfaceHandle->isUnitTestMode() ) {
		return realloc(packet, size);
	}
	else {
		if (s_pPublicMem)
			return s_pPublicMem->specialBlockRealloc(packet, size, szfile, nline);
		return BrNULL;
	}
}

BrBOOL BrIsClearStateMemory()
{
	if (gpMemPool->m_bResetHeapMem)
		return BrFALSE;
	else
		return BrTRUE;
}

#ifdef USE_MEMCHECK

void meminfo(int nBlock, int* pfree_block_space, int* pfree_block_max)
{
	PACKET* current;
	int free_block_space = 0, free_block_max = 0;
	register B_MEMORY* pBlock = BrNULL;
	if (nBlock == -1)
		pBlock = gpMemPool->m_pBoraHeapMemEx;
	else
		pBlock = gpMemPool->MemBlock.m_pBlockArray[nBlock];

	current = (PACKET*)pBlock->_sys_memory;

	/*-----------------------------------------------------------------------*/
	/* LOOP THROUGH ALL PACKETS                                              */
	/*-----------------------------------------------------------------------*/
	while (current < (PACKET*)pBlock->_sys_memory_eptr)
	{
		int size = current->packet_size & ~BLOCK_SIZE_MASK;
		int used = current->packet_size & BLOCK_USED;


		if (!used)
		{
			free_block_space += size;
			free_block_max = BrMAX(free_block_max, size);
			//free_block_max++;
		}

		current = (PACKET*)((char*)current + size + BLOCK_OVERHEAD);
	}

	*pfree_block_max = free_block_max;
	*pfree_block_space = free_block_space;
}

void meminfo_ex(int nBlock, int* pused_block_space, int* pused_block_max)
{
	PACKET* current;
	int used_block_space = 0, used_block_max = 0;
	register B_MEMORY* pBlock = BrNULL;
	if (nBlock == -1)
		pBlock = gpMemPool->m_pBoraHeapMemEx;
	else
		pBlock = gpMemPool->MemBlock.m_pBlockArray[nBlock];

	current = (PACKET*)pBlock->_sys_memory;

	/*-----------------------------------------------------------------------*/
	/* LOOP THROUGH ALL PACKETS                                              */
	/*-----------------------------------------------------------------------*/
	while (current < (PACKET*)pBlock->_sys_memory_eptr)
	{
		int size = current->packet_size & ~BLOCK_SIZE_MASK;
		int used = current->packet_size & BLOCK_USED;


		if (used)
		{
			used_block_space += size + BLOCK_OVERHEAD;
			used_block_max = BrMAX(used_block_max, size);
			//used_block_max++;
		}

		current = (PACKET*)((char*)current + size + BLOCK_OVERHEAD);
	}

	*pused_block_max = used_block_max;
	*pused_block_space = used_block_space;
}


void thread_meminfo(int nBlock, int* pfree_block_space, int* pfree_block_max)
{
	PACKET* current;
	int free_block_space = 0, free_block_max = 0;
	register B_MEMORY* pBlock = BrNULL;

	pBlock = gpBoraThreadStackMem;

	current = (PACKET*)pBlock->_sys_memory;

	/*-----------------------------------------------------------------------*/
	/* LOOP THROUGH ALL PACKETS                                              */
	/*-----------------------------------------------------------------------*/
	while (current < (PACKET*)pBlock->_sys_memory_eptr)
	{
		int size = current->packet_size & ~BLOCK_SIZE_MASK;
		int used = current->packet_size & BLOCK_USED;


		if (!used)
		{
			free_block_space += size;
			free_block_max = BrMAX(free_block_max, size);
			//free_block_max++;
		}

		current = (PACKET*)((char*)current + size + BLOCK_OVERHEAD);
	}

	*pfree_block_max = free_block_max;
	*pfree_block_space = free_block_space;
}

void thread_meminfo_ex(int nBlock, int* pused_block_space, int* pused_block_max)
{
	PACKET* current;
	int used_block_space = 0, used_block_max = 0;
	register B_MEMORY* pBlock = BrNULL;

	pBlock = gpBoraThreadStackMem;

	current = (PACKET*)pBlock->_sys_memory;

	/*-----------------------------------------------------------------------*/
	/* LOOP THROUGH ALL PACKETS                                              */
	/*-----------------------------------------------------------------------*/
	while (current < (PACKET*)pBlock->_sys_memory_eptr)
	{
		int size = current->packet_size & ~BLOCK_SIZE_MASK;
		int used = current->packet_size & BLOCK_USED;


		if (used)
		{
			BrTrace("thread big block : %d", size);
			used_block_space += size + BLOCK_OVERHEAD;
			used_block_max = BrMAX(used_block_max, size);
			//used_block_max++;
		}

		current = (PACKET*)((char*)current + size + BLOCK_OVERHEAD);
	}

	*pused_block_max = used_block_max;
	*pused_block_space = used_block_space;
}

#endif //USE_MEMCHECK


void DebugMemInfo()
{
#if defined(DYNAMIC_MEMORY_BLOCK)
#else

#ifdef _THREAD_DEBUG
#ifndef SAVE_BMP_TO_MEMINFO

#if !defined(NOT_USE_GLOBAL_VARIABLE)
	extern B_MEMORY* gpBoraThreadStackMem; //use for greater than MIN_THREAD_STACK_SIZE
	extern B_MEMORY* gpBoraEventMem; //use for less than MIN_THREAD_STACK_SIZE
#endif

	char pName[256] = { 0, };
	char pFilePath[1024] = { 0, };
	BrCHAR* pExt;
	pExt = strrchr(getDocFileName(), '.');
	if (pExt != NULL)
	{
		strncpy(pFilePath, getDocFileName(), BrStrLen(getDocFileName()) - BrStrLen(pExt));
		sprintf(pName, "_memdebug.txt");
		strcat(pFilePath, pName);
	}
	else
		sprintf(pFilePath, "bora_memdebug.txt");

	void* fp = BFopen(pFilePath, BMV_READ_WRITE);
	if (fp)
	{
		int nTotalMemSize = 0;
		int nTotalUnuseSize = 0;
		int nTotalUnuseCount = 0;
		char pMsg[1024];
		sprintf(pMsg, "Boratech FileViewer Memory Information\n");
		BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);

		sprintf(pMsg, "File : %s\n", getDocFileName());
		BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);

		sprintf(pMsg, "Date : %s\n", __DATE__);
		BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);

		sprintf(pMsg, "Time : %s\n\n", __TIME__);
		BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);

		for (int n = 0; n < 11; n++)
		{
			register PACKET* current;
			register PACKET* freelist;
			register B_MEMORY* pBlock;

			if (n == 8)
				pBlock = GetBlockByIndex(-1);
			else if (n == 9)
				pBlock = gpBoraThreadStackMem;
			else if (n == 10)
				pBlock = gpBoraEventMem;
			else
				pBlock = GetBlockByIndex(n);

			if (!pBlock) continue;

			current = (PACKET*)pBlock->_sys_memory;
			freelist = (PACKET*)pBlock->_sys_free;

			if (!current) continue;

			int nCnt = 0, nUnuseCnt = 0;
			BrLONG nUseSize = 0;
			BrLONG nUnuseSize = 0;
			BrULONG nMaxPacket = 0;

			while (current < (PACKET*)pBlock->_sys_memory_eptr)
			{
				if (current->packet_size & BLOCK_USED)
				{
					nCnt++;
#if 0//defined(BRTHREAD_MEMORY_DEBUG)
					if (n == 10) // event mem
					{
						sprintf(pMsg, "%s(%d) : used memory block(%d)\n", current->dbginfo.filename, current->dbginfo.linenumber, nCnt);
						BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);
					}
#endif
					nUseSize += (BrLONG)(current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD;
				}
				else
				{
					nUnuseCnt++;
					nUnuseSize += current->packet_size;
					nMaxPacket = BrMAX(nMaxPacket, current->packet_size);
				}
				current = (PACKET*)((char*)current + (current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD);
			}

			sprintf(pMsg, "[%d]Block\n\tTotal Size : %d, Used count(size) : %d(%d), Free count(size) : %d(%d -max[%d])\n",
				(n == 8 ? -1 : n),
				pBlock->_memory_size,	//ts
				nCnt,	// uc
				nUseSize,	// us
				nUnuseCnt,	// nc
				nUnuseSize,	// ns
				nMaxPacket);		// max	
			BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);
			nTotalMemSize += pBlock->_memory_size;
			nTotalUnuseSize += nUnuseSize;
			nTotalUnuseCount += nUnuseCnt;
		}
		sprintf(pMsg, "\nMemory Total Size : %d, Total Free count(%d), Total Free size(%d)\n",
			nTotalMemSize, nTotalUnuseCount, nTotalUnuseSize);		// max	
		BFwrite((void*)pMsg, 1, BrStrLen(pMsg), fp);

		BFclose(fp);
	}
#else
#define BITMAP_WIDTH 		640
#define BITMAP_HEIGHT 		480
#define MEM_COUNT 			9
#define MEM_TEXT_HEIGHT	23
#define MEM_BOX_HEIGHT		(BITMAP_HEIGHT / MEM_COUNT) - MEM_TEXT_HEIGHT

	BrBitmap memBitmap;
	memBitmap.m_pBitmap = MakeDeviceDIB2(BITMAP_WIDTH, BITMAP_HEIGHT, 16);

	dc.setBitmapDC(&memBitmap);

	BrDC dc;
	BrBmvPen pen, * pOldPen;
	BrBmvBrush brush, brush1, brush2, * pOldBrush;

	BFont font, * pOldFont = BrNULL;
	BrCOLORREF oldTextColor = font.setFontColor(0x0, 0x0, 0x0);
	font.setFontInfo(14, BrFALSE, BrFALSE, BrFALSE, BrFALSE);
	pOldFont = dc.setFont(&font);

	pen.createPen(eSolidPen, 1, 0x0, 0x0, 0x0);
	pOldPen = dc.setPen(&pen);

	brush.createSolidBrush(0xff, 0xff, 0xff);
	brush1.createSolidBrush(0xd2, 0xb4, 0x8c);
	brush2.createSolidBrush(0, 0xbf, 0xff);
	pOldBrush = dc.setBrush(&brush);

	BRect rc, rcc, rcText;
	dc.fillRect(0, 0, BITMAP_WIDTH, BITMAP_HEIGHT);

	for (int n = 0; n < 9; n++)
	{
		rc.setRect(0, (MEM_BOX_HEIGHT + MEM_TEXT_HEIGHT) * n, BITMAP_WIDTH, (MEM_BOX_HEIGHT + MEM_TEXT_HEIGHT) * n + MEM_BOX_HEIGHT);
		rcc = rc;
		rcText.setRect(0, (MEM_BOX_HEIGHT + MEM_TEXT_HEIGHT) * n + MEM_BOX_HEIGHT, BITMAP_WIDTH, (MEM_BOX_HEIGHT + MEM_TEXT_HEIGHT) * (n + 1));

		dc.frameRect(rc.Left(), rc.Top(), rc.Right(), rc.Bottom());

		register PACKET* current;
		register PACKET* freelist;
		register B_MEMORY* pBlock;

		if (n == 8)
			pBlock = GetBlockByIndex(-1);
		else
			pBlock = GetBlockByIndex(n);
		current = (PACKET*)pBlock->_sys_memory;
		freelist = (PACKET*)pBlock->_sys_free;
		if (!pBlock || !current)
		{
			if (pOldBrush) dc.setBrush(pOldBrush);
			if (pOldPen) dc.setPen(pOldPen);
			return;
		}

		int nW, nCnt = 0, nUnuseCnt = 0, nFreeCnt = 0, bNextDraw = 0, nNextW = 0, nMinSize = 1, nH = 1;
		BrLONG nSPos = 0, nEPos = 0;
		int nBoxSize = rc.getWidth() * rc.getHeight();
		int nMemSize = pBlock->_memory_size / nMinSize;
		BrLONG nUseSize = 0;
		BrLONG nUnuseSize = 0;
		BrLONG nFreeSize = 0;
		BrULONG nMaxPacket = 0;
		BrLPVOID pStartPos = pBlock->_sys_memory_sptr;
		if (nBoxSize < nMemSize)
			nMinSize *= (nMemSize / nBoxSize + 1);
		else
			nMinSize /= (nBoxSize / nMemSize);

		if (nMinSize < 1)
			nMinSize = 1;
		//	BrTrace("pStartPos, [0x%x], nMinSize[%d]", (BrLONG)pStartPos, nMinSize);
		while (current < (PACKET*)pBlock->_sys_memory_eptr)
		{
			nW = ((BrLONG)(current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD) / nMinSize;
			rcc.nRight = rcc.nLeft + nW;
			rcc.nBottom = rcc.nTop + nH;
			if (rcc.nBottom > rc.nBottom)
				break;

			if (rcc.nRight > rc.nRight)
			{
				nNextW = rcc.nRight - (rc.nRight - rcc.nLeft);
				rcc.nRight = rc.nRight;

				if ((current->packet_size & BLOCK_USED) == 1)
				{
					dc.setBrush(&brush1);
					dc.fillRect(rcc.Left(), rcc.Top(), rcc.Right(), rcc.Bottom());
				}
				else if ((current->packet_size & BLOCK_USED) == 2)
				{
					dc.setBrush(&brush2);
					dc.fillRect(rcc.Left(), rcc.Top(), rcc.Right(), rcc.Bottom());
				}

				if (nNextW > rc.nRight)
				{
					int nTmp = nNextW / rc.nRight;
					rcc.nLeft = 0;
					rcc.nRight = rc.nRight;
					rcc.nTop = rcc.nBottom;
					rcc.nBottom = rcc.nTop + nH * nTmp;

					if ((current->packet_size & BLOCK_USED) == 1)
					{
						dc.setBrush(&brush1);
						dc.fillRect(rcc.Left(), rcc.Top(), rcc.Right(), rcc.Bottom());
					}
					else if ((current->packet_size & BLOCK_USED) == 2)
					{
						dc.setBrush(&brush2);
						dc.fillRect(rcc.Left(), rcc.Top(), rcc.Right(), rcc.Bottom());
					}

					rcc.nRight = nNextW - rc.nRight * nTmp;
					rcc.nTop = rcc.nBottom;
					rcc.nBottom = rcc.nTop + nH;
				}
				else
				{
					rcc.nLeft = 0;
					rcc.nRight = rcc.nLeft + nNextW;
					rcc.nTop = rcc.nBottom;
					rcc.nBottom = rcc.nTop + nH;
				}
			}

			rcc.nRight += 1;
			if ((current->packet_size & BLOCK_USED) == 1)
			{
				dc.setBrush(&brush1);
				dc.fillRect(rcc.Left(), rcc.Top(), rcc.Right(), rcc.Bottom());
			}
			else if ((current->packet_size & BLOCK_USED) == 2)
			{
				dc.setBrush(&brush2);
				dc.fillRect(rcc.Left(), rcc.Top(), rcc.Right(), rcc.Bottom());
			}

			rcc.nLeft = rcc.nRight;

			if (current->packet_size & BLOCK_USED)
			{
				nCnt++;
				nUseSize += (BrLONG)(current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD;
				//BrTrace("use, [%d] [0x%x][%d]", nCnt, current, (BrLONG)(current->packet_size&~BLOCK_SIZE_MASK)+BLOCK_OVERHEAD);			
			}
			else
			{
				nUnuseCnt++;
				nUnuseSize += current->packet_size;
				nMaxPacket = BrMAX(nMaxPacket, current->packet_size);
				//BrTrace("unuse, [%d] [0x%x][%d]", nUnuseCnt, current, (BrLONG)(current->packet_size&~BLOCK_SIZE_MASK)+BLOCK_OVERHEAD);
			}

			current = (PACKET*)((char*)current + (current->packet_size & ~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD);
		}

		BString strMsg;
		char pMsg[1024];
		sprintf(pMsg, "[%d],ts[%d],uc[%d],us[%d],nc[%d],ns[%d],max[%d]",
			(n == 8 ? -1 : n),
			pBlock->_memory_size,	//ts
			nCnt,	// uc
			nUseSize,	// us
			nUnuseCnt,	// nc
			nUnuseSize,	// ns
			nMaxPacket);		// max	
		strMsg = pMsg;

		dc.drawChars(&strMsg, rcText.Left(), rcText.Top(), 0);
	}

	if (pOldFont)
		dc.setFont(pOldFont);
	//	DumpImage(memBitmap.m_pBitmap, 0, 0);

	{
		char pName[256] = { 0, };
		char pImgPath[1024] = { 0, };
		BrCHAR* pExt;
		pExt = strrchr(getDocFileName(), '.');
		strncpy(pImgPath, getDocFileName(), BrStrLen(getDocFileName()) - BrStrLen(pExt));

		sprintf(pName, "_%03d.bmp", nBitmapCount++);
		strcat(pImgPath, pName);
		SaveBitmap2(pImgPath, (void*)memBitmap.m_pBitmap);
	}

	if (pOldBrush) dc.setBrush(pOldBrush);
	if (pOldPen) dc.setPen(pOldPen);

	if (memBitmap.m_pBitmap)
	{
		BFreeEx((BrLPVOID)memBitmap.m_pBitmap);
	}
#endif
#endif	

#endif // DYNAMIC_MEMORY_BLOCK
}


#ifdef MEMORY_OVERRUN_CHECK
void BrCheckMemoryOverrun(BrLPVOID dst, BrSIZE_T count, BrCHAR* filename, BrINT fileline, BrCHAR* funcname)
{
	//	if (!dst)	// null üũ
	//	{
	//		BTrace("[%s]%s(%d) dst=0x%x", __FUNCTION__, __FILE__, __LINE__, dst);
	//#ifdef _MM_IX86
	//		__asm int 3;
	//#endif //_MM_IX86
	//	}

	BrBOOL bMemSizeCheck = BrFALSE;
	BR_MEM_TYPE eMemType = GetMemoryType(dst);	// �޸� Ÿ�� üũ
	switch (eMemType)
	{
	case MEM_TYPE_HEAP:
	case MEM_TYPE_LARGEHEAP:
	case MEM_TYPE_NOTUSE:
	case MEM_TYPE_SYSHEAP:
	case MEM_TYPE_LARGESYSHEAP:
		bMemSizeCheck = BrTRUE;
		break;
	default: // MEM_TYPE_NONE => system malloc �Ǵ� stack ������ �޸��̰ų�, BrMalloc���� ���� �޸𸮰� ���� ���
		bMemSizeCheck = BrFALSE;
		break;
	}

	// BrMalloc���� �Ҵ�� �޸𸮿� ���� ������ üũ
	if (bMemSizeCheck)
	{
		// BrMalloc������ �޸� �Ҵ� �� ��û�ߴ� size�� 8�� ����� ���缭 ����ϹǷ�, ���� ��û�ߴ� size���� ���� ũ�� ������ �� ������, ���� ��û�ߴ� size�� �˰� �ʹٸ� �ڵ������ Ȯ���ؾ���
		BrUINT32 nMemorySize = GetPacketMemSize(dst, eMemType);
		if (nMemorySize)
		{
			BrBOOL bOverrun = nMemorySize < count;
			if (bOverrun)
			{
				// ##### ����� ���� ���� Memory Overrun�� �ش��ϹǷ� �ڵ带 �ݵ�� �����Ͻñ� �ٶ��ϴ� #####
				BTrace("!!!!! Memory Overrun detected !!!!! [%s]%s(line:%d) nMemorySize=%d, count=%d", funcname, filename, fileline, nMemorySize, count);
#ifdef _MM_IX86
				__asm int 3;
#endif //_MM_IX86
			}
		}
	}
}

void* BrMemset(BrLPVOID dst, BrINT val, BrSIZE_T count, BrCHAR* filename, BrINT fileline, BrCHAR* funcname)
{
	BrCheckMemoryOverrun(dst, count, filename, fileline, funcname);
#pragma push_macro("memset")
#undef memset
	return memset(dst, val, count);
#pragma pop_macro("memset")
}

void* BrMemcpy(BrLPVOID dst, const void* src, BrSIZE_T count, BrCHAR* filename, BrINT fileline, BrCHAR* funcname)
{
	BrCheckMemoryOverrun(dst, count, filename, fileline, funcname);
#pragma push_macro("memcpy")
#undef memcpy
	return memcpy(dst, src, count);
#pragma pop_macro("memcpy")
}

void* BrMemmove_ovrchk(BrLPVOID dst, const void* src, BrSIZE_T count, BrCHAR* filename, BrINT fileline, BrCHAR* funcname)
{
	BrCheckMemoryOverrun(dst, count, filename, fileline, funcname);
#pragma push_macro("memmove")
#undef memmove
	return memmove(dst, src, count);
#pragma pop_macro("memmove")
}
#endif //MEMORY_OVERRUN_CHECK

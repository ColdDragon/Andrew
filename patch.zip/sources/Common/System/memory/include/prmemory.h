#ifndef	_PRMEMORY_H_
#define	_PRMEMORY_H_


#define USE_MULTI_MEMORY_BLOCK_LIST
#define USE_ADVANCED_BRMALLOC

#define DYNAMIC_MEMORY_BLOCK
#define DYNAMIC_FONTMEM_BLOCK

//#define MALLOC_SPEED_CHECK
//#define FREE_SPEED_CHECK

#ifdef MALLOC_SPEED_CHECK
#define MALLOC_TIME_CHECK BRTHREAD_STOPWATCH
#else
#define MALLOC_TIME_CHECK
#endif

#ifdef FREE_SPEED_CHECK
#define FREE_TIME_CHECK BRTHREAD_STOPWATCH
#else
#define FREE_TIME_CHECK
#endif

// BoraThread(BoraEvent) malloc�� b_init����,
// BoraThread(BoraEvent) free�� b_finalize���� ����

#if defined(__x86_64) || defined(__x86_64__) || \
    defined(__amd64__) || defined(__amd64) || \
    defined(_M_X64) || \
	defined(__aarch64__) || defined(__arm64) || \
	defined(__LP64__) || defined(_LP64) || defined(__LP64)
	#ifdef _M_X64
		#define LARGE_TYPE      __int64
	#else
		#define LARGE_TYPE      int64_t 
	#endif
#else
	#define LARGE_TYPE      BrUINT32
#endif

#if defined(BRTHREAD_MEMORY_DEBUG)
typedef struct mdbginfo	// size�� 8�� ����� ���� ��.
{
	BrCHAR*		filename;
	LARGE_TYPE	linenumber;
	LARGE_TYPE	alloc_count;
	LARGE_TYPE	leakcheck_id;		/* ���� 1byte�� current thread id */
}MDBGINFO;
#endif

#define	MEM_BLOCK_COUNT			1
#ifdef USE_MCORE_MEMPOOL
#	define MEM_MAGIC_NUMBER		0x3FFFFFFF
#	define MEM_USED_MAGIC_NUMBER	0x3FFFFFF0
#	define MEM_MAGIC_NUMBER_MASK	(~0xC000000F)
#else //USE_MCORE_MEMPOOL
#	define MEM_MAGIC_NUMBER		0x7FFFFFFF
#	define MEM_USED_MAGIC_NUMBER	0x7FFFFFF0
#	define MEM_MAGIC_NUMBER_MASK	(~0x0000000F)
#endif //USE_MCORE_MEMPOOL

typedef struct _Bora_Memory_map 
{
	BrUINT32        BORA_HEAPMEM_SIZE;
	BrUINT32        BORA_SYSMEM_SIZE;
	BrUINT32		BORA_HEAPMEM_THRESHOLD;
	BrUINT32		BORA_SYSMEM_THRESHOLD;
	BrUINT32        MEM_MAP_FLAG;	// arrange reverse or forward 
} BORA_MEMORY_MAP;

typedef struct pack 
{
	LARGE_TYPE	packet_size;		/* number of bytes		  */
	struct pack	*last_ptr_nearby;	/* last packet the most close */
#if defined(BRTHREAD_MEMORY_DEBUG)
	MDBGINFO	dbginfo;
#endif
	struct pack	*last_ptr;			/* last elem in free list */
	struct pack	*size_ptr;			/* next elem in free list */
} PACKET;


// BLOCK_OVERHEAD �� ���� �� magic_number�� address�� ���;� �ϰ� �ٽ� BLOCK_OVERHEAD�� ���� _actual_size�� address�� ���;� ��.
typedef struct large_pack
{
	LARGE_TYPE	_actual_size;				/* sizeof this block		*/
	struct large_pack* _prev_large_pack;	/* prev elem in large block list */

	LARGE_TYPE	magic_number;				/* magic_number. MEM_MAGIC_NUMBER, must be this position */
	struct large_pack* _next_large_pack;	/* next elem in large block list */
#if defined(BRTHREAD_MEMORY_DEBUG)
	MDBGINFO	dbginfo;
#endif
} LARGE_PACKET;

typedef struct _B_MEMORY 
{
	BrLONG		_actual_size;
	BrLONG		_memory_size;
	BrCHAR *	_sys_memory;
	PACKET *	_sys_free;
	BrLPVOID	_sys_memory_sptr;
	BrLPVOID	_sys_memory_eptr;
	struct _B_MEMORY*	_prev_memory_block;
	struct _B_MEMORY*	_next_memory_block;
	BrUINT32	_max_packet_size;
	BrUINT32	_total_free_size;
#ifdef USE_ADVANCED_BRMALLOC
	BrUINT32	_not_use_block;
	PACKET *	_small_sys_free;
	BrUINT32	_small_max_packet_size;
	BrUINT32	_dummy;
#endif //USE_ADVANCED_BRMALLOC
} B_MEMORY;

#ifdef USE_MULTI_MEMORY_BLOCK_LIST
#define SBLOCKLIST_COUNT		16		// Small Block List ����
#endif //USE_MULTI_MEMORY_BLOCK_LIST
typedef struct _B_MEM_POOL 
{
	B_MEMORY*		m_pBoraSysMem;
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	B_MEMORY*		m_pBoraHeapMem[SBLOCKLIST_COUNT];
	B_MEMORY*		m_pNotUseBlock[SBLOCKLIST_COUNT];
#else //USE_MULTI_MEMORY_BLOCK_LIST
	B_MEMORY*		m_pBoraHeapMem;
	B_MEMORY*		m_pNotUseBlock;
#endif //USE_MULTI_MEMORY_BLOCK_LIST
	LARGE_PACKET*	m_pBoraLargeSysHeap;
	LARGE_PACKET*	m_pBoraLargeHeap;
	void*			m_pBoraFileMem;

	BrBOOL			m_bResetHeapMem;
	BrBOOL			m_bInitHeapMem;
	BrUINT64			m_available_memory_size;
	BrUINT64			m_allocated_memory_size;
	BrUINT64			m_check_memory_level;//m_available_memory_size�� �����ϱ� ���� ����, 100MB������ ���� Ȯ��

	BrINT			m_MemPool_Id;
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
	BrINT			m_SBlockList_pos;
#endif //USE_MULTI_MEMORY_BLOCK_LIST

#if defined(BRTHREAD_MEMORY_DEBUG)
	BrUINT16	m_alloc_count;
	BrUINT32	m_leakID;
#endif
} B_MEM_POOL;

#define IS_LARGE_PACKET(x) ((((PACKET*)x)->packet_size&MEM_MAGIC_NUMBER_MASK) == MEM_USED_MAGIC_NUMBER)
#define GET_HEADER(x) ((PACKET*)((LPBYTE)x-BLOCK_OVERHEAD))
#define GET_NEXT_PACKET(x) ((PACKET*)(((LPBYTE)x + (x->packet_size&~BLOCK_SIZE_MASK) + BLOCK_OVERHEAD)))

#define retnull()    return 0	
#define retvoid()   return
#define CHECKNULLRET(expr)	if(expr) retnull()
#define CHECKVOIDRET(expr)	if(expr) retvoid()	

#if defined(BRTHREAD_MEMORY_DEBUG)

#define VERIFY_MEMORY_PACKET
#define MEM_DEBUG_TAIL_SIZE		(BrSizeOf(LARGE_TYPE)+BrSizeOf(LARGE_TYPE))
#define MEM_DEBUG_TAIL_VALUE	0xCFCFCFCFDFDFDFDF

void		bora_set_debuginfo(B_MEM_POOL* pMemPool, PACKET* packet, BrCHAR* szfile, BrLONG nline);
void		bora_initialize_packet(PACKET* packet);

void		bora_set_large_debuginfo(B_MEM_POOL* pMemPool, LARGE_PACKET* packet, BrCHAR* szfile, BrLONG nline);
void		bora_large_initialize_packet(LARGE_PACKET* packet);


#if defined(_PLAT_WINDOWS)
inline void bora_memset_packet(PACKET* packet){	memset(packet, 0xCC, BrSizeOf(PACKET)); }
#else // _PLAT_WINDOWS
#define bora_memset_packet(x)
#endif

#define MIN_BLOCK       (BrSizeOf(pack*)+BrSizeOf(pack*))
#define BLOCK_OVERHEAD  (BrSizeOf(LARGE_TYPE)+BrSizeOf(pack*)+BrSizeOf(MDBGINFO))
#define BLOCK_USED      1
#define BLOCK_MASK      (MIN_BLOCK-1)

#define LARGE_BLOCK_OVERHEAD		(BrSizeOf(LARGE_TYPE)+BrSizeOf(large_pack*)+BrSizeOf(LARGE_TYPE)+BrSizeOf(large_pack*)+BrSizeOf(MDBGINFO))
#define LARGE_BLOCK_HALF_OVERHEAD	((BrSizeOf(LARGE_TYPE)+BrSizeOf(large_pack*))

#else

#if defined(BRTHREAD_MEMORY_TAIL)
//#define VERIFY_MEMORY_PACKET
#define MEM_DEBUG_TAIL_SIZE		(BrSizeOf(LARGE_TYPE)+BrSizeOf(LARGE_TYPE))
#define MEM_DEBUG_TAIL_VALUE	0xCFCFCFCFDFDFDFDF
#else
#define MEM_DEBUG_TAIL_SIZE		0x0
#endif

#define bora_set_debuginfo(v, x, y, z)
#define bora_set_large_debuginfo(v, x, y, z)
#define bora_initialize_packet(x)
#define	bora_large_initialize_packet(x)
#define bora_memset_packet(x)

#define MIN_BLOCK       (BrSizeOf(pack*)+BrSizeOf(pack*))
#define BLOCK_OVERHEAD  (BrSizeOf(LARGE_TYPE)+BrSizeOf(pack*))
#define BLOCK_USED      1
#define BLOCK_MASK      (MIN_BLOCK-1)

#define LARGE_BLOCK_OVERHEAD		(BrSizeOf(LARGE_TYPE)+BrSizeOf(large_pack*)+BrSizeOf(LARGE_TYPE)+BrSizeOf(large_pack*))
#define LARGE_BLOCK_HALF_OVERHEAD	(BrSizeOf(LARGE_TYPE)+BrSizeOf(large_pack*))
#endif

#ifdef RENDERING_WITH_BORATHREAD
#ifdef USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
#define BLOCK_SIZE_MASK				(~0x30FFFFF8)
#else //USE_MULTI_MEMORY_BLOCK_LIST
#define BLOCK_SIZE_MASK				(~0x3FFFFFF8)
#endif //USE_MULTI_MEMORY_BLOCK_LIST
#define MEMPOOL_ID_MASK				0xC0000000
#else //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
#define BLOCK_SIZE_MASK				(~0xF0FFFFF8)
#else //USE_MULTI_MEMORY_BLOCK_LIST
#define BLOCK_SIZE_MASK				0x7
#endif //USE_MULTI_MEMORY_BLOCK_LIST
#endif //USE_MCORE_MEMPOOL
#ifdef USE_MULTI_MEMORY_BLOCK_LIST
#define BLOCK_LIST_POS_MASK			0xF000000
#endif //USE_MULTI_MEMORY_BLOCK_LIST
#define SMALL_PACKET_MAX_SIZE		0xFFFFF8
#define THREADID_MASK				0x6

#define UNCHECK_THREADID_FLAG		0x01
#else //RENDERING_WITH_BORATHREAD
#define BLOCK_SIZE_MASK	BLOCK_USED

#endif //RENDERING_WITH_BORATHREAD

#ifdef BORA_THREAD_SUPPORT

#if defined(RENDERING_WITH_BORATHREAD)
#define		THREAD_MAX_COUNT	4 //concurrent maxim threads count
#else
#define 	THREAD_MAX_COUNT	2 //concurrent maxim threads count
#endif

#if !defined(OLD_MS_COMPILER)
	#define		THREAD_STACK_SIZE		BoraThreadTraits::thread_traits::kDefaultThreadStackSize	//one thread stack
	#define		MIN_THREAD_STACK_SIZE	BoraThreadTraits::thread_traits::kMinimumThreadStackSize	//one thread stack
#else
	#define		THREAD_STACK_SIZE		WinFiber::kDefaultThreadStackSize	//one thread stack
	#define		MIN_THREAD_STACK_SIZE	WinFiber::kMinimumThreadStackSize	//one thread stack
#endif

#if defined(BRTHREAD_USE_STANDARDFIBER) || defined(BRTHREAD_USE_PTHREADFIBER) || (defined(_PLAT_LINUX)&&!defined(BRTHREAD_USE_PTHREAD_API)) || defined(BRTHREAD_USE_STDFIBER_VC6)
	#if defined(RENDERING_WITH_BORATHREAD)
		#define		THREAD_MEM_SIZE		( THREAD_STACK_SIZE*3/* Filter + Cache + Interface */ + MIN_THREAD_STACK_SIZE*1/* Render */ + 1024)
	#else
		#define		THREAD_MEM_SIZE		(THREAD_STACK_SIZE*THREAD_MAX_COUNT+1024)
	#endif
#else
	#define THREAD_MEM_SIZE 1024
#endif



#define		EVENT_MEM_SIZE		(1024*128)
#else
#define		THREAD_MAX_COUNT		4 //concurrent maxim threads count
#define		THREAD_STACK_SIZE		(6*1024)//one thread stack
#define		MIN_THREAD_STACK_SIZE	(6*1024)
#define		THREAD_MEM_SIZE			(THREAD_STACK_SIZE*THREAD_MAX_COUNT+1024)
#define		EVENT_MEM_SIZE			(1024*32)
#endif
//end : memory for thread and event 

#define MEM_SZ_1K		0x00000400
#define MEM_SZ_4K		0x00001000
#define MEM_SZ_5K		0x00001400
#define MEM_SZ_8K		0x00002000
#define MEM_SZ_10K		0x00002800
#define MEM_SZ_16K		0x00004000
#define MEM_SZ_32K		0x00008000
#define MEM_SZ_64K		0x00010000
#define MEM_SZ_128K		0x00020000
#define MEM_SZ_256K		0x00040000
#define MEM_SZ_512K		0x00080000
#define MEM_SZ_768K		0x000C0000

#define MEM_SZ_1M		0x00100000
#define MEM_SZ_2M		0x00200000
#define MEM_SZ_3M		0x00300000
#define MEM_SZ_4M		0x00400000
#define MEM_SZ_5M		0x00500000
#define MEM_SZ_8M		0x00800000
#define MEM_SZ_10M		0x00A00000
#define MEM_SZ_16M		0x01000000
#define MEM_SZ_32M		0x02000000
#define MEM_SZ_64M		0x04000000
#define MEM_SZ_128M		0x08000000
#define MEM_SZ_256M		0x10000000
#define MEM_SZ_512M		0x20000000

#define MEM_THRESHOLD	MEM_SZ_10K


#ifdef MEMORY_OVERRUN_CHECK
typedef enum {
	MEM_TYPE_NONE,
	MEM_TYPE_SYSHEAP,
	MEM_TYPE_HEAP,
	MEM_TYPE_NOTUSE,
	MEM_TYPE_LARGESYSHEAP,
	MEM_TYPE_LARGEHEAP
} BR_MEM_TYPE;
#endif //MEMORY_OVERRUN_CHECK


#endif //_PRMEMORY_H_


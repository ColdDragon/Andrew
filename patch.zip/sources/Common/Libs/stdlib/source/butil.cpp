﻿#include <OfficePreComp.hpp>

#include "butil.h"
#include "icuwrapper.h"
#include "binterfacehandle.h"
#include "BFile.h"
#include "constants.h"
#include "BrLocaleLanguageDef.h"
#include "officex_shape3d_enum.h"
#include "ImageLib.h"
#include "../Bwp/Filter/hwp/Common/Manager/HwpSignatureIdentifier.h"
#include "../Bwp/Filter/hwp/Common/Manager/HwpSignatureTraits.h"
#include "prmemory_manager.h"
#include "../Error/ErrorHandle.h"
#include "../Error/CPublicErrorObj.h"
#include "package_def.h"

static const BrINT minSignatureSize = 4;

BrCOLORREF getNewColor(BrCOLORREF color)
{
#ifdef USE_32BIT_IMAGE
	color &= 0x00ffffff;
#endif
	return color;
}

// This is a subfunction of HSLtoRGB
void HSLtoRGB_Subfunction(unsigned int& c, const float& temp1, const float& temp2, const float& temp3)
{
	if((temp3 * 6) < 1)
		c = (unsigned int)((temp2 + (temp1 - temp2)*6*temp3)*100);
	else
		if((temp3 * 2) < 1)
			c = (unsigned int)(temp1*100);
		else
			if((temp3 * 3) < 2)
				c = (unsigned int)((temp2 + (temp1 - temp2)*(.66666 - temp3)*6)*100);
			else
				c = (unsigned int)(temp2*100);
	return;
}

CUtil::CUtil()
{

}

CUtil::~CUtil()
{

}

int CUtil::UniBYTEtoWORD(BrLPWORD pWordStr, BrLPCSTR pByteStr, int nLen)
{
	int len = 0;

	if ( !*pByteStr || nLen==0 )   return 0;

	for ( int i=0; i<nLen; i+=2 )	{
		//----- Hangeul
		*pWordStr = (BrWORD)(*pByteStr) & 0x00FF;
		pByteStr++;
		*pWordStr <<= 8;
		*pWordStr |= ((BrWORD)(*pByteStr) & 0x00FF);

		pWordStr++;
		pByteStr++;
		len++;
	}

	*pWordStr = 0;
	return(len);
}

//  Convert BYTE string to BrWORD string
int CUtil::BYTEtoWORD(BrLPWORD pWordStr, LPBYTE pByteStr)
{
	int   len = 0;

	if (!*pByteStr)
		return (BrFALSE);

	while (*pByteStr)
	{
		if (*pByteStr > 0x80 && *(pByteStr + 1))
		{
			*pWordStr = (BrWORD) (*pByteStr) & 0x00FF;
			pByteStr++;
			*pWordStr <<= 8;
			*pWordStr |= ((BrWORD) (*pByteStr) & 0x00FF);
		}
		else
		{
			if (*pByteStr == 0x0d && *(pByteStr + 1) == 0x0a)
				pByteStr++;
			*pWordStr = (BrWORD) (*pByteStr) & 0x00FF;
		}

		pWordStr++;
		pByteStr++;
		len++;
	}

	*pWordStr = 0;
	return (len);
}

//  Convert BrWORD string to BYTE string
int CUtil::WORDtoBYTE(BrLPWORD pWordStr, LPBYTE pByteStr)
{
	int len = 0;
	BrWORD wTemp;

	if(!pWordStr) return BrFALSE;

	while( *pWordStr)
	{
		wTemp = *pWordStr; 
		if( wTemp>0xff )
		{
			*pByteStr = (wTemp) >> 8;	// HIBYTE(wTemp); 
			pByteStr++; len++;
			*pByteStr = (wTemp) & 0xff;	// LOBYTE(wTemp);    
		}
		else
		{
			if( ((wTemp) & 0xff)/*LOBYTE(wTemp)*/ == 0x000a)
			{
				*pByteStr = 0x0d;
				pByteStr++; len++;
				*pByteStr = 0x0a;
			}
			else
			{
				if( ((wTemp) & 0xff)/*LOBYTE(wTemp)*/ > 0x7F )	//--- ASCII code 128 이상은 모두 걸러내자.
					*pByteStr = 0x20;
				else
					*pByteStr = (wTemp) & 0xff;	// LOBYTE(wTemp);    
			}
		}

		pWordStr++;
		pByteStr++;
		len++;
	}        
	*pByteStr = 0;
	return len;
}

//  Convert BrWORD string to BrWORD string
int CUtil::wstrcpy(BrLPWORD pDestStr, BrLPWORD pSrcStr)
{
	int   len = 0;

	if (!*pSrcStr)
		return (BrFALSE);

	while (*pSrcStr)
	{
		*pDestStr = *pSrcStr;

		pDestStr++;
		pSrcStr++;
		len++;
	}

	*pDestStr = 0;
	return (len);
}
int CUtil::wstrncpy(BrLPWORD pDestStr, BrLPWORD pSrcStr, int nLength)
{
	WORD *p = pDestStr;
	int   len = 0;

	if (!*pSrcStr || nLength <= 0)
		return (BrFALSE);

	while (*pSrcStr && len < nLength)
	{
		*pDestStr = *pSrcStr;

		pDestStr++;
		pSrcStr++;
		len++;
	}

	*pDestStr = 0;
	return (len);
}

//  append word string
void CUtil::wstrcat(BrLPWORD pDestStr, BrLPWORD pSrcStr)
{
	if (!*pSrcStr)
		return;

	pDestStr += wstrlen(pDestStr);

	while (*pSrcStr)
	{
		*pDestStr = *pSrcStr;

		pDestStr++;
		pSrcStr++;
	}

	*pDestStr = 0;
}

//  append word string
void CUtil::wstrcat1(BrLPWORD pDestStr, BrLPSTR pSrcStr)
{
	if (!*pSrcStr)
		return;

	pDestStr += wstrlen(pDestStr);

	while (*pSrcStr)
	{
		*pDestStr = *pSrcStr;

		pDestStr++;
		pSrcStr++;
	}

	*pDestStr = 0;
}

//  get word string length
int CUtil::wstrlen(BrLPWORD pStr)
{
	int		len = 0;

	while ( *pStr )	{
		pStr++;
		len++;
	}
	return len;
}

//  get word string length
int CUtil::BCharlen(BChar *pStr)
{
	int		len = 0;

	while ( pStr->unicode() )	{
		pStr++;
		len++;
	}
	return len;
}

int CUtil::WcsToMbsz( char *mbstr, const BrWCHAR *wcstr, int count )
{
#ifdef IMPORT_HTML
	if( mbstr == BrNULL )
	{
		// 갯수만 리턴.  %%%%%%%%%%%한글이라고 가정합니다.
#ifdef ANDROID_PLATFORM
		return WideCharToMultiByte( CP_UTF8 , 0 , wcstr , -1 , BrNULL , 0 ,  BrNULL, BrNULL )-1; // \0은 포함하지 않으므로 -1해 준다.
#else
		return WideCharToMultiByte( 949 , 0 , wcstr , -1 , BrNULL , 0 ,  BrNULL, BrNULL )-1; // \0은 포함하지 않으므로 -1해 준다.
#endif
	}
	else
	{
#ifdef ANDROID_PLATFORM
		return WideCharToMultiByte( CP_UTF8 , 0 , wcstr , -1 , mbstr , count , BrNULL, BrNULL )-1;
#else
		return WideCharToMultiByte( 949 , 0 , wcstr , -1 , mbstr , count , BrNULL, BrNULL )-1;
#endif
	}
#else
	return 0;
#endif
}

int CUtil::MbszToWcs( BrWCHAR *wcstr, const char *mbstr, int count )
{
#ifdef IMPORT_HTML
	if( wcstr == BrNULL )
	{
		// 갯수만 리턴.  %%%%%%%%%%%한글이라고 가정합니다.
		return MultiByteToWideChar( 949 , 0 , mbstr , -1 , BrNULL , 0 )-1; // \0은 포함하지 않으므로 -1해 준다.
	}
	else
	{
		return MultiByteToWideChar( 949 , 0 , mbstr , -1 , wcstr , count)-1;
	}
#else
	return 0;
#endif
}

BrBOOL CUtil::IsUniReadByte(unsigned short Uni)
{
	if( Uni > 0xff )
		return BrTRUE;
	else
		return BrFALSE;
}

// [이상호] sheet에서 가져옴 멀티 바이트 unicode로
// a_strChar : 항상 Multibyte 형태 주의
BString CUtil::MultibyteToBString(const BrCHAR* a_strChar)
{

	//멀티 바이트 변환 방법 죄다 가져오긴 했는데 제대로 될려나..
	BString retString;
	if(a_strChar == BrNULL)
		return retString;

	if ( BrStrLen(a_strChar) > 0 )
	{
		BrINT nCodePage = getCodePageOfString((char*)a_strChar, BrStrLen(a_strChar));
		BrINT wLen = BrMultiByteToWideChar(nCodePage, a_strChar, BrStrLen(a_strChar), BrNULL, 0) + 1; //WideChar를 위한 길이를 구함
		BrUSHORT* pOutput = (BrUSHORT*)BrCalloc(wLen, BrSizeOf(BrUSHORT));
		if (pOutput)
		{
			BrINT32 nRetSize = 0;
			if (  (nRetSize = BrMultiByteToWideChar(nCodePage, a_strChar, BrStrLen(a_strChar), pOutput, wLen)) != 0 )
			{
				for (BrINT32 i = 0; i < nRetSize && pOutput[i]; i++)
					retString += BChar(pOutput[i]);
			}
			else
				retString = KSC5601ToUnicode((BrCHAR*)a_strChar, BrStrLen((const BrCHAR*)a_strChar));

			BR_SAFE_FREE(pOutput);
		}
	}

	retString.utf8();
	return retString;
}

BrBOOL CUtil::UnicodeToUTF8(BrLPSTR utf8_string, int *utf8_length, const BString &utf16_string)
{
	if (utf8_string == NULL || *utf8_length < 0)
		return BrFALSE;

	if (*utf8_length == 0)
		return BrTRUE;

	int utf16_length = utf16_string.length();
	if (utf16_length == 0) {
		utf8_string[0] = '\0';
		return BrTRUE;
	}

	BArray<BrWCHAR> utf16_array;
	const BChar *utf16_unicode = utf16_string.unicode();
	for (int i = 0; i < utf16_length; ++i) {
		BrWCHAR utf16_char = utf16_unicode[i].unicode();
		utf16_array.Add(utf16_char);
	}
	*utf8_length = BrWideCharToMultiByte(CP_UTF8,
										utf16_array.data(), utf16_length,
										utf8_string, *utf8_length);

	return BrTRUE;
}

BString CUtil::KSC5601ToUnicode(BrLPCSTR chars, int len)
{
	BrBYTE b = 0, b2 = 0;
	BrBYTE *p = (BrBYTE *)chars;
	BrWCHAR* wideChars = BrNULL;
	BString	result;
	int nCnt= 0;
	
#if 0	//기존 코드
	BrWCHAR wideChar = 0;

	while( 1 ) 
	{
		b = *p;
		p++;
		nCnt++;

		if( IsDBCSLeadByte( b , *p ) )
		{
			b2 = *p;
			p++;
			nCnt++;
			if( b2 ==0 )//트레일이 0이네요.
			{
				wideChar = 0;
			}
			else
			{
				wideChar =  (BrWCHAR) KSC5601ToUnicode( BrMAKEWORD( b2 , b ) );
				if ( wideChar==0 )	
					wideChar = ' ';
			}
		}
		else
		{
			wideChar = (BrWCHAR) b;
		}

		result += BChar(wideChar);
		if( nCnt >= len )
		{
			return result;
		}
	}
#else
	nCnt = BrMultiByteToWideChar( /*CP_ACP*/CP_KSC5601, chars, BrStrLen(chars), wideChars, 0 );

	if(nCnt > 0)
	{
		wideChars = (BrWCHAR*)BrCalloc(nCnt+1, sizeof(BrWCHAR));
		nCnt = BrMultiByteToWideChar( /*CP_ACP*/CP_KSC5601, chars, BrStrLen(chars), wideChars, nCnt );
		result = wideChars;
		BR_SAFE_FREE( wideChars );
	}
	else
	{
		BChar a;
		result += a;
	}
#endif

	return result;
}

BrWORD CUtil::KSC5601ToUnicode(BrWORD code)
{
	BrWORD nRet= 0;
	if (code < 0xa1)
		nRet=code;
	else
	{
		BrWCHAR aWChar[2] = {0};
		BrCHAR pIn[3] = {0,};
		pIn[0] = (code >> 8) & 0xff; 
		pIn[1] = code & 0xff;
		//[2012.08.20][배원융][TID:8553] 중국어 환경에서 한글 폰트명 깨지는 문제 수정
		//KSC5601ToUnicode 라는 함수명은 Input String이 KSC5601이라는 전제가 있는 것이므로
		//Codepage값을 KSC5601을 명시적으로 주어야 한다
		//그렇지 않고 ACP를 줄 경우 실행 환경에 따라 다른 CodePage가 다르게 적용되어 글자가 깨지게 된다
		//이 수정으로 발생하는 문제의 경우 해당 함수를 목적에 맞지 않게 사용하고 있을 가능성이 있으므로 호출단을 먼저 검토 해야 한다.
		//BrMultiByteToWideChar( /*CP_ACP*/CP_KSC5601, (BrLPCSTR)pIn, BrStrLen(pIn), (BrLPWSTR)&pOutput, sizeof(pOutput) );
		if(BrMultiByteToWideChar( /*CP_ACP*/CP_KSC5601, (BrLPCSTR)pIn, BrStrLen(pIn), aWChar, 1 ))
			nRet=aWChar[0];
		//if (pOutput != 0)    nRet=aWChar[0];
	}

	return nRet;
}
LPBYTE CUtil::UnicodeToKSC5601(const BString& chars, int* len)
{
	int i, nCnt = 0;
	int l = (int)chars.length();
	int rlen = l*2+1;
	unsigned short uni;
	unsigned char* rstr = (unsigned char*)BrMalloc(rlen);
	if( !rstr ) return NULL;

	memset(rstr, 0, rlen);
	for (i=0; i<l; i++) 
	{		
		BChar ch = chars[i];
		uni = UnicodeToKSC5601(ch.unicode());
		if (uni > 0)
		{
			if ((uni  >> 8) == 0)
				rstr[nCnt++] = (uni & 0xff);
			else
			{
				rstr[nCnt++] = (uni >> 8);
				rstr[nCnt++] = (uni & 0xff);
			}
		}
		else
			rstr[nCnt++] = (unsigned char) 0;	
	}

	if(len) *len = nCnt+1;

	if (nCnt+1 != rlen)
	{
		rstr = (unsigned char*)BrRealloc((BrLPVOID)rstr, nCnt+1);
		rstr[nCnt] = '\0';
	}

	return rstr;
}

LPBYTE CUtil::UnicodeToKSC5601(BrLPCWSTR chars, int* len)
{
	BString strString;
	strString = chars;

	LPBYTE pOutData = UnicodeToKSC5601(strString, len);

	return pOutData;
}

BrWORD CUtil::UnicodeToKSC5601(BrWORD unicode)
{
	BrWORD nRet= 0;	
	if (unicode < 0xa1)
		nRet = unicode;
	else
	{
		BrCHAR pOutput[3] = {0,};				
		BrWideCharToMultiByte( CP_KSC5601, (BrLPCWSTR)&unicode, 1, (BrLPSTR)pOutput, sizeof(pOutput) );
		if (pOutput[0] != 0)  
		{
			if (pOutput[1])
				nRet = ((pOutput[0] << 8) & 0xff00) | (pOutput[1] & 0xff);
			else
				nRet = pOutput[0];
		}
	}

	return nRet;
}

int CUtil::WideCharToMultiByte( BrUINT CodePage,  BrDWORD dwFlags,  BrLPCWSTR lpWideCharStr,   int cchWideChar,  BrLPSTR lpMultiByteStr,   int cbMultiByte,  BrLPCSTR lpDefaultChar,  BrBOOL* lpUsedDefaultChar )
{
	// cchWideChar가 0 로 끝나면  cchWideChar는 -1이 될 수 있다. 이때 와이드쪽이 0까지 포함하므로 리턴하는 값은 0까지 포함하는 갯수이다.
	// 또 이때 lpMultiByteStr에 값을 넣는다면 이값에도 0가 포함될 것이다.
	// cbMultiByte = 0 일때 lpMultiByteStr는 무시되며 리턴값은 멀티 바이트로 만들어지는 멀티 바이트의 바이트 갯수이다. cchWideChar==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	int mi =  0;
	BrWCHAR* pp = (BrWCHAR*) lpWideCharStr;

	BrWCHAR wideChar = 0;
	BrWCHAR bb = 0;

	if( cchWideChar < -1 || cchWideChar == 0 )
		return 0;

	if( CodePage == 949 || CodePage == 51949 /*|| CodePage == 0*/ )
	{
		// 국내향 노말폰 코드 변환 함수에서 메모리 덮어쓰는 문제가 발생하여 막음
		//		mi = BrConvertToMultiByte((BrUSHORT *)lpWideCharStr, cbMultiByte, lpMultiByteStr);
		//		if (mi > 0)
		//			return mi;

		if( cbMultiByte == 0 )
		{   
			//필요한 갯수만 리턴 , lpMultiByteStr는 참고 하지 않는다.

			if( cchWideChar == -1 )
			{
				// \0 이 나올때 까지 계산

				while( 1 )
				{
					wideChar = *pp;
					pp++;

					if( wideChar ==0 )
					{
						mi++;
						return mi;
					}

					//					if( wideChar > 0xff )
					if (IsUniReadByte(wideChar))
						mi+=2;
					else
						mi++;
				}

				//여기는 절대 타지 않는다.
				return 0;

			}
			else
			{
				// 와이드에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 멀티는 갯수가 0이므로 와이드의갯수까지 계산해서 그 때까지의 멀티를 리턴하면 된다.

				BrWCHAR* pOut = (BrWCHAR*) lpWideCharStr + cchWideChar; //계산할 갯수 범위 밖에거 중에 ?번째.


				//cchWideChar 까지 게산
				while( pp  <  pOut  ) 
				{
					wideChar = *pp;
					pp++;

					//					if( wideChar > 0xff )
					if (IsUniReadByte(wideChar))						
						mi+=2;
					else
						mi++;
				}

				return mi; 
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrBYTE* pMulti = (BrBYTE*) lpMultiByteStr;

			if( cchWideChar == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 멀티 갯수이내로 해야 하므로 멀티 갯수를 초과하면 0을 리턴해 준다.
				// 이때 중간에 있는 \0은 한개의 멀티로 계산할 것.

				if( cbMultiByte < 0 || lpMultiByteStr==BrNULL ) return 0;		

				BrLPWSTR pOut = (BrLPWSTR) lpWideCharStr + cchWideChar; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrBYTE* pMultiOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //와이드의 범위 밖의 거 중에서 ?번째.

				// \0 이 나올때 까지 계산

				while( 1 )
				{
					wideChar = *pp;
					pp++;

					if( wideChar ==0 )
					{
						mi++;
						*pMulti = 0;
						return mi;
					}



					//					if( wideChar > 0xff )
					if (IsUniReadByte(wideChar))						
					{
						bb = UnicodeToKSC5601( wideChar );
						if( pMulti < pMultiOut-1 )
						{
							*pMulti = BrHIBYTE( bb );
							pMulti++;
							*pMulti = BrLOBYTE( bb) ;
							pMulti++;
							mi+=2;
						}
						else
							return 0;

					}
					else
					{
						if( pMulti < pMultiOut )
						{
							*pMulti = BrBYTE( wideChar );
							pMulti++;
							mi++;
						}
						else
							return 0;
					}
				}

				//여기는 절대 타지 않는다.
				return 0;

			}
			else
			{
				// 와이드에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 멀티는 갯수가 있으므로 멀티의 범위를 넘어 가는지 체크 해 준다. 넘어 가면 0을 리턴한다.

				BrWCHAR* pOut = (BrWCHAR*) lpWideCharStr + cchWideChar; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrBYTE* pOutMulti = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.

				if( cbMultiByte < 0 || lpMultiByteStr==BrNULL ) return 0;	

				//cchWideChar 까지 게산
				while( pp  <  pOut  ) 
				{
					wideChar = *pp;
					pp++;



					//					if( wideChar > 0xff )
					if (IsUniReadByte(wideChar))						
					{
						bb = UnicodeToKSC5601( wideChar );
						if( pMulti < pOutMulti-1 )
						{
							*pMulti = BrHIBYTE( bb );
							if( *pMulti ==0  )
								*pMulti = (BrBYTE)'?';	
							pMulti++;
							*pMulti = BrLOBYTE( bb) ;
							if( *pMulti ==0  )
								*pMulti = (BrBYTE)'?';	
							pMulti++;
							mi+=2;
						}
						else
							return 0;

					}
					else
					{
						if( pMulti < pOutMulti )
						{
							*pMulti = BrBYTE( wideChar );
							pMulti++;
							mi++;
						}
						else
							return 0;
					}

				}

				return mi; 
			}


		}
	}
	else if( CodePage == CP_UTF8 )
	{
		mi = WideCharToMultiByte_UTF8( CodePage,  dwFlags,  lpWideCharStr,   cchWideChar,  lpMultiByteStr,  cbMultiByte, lpDefaultChar, lpUsedDefaultChar );
	}
	else
	{
#ifdef ANDROID_PLATFORM
		if( CodePage == CP_ACP )
		{
			mi = WideCharToMultiByte_UTF8( CP_UTF8,  dwFlags,  lpWideCharStr,   cchWideChar,  lpMultiByteStr,  cbMultiByte, lpDefaultChar, lpUsedDefaultChar );
			return mi;
		}
#endif
		mi = BrWideCharToMultiByte( CodePage, (BrLPCWSTR)lpWideCharStr, cchWideChar, (BrLPSTR)lpMultiByteStr, cbMultiByte );
	}

	return mi;
}

int CUtil::WideCharToMultiByte_UTF8( BrUINT CodePage,  BrDWORD dwFlags,  BrLPCWSTR lpWideCharStr,   int cchWideChar,  BrLPSTR lpMultiByteStr,   int cbMultiByte,  BrLPCSTR lpDefaultChar,  BrBOOL* lpUsedDefaultChar )
{
	// cchWideChar가 0 로 끝나면  cchWideChar는 -1이 될 수 있다. 이때 와이드쪽이 0까지 포함하므로 리턴하는 값은 0까지 포함하는 갯수이다.
	// 또 이때 lpMultiByteStr에 값을 넣는다면 이값에도 0가 포함될 것이다.
	// cbMultiByte = 0 일때 lpMultiByteStr는 무시되며 리턴값은 멀티 바이트로 만들어지는 멀티 바이트의 바이트 갯수이다. cchWideChar==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	int mi =  0;
	BrWCHAR* pp = (BrWCHAR*) lpWideCharStr;

	BrWCHAR wideChar = 0;
	BrWCHAR bb = 0;

	BrBYTE ch[4];



	if( cchWideChar < -1 || cchWideChar == 0 )
		return 0;

	if( cbMultiByte == 0 )
	{   
		//필요한 갯수만 리턴 , lpMultiByteStr는 참고 하지 않는다.

		if( cchWideChar == -1 )
		{
			// \0 이 나올때 까지 계산
			while( 1 )
			{
				wideChar = *pp;
				pp++;

				if(  wideChar == 0 )
				{
					mi++;
					return mi;
				}
				else if( wideChar < 0x80 )
				{
					mi++;
				}
				else if( wideChar < 0x800 )
				{
					mi+=2;
				}
				else if( wideChar < 0x10000 )
				{
					mi+=3;
				}
				else
				{
					//4바이트 문자 이다.
					mi+=4;
				}
			}

			//여기는 절대 타지 않는다.
			return 0;

		}
		else
		{
			// 와이드에 갯수가 있어서 그 갯수까지 계산한다.
			// 근데 멀티는 갯수가 0이므로 와이드의갯수까지 계산해서 그 때까지의 멀티를 리턴하면 된다.

			BrWCHAR* pOut = (BrWCHAR*) lpWideCharStr + cchWideChar; //계산할 갯수 범위 밖에거 중에 ?번째.


			//cchWideChar 까지 게산
			while( pp  <  pOut  ) 
			{
				wideChar = *pp;
				pp++;

				if(  wideChar == 0 )
				{
					mi++;
				}
				else if( wideChar < 0x80 )
				{
					mi++;
				}
				else if( wideChar < 0x800 )
				{
					mi+=2;
				}
				else if( wideChar < 0x10000 )
				{
					mi+=3;
				}
				else
				{
					//4바이트 문자 이다.
					mi+=4;
				}
			}

			return mi; 
		}

	}
	else  
	{
		//이부분은 값을 V팅하는 부분

		BrBYTE* pMulti = (BrBYTE*) lpMultiByteStr;

		if( cchWideChar == -1 )
		{
			// \0 이 나올때 까지 계산하여 V팅.

			// 근데 멀티 갯수이내로 해야 하므로 멀티 갯수를 초과하면 0을 리턴해 준다.
			// 이때 중간에 있는 \0은 한개의 멀티로 계산할 것.

			if( cbMultiByte < 0 || lpMultiByteStr==BrNULL )
				return 0;		

			BrLPWSTR pOut = (BrLPWSTR) lpWideCharStr + cchWideChar; //계산할 갯수 범위 밖에거 중에 ?번째.
			BrBYTE* pMultiOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //와이드의 범위 밖의 거 중에서 ?번째.

			// \0 이 나올때 까지 계산

			while( 1 )
			{
				wideChar = *pp;
				pp++;

				if( wideChar ==0 )
				{
					mi++;
					*pMulti = 0;
					return mi;
				}
				else if( wideChar < 0x80 )
				{
					*pMulti=(BYTE)wideChar;
					pMulti++;
					mi++;
				}
				else if( wideChar < 0x800 )
				{
					if( pMulti+2 > pMultiOut )
						return 0;

					ch[1] =  (BrBYTE)( wideChar & 0x3f );
					ch[1] += 0x80;
					wideChar = wideChar / 0x40;

					ch[0] = (BYTE)wideChar;
					ch[0] += 0xc0;

					*pMulti = ch[0];
					pMulti++;
					*pMulti = ch[1];
					pMulti++;

					mi+=2;
				}
				else if( wideChar < 0x10000 )
				{
					if( pMulti+3 > pMultiOut )
						return 0;

					ch[2] = (BrBYTE)( wideChar & 0x3f );
					ch[2] += 0x80;
					wideChar = wideChar/0x40;

					ch[1] = (BrBYTE)( wideChar & 0x3f );
					ch[1] += 0x80;
					wideChar = wideChar/0x40;

					ch[0] = (BYTE)wideChar;
					ch[0] += 0xe0;

					*pMulti = ch[0];
					pMulti++;
					*pMulti = ch[1];
					pMulti++;
					*pMulti = ch[2];
					pMulti++;

					mi+=3;
				}
				else
				{
					if( pMulti+4 > pMultiOut )
						return 0;

					//4바이트 문자 이다.
					ch[3] = (BrBYTE)( wideChar & 0x3f);
					ch[3] += 0x80;
					wideChar = wideChar/0x40;

					ch[2] = (BrBYTE)( wideChar & 0x3f);
					ch[2] += 0x80;
					wideChar = wideChar/0x40;

					ch[1] = (BrBYTE)( wideChar & 0x3f);
					ch[1] += 0x80;
					wideChar = wideChar/0x40;

					ch[0] = (BYTE)wideChar;
					ch[0] += 0xf0;

					*pMulti = ch[0];
					pMulti++;
					*pMulti = ch[1];
					pMulti++;
					*pMulti = ch[2];
					pMulti++;
					*pMulti = ch[2];
					pMulti++;

					mi+=4;
				}

				if( pMulti == pMultiOut )
					return 0;
			}

			//여기는 절대 타지 않습니다.
			return 0;
		}
		else
		{
			// 와이드에 갯수가 있어서 그 갯수까지 계산한다.
			// 근데 멀티는 갯수가 있으므로 멀티의 범위를 넘어 가는지 체크 해 준다. 넘어 가면 0을 리턴한다.

			BrWCHAR* pOut = (BrWCHAR*) lpWideCharStr + cchWideChar; //계산할 갯수 범위 밖에거 중에 ?번째.
			BrBYTE* pMultiOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.

			if( cbMultiByte < 0 || lpMultiByteStr==BrNULL ) return 0;	

			//cchWideChar 까지 게산
			while( pp  <  pOut  ) 
			{
				wideChar = *pp;
				pp++;

				if( wideChar ==0 )
				{
					mi++;
					*pMulti = 0;
					pMulti++;
				}
				else if( wideChar < 0x80 )
				{
					*pMulti=(BYTE)wideChar;
					pMulti++;
					mi++;
				}
				else if( wideChar < 0x800 )
				{
					if( pMulti+2 > pMultiOut )
						return 0;

					ch[1] =  (BrBYTE)( wideChar & 0x3f );
					ch[1] += 0x80;
					wideChar = wideChar / 0x40;

					ch[0] = (BYTE)wideChar;
					ch[0] += 0xc0;

					*pMulti = ch[0];
					pMulti++;
					*pMulti = ch[1];
					pMulti++;

					mi+=2;
				}
				else if( wideChar < 0x10000 )
				{
					if( pMulti+3 > pMultiOut )
						return 0;

					ch[2] = (BrBYTE)( wideChar & 0x3f );
					ch[2] += 0x80;
					wideChar = wideChar/0x40;

					ch[1] = (BrBYTE)( wideChar & 0x3f );
					ch[1] += 0x80;
					wideChar = wideChar/0x40;

					ch[0] = (BrBYTE)wideChar;
					ch[0] += 0xe0;

					*pMulti = ch[0];
					pMulti++;
					*pMulti = ch[1];
					pMulti++;
					*pMulti = ch[2];
					pMulti++;

					mi+=3;
				}
				else
				{
					if( pMulti+4 > pMultiOut )
						return 0;

					//4바이트 문자 이다.
					ch[3] = (BrBYTE)( wideChar & 0x3f);
					ch[3] += 0x80;
					wideChar = wideChar/0x40;

					ch[2] = (BrBYTE)( wideChar & 0x3f);
					ch[2] += 0x80;
					wideChar = wideChar/0x40;

					ch[1] = (BrBYTE)( wideChar & 0x3f);
					ch[1] += 0x80;
					wideChar = wideChar/0x40;

					ch[0] = (BYTE)wideChar;
					ch[0] += 0xf0;

					*pMulti = ch[0];
					pMulti++;
					*pMulti = ch[1];
					pMulti++;
					*pMulti = ch[2];
					pMulti++;
					*pMulti = ch[2];
					pMulti++;

					mi+=4;
				}

				if( pMulti == pMultiOut && pp  <  pOut  )
					return 0;
			}

			return mi; 
		}
	}

	return mi;
}

int CUtil::MultiByteToWideChar( BrUINT CodePage  , BrDWORD dwFlag, BrLPCSTR  lpMultiByteStr , int cbMultiByte , BrLPWSTR lpWideStr , int cchWideChar )
{
	//설명 lpMultiByteStr가 \0 로 끝나면  cbMultiByte는 -1이 될 수 있다. 이때 멀티쪽이 \0까지 포함하므로 리턴하는 값은 \0까지 포함하는 갯수이다.
	//또 이때 lpWideStr에 값을 넣는다면 이값에도 \0가 포함될 것이다.
	//     cchWideChar = 0 일때 lpWideStr는 무시되며 리턴값은 와이드로 만들어 지는 와이드의 갯수이다. cbMultiByte==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	//멀티 바이트의 마지막이 리드바이트로 끝나는 경우는 마지막 리드 바이트는 \0으로 새석하며 그 \0으로 해석한 바이트늘 한개의 와이드 바이트로 해석하여 리턴 갯수에 포함시킨다. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

	//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;

	if( CodePage == 949 || CodePage == 51949 || CodePage == 0 )
	{
		wi = BrMultiByteToWideChar( CodePage, (BrLPCSTR)lpMultiByteStr, cbMultiByte, (BrLPWSTR)lpWideStr, cchWideChar);
		if (wi > 0)			return wi;

		if( cchWideChar == 0 )
		{   
			//필요한 갯수만 리턴 , lpWideStr는 참고 하지 않는다.

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산. 또는 Tail byte가 0일때 까지 처리 한다.

				while( 1 )//mi < cbMultiByte && wi < cchWideChar )
				{
					b = *p;
					p++;

					if( IsDBCSLeadByte( b , *p ) )
					{
						b2 = *p; 
						p++;

						if( b2==0 )
						{
							wi++;
							return wi;
						}
					}
					else
					{
						if( b==0 )
						{
							wi++;
							return wi;
						}
					}
					wi++;
				}

				//여기는 절대 타지 않는다.
				return 0;

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 0이므로 멀티 까지 계산해서 그 와이드의 갯수를 리턴하면 된다. 
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.


				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut - 1  ) // 마지막 바이트는 여기서 제외.
				{
					b = *p;
					p++;

					if( IsDBCSLeadByte( b , *p ) )
					{
						p++;
					}
					wi++;
				}

				// p는  범위의 마지막 이거나.. 범위를 하나 벗어난 것중의 하나.
				if( p < pOut )
				{
					// 범위의 마지막. 마지막이 \0이던 그렇지 않던간에 +1을 해서 리턴.
					wi++;
					return wi;
				}
				else
				{
					//범위를 벗어난 상황 , 지금까지 구한값 리턴
					return wi; 
				}
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				while( 1 ) 
				{
					b = *p;
					p++;

					if( IsDBCSLeadByte( b , *p ) )
					{
						b2 = *p;
						p++;
						if( b2 ==0 )//트레일이 0이네요.
						{
							wideChar = 0;
						}
						else
						{
							wideChar =  (BrWCHAR) KSC5601ToUnicode( BrMAKEWORD( b2 , b ) );
							if ( wideChar==0 )	
								wideChar = ' ';
						}
					}
					else
					{
						wideChar = (BrWCHAR) b;
					}

					if( pw < pWideOut )
						*pw = wideChar;
					else
						return 0;

					pw++;
					wi++;

					if( wideChar ==0 )
					{
						return wi;
					}

				}


				//여기는 절대 타지 않는다.
				return 0;

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut - 1  ) // 마지막 바이트는 여기서 제외.
				{
					b = *p;
					p++;

					if( IsDBCSLeadByte( b , *p ) )
					{
						b2 = *p;
						p++;
						if( b2 ==0 )//트레일이 0이네요.
						{
							wideChar = 0;
						}
						else
						{
							wideChar =  (BrWCHAR) KSC5601ToUnicode( BrMAKEWORD( b2 , b ) );
							if ( wideChar==0 )
								wideChar = ' ';
						}
					}
					else
					{
						wideChar = (BrWCHAR) b;
					}

					if( pw < pWideOut )
						*pw = wideChar;
					else
						return 0;

					pw++;
					wi++;

				}

				// p는  범위의 마지막 이거나.. 범위를 하나 벗어난 것중의 하나.
				if( p < pOut )
				{
					//범의의 마지막.
					if( pw < pWideOut )
					{
						b = *p;
						if( IsDBCSLeadByte( b , *(p+1) ) )
							*pw = 0;
						else
							*pw = (BrWCHAR) b;

						wi++;
						return wi;
					}
					else
					{
						return 0;
					}
				}
				else
				{
					//범위를 벗어난 상황 , 지금까지 구한값 리턴
					return wi;
				}

			}
		}
	}
	else if( CodePage == CP_UTF8 )
	{
		return MultiByteToWideChar_UTF8( lpMultiByteStr , cbMultiByte , lpWideStr , cchWideChar );
	}
	else if( CodePage == 28591 ) //iso_8859-1
	{
		return MultiByteToWideChar_ISO8859_1( lpMultiByteStr , cbMultiByte , lpWideStr , cchWideChar );
	}
	else if( CodePage == 1252 || CodePage == 20127 )		// 2008.8.14
	{
		return MultiByteToWideChar_1252( lpMultiByteStr , cbMultiByte , lpWideStr , cchWideChar );
	}
	else if( CodePage == 1251 )
	{
		return MultiByteToWideChar_1251( lpMultiByteStr , cbMultiByte , lpWideStr , cchWideChar );
	}
	else if( CodePage ==  1201 ) // BigEndian UNICODE FE FF
	{
		return MultiByteToWideChar_1201( lpMultiByteStr , cbMultiByte , lpWideStr , cchWideChar );
	}
	else
	{
		return BrMultiByteToWideChar( CodePage, (BrLPCSTR)lpMultiByteStr, cbMultiByte, (BrLPWSTR)lpWideStr, cchWideChar);
	}

	return wi;
}

int CUtil::MultiByteToWideChar_UTF8(  BrLPCSTR  lpMultiByteStr , int cbMultiByte , BrLPWSTR lpWideStr , int cchWideChar )
{
	return BoraMultiByteToWideChar_UTF8(lpMultiByteStr , cbMultiByte , lpWideStr , cchWideChar );

	//아래 내용을 BoraMultiByteToWideChar_UTF8로 옮김.
	//Html 을 안쓰는 경우에 이 파일을 안써서 문제됨.
#if 0
	//설명 lpMultiByteStr가 \0 로 끝나면  cbMultiByte는 -1이 될 수 있다. 이때 멀티쪽이 \0까지 포함하므로 리턴하는 값은 \0까지 포함하는 갯수이다.
	//또 이때 lpWideStr에 값을 넣는다면 이값에도 \0가 포함될 것이다.
	//     cchWideChar = 0 일때 lpWideStr는 무시되며 리턴값은 와이드로 만들어 지는 와이드의 갯수이다. cbMultiByte==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	//멀티 바이트의 마지막이 리드바이트로 끝나는 경우는 마지막 리드 바이트는 \0으로 새석하며 그 \0으로 해석한 바이트늘 한개의 와이드 바이트로 해석하여 리턴 갯수에 포함시킨다. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

	//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;


	{
		if( cchWideChar == 0 )
		{
			//필요한 갯수만 리턴 , lpWideStr는 참고 하지 않는다.

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산. 또는 Tail byte가 0일때 까지 처리 한다.
				while( 1 ) 
				{
					b = *p;

					if( b < 0x80 )
					{
						p++;
					}
					else if( b < 0xe0 )
					{
						p++;
						if( *p == 0 )
						{
							p++;
						}
						else
						{
							p++;
						}
					}
					else if( b < 0xf0 )
					{
						p++;
						if( *p == 0 )
						{
							p++;
							p++;
						}
						else
						{
							p++;
							if( *p == 0 )
							{
								p++;
							}
							else
							{
								p++;
							}
						}
					}
					else if( b < 0xf8 )
					{

						p++;
						if( *p == 0 )
						{
							p++;
							p++;
							p++;
						}
						else
						{
							p++;
							if( *p == 0 )
							{
								p++;
								p++;
							}
							else
							{
								p++;
								if( *p == 0 )
								{
									p++;
								}
								else
								{
									p++;
									wi++;
								}
							}
						}

					}
					else
					{
						//유니코드 범위를 넘어 서는 값이 들어 왔습니다.
						return 0;
					}

					wi++;

					if( b == 0 )
						return wi;
				}

				//여기는 절대 타지 않는다.
				return 0;

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 0이므로 멀티 까지 계산해서 그 와이드의 갯수를 리턴하면 된다. 
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.


				//멀티 바이트 갯수까지 계산을 함.
				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut ) //마지막 바이트 까지 계산.
				{

					b = *p;

					if( b < 0x80 )
					{
						p++;
					}
					else if( b < 0xe0 )
					{

						p++;

						if( p == pOut )
						{
							;
						}
						else
						{
							p++;
						}
					}
					else if( b < 0xf0 )
					{
						p++;
						if( p == pOut )
						{
							;
						}
						else
						{
							p++;
							if( p == pOut )
							{
								;
							}
							else
							{
								p++;
							}
						}
					}
					else if( b < 0xf8 )
					{
						p++;
						if( p == pOut )
						{
							;
						}
						else
						{
							p++;
							if( p == pOut )
							{
								;
							}
							else
							{
								p++;
								if( p == pOut )
								{
									;
								}
								else
								{
									p++;
									wi++;
								}
							}
						}

					}
					else
					{
						//유니코드 범위를 넘어 서는 값이 들어 왔습니다.
						return 0;
					}

					wi++;
				}

				return wi;
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;

			BYTE  utf[4];

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.

				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				// \0이 나올때 까지 계산.
				while( 1 ) 
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					if( b < 0x80 )
					{
						*pw = b;
						p++;
					}
					else if( b < 0xe0 )
					{

						utf[0] =( *p & 0x1f );
						p++;

						if( *p == 0 )
						{
							p++;
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f );
							p++;
							*pw =  utf[0]*0x40;
							*pw += utf[1];
						}
					}
					else if( b < 0xf0 )
					{
						utf[0] =( *p & 0x0f );
						p++;
						if( *p == 0 )
						{
							p++;
							p++;
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( *p == 0 )
							{
								p++;
								*pw = 0;
							}
							else
							{
								utf[2] =( *p & 0x3f );  
								p++;

								*pw =  utf[0] * 0x1000;
								*pw += utf[1] * 0x40;
								*pw += utf[2];
							}
						}
					}
					else if( b < 0xf8 )
					{

						utf[0] =( *p & 0x07 );
						p++;
						if( *p == 0 )
						{
							p++;
							p++;
							p++;
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( *p == 0 )
							{
								p++;
								p++;
								*pw = 0;
							}
							else
							{
								utf[2] =( *p & 0x3f ); 
								p++;
								if( *p == 0 )
								{
									p++;
									*pw = 0;
								}
								else
								{
									utf[3] =( *p & 0x3f ); 
									p++;

									//먼저 값을 구한다.
									BrDWORD dword;
									dword = utf[0] * 0x40000;
									dword += utf[1]* 0x1000;
									dword += utf[2]* 0x40;
									dword += utf[3];

									BrDWORD pair = dword - 0x10000;

									BrWORD pl= (BrWORD)(pair & 0x3ff); //하위 10bit
									BrWORD ph= (BrWORD)(pair / 0x400); //상위 10bit

									BrWORD uh = ph | 0xd800;
									BrWORD ul = pl | 0xdc00; 

									// 파일 상에서의 순서는 uh ul 
									// 바이트 단위까지 한다면  uh-lowbyte , uh-highbyte , ul-lowbyte , ul-highbyte 순서로 파일에 저장 됨

									*pw = uh;
									pw++;
									if( pw == pWideOut )
									{
										return 0;
									}
									else
									{
										*pw = ul;
									}
								}
							}
						}

					}
					else
					{
						//유니코드 범위를 넘어 서는 값이 들어 왔습니다.
						return 0;
					}

					pw++;

					if( b == 0 )
						return ( pw - lpWideStr );
				}

				return 0; //여기는 안탄다.

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut ) //마지막 바이트 까지 계산.
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					if( b < 0x80 )
					{
						*pw = b;
						p++;
					}
					else if( b < 0xe0 )
					{

						utf[0] =( *p & 0x1f );
						p++;

						if( p == pOut )
						{
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f );
							p++;
							*pw =  utf[0]*0x40;
							*pw += utf[1];
						}
					}
					else if( b < 0xf0 )
					{
						utf[0] =( *p & 0x0f );
						p++;
						if( p == pOut )
						{
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( p == pOut )
							{
								*pw = 0;
							}
							else
							{
								utf[2] =( *p & 0x3f );  
								p++;

								*pw =  utf[0] * 0x1000;
								*pw += utf[1] * 0x40;
								*pw += utf[2];
							}
						}
					}
					else if( b < 0xf8 )
					{

						utf[0] =( *p & 0x07 );
						p++;
						if( p == pOut )
						{
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( p == pOut )
							{
								*pw = 0;
							}
							else
							{

								utf[2] =( *p & 0x3f ); 
								p++;
								if( p == pOut )
								{
									*pw = 0;
								}
								else
								{
									utf[3] =( *p & 0x3f ); 
									p++;

									//먼저 값을 구한다.
									BrDWORD dword;
									dword = utf[0] * 0x40000;
									dword += utf[1]* 0x1000;
									dword += utf[2]* 0x40;
									dword += utf[3];

									BrDWORD pair = dword - 0x10000;

									BrWORD pl= (BrWORD)(pair & 0x3ff); //하위 10bit
									BrWORD ph= (BrWORD)(pair / 0x400); //상위 10bit

									BrWORD uh = ph | 0xd800;
									BrWORD ul = pl | 0xdc00; 

									// 파일 상에서의 순서는 uh ul 
									// 바이트 단위까지 한다면  uh-lowbyte , uh-highbyte , ul-lowbyte , ul-highbyte 순서로 파일에 저장 됨

									*pw = uh;
									pw++;
									if( pw == pWideOut )
									{
										return 0;
									}
									else
									{
										*pw = ul;
									}
								}
							}
						}

					}
					else
					{
						//유니코드 범위를 넘어 서는 값이 들어 왔습니다.
						return 0;
					}

					pw++;
				}

				return ( pw - lpWideStr );

			}
		}

		return 0; //여기는 안탄다.
	}

	return wi;

#endif //0
}

int CUtil::MultiByteToWideChar_ISO8859_1(  BrLPCSTR  lpMultiByteStr , int cbMultiByte , BrLPWSTR lpWideStr , int cchWideChar )
{
	// iso_8859-1
	//ANSI 코드 V이라고 가정하자.
	// 글자 값은 Code values 00~1F, 7F, and 80~9F are not assigned to characters by ISO/IEC 8859-1.

	//설명 lpMultiByteStr가 \0 로 끝나면  cbMultiByte는 -1이 될 수 있다. 이때 멀티쪽이 \0까지 포함하므로 리턴하는 값은 \0까지 포함하는 갯수이다.
	//또 이때 lpWideStr에 값을 넣는다면 이값에도 \0가 포함될 것이다.
	//     cchWideChar = 0 일때 lpWideStr는 무시되며 리턴값은 와이드로 만들어 지는 와이드의 갯수이다. cbMultiByte==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	//멀티 바이트의 마지막이 리드바이트로 끝나는 경우는 마지막 리드 바이트는 \0으로 새석하며 그 \0으로 해석한 바이트늘 한개의 와이드 바이트로 해석하여 리턴 갯수에 포함시킨다. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

	//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;


	{
		if( cchWideChar == 0 )
		{
			//필요한 갯수만 리턴 , lpWideStr는 참고 하지 않는다.

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산. 또는 Tail byte가 0일때 까지 처리 한다.
				while( *p++ ) 
				{
					wi++;
				}

				return wi;
			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 0이므로 멀티 까지 계산해서 그 와이드의 갯수를 리턴하면 된다. 
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				return cbMultiByte;
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.

				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				// \0이 나올때 까지 계산.
				while( 1 ) 
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					*pw = b;
					pw++;
					p++;

					if( b == 0 )
						return (BrINT32)( pw - lpWideStr );
				}

				return 0; //여기는 안탄다.

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut ) //마지막 바이트 까지 계산.
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					*pw = b;
					p++;
					pw++;
				}

				return (BrINT32)( pw - lpWideStr );
			}
		}

		return 0; //여기는 안탄다.
	}

	return wi;
}

int CUtil::MultiByteToWideChar_1252(  BrLPCSTR  lpMultiByteStr , int cbMultiByte , BrLPWSTR lpWideStr , int cchWideChar )
{
	// 1252 charset
	// ANSI 코드 V이라고 가정하자.
	//무조건 1바이트를 2바이트 문자로 변환.

	//설명 lpMultiByteStr가 \0 로 끝나면  cbMultiByte는 -1이 될 수 있다. 이때 멀티쪽이 \0까지 포함하므로 리턴하는 값은 \0까지 포함하는 갯수이다.
	//또 이때 lpWideStr에 값을 넣는다면 이값에도 \0가 포함될 것이다.
	//     cchWideChar = 0 일때 lpWideStr는 무시되며 리턴값은 와이드로 만들어 지는 와이드의 갯수이다. cbMultiByte==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	//멀티 바이트의 마지막이 리드바이트로 끝나는 경우는 마지막 리드 바이트는 \0으로 새석하며 그 \0으로 해석한 바이트늘 한개의 와이드 바이트로 해석하여 리턴 갯수에 포함시킨다. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

	//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;


	{
		if( cchWideChar == 0 )
		{
			//필요한 갯수만 리턴 , lpWideStr는 참고 하지 않는다.

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산. 또는 Tail byte가 0일때 까지 처리 한다.
				while( *p++ ) 
				{
					wi++;
				}

				return wi;
			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 0이므로 멀티 까지 계산해서 그 와이드의 갯수를 리턴하면 된다. 
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				return cbMultiByte;
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.

				// 이때 중간에 있는 \0은 한개의 와이드로 계산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				// \0이 나올때 까지 계산.
				while( 1 ) 
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					*pw = b;
					pw++;
					p++;

					if( b == 0 )
						return (BrINT32)( pw - lpWideStr );
				}

				return 0; //여기는 안탄다.

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut ) //마지막 바이트 까지 계산.
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					*pw = b;
					p++;
					pw++;
				}

				return (BrINT32)( pw - lpWideStr );
			}
		}

		return 0; //여기는 안탄다.
	}

	return wi;
}

const BrWORD Windows1251CodeTable[256] = {
	0x00, 0x01, 0x02, 0x03, 0x04 ,0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F
	, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F
	, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F
	, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F
	, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F
	, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F
	, 0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F
	, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F
	, 0x00402,0x00403,0x00201A,0x00453,0x00201E, 0x002026, 0x002020, 0x002021
	, 0x0020AC, 0x002030, 0x00409, 0x002039, 0x0040A, 0x0040C, 0x0040B, 0x0040F //
	, 0x00452,0x002018,0x002019,0x00201C,0x00201D, 0x002022, 0x002013, 0x002014
	, 0x0020, 0x002122, 0x00459, 0x00203A, 0x0045A, 0x0045C, 0x0045B, 0x0045F //
	, 0x00A0,0x0040E,0x0045E, 0x00408, 0x00A4,0x00490, 0x00A6, 0x00A7, 0x00401
	, 0x00A9, 0x00404, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x00407 //
	, 0x00B0,0x00B1,0x00406, 0x00456, 0x00491,0x00B5, 0x00B6, 0x00B7
	, 0x00451	, 0x002116, 0x00454, 0x00BB, 0x00458, 0x00405, 0x00455, 0x00457 //
	, 0x00410,0x00411,0x00412,0x00413,0x00414,0x00415, 0x00416, 0x00417
	, 0x00418	, 0x00419, 0x0041A, 0x0041B, 0x0041C, 0x0041D, 0x0041E, 0x0041F
	, 0x00420,0x00421,0x00422,0x00423,0x00424,0x00425, 0x00426, 0x00427
	, 0x00428, 0x00429, 0x0042A, 0x0042B, 0x0042C, 0x0042D, 0x0042E, 0x0042F
	, 0x00430,0x00431,0x00432,0x00433,0x00434,0x00435, 0x00436, 0x00437
	, 0x00438, 0x00439, 0x0043A, 0x0043B, 0x0043C, 0x0043D, 0x0043E, 0x0043F
	, 0x00440,0x00441,0x00442,0x00443,0x00444,0x00445, 0x00446, 0x00447
	, 0x00448, 0x00449, 0x0044A, 0x0044B, 0x0044C, 0x0044D, 0x0044E, 0x0044F 
}; // 0x98에 해당하는 글자는 없다. 그러나 스페이스로 치환한다.

int CUtil::MultiByteToWideChar_1251(  BrLPCSTR  lpMultiByteStr , int cbMultiByte , BrLPWSTR lpWideStr , int cchWideChar )
{
	// 1251 charset
	// 위의 코드표.
	//무조건 1바이트를 2바이트 문자로 변환.

	//설명 lpMultiByteStr가 \0 로 끝나면  cbMultiByte는 -1이 될 수 있다. 이때 멀티쪽이 \0까지 포함하므로 리턴하는 값은 \0까지 포함하는 갯수이다.
	//또 이때 lpWideStr에 값을 넣는다면 이값에도 \0가 포함될 것이다.
	//     cchWideChar = 0 일때 lpWideStr는 무시되며 리턴값은 와이드로 만들어 지는 와이드의 갯수이다. cbMultiByte==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	//멀티 바이트의 마지막이 리드바이트로 끝나는 경우는 마지막 리드 바이트는 \0으로 새석하며 그 \0으로 해석한 바이트늘 한개의 와이드 바이트로 해석하여 리턴 갯수에 포함시킨다. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

	//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;


	{
		if( cchWideChar == 0 )
		{
			//필요한 갯수만 리턴 , lpWideStr는 참고 하지 않는다.

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산. 또는 Tail byte가 0일때 까지 처리 한다.
				while( *p++ ) 
				{
					wi++;
				}

				return wi;
			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 0이므로 멀티 까지 계산해서 그 와이드의 갯수를 리턴하면 된다. 
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				return cbMultiByte;
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;

			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.

				// 이때 중간에 있는 \0은 한개의 와이드로 계산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				// \0이 나올때 까지 계산.
				while( 1 ) 
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					*pw = Windows1251CodeTable[b];
					pw++;
					p++;

					if( b == 0 )
						return (BrINT32)( pw - lpWideStr );
				}

				return 0; //여기는 안탄다.

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut ) //마지막 바이트 까지 계산.
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					*pw = Windows1251CodeTable[b];
					p++;
					pw++;
				}

				return (BrINT32)( pw - lpWideStr );
			}
		}

		return 0; //여기는 안탄다.
	}

	return wi;
}


// BigEndian UNICODE
int CUtil::MultiByteToWideChar_1201(  BrLPCSTR  lpMultiByteStr , int cbMultiByte , BrLPWSTR lpWideStr , int cchWideChar )
{
	// 1251 charset
	// 위의 코드표.
	//무조건 1바이트를 2바이트 문자로 변환.

	//설명 lpMultiByteStr가 \0 로 끝나면  cbMultiByte는 -1이 될 수 있다. 이때 멀티쪽이 \0까지 포함하므로 리턴하는 값은 \0까지 포함하는 갯수이다.
	//또 이때 lpWideStr에 값을 넣는다면 이값에도 \0가 포함될 것이다.
	//     cchWideChar = 0 일때 lpWideStr는 무시되며 리턴값은 와이드로 만들어 지는 와이드의 갯수이다. cbMultiByte==-1이면 0도 포함

	// 메모리 영역이 작거나 하면 0을 리턴해야 한다.

	//멀티 바이트의 마지막이 리드바이트로 끝나는 경우는 마지막 리드 바이트는 \0으로 새석하며 그 \0으로 해석한 바이트늘 한개의 와이드 바이트로 해석하여 리턴 갯수에 포함시킨다. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

	//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;


	{
		if( cchWideChar == 0 )
		{
			//필요한 갯수만 리턴 , lpWideStr는 참고 하지 않는다.

			if( cbMultiByte == -1 )
			{
				BrLPWSTR pmw = (BrLPWSTR) lpMultiByteStr;
				// \0 이 나올때 까지 계산. 또는 Tail byte가 0일때 까지 처리 한다.
				while( *pmw++ ) 
				{
					wi++;
				}

				return wi;
			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 0이므로 멀티 까지 계산해서 그 와이드의 갯수를 리턴하면 된다. 
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				return (cbMultiByte+1)/2;
			}

		}
		else  
		{
			//이부분은 값을 V팅하는 부분

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;
			BrLPWSTR pmw = (BrLPWSTR) lpMultiByteStr;


			if( cbMultiByte == -1 )
			{
				// \0 이 나올때 까지 계산하여 V팅.

				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.

				// 이때 중간에 있는 \0은 한개의 와이드로 계산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				// \0이 나올때 까지 계산.
				while( 1 ) 
				{
					if( pw == pWideOut )
						return 0;

					*( (LPBYTE)pw ) = *( (LPBYTE)pmw+1 );
					*( (LPBYTE)pw+1 ) = *( (LPBYTE)pmw );

					if( *pw == 0 )
					{
						return (BrINT32)( pw - lpWideStr + 1 );
					}

					pw++;
					pmw++;
				}

				return 0; //여기는 안탄다.

			}
			else
			{
				// 멀티에 갯수가 있어서 그 갯수까지 계산한다.
				// 근데 와이드 갯수가 있으므로 와이드 갯수를 초과할 대 0 을 리턴해 버린다.
				// 이때 중간에 있는 \0은 한개의 와이드로 게산이 된다. tail byte가 0인 넘들의 경우 0으로 변환된다.

				if( cchWideChar < 0 || lpWideStr==BrNULL ) return 0;		

				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //계산할 갯수 범위 밖에거 중에 ?번째.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //와이드의 범위 밖의 거 중에서 ?번째.

				//멀티 바이트 갯수까지 계산을 함.
				while( p  <  pOut ) //마지막 바이트 까지 계산.
				{
					if( pw == pWideOut )
						return 0;

					if( p+1 == pOut )
					{//마지막 한바이트 처리.. 
						*pw = (BrWCHAR)*(p);
					}
					else
					{
						*( (LPBYTE)pw ) = *( (LPBYTE)pmw+1 );
						*( (LPBYTE)pw+1 ) = *( (LPBYTE)pmw );
					}

					p+=2;
					pmw++;
					pw++;
				}

				return (BrINT32)( pw - lpWideStr );
			}
		}

		return 0; //여기는 안탄다.
	}

	return wi;
}

BrWCHAR *CUtil::WcsNcpy( BrWCHAR *strDestination, const BrWCHAR *strSource , int count)
{
	BrWCHAR *p = strDestination;
	int len = count;
	while( len-- )
	{
		*p++ = *strSource++;
	}

	*p =0;
	return strDestination;
}

BrWCHAR *CUtil::WcsCpy( BrWCHAR *strDestination, const BrWCHAR *strSource )
{
	BrWCHAR *p = strDestination;
	int len = WcsLen( strSource );
	while( len-- )
	{
		*p++ = *strSource++;
	}

	*p =0;
	return strDestination;
}

BrINT CUtil::WcsCpyEx( BChar *strDestination, const BrWCHAR *strSource )
{
	BChar *p = strDestination;
	int len = WcsLen( strSource );
	int nStrLen = len;
	while( len-- )
	{
		*p++ = *strSource++;
	}
	*p =0;
	return nStrLen;
}

BrWCHAR *CUtil::WcsStr( const BrWCHAR *string, const BrWCHAR *strCharSet )
{
	BrWCHAR *cp = (BrWCHAR *) string;
	BrWCHAR *s1, *s2;

	if ( !*strCharSet)
		return (BrWCHAR *)string;

	while (*cp)
	{
		s1 = cp;
		s2 = (BrWCHAR *) strCharSet;

		while ( *s1 && *s2 && !(*s1-*s2) )
			s1++, s2++;

		if (!*s2)
			return(cp);

		cp++;
	}

	return BrNULL;
}

BrWCHAR *CUtil::WcsChr( const BrWCHAR *string, BrWCHAR ch )
{
	BrWCHAR *cp = (BrWCHAR *) string;

	while (*cp)
	{
		if( *cp == ch )
			return cp;
		cp++;
	}

	return BrNULL;
}

BrWCHAR *CUtil::WcsIStr( const BrWCHAR *string, const BrWCHAR *strCharSet )
{
	BrWCHAR *cp = (BrWCHAR *) string;
	BrWCHAR *s1, *s2;

	if ( !*strCharSet)
		return (BrWCHAR *)string;

	while (*cp)
	{
		s1 = cp;
		s2 = (BrWCHAR *) strCharSet;

		while ( *s1 && *s2 && (     !(*s1-*s2) || (IS_ALPHABET(*s1) && IS_ALPHABET(*s2) && ( *s1-*s2 ==0x20   || *s1-*s2 == -0x20 )   )    )  )
			s1++, s2++;

		if (!*s2)
			return(cp);

		cp++;
	}

	return BrNULL;
}
int CUtil::StrIcmp( const char *string1, const char *string2 )
{
	int f, l;

	do {
		if ( ((f = (unsigned char)(*(string1++))) >= 'A') &&
			(f <= 'Z') )
			f -= 'A' - 'a';
		if ( ((l = (unsigned char)(*(string2++))) >= 'A') &&
			(l <= 'Z') )
			l -= 'A' - 'a';
	} while ( f && (f == l) );

	return(f - l);
}

int CUtil::StrIcmp( const char *string1, BrLPCWSTR string2 )
{
	int f, l;

	do {
		if ( ((f = (unsigned char)(*(string1++))) >= 'A') &&
			(f <= 'Z') )
			f -= 'A' - 'a';
		if ( ((l = (BrWCHAR)(*(string2++))) >= 'A') &&
			(l <= 'Z') )
			l -= 'A' - 'a';
	} while ( f && (f == l) );

	return(f - l);
}

BrWCHAR *CUtil::WcsLwr( BrWCHAR *string )
{
	BrWCHAR* p = string;

	BrWCHAR c =0; 

	while( c = *p )
	{
		if( c > 0x40  && c < 0x5B )
		{
			*p = c + 0x20;
		}
		p++;
	}

	return string;
}


BrWCHAR *CUtil::WcsUpr( BrWCHAR *string )
{
	BrWCHAR* p = string;

	BrWCHAR c =0; 

	while( c = *p )
	{
		if( c > 0x60  && c < 0x7B )
		{
			*p = c - 0x20;
		}
		p++;
	}

	return string;
}
char *CUtil::StrLwr( char *string )
{
	char* p = string;

	char c =0; 

	while( c = *p )
	{
		if( IsDBCSLeadByte( *p , *(p+1)) )
		{
			p+=2;
		}
		else
		{
			if( c > 0x40  && c < 0x5B )
			{
				*p = c + 0x20;
			}

			p++;
		}
	}

	return string;
}

char *CUtil::StrUpr( char *string )
{
	char* p = string;

	char c =0; 

	while( c = *p )
	{
		if( IsDBCSLeadByte( *p , *(p+1) ) )
		{
			p+=2;
		}
		else
		{
			if( c > 0x61  && c < 0x7B )
			{
				*p = c - 0x20;
			}

			p++;
		}
	}

	return string;
}

BrWCHAR* CUtil::WcsPbrkA(BrWCHAR* szString , BrLPCSTR szCharSet)
{
	BrWCHAR* test = szString;

	BrLPSTR test2;

	while(*test)
	{
		test2 = (BrLPSTR) szCharSet;
		while( *test2 )
		{
			if( *test == *test2 )
				return test;

			test2++;
		}
		test++;
	}
	return BrNULL;
}


BrWCHAR* CUtil::WcsPbrk(BrWCHAR* szString , const BrWCHAR* szCharSet)
{
	BrWCHAR* test = szString;

	BrWCHAR* test2;

	while(*test)
	{
		test2 = (BrWCHAR*) szCharSet;
		while( *test2 )
		{
			if( *test == *test2 )
				return test;

			test2++;
		}
		test++;
	}
	return BrNULL;
}

unsigned int CUtil::WcsLen( const BrWCHAR	*string )
{
	if(!string || 0 == *string)
		return 0;

	BrWCHAR* p= (BrWCHAR*) string;
	while( *p++ );

	return (BrUINT)(BrVULONG)(p - string -1);
}

int CUtil::StrCmp(BrCHAR* pStr1, BrCHAR* pStr2)
{
	if (pStr1 == pStr2)	return 0;
	if (pStr1 == BrNULL)	return 1;
	if (pStr2 == BrNULL)	return -1;

	while (*pStr1 && *pStr1 == *pStr2)
	{
		pStr1++;
		pStr2++;
	}

	return *pStr1 - *pStr2;
}

int CUtil::WcsCmp(BrLPCWSTR string1, BrLPCWSTR string2 )
{
	int ret = 0 ;

	while( ! (ret = (int)(*string1 - *string2)) && *string2)
		++string1, ++string2;

	if ( ret < 0 )
		ret = -1 ;
	else if ( ret > 0 )
		ret = 1 ;

	return( ret );
}

int CUtil::WcsNCmp(BrLPCWSTR string1, BrLPCWSTR string2, int count)
{
	int ret = 0;

	int i = 0;
	while (i < count && (ret = (int)(*string1 - *string2)) == 0 && *string2 != 0)
	{
		++string1;
		++string2;
		i++;
	}

	if (ret < 0)
		ret = -1;
	else if (ret > 0)
		ret = 1;

	return(ret);
}

int CUtil::WcsCmpA( BrLPCWSTR string1, BrLPCSTR string2 )
{
	BrWCHAR ch1 , ch2;
	BrLPCWSTR p1 = string1;
	BrLPCSTR p2 = string2;
	while( 1 )
	{
		ch1 = *p1++;
		ch2 = *p2++;
		if( ch1 == ch2 )
		{
			if( ch1 == 0 )
			{
				return 0;
			}
			continue;
		}

		if( ch1 > ch2 )
			return 1;
		else
			return -1;
	}

	return -1;
}

int CUtil::strnCmp( BrLPCWSTR string1, BrLPCSTR string2, BrINT nCnt )
{
	BrWCHAR ch1 , ch2;
	BrLPCWSTR p1 = string1;
	BrLPCSTR p2 = string2;
	while( nCnt-->0 )
	{
		ch1 = *p1++;
		ch2 = *p2++;
		if( ch1 == ch2 )
		{
			if( nCnt==0 )
			{
				return 0;
			}
			continue;
		}

		if( ch1 > ch2 )
			return 1;
		else
			return -1;
	}

	return -1;
}

int CUtil::WcsICmp( BrLPCWSTR string1, BrLPCWSTR string2 )
{
	BrWCHAR ch1 , ch2;
	BrLPCWSTR p1 = string1;
	BrLPCWSTR p2 = string2;
	while( 1 )
	{
		ch1 = *p1++;
		if( ch1 > 0x40 && ch1 < 0x5B )
			ch1 += 0x20;
		ch2 = *p2++;
		if( ch2 > 0x40 && ch2 < 0x5B )
			ch2 += 0x20;

		if( ch1 == ch2 )
		{
			if( ch1 == 0 )
			{
				return 0;
			}
			continue;
		}

		if( ch1 > ch2 )
			return 1;
		else
			return -1;
	}

	return -1;
}

int CUtil::WcsNICmp(BrLPCWSTR string1, BrLPCWSTR string2, int n)
{
	BrUINT c1, c2;
	if (string1 == string2 || n == 0)
		return 0;
	do
	{
		c1 = (BrUINT)BrToLower(*string1++);
		c2 = (BrUINT)BrToLower(*string2++);
		if (c1 == L'\0' || c1 != c2)
			return c1 - c2;
	} while (--n > 0);

	return c1 - c2;
}

int CUtil::WcsICmpA( BrLPCWSTR string1, BrLPCSTR string2 )
{
	BrWCHAR ch1 , ch2;
	BrLPCWSTR p1 = string1;
	BrLPCSTR p2 = string2;
	while( 1 )
	{
		ch1 = *p1;
		if( ch1 > 0x40 && ch1 < 0x5B )
			ch1 += 0x20;
		ch2 = *p2;
		if( ch2 > 0x40 && ch2 < 0x5B )
			ch2 += 0x20;

		if( ch1 == ch2 )
		{
			if( ch1 == 0 )
			{
				return 0;
			}
			p1++;
			p2++;
			continue;
		}

		if( ch1 > ch2 )
			return 1;
		else
			return -1;
	}

	return -1;
}

char* CUtil::strWcs( BrLPCSTR string, BrLPCWSTR wstring )
{
	unsigned char* cp = (unsigned char*) string;
	unsigned char *s1;
	BrWCHAR* s2; 

	if ( !wstring || *wstring == 0 )
		return (char *)string;

	while( *cp != 0 )
	{
		s1 = cp;
		s2 = (BrLPWSTR)wstring;

		while ( *s1 != 0 && *s2 !=0 && (*s1-*s2)==0 )
			s1++, s2++;

		if ( *s2==0 )
			return (char*)cp;

		cp++;
	}

	return BrNULL;

}

BrLPWSTR CUtil::WcsStrA(BrLPCWSTR string, BrLPCSTR strCharSet)
{
	BrWCHAR* cp = (BrWCHAR*)string;
	BrWCHAR* s1;
	unsigned char* s2;

	if (!*strCharSet)
		return (BrWCHAR*)string;

	while (*cp)
	{
		s1 = cp;
		s2 = (unsigned char*)strCharSet;

		while (*s1 && *s2 && !(*s1 - *s2))
			s1++, s2++;

		if (!*s2)
			return(cp);

		cp++;
	}

	return BrNULL;
}

BrLPWSTR CUtil::strRchr(BrLPWSTR szString , BrWCHAR ch)
{
	int len = WcsLen( szString );
	BrLPWSTR test = szString+len-1;


	while(*test && test > szString-1)
	{
		if( *test == ch )
			return test;
		test--;
	}
	return BrNULL;
}
BrBOOL CUtil::isWingdingFont(BrLPWORD pFaceName)
{
	if( !pFaceName )
		return BrFALSE;

	if(0 == WcsICmpA(pFaceName,"Wingdings")
		|| 0 == WcsICmpA(pFaceName,"Webdings")
		|| 0 == WcsICmpA(pFaceName,"Wingdings 2")
		|| 0 == WcsICmpA(pFaceName,"Wingdings 3") )
		return BrTRUE;

	return BrFALSE;
}

BrBOOL CUtil::isSymbolFont(BrLPWORD pFaceName)
{
	if( !pFaceName )
		return BrFALSE;


	if(0 == WcsICmpA(pFaceName,"Symbol") )
		return BrTRUE;

	return BrFALSE;
}

BrBOOL CUtil::checkFontIsSymbolType(BrLPWORD pFaceName)
{
	if( !pFaceName )
		return BrFALSE;

	if(0 == WcsICmpA(pFaceName,"Wingdings")
		|| 0 == WcsICmpA(pFaceName,"Wingdings 2")
		|| 0 == WcsICmpA(pFaceName,"Wingdings 3")
		|| 0 == WcsICmpA(pFaceName,"Webdings")
		|| 0 == WcsICmpA(pFaceName,"Symbol")
		|| 0 == WcsICmpA(pFaceName,"VisualUI")
		|| 0 == WcsICmpA(pFaceName,"MS Reference Specialty")
		|| 0 == WcsICmpA(pFaceName,"Marlett")
		|| 0 == WcsICmpA(pFaceName,"MT Extra")
		|| 0 == WcsICmpA(pFaceName,"Bookshelf Symbol 7"))
		return BrTRUE;

	return BrFALSE;
}

BString CUtil::UTF8ToBString(const char* pStr)
{
	if (pStr == BrNULL)
		return BString(BrNULL);

BTrace("%s(%d) %s pStr[%s]", __FILE__, __LINE__, __FUNCTION__, pStr);
	
	//Andrew C.Lee 코드 변환 로직이 오동작하여 변경함
#if 1
	int nLen = strlen(pStr);
	unsigned short *pOutput = (unsigned short *)BrCalloc(nLen+1, sizeof(unsigned short));
	if ( pOutput == BrNULL )
		return BrNULL;

	int nRetLen = BrMultiByteToWideChar(CP_UTF8, (char*)pStr, nLen, (BrLPWSTR)pOutput, nLen);
	pOutput[nRetLen] = '\0';
	BString str((const BChar*)pOutput, nRetLen);
	BrFree(pOutput);
#else
	int nCount = BrStrLen(pStr);
	int nLen = 0, nPos = 0;
	BChar *arr = BrNEW BChar[nCount*3+1];
	if (arr == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		return BrNULL;
	}

	byte c, c1, c2;
	do 
	{
		c = pStr[nPos++];
		if (c < 0x80)
			arr[nLen++] = c;
		else if (c < 0xE0)
		{
			c1 = pStr[nPos++];
			arr[nLen++] = (c - 0xC0) << 6 | (c1 - 0x80); 
		}
		else
		{
			c1 = pStr[nPos++];
			c2 = pStr[nPos++];
			arr[nLen++] = (c - 0xE0) << 12 | (c1 - 0x80) << 6 | (c2 - 0x80);
		}
	} while (nPos <= nCount - 1);

	arr[nLen] = 0;
	BString str(arr, nLen);
	BrDELETE[] arr;
#endif
	return str;
}

//  convert word string to lower case
void CUtil::wlower(BrLPWORD pStr)
{
	while ( *pStr )	{
		*pStr = BrToLower(*pStr);
		pStr++;
	}
}


void CUtil::BrBoundary(BrRect *pBound, BrINT x, BrINT y)
{
	if(x < pBound->left)
		pBound->left = x;
	if(x > pBound->right)
		pBound->right = x;	

	if(y < pBound->top)
		pBound->top = y;
	if(y > pBound->bottom)
		pBound->bottom = y;
}

void CUtil::BrBoundary(BrFRect *pBound, BrFLOAT x, BrFLOAT y)
{
	if(x < pBound->left)
		pBound->left = x;
	if(x > pBound->right)
		pBound->right = x;	

	if(y < pBound->top)
		pBound->top = y;
	if(y > pBound->bottom)
		pBound->bottom = y;
}

void CUtil::BrBoundary(BrFRect *pBound, BrDOUBLE x, BrDOUBLE y)
{
	if(x < pBound->left)
		pBound->left = x;
	if(x > pBound->right)
		pBound->right = x;	

	if(y < pBound->top)
		pBound->top = y;
	if(y > pBound->bottom)
		pBound->bottom = y;
}

BrRect CUtil::BrBoundary(LPBrPOINT lpps, BrINT32 nPoints)
{	
	BrRect rect;

	rect.left = rect.right  = lpps->x;
	rect.top  = rect.bottom = lpps->y;	

	for(int i = 1;  i < nPoints; i++)
	{
		if ( lpps[i].x < rect.left )   rect.left = lpps[i].x;
		if ( lpps[i].x > rect.right )  rect.right = lpps[i].x;
		if ( lpps[i].y < rect.top  )   rect.top = lpps[i].y;
		if ( lpps[i].y > rect.bottom)  rect.bottom = lpps[i].y;		
	}
	return rect;
}

BrRect CUtil::BrBoundary(LPBrFPOINT lpp, BrINT32 nCount)
{
	BRTHREAD_ASSERT(nCount > 0);
	BrRect sRect = {0};
	BrFRect sFRect = {lpp[0].x, lpp[0].y, lpp[0].x, lpp[0].y};

	for(BrINT32 i = 1; i < nCount; i++)
	{
		if(lpp[i].x < sFRect.left)
			sFRect.left = lpp[i].x;
		if(lpp[i].x > sFRect.right)
			sFRect.right = lpp[i].x;
		if(lpp[i].y < sFRect.top)
			sFRect.top = lpp[i].y;
		if(lpp[i].y > sFRect.bottom)
			sFRect.bottom = lpp[i].y;		
	}

	sRect.left		= (BrLONG)sFRect.left;
	sRect.top		= (BrLONG)sFRect.top;
	sRect.right		= (BrLONG)(ceil(sFRect.right));
	sRect.bottom	= (BrLONG)(ceil(sFRect.bottom));

	return sRect;
}


BRect CUtil::BrBoundary(BPoint p1, BPoint p2, BPoint p3, BPoint p4)
{
	BRect rect(p1.x,p1.y,p1.x,p1.y);;
	BPoint ptLT = p1;
	BPoint ptRB = p1;

	if (!ptLT.IsLeft(p2))
		ptLT.x=p2.x;
	if (ptLT.IsAbove(p2))
		ptLT.y=p2.y;
	if (!ptRB.IsRight(p2))
		ptRB.x = p2.x;
	if (ptRB.IsBelow(p2))
		ptRB.y = p2.y;

	if (!ptLT.IsLeft(p3))
		ptLT.x=p3.x;
	if (ptLT.IsAbove(p3))
		ptLT.y=p3.y;
	if (!ptRB.IsRight(p3))
		ptRB.x = p3.x;
	if (ptRB.IsBelow(p3))
		ptRB.y = p3.y;

	if (!ptLT.IsLeft(p4))
		ptLT.x=p4.x;
	if (ptLT.IsAbove(p4))
		ptLT.y=p4.y;
	if (!ptRB.IsRight(p4))
		ptRB.x = p4.x;
	if (ptRB.IsBelow(p4))
		ptRB.y = p4.y;


	rect = BRect(ptLT, ptRB);
	return rect;
}
BString CUtil::BrTakeFileExtFromPath(const BrCHAR *fullpath)
{
	BString ext;

	const BrCHAR *offset = strrchr(fullpath, '.');
	int len = offset? BrStrLen(offset) : 0;
	for (int i = 1;i < len; ++i) {
		BrUINT16 uc = BrToUpper(static_cast<BrUINT16>(offset[i]));
		ext.append(static_cast<BrCHAR>(uc));
	}

	return ext;
}
// This function extracts the hue, saturation, and luminance from "color" 
// and places these values in h, s, and l respectively.
void CUtil::RGBtoHSL(unsigned int color,unsigned int& h, unsigned int& s, unsigned int& l)
{
	unsigned int r = (unsigned int)GetRValue(color);
	unsigned int g = (unsigned int)GetGValue(color);
	unsigned int b = (unsigned int)GetBValue(color);

	float r_percent = ((float)r)/255;
	float g_percent = ((float)g)/255;
	float b_percent = ((float)b)/255;

	float max_color = 0;
	if((r_percent >= g_percent) && (r_percent >= b_percent))
	{
		max_color = r_percent;
	}
	if((g_percent >= r_percent) && (g_percent >= b_percent))
		max_color = g_percent;
	if((b_percent >= r_percent) && (b_percent >= g_percent))
		max_color = b_percent;

	float min_color = 0;
	if((r_percent <= g_percent) && (r_percent <= b_percent))
		min_color = r_percent;
	if((g_percent <= r_percent) && (g_percent <= b_percent))
		min_color = g_percent;
	if((b_percent <= r_percent) && (b_percent <= g_percent))
		min_color = b_percent;

	float L = 0;
	float S = 0;
	float H = 0;

	L = (max_color + min_color)/2;

	if(max_color == min_color)
	{
		S = 0;
		H = 0;
	}
	else
	{
		if(L < .50)
		{
			S = (max_color - min_color)/(max_color + min_color);
		}
		else
		{
			S = (max_color - min_color)/(2 - max_color - min_color);
		}
		if(max_color == r_percent)
		{
			H = (g_percent - b_percent)/(max_color - min_color);
		}
		if(max_color == g_percent)
		{
			H = 2 + (b_percent - r_percent)/(max_color - min_color);
		}
		if(max_color == b_percent)
		{
			H = 4 + (r_percent - g_percent)/(max_color - min_color);
		}
	}
	s = (unsigned int)(S*100);
	l = (unsigned int)(L*100);
	H = H*60;
	if(H < 0)
		H += 360;
	h = (unsigned int)H;
}

// This function converts the "color" object to the equivalent RGB values of
// the hue, saturation, and luminance passed as h, s, and l respectively
unsigned int CUtil::HSLtoRGB(const unsigned int& h, const unsigned int& s, const unsigned int& l)
{
	unsigned int r = 0;
	unsigned int g = 0;
	unsigned int b = 0;

	float L = ((float)l)/100;
	float S = ((float)s)/100;
	float H = ((float)h)/360;

	if(s == 0)
	{
		r = l;
		g = l;
		b = l;
	}
	else
	{
		float temp1 = 0;
		if(L < .50)
		{
			temp1 = L*(1 + S);
		}
		else
		{
			temp1 = L + S - (L*S);
		}

		float temp2 = 2*L - temp1;

		float temp3 = 0;
		for(int i = 0 ; i < 3 ; i++)
		{
			switch(i)
			{
			case 0: // red
				{
					temp3 = H + .33333f;
					if(temp3 > 1)
						temp3 -= 1;
					HSLtoRGB_Subfunction(r,temp1,temp2,temp3);
					break;
				}
			case 1: // green
				{
					temp3 = H;
					HSLtoRGB_Subfunction(g,temp1,temp2,temp3);
					break;
				}
			case 2: // blue
				{
					temp3 = H - .33333f;
					if(temp3 < 0)
						temp3 += 1;
					HSLtoRGB_Subfunction(b,temp1,temp2,temp3);
					break;
				}
			default:
				{

				}
			}
		}
	}
	r = (unsigned int)((((float)r)/100)*255);
	g = (unsigned int)((((float)g)/100)*255);
	b = (unsigned int)((((float)b)/100)*255);
	return BrRGB(r,g,b);
}

unsigned int CUtil::BrightenColor(unsigned int color,int amount)
{
	unsigned int h,s,l;

	//BrINT nR = GetRValue(color);
	//BrINT nG = GetGValue(color);
	//BrINT nB = GetBValue(color);

	RGBtoHSL(color,h,s,l);

	l += amount;

	if (l > 100)
		l = 100;

	unsigned int colorAfter = HSLtoRGB(h,s,l);

	//BrINT nRAfter = GetRValue(colorAfter);
	//BrINT nGAfter = GetGValue(colorAfter);
	//BrINT nBAfter = GetBValue(colorAfter);

	return colorAfter;
}

unsigned int CUtil::BrightenColor(unsigned int color)
{
	unsigned int h,s,l;

	//BrINT nR = GetRValue(color);
	//BrINT nG = GetGValue(color);
	//BrINT nB = GetBValue(color);

	RGBtoHSL(color,h,s,l);

	l += (100-l)/2;	// <- Header/Footer 편집모드일때 Luminance Change 지원
	// 이 방식이 아닌것 같음, 예외 존재

	if (l > 100)
		l = 100;

	unsigned int colorAfter = HSLtoRGB(h,s,l);

	//BrINT nRAfter = GetRValue(colorAfter);
	//BrINT nGAfter = GetGValue(colorAfter);
	//BrINT nBAfter = GetBValue(colorAfter);

	return colorAfter;
}

unsigned int CUtil::DarkenColor(unsigned int color,int amount)
{
	unsigned int h,s,l;

	//BrINT nR = GetRValue(color);
	//BrINT nG = GetGValue(color);
	//BrINT nB = GetBValue(color);

	RGBtoHSL(color,h,s,l);

	if ( amount >= l )
	{
		l = 0;
	}
	else
	{
		l-=amount;
	}

	//BrINT nRAfter = GetRValue(colorAfter);
	//BrINT nGAfter = GetGValue(colorAfter);
	//BrINT nBAfter = GetBValue(colorAfter);

	unsigned int colorAfter = HSLtoRGB(h,s,l);

	return colorAfter;
}

bool  CUtil::isUcs4String ( BString a_strString )
{
	for ( unsigned int ii = 0; ii < a_strString.length(); ii++)
	{
		BrUSHORT wNextCode = (BrUSHORT)a_strString.at(ii+1).unicode();
		if (isSurrogatePair(a_strString.at(ii).unicode(), wNextCode))
			return true;
	}
	return false;
}

BrBOOL CUtil::IsDBCSLeadByte( BYTE TestChar , BYTE AfterChar )
{
	if( TestChar > 0x80 && AfterChar)
		return BrTRUE;

	return BrFALSE;
}

int CUtil::BStringToWord(const BString &uc, BrWORD *buf)
{
	if (!buf)
		return false;

	const BChar	*unicodeBuf;
	int nIndex = 0;
	uint nLen = uc.length ();
	unicodeBuf = uc.unicode();
	BrWORD	w;

	for (uint n = 0; n < nLen; n++)
	{
		w = unicodeBuf[n].unicode();
		if ( w==0 )		break;
		buf[nIndex++] = w;
	}

	buf[nIndex] = 0;

	return nIndex;
}

int CUtil::BStringToWord_S(const BString &uc, BrWORD *buf, BrINT32 bufSize)
{
	if (!buf || bufSize == 0)
		return 0;

	const BChar	*unicodeBuf = BrNULL;
	int nIndex = 0;
	uint nLen = uc.length ();
	unicodeBuf = uc.unicode();
	BrWORD	w = 0;
	memset(buf, 0, bufSize * sizeof(BrWORD));

	if(nLen > bufSize)
	{
		SET_ERROR(kPoErrBufferOverFlow, "string size overflow");
		return 0;
	}

	for (uint n = 0; n < nLen; n++)
	{
		w = unicodeBuf[n].unicode();
		if ( w==0 )		break;
		buf[nIndex++] = w;
	}

	return nIndex;
}

double CUtil::calcAngle(BPoint sp, BPoint ep)
{
	sp.y *= -1;
	ep.y *= -1;
	if (sp.y == ep.y)
	{
		if (sp.x < ep.x)
			return 0;
		return 180;
	}
	if (sp.x == ep.x)
	{
		if (sp.y < ep.y)
			return 90;
		return 270;
	}

	double r = BrAtan2(ep.y - sp.y, ep.x - sp.x);
	double angle = 180. * r / PI;
	//		Math.toDegrees(r);
	if (angle < 0)
		angle += 360;
	else if (angle > 360)
		angle = angle - 360;
	return angle;
}

//Andrew C.Lee 엔진 초기화 이후 사용 가능한 BrSysMalloc으로 변경(std::unique_ptr를 사용하여 함수 종료시 메모리가 해제됨)
BrAutoChar CUtil::convertBStringToChar(const BString *pStr, int nCodePage)
{
	BrINT32 nRetLen = 0;

	if( pStr )
		nRetLen = pStr->length();

	BrCHAR* out = BrNULL;
	if (nRetLen > 0)
	{
		out = (BrCHAR*)FindSysAllocPtr((nRetLen*4)+1);
		if ( out )
		{			
			nRetLen = BrWideCharToMultiByte(nCodePage, (BrLPCWSTR)pStr->unicode(), nRetLen, (BrLPSTR)out, (nRetLen*4)+1);
			out[nRetLen] = '\0';
		}
	}
	
	return BrAutoChar(out, [](BrCHAR* p) { 
		FindSysFreePtr(p); 
		});
}

//pOutBuffer는 외부에서 (pStr->length() * 4) + 1 크기 이상의 char buffer 필요
void CUtil::convertBStringToCharWithBuffer(const BString* pStr, OUT char* pOutBuffer, int nCodePage) {
	if (pStr == nullptr)
		return;
	else if (pOutBuffer == nullptr)
		BRTHREAD_ASSERT(0);

	int retLen = BrWideCharToMultiByte(nCodePage, (BrLPCWSTR)pStr->unicode(), pStr->length(), (BrLPSTR)pOutBuffer, (pStr->length() * 4) + 1);
	pOutBuffer[retLen] = NULL;
}

BrINT CUtil::convertImageContrast(BrINT nContrast)
{
	if ( nContrast > 0x10000 )
	{
		BrDOUBLE fX = nContrast;
		fX /= 0x10000;
		fX /= 51;	// 50 + 1 to round
		fX = 1/fX;
		fX -= 100;
		fX = -fX;
		fX = (fX-50)*2;
		nContrast = (BrINT)BrFRound((BrFLOAT)fX);
	}
	else if ( nContrast == 0x10000 )
		nContrast = 0;
	else
	{
		BrDOUBLE fx = nContrast;
		fx *= 101;	//100 + 1 to round
		fx /= 0x10000;
		fx -= 100;
		nContrast = (BrINT)BrFRound((BrFLOAT)fx);
	}

	return nContrast;
}

NRString* CUtil::WORDtoNRString(BrWORD* a_pWord, BrINT32 a_nLen)
{
	NRString* pStr = BrNEW NRString();
	if( !pStr)
		return BrNULL;

	for(BrINT32 i = 0; i < a_nLen; i++)
	{
		if( 0 == a_pWord[i] )
			break;
		pStr->append(NRChar(a_pWord[i]));
	}

	return pStr;
}

BString* CUtil::WORDtoBString(BrWORD a_Word)
{
	BString* pStr = BrNEW BString();
	if( !pStr)
		return BrNULL;

	pStr->append(BChar(a_Word));

	return pStr;
}

int CUtil::FindNoCaseOfUTF8(LPBYTE lpUTF, BrLPCTSTR lpszSub, int nStart, int nEnd)
{
	// cr4510 unicode 이함수는 유니코드에서 다시 정의 해야 합니다.
	int i= nStart; // index
	int len = BrStrLen( (const char*) lpUTF );

	if( nEnd!=-1 ) // -1이면 끝까지
		len = BrMIN( nEnd+1 , len ); 

	int len2 = BrStrLen( lpszSub );

	int index = -1;
	if( len2 == 0 )
		return index;

	int j=0; //sub index

	BYTE b;
	BYTE c;
	bool yes = false; // 현제 내부 비교중인지..
	bool bOne=false; //지금 글자가 맞는지..

	while( i < len )
	{
		b = *(lpUTF + i);
		c = (BYTE) *(lpszSub +j);

		bOne = false;

		if( b==c )
		{
			bOne = true;			
		}
		else
		{
			if(  c > 64 && c < 91 ) //대문자
			{
				if(  b == c+32)
				{
					bOne=true;

				}
			}
			else if( c >96 && c<123 ) //소문자
			{
				if( b==c-32 )
				{
					bOne=true;
				}
			}
		}

		if( bOne==false )
		{
			j=0;

			if( yes==false )
				i++;
			else
				yes = false;
		}
		else
		{
			i++; j++;
			yes = true;
		}


		if( j==len2 )
		{
			index = i-len2;
			break;
		}

	}

	return index;

}

BrDWORD CUtil::getColor(const BrCHAR *pColor)
{
	BrDWORD nColor = 0xFF000000;
	if( 0 == strcmp(pColor, "auto") )
	{
		return 0;
	}
	else if(0 == strncmp(pColor,"black",5))
		nColor = RGB_BLACK;
	else if( 0 == strncmp(pColor, "silver",6) || 0 == strncmp(pColor, "lightGray",9))
		nColor = RGB_LTGRAY;
	else if( 0 == strncmp(pColor, "gray",4) || 0 == strncmp(pColor, "darkGray",8))
		nColor = RGB_DKGRAY;
	else if( 0 == strncmp(pColor, "white",5) )
		nColor = RGB_WHITE;
	else if( 0 == strncmp(pColor, "maroon",6) )
		nColor = RGB_MAROON;
	else if( 0 == strncmp(pColor, "red",3) )
		nColor = RGB_RED;
	else if( 0 == strncmp(pColor, "darkRed",7) )
		nColor = RGB_DKRED;
	else if( 0 == strncmp(pColor, "purple",6) || 0 == strncmp(pColor, "darkMagenta",11))
		nColor = RGB_DKMAGENTA;
	else if( 0 == strncmp(pColor, "fuchsia",7) || 0 == strncmp(pColor, "magenta",7))
		nColor = RGB_MAGENTA;
	else if( 0 == strncmp(pColor, "darkGreen",8))
		nColor = RGB_DKGREEN;
	else if( 0 == strncmp(pColor, "green",5) || 0 == strncmp(pColor, "lime",4) )
		nColor = RGB_GREEN;
	else if( 0 == strncmp(pColor, "olive",5) )
		nColor = RGB_OLIVE;
	else if( 0 == strncmp(pColor, "yellow",6) )
		nColor = RGB_YELLOW;
	else if( 0 == strncmp(pColor, "darkYellow",10) )
		nColor = RGB_DKYELLOW;
	else if( 0 == strncmp(pColor, "navy",4) || 0 == strncmp(pColor, "darkBlue",8))
		nColor = RGB_DKBLUE;
	else if( 0 == strncmp(pColor, "blue",4) )
		nColor = RGB_BLUE;
	else if( 0 == strncmp(pColor, "teal",4) || 0 == strncmp(pColor, "darkCyan",8))
		nColor = RGB_DKCYAN;
	else if( 0 == strncmp(pColor, "aqua",4) || 0 == strncmp(pColor, "cyan",4) )
		nColor = RGB_AQUA;
	else if( 0 == strncmp(pColor, "fill lighten(51)",16) )
		nColor = RGB_WHITE;
	else if( 0 == strncmp(pColor, "fill darken(153)",16) )
		nColor = RGB_BLACK;
	else if( 0 == strncmp(pColor, "windowText", 10))
		nColor = RGB_BLACK;
	else if( 0 == strncmp(pColor, "none", 4))
		nColor = NONE_COLOR_BITS;
	else if( pColor[0] == '#' )
	{
		//#NNN[NNNN] 형태의 컬러 값의 뒤 []내용 삭제 2011-11-02 toypilot #TID : 1050
		BrBOOL bNeedCutColor = BrFALSE;	
		BString sColorString;
		BrINT32 nCount = 0;
		if(BrStrLen(pColor) != 4) {
			for(uint i = 0; i < BrStrLen(pColor); i++)
			{
				if(pColor[i] == 0x20) {
					bNeedCutColor = BrTRUE;
					nCount = i;
					break;
				}
			}
			if (bNeedCutColor) {
				sColorString.append(pColor);
				sColorString = sColorString.left(nCount);
			}
		}

		if(BrStrLen(pColor)==4 || (bNeedCutColor && 4 == nCount) ) {
			BrCHAR cColor[6];
			for(BrINT32 i=0; i<3; i++){
				if(bNeedCutColor)
				{
					cColor[i*2] = sColorString.at(i+1);
					cColor[i*2+1] = sColorString.at(i+1);
				}
				else
				{
					cColor[i*2] = pColor[i+1];
					cColor[i*2+1] = pColor[i+1];
				}


			}
			BrINT32 nResult = -1;
			sscanf_s(&cColor[0], "%x", &nResult);
			nColor = ((nResult >> 16) & 0x0000ff) | (nResult & 0x00ff00) | ((nResult << 16) & 0xff0000);
		}
		else 
		{
			BrINT32 nResult = -1;
			sscanf_s(&pColor[1], "%x", &nResult);
			nColor = ((nResult >> 16) & 0x0000ff) | (nResult & 0x00ff00) | ((nResult << 16) & 0xff0000);
		}
	}
	else
	{
		BrINT32 nResult = -1;
		sscanf_s(pColor, "%x", &nResult);

#ifdef USE_32BIT_IMAGE
		BrBYTE* pResult = (BrBYTE*)& nResult;
		nColor = BrRGB(pResult[eBrARGB_R], pResult[eBrARGB_G], pResult[eBrARGB_B]);		
#else //USE_32BIT_IMAGE
		nColor = ((nResult >> 16) & 0x0000ff) | (nResult & 0x00ff00) | ((nResult << 16) & 0xff0000);
#endif //USE_32BIT_IMAGE
	}

	return nColor;
}


BrBOOL CUtil::isWebURLHeader(BrLPWORD pBuf)
{
	if ( !pBuf || pBuf[0]==0 )	
		return BrFALSE;

	BrINT nLen = wstrlen(pBuf);
	if ( nLen < 3 || nLen > 512 )	
		return BrFALSE; 

	if ( strnCmp(pBuf, "http", 4)==0)
	{
		return BrTRUE;
	}
	else if ( strnCmp(pBuf, "rtsp", 4)==0)
	{
		return BrTRUE;
	}
	else if ( strnCmp(pBuf, "ftp", 4)==0)
	{
		return BrTRUE;
	}
	else if ( strnCmp(pBuf, "www", 3)==0)
	{
		return BrTRUE;
	}
	
	return BrFALSE;
}

// 1. 접두어로 올 수 있는 단어 http, https, Http, Https, rtsp, Rtsp
// 2. 아이피 어드레스
// 3. "@" 이 문자열에 포함되어 있으면 false 리턴 
BrBOOL CUtil::isWebURLStr(BrLPWORD pBuf)
{
#ifdef SUPPORT_AUTO_WEB_URL
	if ( !pBuf || pBuf[0]==0 )	return BrFALSE;

	BrINT i, nLen;
	nLen = wstrlen(pBuf);
	if ( nLen<10 || nLen>512 )	return BrFALSE; // [2/22/2016 hyunwook][ZPD-26329] 최대 길이 제한 수정(256->512)

	BrBOOL bHeader = BrFALSE, bIsDot = BrFALSE, bWWW = BrFALSE;
	BrINT	nCnt = 0;
	if ( strnCmp(pBuf, "https", 5)==0 || strnCmp(pBuf, "Https", 5)==0 || strnCmp(pBuf, "HTTPS", 5)==0 )
	{
		bHeader = BrTRUE;
		nCnt = 5;
	}
	else if ( strnCmp(pBuf, "http", 4)==0 || strnCmp(pBuf, "Http", 4)==0 || strnCmp(pBuf, "HTTP", 4)==0 )
	{
		bHeader = BrTRUE;
		nCnt = 4;
	}
	else if ( strnCmp(pBuf, "rtsp", 4)==0 || strnCmp(pBuf, "Rtsp", 4)==0 || strnCmp(pBuf, "RTSP", 4)==0 )
	{
		bHeader = BrTRUE;
		nCnt = 4;
	}
	else if ( strnCmp(pBuf, "ftp", 3)==0 || strnCmp(pBuf, "Ftp", 3)==0 || strnCmp(pBuf, "FTP", 3)==0 )
	{
		bHeader = BrTRUE;
		nCnt = 3;
	}
	else if ( strnCmp(pBuf, "www.", 4)==0 || strnCmp(pBuf, "WWW.", 4)==0 || strnCmp(pBuf, "Www.", 4)==0)
	{
		bHeader = BrTRUE;
		bWWW = BrTRUE;
		bIsDot = BrTRUE;
		nCnt = 4;
	}
	if ( !bHeader )		return BrFALSE;

	if ( !bWWW && strnCmp(pBuf+nCnt, "://", 3)!=0 )
		return BrFALSE;

	if ( !bWWW )
		nCnt += 3;

	BrBOOL bCharCode = BrFALSE;
	for ( i=nCnt; i<nLen; i++ )
	{
		switch ( pBuf[i] )
		{
		case '.' :
			bIsDot = BrTRUE;
			bCharCode = BrFALSE;
			break;
		case '@' :
			return BrFALSE;
		default :
			bCharCode = BrTRUE;
			break;
		}
	}

	// 마지막이 '.'이면 Web URL이 아님.
	if ( !bCharCode )	return BrFALSE;
	return BrTRUE;
#else
	return BrFALSE;
#endif
}

// 1. 이메일 접두어: a-z, A-Z, 0~9, ".", "_", "%", "-" 가 최소 1~256 길이 
// 2. 접두어 다음에 나올 필수 단어: "@" 
// 3. 서버 이름 규칙: 0~64 자의 알파벳 대소문자, 0~9의 숫자, "-"
// 4. 서버이름 다음에 나오는 필수 부호: "." 
// 5. 도메인 규칙: 0~25자의 알파벳 대소문자, 0~9의 숫자 "-"
BrBOOL CUtil::isEMailStr(BrLPWORD pBuf)
{
#ifdef SUPPORT_AUTO_EMAIL_ADDRESS
	if ( !pBuf || pBuf[0]==0 )	return BrFALSE;

	BrINT i, nLen, nStart;
	nLen = wstrlen(pBuf);
	if ( nLen<6 || nLen>256 )	return BrFALSE;

	BrBOOL bIsAt = BrFALSE, bIsDot = BrFALSE;
	BrBOOL bCharCode = BrFALSE;
	nStart = 0;

	//[M-23528] hnsong:2013-02-18 
	if ( strnCmp(pBuf, "mailto://", 9)==0 || strnCmp(pBuf, "Mailto://", 9)==0 )
	{
		nStart = 9;
	}

	for ( i=nStart; i<nLen; i++ )
	{
		switch ( pBuf[i] )
		{
		case '@' :
			if ( i==0 || bIsAt )
			{
				return BrFALSE;
			}
			bIsAt = BrTRUE;
			break;
		case '.' :
			if ( bIsAt )
			{
				bIsDot = BrTRUE;
				bCharCode = BrFALSE;
			}
			break;
		case '_' :
		case '%' :
			if ( bIsAt )
				return BrFALSE;
			break;
		case '-' :
			if ( bIsAt )
				bCharCode = BrTRUE;
			break;
		default :
			if ( (pBuf[i]>='0' && pBuf[i]<='9') || (pBuf[i]>='a' && pBuf[i]<='z') || (pBuf[i]>='A' && pBuf[i]<='Z') )
			{
				if ( bIsAt )
					bCharCode = BrTRUE;
			}
			else
				return BrFALSE;
			break;
		}
	}

	// check valid
	if ( !bIsAt || !bIsDot || !bCharCode )	return BrFALSE;
	return BrTRUE;
#else
	return BrFALSE;
#endif
}

// check phone number of current line
// (02)6190-7701
// 010-9946-6774
// 02-6190-7701
// +82-2-6190-7701
BrBOOL CUtil::isPhoneNumberStr(BrLPWORD pBuf)
{
#ifdef SUPPORT_TELEPHONE_NUMBER
	if ( !pBuf || pBuf[0]==0 )	return BrFALSE;

	BrBOOL	bSeperate = BrFALSE;
	BrINT i, nLen, nDashNum=0, nNumCodeCnt=0;
	nLen = wstrlen(pBuf);
	// 최소 5글자 이상일 때에만 전화번호 true 로 리턴
	if ( (nLen < PHONE_MIN_NUMBER) || (nLen > PHONE_MAX_NUMBER) )	return BrFALSE;

	BrBOOL bNumCode = BrFALSE;
	for ( i=0; i<nLen; i++ )
	{
		switch ( pBuf[i] )
		{
			// Number
		case '0' :
		case '1' :
		case '2' :
		case '3' :
		case '4' :
		case '5' :
		case '6' :
		case '7' :
		case '8' :
		case '9' :
			bNumCode = BrTRUE;
			nNumCodeCnt++;
			break;
			// 맨 앞만 허용
		case '(' :
		case '+' :
			if ( i!=0 )
			{
				return BrFALSE;
			}
			bNumCode = BrFALSE;
			break;
			// 중간에 들어가는 것 허용
		case '-' :
			// 첫 숫자가 하나일때는 전화번호로 간주하지 않는다.
			if ( nDashNum==0 && nNumCodeCnt<=1 )	return BrFALSE;
			nDashNum++;
		case '~' :
			// Dash 가 없이 바로 나타나는 경우는 전화번호로 간주하지 않는다. [XRF-1715]
			if ( nDashNum==0 )		return BrFALSE;
			bSeperate = BrTRUE;
		case ')' :
			// case '.' :
			bNumCode = BrFALSE;
			break;
		default :
			return BrFALSE;
			break;
		}
	}

	// 마지막이 숫자가 아니면 Phone Number가 아님.
	if ( !bNumCode )	return BrFALSE;

	// '-' 와 같이 seperate가 하나도 없으면 Phone Number가 아님.
	if ( !bSeperate )	return BrFALSE;

	// 숫자가 7자 이하이면 전화 번호로 처리하지 않음 (IOS에서 참조) CSP-122
	if ( nNumCodeCnt<7 )	return BrFALSE;

	// 현재 몇몇 언어들의 DatePattern이 "0000-00-00/00-00-0000"으로 표시되고 있습니다.
	// 위와 같은 Pattern으로 Date가 들어가게 되면 AutoLink 동작으로 인해 Date Object의 text가 파란색이 되고 밑줄 쳐지는 현상이 나타나고 있습니다.
	// 때문에 "0000-00-00/00-00-0000" 2가지 Pattern은 AutoLink? 기능이 적용되지 않도록 검토 요청드립니다.
	if ( nLen==10 && nNumCodeCnt==8 && nDashNum==2 )
	{
		if ( pBuf[4]=='-' && pBuf[7]=='-' )	return BrFALSE;
		if ( pBuf[2]=='-' && pBuf[5]=='-' )	return BrFALSE;
	}

	return BrTRUE;
#else
	return BrFALSE;
#endif
}


BrINT  CUtil::ConvertLightTypeToLightRigType(BrLightType nLightType)
{
	BrINT nLightRigType = 0;
	switch (nLightType)
	{
	case BR_LIGHT_TYPE_THREE_POINT :	nLightRigType = OfficeX3DLightRigTypeThreePoint;	break;
	case BR_LIGHT_TYPE_BALANCE :		nLightRigType = OfficeX3DLightRigTypeBalanced;		break;
	case BR_LIGHT_TYPE_SOFT :			nLightRigType = OfficeX3DLightRigTypeSoft;			break;
	case BR_LIGHT_TYPE_HARSH :			nLightRigType = OfficeX3DLightRigTypeHarsh;			break;
	case BR_LIGHT_TYPE_FLOOD :			nLightRigType = OfficeX3DLightRigTypeFlood;			break;
	case BR_LIGHT_TYPE_CONTRASTING :	nLightRigType = OfficeX3DLightRigTypeContrasting;	break;
	case BR_LIGHT_TYPE_MORNING :		nLightRigType = OfficeX3DLightRigTypeMorning;		break;
	case BR_LIGHT_TYPE_SUNRISE :		nLightRigType = OfficeX3DLightRigTypeSunrise;		break;
	case BR_LIGHT_TYPE_SUNSET :			nLightRigType = OfficeX3DLightRigTypeSunset;		break;
	case BR_LIGHT_TYPE_CHILLY :			nLightRigType = OfficeX3DLightRigTypeChilly;		break;
	case BR_LIGHT_TYPE_FREEZING :		nLightRigType = OfficeX3DLightRigTypeFreezing;		break;
	case BR_LIGHT_TYPE_FLAT :			nLightRigType = OfficeX3DLightRigTypeFlat;			break;
	case BR_LIGHT_TYPE_TWO_POINT :		nLightRigType = OfficeX3DLightRigTypeTwoPoint;		break;
	case BR_LIGHT_TYPE_GLOW :			nLightRigType = OfficeX3DLightRigTypeGlow;			break;
	case BR_LIGHT_TYPE_BRIGHT_ROOM :	nLightRigType = OfficeX3DLightRigTypeBrightRoom;	break;
	}

	return nLightRigType;
}

BrLightType CUtil::ConvertLightRigTypeToLightType(BrINT nLightRigType)
{
	BrLightType nLightType = BR_LIGHT_TYPE_NONE;
	switch (nLightRigType)
	{
	case OfficeX3DLightRigTypeThreePoint :	nLightType = BR_LIGHT_TYPE_THREE_POINT;	break;
	case OfficeX3DLightRigTypeBalanced :	nLightType = BR_LIGHT_TYPE_BALANCE;		break;
	case OfficeX3DLightRigTypeSoft :		nLightType = BR_LIGHT_TYPE_SOFT;		break;
	case OfficeX3DLightRigTypeHarsh :		nLightType = BR_LIGHT_TYPE_HARSH;		break;
	case OfficeX3DLightRigTypeFlood :		nLightType = BR_LIGHT_TYPE_FLOOD;		break;
	case OfficeX3DLightRigTypeContrasting :	nLightType = BR_LIGHT_TYPE_CONTRASTING;	break;
	case OfficeX3DLightRigTypeMorning :		nLightType = BR_LIGHT_TYPE_MORNING;		break;
	case OfficeX3DLightRigTypeSunrise :		nLightType = BR_LIGHT_TYPE_SUNRISE;		break;
	case OfficeX3DLightRigTypeSunset :		nLightType = BR_LIGHT_TYPE_SUNSET;		break;
	case OfficeX3DLightRigTypeChilly :		nLightType = BR_LIGHT_TYPE_CHILLY;		break;
	case OfficeX3DLightRigTypeFreezing :	nLightType = BR_LIGHT_TYPE_FREEZING;	break;
	case OfficeX3DLightRigTypeFlat :		nLightType = BR_LIGHT_TYPE_FLAT;		break;
	case OfficeX3DLightRigTypeTwoPoint :	nLightType = BR_LIGHT_TYPE_TWO_POINT;	break;
	case OfficeX3DLightRigTypeGlow :		nLightType = BR_LIGHT_TYPE_GLOW;		break;
	case OfficeX3DLightRigTypeBrightRoom :	nLightType = BR_LIGHT_TYPE_BRIGHT_ROOM;	break;
	}
	return nLightType;
}

BrINT  CUtil::ConvertMaterialTypeToOfficeX3DPresetMaterialType(BrMaterialType nMaterialType)
{
	BrINT nOfficeX3DPresetMaterialType = 0;
	switch (nMaterialType)
	{
	case BR_MATERIAL_TYPE_MATTE :				nOfficeX3DPresetMaterialType = OfficeX3DTypeMatte;				break;
	case BR_MATERIAL_TYPE_WARM_MATTE :			nOfficeX3DPresetMaterialType = OfficeX3DTypeWarmMatte;			break;
	case BR_MATERIAL_TYPE_PLASTIC :				nOfficeX3DPresetMaterialType = OfficeX3DTypePlastic;			break;
	case BR_MATERIAL_TYPE_METAL :				nOfficeX3DPresetMaterialType = OfficeX3DTypeMetal;				break;
	case BR_MATERIAL_TYPE_DARK_EDGE :			nOfficeX3DPresetMaterialType = OfficeX3DTypeDarkEdge;			break;
	case BR_MATERIAL_TYPE_SOFT_EDGE :			nOfficeX3DPresetMaterialType = OfficeX3DTypeSoftEdge;			break;
	case BR_MATERIAL_TYPE_FLAT :				nOfficeX3DPresetMaterialType = OfficeX3DTypeFlat;				break;
	case BR_MATERIAL_TYPE_WIRE_FRAME :			nOfficeX3DPresetMaterialType = OfficeX3DTypeLegacyWireFrame;	break;
	case BR_MATERIAL_TYPE_POWDER :				nOfficeX3DPresetMaterialType = OfficeX3DTypePowder;				break;
	case BR_MATERIAL_TYPE_TRANSLUCENT_POWDER :	nOfficeX3DPresetMaterialType = OfficeX3DTypeTranslucentPowder;	break;
	case BR_MATERIAL_TYPE_CLEAR :				nOfficeX3DPresetMaterialType = OfficeX3DTypeClear;				break;
	}

	return nOfficeX3DPresetMaterialType;
}

BrMaterialType CUtil::ConvertOfficeX3DPresetMaterialTypeToMaterialType(BrINT nOfficeX3DPresetMaterialType)
{
	BrMaterialType nMaterialType = BR_MATERIAL_TYPE_NONE;
	switch (nOfficeX3DPresetMaterialType)
	{
	case OfficeX3DTypeMatte :				nMaterialType = BR_MATERIAL_TYPE_MATTE;					break;
	case OfficeX3DTypeWarmMatte :			nMaterialType = BR_MATERIAL_TYPE_WARM_MATTE;			break;
	case OfficeX3DTypePlastic :				nMaterialType = BR_MATERIAL_TYPE_PLASTIC;				break;
	case OfficeX3DTypeMetal :				nMaterialType = BR_MATERIAL_TYPE_METAL;					break;
	case OfficeX3DTypeDarkEdge :			nMaterialType = BR_MATERIAL_TYPE_DARK_EDGE;				break;
	case OfficeX3DTypeSoftEdge :			nMaterialType = BR_MATERIAL_TYPE_SOFT_EDGE;				break;
	case OfficeX3DTypeFlat :				nMaterialType = BR_MATERIAL_TYPE_FLAT;					break;
	case OfficeX3DTypeLegacyWireFrame :		nMaterialType = BR_MATERIAL_TYPE_WIRE_FRAME;			break;
	case OfficeX3DTypePowder :				nMaterialType = BR_MATERIAL_TYPE_POWDER;				break;
	case OfficeX3DTypeTranslucentPowder :	nMaterialType = BR_MATERIAL_TYPE_TRANSLUCENT_POWDER;	break;
	case OfficeX3DTypeClear :				nMaterialType = BR_MATERIAL_TYPE_CLEAR;					break;
		/* 슬라이드 셀 입체 원래는 OfficeX3DTypeDarkEdge 이나 색상이 너무 어두워  OfficeX3DTypeLegacyPlastic로 올려서 디스플레이 해주고 있음*/
	case OfficeX3DTypeLegacyPlastic :		nMaterialType = BR_MATERIAL_TYPE_DARK_EDGE;				break;
	}
	return nMaterialType;
}

BRect CUtil::calcBoundary( BrPoint* lpp, int nPoint)
{
	BRect rc(0x7fffffff, 0x7fffffff, 0x80000000 , 0x80000000);
	for (int i = 0; i < nPoint; i++, lpp++)
	{
		rc.nLeft = BrMIN(lpp->x, rc.nLeft);
		rc.nTop = BrMIN(lpp->y, rc.nTop);
		rc.nRight = BrMAX(lpp->x, rc.nRight);
		rc.nBottom = BrMAX(lpp->y, rc.nBottom);
	}
	return rc;
}

BrBOOL CUtil::GetFontIndexByName(BrUSHORT* strFontName, BrUSHORT* strLocalFontName, BrUINT16 nLen)
{
	BrINT i = 0;
	BrUSHORT cNCode;

	++strFontName;
	for(i = 0; i < nLen; i++)
	{
		if(strLocalFontName[i]== 0)
			break;
		cNCode = BrToLower(strFontName[i]);
		if(cNCode != strLocalFontName[i])
			break;
	}
	if(i < nLen)
		return BrFALSE;
	else
		return BrTRUE;
}

BrBOOL CUtil::isDoubleComExpFont(BrLPWORD pFaceName)
{
	BrINT nLen = BrWcsLen(pFaceName);
	BrBOOL bHangleFont = BrFALSE;
	BrUSHORT cNCode = 0;

	for (BrINT i = 0; i < nLen; i++)
	{
		if (pFaceName[i] == 0)
		{
			bHangleFont = BrFALSE;
			break;
		}

		cNCode = BrToLower(pFaceName[i]);

		if (IS_EAST_ASIAN(cNCode))
		{
			bHangleFont = BrTRUE;
			break;
		}
	}

	if(!bHangleFont)
		return BrFALSE;

	BrBOOL bDoubleExpFont = BrTRUE;
	cNCode = BrToLower(pFaceName[0]);
		
	switch(cNCode)
	{
		case 0xAC00:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xB294, 0xC548, 0xC0C1, 0xC218, 0xCCB4, 0x00 };	//가는안상수체	6
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xAD75:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xC740, 0xC548, 0xC0C1, 0xC218, 0xCCB4, 0x00 };	//굵은안상수체	6
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xb9d1:
			if(nLen == 5)
			{
				BrUSHORT wLocalFont[] = {0xc740, 0x20, 0xace0, 0xb515, 0x00}; 	//맑은 고딕
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					return BrFALSE;
			}
			break;
		case 0xBB38:
			if(nLen == 7)
			{
				BrUSHORT wLocalFont[] = { 0xCCB4, 0xBD80, 0x20, 0xB3CB, 0xC74C, 0xCCB4, 0x00 };	//문체부 돋음체
				BrUSHORT wLocalFont2[] = { 0xCCB4, 0xBD80, 0x20, 0xBC14, 0xD0D5, 0xCCB4, 0x00 };	//문체부 바탕체

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xCCB4, 0xBD80, 0x20, 0xC4F0, 0xAE30, 0x20, 0xC815, 0xCCB4, 0x00 };	//문체부 쓰기 정체	9
				BrUSHORT wLocalFont2[] = { 0xCCB4, 0xBD80, 0x20, 0xD6C8, 0xBBFC, 0xC815, 0xC74C, 0xCCB4, 0x00 };	//문체부 훈민정음체	9

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
			}
			else if(nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0xCCB4, 0xBD80, 0x20, 0xAD81, 0xCCB4, 0x20, 0xC815, 0xC790, 0xCCB4, 0x00 };	//문체부 궁체 정자체	10
				BrUSHORT wLocalFont2[] = { 0xCCB4, 0xBD80, 0x20, 0xAD81, 0xCCB4, 0x20, 0xD758, 0xB9BC, 0xCCB4, 0x00 };	//문체부 궁체 흘림체	10
				BrUSHORT wLocalFont3[] = { 0xCCB4, 0xBD80, 0x20, 0xC81C, 0xBAA9, 0x20, 0xB3CB, 0xC74C, 0xCCB4, 0x00 };	//문체부 제목 돋음체	10
				BrUSHORT wLocalFont4[] = { 0xCCB4, 0xBD80, 0x20, 0xC81C, 0xBAA9, 0x20, 0xBC14, 0xD0D5, 0xCCB4, 0x00 };	//문체부 제목 바탕체	10

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont4, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xC548:
			if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xC0C1, 0xC218, 0x32, 0x30, 0x30, 0x36, 0xAC00, 0xB294, 0x00 };	//안상수2006가는	9
				BrUSHORT wLocalFont2[] = { 0xC0C1, 0xC218, 0x32, 0x30, 0x30, 0x36, 0xAD75, 0xC740, 0x00 };	//안상수2006굵은	9
				BrUSHORT wLocalFont3[] = { 0xC0C1, 0xC218, 0x32, 0x30, 0x30, 0x36, 0xC911, 0xAC04, 0x00 };	//안상수2006중간	9

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xC591:
			if(nLen == 6)
			{
				if(pFaceName[1] == 0xC7AC)
				{
					if(pFaceName[2] == 0xAE68)
					{
						BrUSHORT wLocalFont[] = { 0xBE44, 0xCCB4, 0x62, 0x00 };	//양재깨비체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xAF43)
					{
						BrUSHORT wLocalFont[] = { 0xAC8C, 0xCCB4, 0x6D, 0x00 };	//양재꽃게체M	6	
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xB09C)
					{
						BrUSHORT wLocalFont[] = { 0xCD08, 0xCCB4, 0x6D, 0x00 };	//양재난초체M	6	
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xB9E4)
					{
						BrUSHORT wLocalFont[] = { 0xD654, 0xCCB4, 0x73, 0x00 };	//양재매화체S	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xBC31)
					{
						BrUSHORT wLocalFont[] = { 0xB450, 0xCCB4, 0x62, 0x00 };	//양재백두체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xBCA8)
					{
						BrUSHORT wLocalFont[] = { 0xB77C, 0xCCB4, 0x6D, 0x00 };	//양재벨라체M	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xBD93)
					{
						BrUSHORT wLocalFont[] = { 0xAF43, 0xCCB4, 0x6C, 0x00 };	//양재붓꽃체L	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xC18C)
					{
						BrUSHORT wLocalFont[] = { 0xC2AC, 0xCCB4, 0x73, 0x00 };	//양재소슬체S	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xC640)
					{
						BrUSHORT wLocalFont[] = { 0xB2F9, 0xCCB4, 0x6D, 0x00 };	//양재와당체M	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xC774)
					{
						BrUSHORT wLocalFont[] = { 0xB2C8, 0xC15C, 0xCCB4, 0x00 };	//양재이니셜체	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xCC38)
					{
						BrUSHORT wLocalFont[] = { 0xC22F, 0xCCB4, 0x62, 0x00 };	//양재참숯체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xD2BC)
					{
						BrUSHORT wLocalFont[] = { 0xD2BC, 0xCCB4, 0x62, 0x00 };	//양재튼튼체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
				}
			}
			else if(nLen == 7)
			{
				if(pFaceName[1] == 0xC7AC)
				{
					if(pFaceName[2] == 0xB2E4)
					{
						BrUSHORT wLocalFont[] = { 0xC6B4, 0xBA85, 0xC870, 0x6D, 0x00 };	//양재다운명조M	7	
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
					else if(pFaceName[2] == 0xBCF8)
					{
						BrUSHORT wLocalFont[] = { 0xBAA9, 0xAC01, 0xCCB4, 0x6D, 0x00 };	//양재본목각체M	7
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							return BrFALSE;
					}
				}
			}
			break;
		case 0xC911:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xAC04, 0xC548, 0xC0C1, 0xC218, 0xCCB4, 0x00 };	//중간안상수체	6
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xD0DC:
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0x20, 0xB098, 0xBB34, 0x00 };	//태 나무	4
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xD39C:
			if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = { 0xD758, 0xB9BC, 0x00 };	//펜흘림	3
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xd55c:
			if(nLen == 7)
			{
				if(pFaceName[1] == 0xCEF4 && pFaceName[2] == 0x20)
				{
					if(pFaceName[3] == 0xBC31)
					{
						BrUSHORT wLocalFont[] = { 0xC81C, 0x20, 0x62, 0x00 };	//한컴 백제 B	7
						BrUSHORT wLocalFont2[] = { 0xC81C, 0x20, 0x6D, 0x00 };	//한컴 백제 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							return BrFALSE;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							return BrFALSE;
					}
					else if(pFaceName[3] == 0xC18C)
					{
						BrUSHORT wLocalFont[] = { 0xB9DD, 0x20, 0x62, 0x00 };	//한컴 소망 B	7
						BrUSHORT wLocalFont2[] = { 0xB9DD, 0x20, 0x6D, 0x00 };	//한컴 소망 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							return BrFALSE;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							return BrFALSE;
					}
					else if(pFaceName[3] == 0xC194)
					{
						BrUSHORT wLocalFont[] = { 0xC78E, 0x20, 0x62, 0x00 };	//한컴 솔잎 B	7
						BrUSHORT wLocalFont2[] = { 0xC78E, 0x20, 0x6D, 0x00 };	//한컴 솔잎 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							return BrFALSE;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							return BrFALSE;
					}
					else if(pFaceName[3] == 0xC724)
					{
						BrUSHORT wLocalFont[] = { 0xCCB4, 0x20, 0x62, 0x00 };	//한컴 윤체 B	7
						BrUSHORT wLocalFont2[] = { 0xCCB4, 0x20, 0x6C, 0x00 };	//한컴 윤체 L	7
						BrUSHORT wLocalFont3[] = { 0xCCB4, 0x20, 0x6D, 0x00 };	//한컴 윤체 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							return BrFALSE;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							return BrFALSE;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont3, nLen-4))
							return BrFALSE;
					}

				}
			}
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0x20, 0xCFE8, 0xC7AC, 0xC988, 0x20, 0x62, 0x00 };	//한컴 쿨재즈 B	8
				BrUSHORT wLocalFont2[] = { 0xCEF4, 0x20, 0xCFE8, 0xC7AC, 0xC988, 0x20, 0x6C, 0x00 };	//한컴 쿨재즈 L	8
				BrUSHORT wLocalFont3[] = { 0xCEF4, 0x20, 0xCFE8, 0xC7AC, 0xC988, 0x20, 0x6D, 0x00 };	//한컴 쿨재즈 M	8

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					return BrFALSE;
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0x20, 0xBC14, 0xAC90, 0xC138, 0xC77C, 0x20, 0x62, 0x00 };	//한컴 바겐세일 B	9
				BrUSHORT wLocalFont2[] = { 0xCEF4, 0x20, 0xBC14, 0xAC90, 0xC138, 0xC77C, 0x20, 0x6D, 0x00 };	//한컴 바겐세일 M	9

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
			}
			else if(nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0x20, 0xC724, 0xACE0, 0xB515, 0x20, 0x32, 0x33, 0x30, 0x00 };	//한컴 윤고딕 230	10
				BrUSHORT wLocalFont2[] = { 0xCEF4, 0x20, 0xC724, 0xACE0, 0xB515, 0x20, 0x32, 0x34, 0x30, 0x00 };	//한컴 윤고딕 240	10
				BrUSHORT wLocalFont3[] = { 0xCEF4, 0x20, 0xC724, 0xACE0, 0xB515, 0x20, 0x32, 0x35, 0x30, 0x00 };	//한컴 윤고딕 250	10

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					return BrFALSE;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					return BrFALSE;
			}
			break;
		case 0xd568:	//함
			if(nLen == 5)
			{
				if(pFaceName[1]==0xcd08 && pFaceName[2]==0xb86c)	//초롬
				{
					BrUSHORT wLocalFont[] = { 0xB3CB, 0xC6C0, 0x00 };	//함초롬돋움	5
					BrUSHORT wLocalFont2[] = { 0xBC14, 0xD0D5, 0x00 };	//함초롬바탕	5

					if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[2], wLocalFont2, nLen-3))
						return BrFALSE;
				}
			}
			break;
		case 0xd734:	// 휴
			if(pFaceName[1] == 0xba3c)	// 먼
			{
				if ( nLen == 4)
				{
					BrUSHORT wLocalFont1[] = {  0xba85, 0xc870, 0x00 }; 
					
					if(GetFontIndexByName(&pFaceName[1], wLocalFont1, nLen-2))
						return BrFALSE;
				}
				else if ( nLen == 5)
				{
					BrUSHORT wLocalFont1[] = {  0xb9e4, 0xc9c1, 0xccb4, 0x00 }; 
					BrUSHORT wLocalFont2[] = {  0xbaa8, 0xc74c, 0x74, 0x00 }; 
					BrUSHORT wLocalFont3[] = {  0xc544, 0xbbf8, 0xccb4, 0x00 }; 
					BrUSHORT wLocalFont4[] = {  0xd3b8, 0xc9c0, 0xccb4, 0x00 }; 

					if(GetFontIndexByName(&pFaceName[1], wLocalFont1, nLen-2))
						return BrFALSE;
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						return BrFALSE;
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))	
						return BrFALSE;
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))	
						return BrFALSE;
				}
				else if(nLen == 6)
				{
					BrUSHORT wLocalFont[] = { 0xAC00, 0xB294, 0xC0D8, 0xCCB4, 0x00 };	//휴먼가는샘체	6
					BrUSHORT wLocalFont2[] = { 0xAC00, 0xB294, 0xD338, 0xCCB4, 0x00 };	//휴먼가는팸체	6
					BrUSHORT wLocalFont3[] = { 0xC911, 0xAC04, 0xC0D8, 0xCCB4, 0x00 };	//휴먼중간샘체	6
					BrUSHORT wLocalFont4[] = { 0xC911, 0xAC04, 0xD338, 0xCCB4, 0x00 };	//휴먼중간팸체	6

					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))
						return BrFALSE;
				}
			}
			break;
		case 0x68:
			if(nLen == 7)
			{
				BrUSHORT wLocalFont[] = { 0x79, 0xC595, 0xC740, 0xC0D8, 0xBB3C, 0x6d, 0x00 };	//HY얕은샘물M	7
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			break;
		case 0x6d:
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0x64, 0xC194, 0xCCB4, 0x00 };	//MD솔체	4
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					return BrFALSE;
			}
			else if(nLen == 5)
			{
				if(BrToLower(pFaceName[1]) == 0x64)
				{
					BrUSHORT wLocalFont[] = { 0xAC1C, 0xC131, 0xCCB4, 0x00 };	//MD개성체	5
					BrUSHORT wLocalFont2[] = { 0xC544, 0xB871, 0xCCB4, 0x00 };	//MD아롱체	5
					BrUSHORT wLocalFont3[] = { 0xC544, 0xD2B8, 0xCCB4, 0x00 };	//MD아트체	5
					BrUSHORT wLocalFont4[] = { 0xC774, 0xC19D, 0xCCB4, 0x00 };	//MD이솝체	5

					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))
						return BrFALSE;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))
						return BrFALSE;
				}
			}
			break;
		default:
			break;
	}

	return bDoubleExpFont;
}

BrINT32	CUtil::CheckDefaultFlag(BrINT32 nFlg, BrWORD wCode)
{
	BrINT32 nFontFlag = nFlg; 

	switch(nFontFlag)
	{
		case f_ArialUnicodeMS_SameKind: break;						
		case f_MakeunGodik_SameKind: break;								
		case f_VinerHandITC_SameKind: break;							
		case f_Papyrus_SameKind: break;									
		case f_LucidaSansUnicode_SameKind: break;						
		case f_Jokerman_SameKind: break;								
		case f_Bauhaus93_SameKind: break;								
		case f_Padauk_SameKind: break;									
		case f_HyumeonAmiche_SameKind: break;							
		case f_ArialBlack_SameKind: break;		
		case f_ComicSansMS_SameKind: break;	
		case f_HyumeonYetche_SameKind: break;
		case f_LucidaHandwriting_SameKind: break;
		case f_PalatinoLinotype_SameKind: break;
		case f_KristenITC_SameKind: break;
		case f_Fences_SameKind: break;		
		case f_GoudyStout_SameKind: break;
		case f_CurlzMT_SameKind: break;
		case f_Algerian_SameKind: break;	
		//case f_Aldhabi_SameKind: break;	어떤 함수인지 확인 필요
		//case f_UnBatang_SameKind: break;
		case f_MTExtra_SameKind: break;
		case f_Pristina_SameKind: break;
		case f_Sylfaen_SameKind: break;
		case f_BlackadderITC_SameKind: break;
		case f_SnapITC_SameKind: break;
		case f_BradleyHandITC_SameKind: break;	
		case f_RageItalic_SameKind: break;
		case f_HarlowSolidItalic_SameKind: break;
		case f_SnellBT_SameKind: break;
		case f_BrushScriptMT_SameKind: break;
		case f_WideLatin_SameKind: break;
		case f_Freehand591BT_SameKind: break;
		case f_BookAntiqua_SameKind: break;	
		case f_GillSansUltraBoldCondensed_SameKind: break;
		case f_Century_SameKind: break;
		case f_Castellar_SameKind: break;
		case f_Magneto_SameKind: break;
		case f_Verdana_SameKind: break;
		case f_Impact_SameKind: break;
		case f_Calibri_SameKind: break;
		case f_AgencyFB_SameKind: break;
		case f_BernardMTCon_SameKind: break;
		case f_PTBarnumBT_SameKind: break;
		case f_NewsGothBT_SameKind: break;
		case f_BodoniMT_SameKind: break;
		case f_HighTowerText_SameKind: break;
		case f_BodoniMTBlack_SameKind: break;
		case f_Cambria_SameKind: break;	
		case f_LucidaBright_SameKind: break;
		case f_BalloonXBdBT_SameKind: break;
		case f_Onyx_SameKind: break;
		case f_Arial_SameKind: break;	
		case f_Chiller_SameKind: break;
		case f_AmericanaBT_SameKind: break;
		case f_GillSansMT_SameKind: break;
		case f_Garamond_SameKind: break;
		case f_PoorRichard_SameKind: break;
		case f_BerlinSansFBDemi_SameKind: break;
		case f_CourierNew_SameKind: break;	
		case f_ErasLightITC_SameKind: break;
		case f_CalifornianFB_SameKind: break;
		case f_Centaur_SameKind: break;
		case f_ErasMediumITC_SameKind: break;
		case f_BritannicBold_SameKind: break;
		case f_Wingdings_SameKind: break;
		case f_BellMT_SameKind: break;	
		case f_CopperplateGotBold_SameKind: break;
		case f_BookshelfSymbol5_SameKind: break;
		case f_MonotypeCorsiva_SameKind: break;
		case f_TwCenMT_SameKind: break;
		case f_KunstlerScript_SameKind: break;
		case f_HMULTI2_SameKind: break;
		case f_BerlinSansFB_SameKind: break;	
		case f_NiagaraEngraved_SameKind: break;
		case f_H_PROSYM_SameKind: break;
		case f_H_MULT1_SameKind: break;
		case f_TwCenMTCondensedExtraBold_SameKind: break;
		case f_FootlightMTLight_SameKind: break;
		case f_ColonnaMT_SameKind: break;	
		case f_HESPERANTO_SameKind: break;
		case f_Haettenschweiler_SameKind: break;
		case f_Parchment_SameKind: break;
		case f_TwCenMTCondensed_SameKind: break;
		case f_ModernNo20_SameKind: break;
		case f_CopprpGothBT_SameKind: break;
		case f_BankGothicMdBT_SameKind: break;
		case f_OCRAExtended_SameKind: break;
		case f_MSOutlook_SameKind: break;
		case f_Playbill_SameKind: break;	
		case f_Vrinda_SameKind: break;
		case f_Kartika_SameKind: break;	
		case f_PalaceScriptMT_SameKind: break;	
		case f_MicrosoftYaHei_SameKind: break;
		case f_Batang_SameKind: break;		
		case f_YunDesignWeb_SameKind: break;
		case f_HanComBatangExt_SameKind: break;
		case f_MicrosoftJhengHei_SameKind: break;
		case f_Gulim_SameKind:break;
		default: 
			if ( wCode>0xFF )
				nFontFlag = f_Batang_SameKind; 
			else
				nFontFlag = f_Arial_SameKind; 
			break;
	}
	return nFontFlag;
}

BrINT32	CUtil::getFontFlag(BrLPWORD pFaceName, BrWORD wCode, BrBOOL bOdtDocType)
{
	BrINT nLen = 0;
	nLen = BrWcsLen(pFaceName);

	BrINT32 nFontFlag = f_Base_SameKind; 

	BrUSHORT cNCode = BrToLower(pFaceName[0]);

	switch(cNCode)
	{
		case 0xAC00:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xB294, 0xC548, 0xC0C1, 0xC218, 0xCCB4, 0x00 };	//가는안상수체	6
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_GaneunAnsangsooche_SameKind;
			}
			break;
		case 0xAD74:
			if(nLen == 2)
			{
				if(pFaceName[1] == 0xb9bc) //굴림
					nFontFlag = f_Gulim_SameKind;				
			}
			else if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = {0xb9bc, 0xccb4, 0x00 };//굴림체
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Gullimche_SameKind;
			}
			break;
		case 0xAD75:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xC740, 0xC548, 0xC0C1, 0xC218, 0xCCB4, 0x00 };	//굵은안상수체	6
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_GukeunAnsangsooche_SameKind;
			}
			break;
		case 0xad81:
			if(nLen == 2)
			{
				if(pFaceName[1] == 0xc11c) //궁서
					nFontFlag = f_Gungseo_SameKind;									
			}
			else if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = {0xc11c, 0xccb4, 0x00 };//궁서체
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Gungseoche_SameKind;			
			}
			break;
		case 0xB098:
			if(nLen == 4)
			{			
				BrUSHORT wLocalFont[] = { 0xB214, 0xACE0, 0xB515, 0x00 }; //나눔고딕
				BrUSHORT wLocalFont2[] = { 0xB214, 0xBA85, 0xC870, 0x00 }; //나눔명조

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_NaNumGodik_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_NaNumMyeongjo_SameKind;
			}
			break;
		case 0xb3cb:
			if(nLen == 2)
			{
				if(pFaceName[1] == 0xc6c0) //돋음
					nFontFlag = f_Dotum_SameKind;
			}
			else if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = {0xc6c0, 0xccb4, 0x00 };//돋음체
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Dotumche_SameKind;			
			}
			break;
		case 0xb9d1:
			if(nLen == 5)
			{
				BrUSHORT wLocalFont[] = {0xc740, 0x20, 0xace0, 0xb515, 0x00}; 	//맑은 고딕
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_MakeunGodik_SameKind;
			}
			else if(nLen == 4)	// SRG-2379
			{
				BrUSHORT wLocalFont[] = {0xc740, 0xace0, 0xb515, 0x00}; 	//맑은고딕
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_MakeunGodik_SameKind;
			}
			break;
		case 0xBB38:
			if(nLen == 7)
			{
				BrUSHORT wLocalFont[] = { 0xCCB4, 0xBD80, 0x20, 0xB3CB, 0xC74C, 0xCCB4, 0x00 };	//문체부 돋음체
				BrUSHORT wLocalFont2[] = { 0xCCB4, 0xBD80, 0x20, 0xBC14, 0xD0D5, 0xCCB4, 0x00 };	//문체부 바탕체

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_MunchebuDotumche_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_MunchebuBatangche_SameKind;
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xCCB4, 0xBD80, 0x20, 0xC4F0, 0xAE30, 0x20, 0xC815, 0xCCB4, 0x00 };	//문체부 쓰기 정체	9
				BrUSHORT wLocalFont2[] = { 0xCCB4, 0xBD80, 0x20, 0xD6C8, 0xBBFC, 0xC815, 0xC74C, 0xCCB4, 0x00 };	//문체부 훈민정음체	9

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_MunchebuSseugijungche_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_MunchebuHunminjungeumche_SameKind;
			}
			else if(nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0xCCB4, 0xBD80, 0x20, 0xAD81, 0xCCB4, 0x20, 0xC815, 0xC790, 0xCCB4, 0x00 };	//문체부 궁체 정자체	10
				BrUSHORT wLocalFont2[] = { 0xCCB4, 0xBD80, 0x20, 0xAD81, 0xCCB4, 0x20, 0xD758, 0xB9BC, 0xCCB4, 0x00 };	//문체부 궁체 흘림체	10
				BrUSHORT wLocalFont3[] = { 0xCCB4, 0xBD80, 0x20, 0xC81C, 0xBAA9, 0x20, 0xB3CB, 0xC74C, 0xCCB4, 0x00 };	//문체부 제목 돋음체	10
				BrUSHORT wLocalFont4[] = { 0xCCB4, 0xBD80, 0x20, 0xC81C, 0xBAA9, 0x20, 0xBC14, 0xD0D5, 0xCCB4, 0x00 };	//문체부 제목 바탕체	10

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_MunchebugungcheJungjache_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_MunchebugungcheHeulrimche_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					nFontFlag = f_MunchebuJemokDotumche_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont4, nLen-1))
					nFontFlag = f_MunchebuJemokBatangche_SameKind;
			}
			break;
		case 0xbc14:
			if(nLen == 2)
			{
				if(pFaceName[1] == 0xd0d5) //바탕
					nFontFlag = f_Batang_SameKind;
			}
			else if(nLen == 3)
			{
				if(pFaceName[1] == 0xd0d5 && pFaceName[2] == 0xccb4) //바탕체
					nFontFlag = f_Batangche_SameKind;
			}
			break;
		case 0xc0c8:
			if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = { 0xad74, 0xb9bc, 0x00 }; //새굴림 3
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_SaeGulim_SameKind;
			}			
			break;
		case 0xc2e0:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xBA85, 0x0020, 0xB514, 0xB098, 0xB8E8, 0x00 }; //신명 디나루 6
				BrUSHORT wLocalFont2[] = { 0xBA85, 0xC870, 0xD655, 0xC7A5, 0xB458, 0x00 }; //신명조확장둘 6
				BrUSHORT wLocalFont3[] = { 0xBA85, 0xC870, 0xD655, 0xC7A5, 0xC14B, 0x00 }; //신명조확장셋 6
				BrUSHORT wLocalFont4[] = { 0xBa85, 0x0020, 0xD0DC, 0xBA85, 0xC870, 0x00 }; //신명 태명조 6
				BrUSHORT wLocalFont5[] = { 0xBa85, 0x0020, 0xACAC, 0xBA85, 0xC870, 0x00 }; //신명 견명조 6
				
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_HanComBatangExt_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont2, nLen-1))
					nFontFlag = f_Kartika_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont3, nLen-1))
					nFontFlag = f_Kartika_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont4, nLen-1))		// XPD-19029
					nFontFlag = f_Batang_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont5, nLen-1))
					nFontFlag = f_Batang_SameKind;
			}
			else if(nLen == 7)
			{
				BrUSHORT wLocalFont[] = { 0xBA85, 0xC870, 0xD655, 0xC7A5, 0xD558, 0xB098, 0x00 }; //신명조확장하나 7
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}	
			break;
		case 0xC548:
			if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xC0C1, 0xC218, 0x32, 0x30, 0x30, 0x36, 0xAC00, 0xB294, 0x00 };	//안상수2006가는	9
				BrUSHORT wLocalFont2[] = { 0xC0C1, 0xC218, 0x32, 0x30, 0x30, 0x36, 0xAD75, 0xC740, 0x00 };	//안상수2006굵은	9
				BrUSHORT wLocalFont3[] = { 0xC0C1, 0xC218, 0x32, 0x30, 0x30, 0x36, 0xC911, 0xAC04, 0x00 };	//안상수2006중간	9

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_Ansangsoo2006Ganeun_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_Ansangsoo2006Gukeun_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					nFontFlag = f_Ansangsoo2006Joonggan_SameKind;
			}
			break;
		case 0xC591:
			if(nLen == 6)
			{
				if(pFaceName[1] == 0xC7AC)
				{
					if(pFaceName[2] == 0xAE68)
					{
						BrUSHORT wLocalFont[] = { 0xBE44, 0xCCB4, 0x62, 0x00 };	//양재깨비체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeKkaebicheB_SameKind;
					}
					else if(pFaceName[2] == 0xAF43)
					{
						BrUSHORT wLocalFont[] = { 0xAC8C, 0xCCB4, 0x6D, 0x00 };	//양재꽃게체M	6	
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeKkotgecheM_SameKind;
					}
					else if(pFaceName[2] == 0xB09C)
					{
						BrUSHORT wLocalFont[] = { 0xCD08, 0xCCB4, 0x6D, 0x00 };	//양재난초체M	6	
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeNanchocheM_SameKind;
					}
					else if(pFaceName[2] == 0xB9E4)
					{
						BrUSHORT wLocalFont[] = { 0xD654, 0xCCB4, 0x73, 0x00 };	//양재매화체S	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeMaehwacheS_SameKind;
					}
					else if(pFaceName[2] == 0xBC31)
					{
						BrUSHORT wLocalFont[] = { 0xB450, 0xCCB4, 0x62, 0x00 };	//양재백두체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeBaekdoocheB_SameKind;
					}
					else if(pFaceName[2] == 0xBCA8)
					{
						BrUSHORT wLocalFont[] = { 0xB77C, 0xCCB4, 0x6D, 0x00 };	//양재벨라체M	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeBelracheM_SameKind;
					}
					else if(pFaceName[2] == 0xBD93)
					{
						BrUSHORT wLocalFont[] = { 0xAF43, 0xCCB4, 0x6C, 0x00 };	//양재붓꽃체L	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeButkkotcheL_SameKind;
					}
					else if(pFaceName[2] == 0xC18C)
					{
						BrUSHORT wLocalFont[] = { 0xC2AC, 0xCCB4, 0x73, 0x00 };	//양재소슬체S	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeSoseulcheS_SameKind;
					}
					else if(pFaceName[2] == 0xC640)
					{
						BrUSHORT wLocalFont[] = { 0xB2F9, 0xCCB4, 0x6D, 0x00 };	//양재와당체M	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeWadangcheM_SameKind;
					}
					else if(pFaceName[2] == 0xC774)
					{
						BrUSHORT wLocalFont[] = { 0xB2C8, 0xC15C, 0xCCB4, 0x00 };	//양재이니셜체	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeInitialche_SameKind;
					}
					else if(pFaceName[2] == 0xCC38)
					{
						BrUSHORT wLocalFont[] = { 0xC22F, 0xCCB4, 0x62, 0x00 };	//양재참숯체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeChamsutcheB_SameKind;
					}
					else if(pFaceName[2] == 0xD2BC)
					{
						BrUSHORT wLocalFont[] = { 0xD2BC, 0xCCB4, 0x62, 0x00 };	//양재튼튼체B	6
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeTeunteuncheB_SameKind;
					}
				}
			}
			else if(nLen == 7)
			{
				if(pFaceName[1] == 0xC7AC)
				{
					if(pFaceName[2] == 0xB2E4)
					{
						BrUSHORT wLocalFont[] = { 0xC6B4, 0xBA85, 0xC870, 0x6D, 0x00 };	//양재다운명조M	7	
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeDaunMyeongjoM_SameKind;
					}
					else if(pFaceName[2] == 0xBCF8)
					{
						BrUSHORT wLocalFont[] = { 0xBAA9, 0xAC01, 0xCCB4, 0x6D, 0x00 };	//양재본목각체M	7
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_YangjaeBonmokgakcheM_SameKind;
					}
				}
			}
			break;
		case 0xC57D:
			if(nLen == 2)
			{
				BrUSHORT wLocalFont[] = { 0xBB3C, 0x00 }; //약물 2
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}			
			break;
		case 0xC601:
			if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0xBB38, 0xAFB8, 0xBBF8, 0xAE30, 0x28, 0xAC00, 0x29, 0x00 }; //영문꾸미기(가) 8
				BrUSHORT wLocalFont2[] = { 0xBB38, 0xAFB8, 0xBBF8, 0xAE30, 0x28, 0xB098, 0x29, 0x00 }; //영문꾸미기(나) 8
				BrUSHORT wLocalFont3[] = { 0xBB38, 0xAFB8, 0xBBF8, 0xAE30, 0x28, 0xB2E4, 0x29, 0x00 }; //영문꾸미기(다) 8

				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont2, nLen-1))
					nFontFlag = f_Kartika_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont3, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}
		case 0xc724:
			if(nLen == 7)
			{
				BrUSHORT wLocalFont[] = { 0xB514, 0xC790, 0xC778, 0xC6F9, 0xACE0, 0xB515, 0x00 }; //윤디자인웹고딕 7
				BrUSHORT wLocalFont2[] = { 0xB514, 0xC790, 0xC778, 0xC6F9, 0xBA85, 0xC870, 0x00 }; //윤디자인웹명조 7

				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_YunDesignWeb_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont2, nLen-1))
					nFontFlag = f_YunDesignWeb_SameKind;
			}
			else if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xB514, 0xC790, 0xC778, 0xACE0, 0xB515, 0x00 }; //윤디자인고딕 6		
				BrUSHORT wLocalFont2[] = { 0xB514, 0xC790, 0xC778, 0xBA85, 0xC870, 0x00 }; //윤디자인명조 6		

				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Jokerman_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont2, nLen-1))
					nFontFlag = f_YunDesignWeb_SameKind;
			}
			break;
		case 0xc740:
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0x20, 0xBC14, 0xD0D5, 0x00 }; //은 바탕 4
				BrUSHORT wLocalFont2[] = { 0x20, 0xB3CB, 0xC6C0, 0x00 }; //은 돋움 4

				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_UnBatang_SameKind;
				else if(GetFontIndexByName(pFaceName, wLocalFont2, nLen-1))
					nFontFlag = f_UnBatang_SameKind;
			}
			break;
		case 0xc88b:
			if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0xC740, 0x005F, 0xBC14, 0xB2E4, 0xCE5C, 0xAD6C, 0xB4E4, 0x00 }; //좋은_바다친구들 8
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MakeunGodik_SameKind;
			}
		case 0xCABD:
			if(nLen == 2)
			{
				BrUSHORT wLocalFont[] = { 0xC790, 0x00 }; //쪽자 2
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}			
			break;
		case 0xC911:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xAC04, 0xC548, 0xC0C1, 0xC218, 0xCCB4, 0x00 };	//중간안상수체	6
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_JoongganAnsangsooche_SameKind;
			}
			break;
		case 0xD0DC:
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0x20, 0xB098, 0xBB34, 0x00 };	//태 나무	4
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_Taenamoo_SameKind;
			}
			break;
		case 0xD39C:
			if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = { 0xD758, 0xB9BC, 0x00 };	//펜흘림	3
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_Penheulrim_SameKind;
			}
			break;
		case 0xD3F4:
			if(pFaceName[1]==0xb77c && pFaceName[2]==0xb9ac && pFaceName[3]==0xc2a4)	// 라리스
			{
				if(nLen == 6)
				{
					BrUSHORT wLocalFont[] = { 0xBC14, 0xD0D5, 0x00 }; //폴라리스바탕
					if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
						nFontFlag = f_HanComBatang_SameKind;
				}
				else if(nLen == 7)
				{
					BrUSHORT wLocalFont[] = { 0xc911, 0xace0, 0xb515, 0x0000 };		//폴라리스중고딕
					if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
						nFontFlag = f_HanyangJungGodik_SameKind;
				}
				else if(nLen == 13)
				{
					BrUSHORT wLocalFont[] = { 0xACE0, 0xB515, 0x002D, 0xD734, 0xBA3C, 0xACE0, 0xB515, 0xD638, 0xD658, 0x0000 }; 
					BrUSHORT wLocalFont1[] = { 0xBA85, 0xC870, 0x002D, 0xD734, 0xBA3C, 0xBA85, 0xC870, 0xD638, 0xD658, 0x0000 }; 

					if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
						nFontFlag = f_HyumeonGothic_SameKind;		//폴라리스고딕-휴먼고딕호환
					else if(GetFontIndexByName(&pFaceName[3], wLocalFont1, nLen-4))
						nFontFlag = f_HyumeonMyeongjo_SameKind;		//폴라리스명조-휴먼명조호환
				}
				else if(nLen == 15)
				{
					BrUSHORT wLocalFont[] = { 0xc0c8, 0xB3CB, 0xC6C0, 0x002d, 0xd568, 0xcd08, 0xb86c, 0xB3CB, 0xC6C0, 0xd638, 0xd658, 0x0000 };		//폴라리스새돋움-함초롬돋움호환 15
					BrUSHORT wLocalFont2[] = { 0xc0c8, 0xbc14, 0xd0d5, 0x002d, 0xd568, 0xcd08, 0xb86c, 0xbc14, 0xd0d5, 0xd638, 0xd658, 0x0000 };	//폴라리스새바탕-함초롬바탕호환 15

					if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
						nFontFlag = f_HamChoromDotum_SameKind;
					else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
						nFontFlag = f_HamChoromBatang_SameKind;
				}
			}
			
			break;
		case 0xd55c:
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0xBC14, 0xD0D5, 0x00 }; //한컴바탕 4
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_HanComBatang_SameKind;
			}
			else if(nLen == 5)
			{
				if(pFaceName[1] == 0xC591)	//한양
				{
					BrUSHORT wLocalFont1[] = { 0xACAC, 0xACE0, 0xB515, 0x00 };		//한양견고딕 5
					BrUSHORT wLocalFont2[] = { 0xACAC, 0xBA85, 0xC870, 0x00 };		//한양견명조 5
					BrUSHORT wLocalFont3[] = { 0xC2E0, 0xBA85, 0xC870, 0x00 };		//한양신명조 5
					BrUSHORT wLocalFont4[] = { 0xC911, 0xACE0, 0xB515, 0x00 };		//한양중고딕 5
					if(GetFontIndexByName(&pFaceName[1], wLocalFont1, nLen-2))
						nFontFlag = f_HanyangGyeonGodik_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_HanyangGyeonMyeongjo_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))
					{
						// HEJ-1624 (ODT 540과의 호환성을 위하여)
						if ( bOdtDocType )
							nFontFlag = f_HanyangSinMyeongjo_SameKind;
						else
							nFontFlag = f_Batang_SameKind;	// f_HanyangSinMyeongjo_SameKind;
					}
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))
						nFontFlag = f_HanyangJungGodik_SameKind;
				}
			}
			else if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0xBC14, 0xD0D5, 0xD655, 0xC7A5, 0x00 }; //한컴바탕확장 6
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_HanComBatangExt_SameKind;
			}
			else if(nLen == 7)
			{
				if(pFaceName[1] == 0xCEF4 && pFaceName[2] == 0x20)
				{
					if(pFaceName[3] == 0xBC31)
					{
						BrUSHORT wLocalFont[] = { 0xC81C, 0x20, 0x62, 0x00 };	//한컴 백제 B	7
						BrUSHORT wLocalFont2[] = { 0xC81C, 0x20, 0x6D, 0x00 };	//한컴 백제 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_HanComBaekjeB_SameKind;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							nFontFlag = f_HanComBaekjeM_SameKind;
					}
					else if(pFaceName[3] == 0xC18C)
					{
						BrUSHORT wLocalFont[] = { 0xB9DD, 0x20, 0x62, 0x00 };	//한컴 소망 B	7
						BrUSHORT wLocalFont2[] = { 0xB9DD, 0x20, 0x6D, 0x00 };	//한컴 소망 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_HanComSomangB_SameKind;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							nFontFlag = f_HanComSomangM_SameKind;
					}
					else if(pFaceName[3] == 0xC194)
					{
						BrUSHORT wLocalFont[] = { 0xC78E, 0x20, 0x62, 0x00 };	//한컴 솔잎 B	7
						BrUSHORT wLocalFont2[] = { 0xC78E, 0x20, 0x6D, 0x00 };	//한컴 솔잎 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_HanComSolipB_SameKind;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							nFontFlag = f_HanComSolipM_SameKind;
					}
					else if(pFaceName[3] == 0xC724)
					{
						BrUSHORT wLocalFont[] = { 0xCCB4, 0x20, 0x62, 0x00 };	//한컴 윤체 B	7
						BrUSHORT wLocalFont2[] = { 0xCCB4, 0x20, 0x6C, 0x00 };	//한컴 윤체 L	7
						BrUSHORT wLocalFont3[] = { 0xCCB4, 0x20, 0x6D, 0x00 };	//한컴 윤체 M	7

						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_HanComYooncheB_SameKind;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont2, nLen-4))
							nFontFlag = f_HanComYooncheL_SameKind;
						else if(GetFontIndexByName(&pFaceName[3], wLocalFont3, nLen-4))
							nFontFlag = f_HanComYooncheM_SameKind;
					}

				}
			}
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0x20, 0xCFE8, 0xC7AC, 0xC988, 0x20, 0x62, 0x00 };	//한컴 쿨재즈 B	8
				BrUSHORT wLocalFont2[] = { 0xCEF4, 0x20, 0xCFE8, 0xC7AC, 0xC988, 0x20, 0x6C, 0x00 };	//한컴 쿨재즈 L	8
				BrUSHORT wLocalFont3[] = { 0xCEF4, 0x20, 0xCFE8, 0xC7AC, 0xC988, 0x20, 0x6D, 0x00 };	//한컴 쿨재즈 M	8

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_HanComCooljazzB_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_HanComCooljazzL_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					nFontFlag = f_HanComCooljazzM_SameKind;
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0x20, 0xBC14, 0xAC90, 0xC138, 0xC77C, 0x20, 0x62, 0x00 };	//한컴 바겐세일 B	9
				BrUSHORT wLocalFont2[] = { 0xCEF4, 0x20, 0xBC14, 0xAC90, 0xC138, 0xC77C, 0x20, 0x6D, 0x00 };	//한컴 바겐세일 M	9

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_HanComBargainsaleB_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_HanComBargainsaleM_SameKind;
			}
			else if(nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0xCEF4, 0x20, 0xC724, 0xACE0, 0xB515, 0x20, 0x32, 0x33, 0x30, 0x00 };	//한컴 윤고딕 230	10
				BrUSHORT wLocalFont2[] = { 0xCEF4, 0x20, 0xC724, 0xACE0, 0xB515, 0x20, 0x32, 0x34, 0x30, 0x00 };	//한컴 윤고딕 240	10
				BrUSHORT wLocalFont3[] = { 0xCEF4, 0x20, 0xC724, 0xACE0, 0xB515, 0x20, 0x32, 0x35, 0x30, 0x00 };	//한컴 윤고딕 250	10

				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_HanComYoonGodik230_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont2, nLen-1))
					nFontFlag = f_HanComYoonGodik240_SameKind;
				else if(GetFontIndexByName(&pFaceName[0], wLocalFont3, nLen-1))
					nFontFlag = f_HanComYoonGodik250_SameKind;
			}
			break;
		case 0xd568:	//함			
			if(nLen == 5)
			{
				if(pFaceName[1]==0xcd08 && pFaceName[2]==0xb86c)	//초롬
				{
					BrUSHORT wLocalFont[] = { 0xB3CB, 0xC6C0, 0x00 };	//함초롬돋움	5
					BrUSHORT wLocalFont2[] = { 0xBC14, 0xD0D5, 0x00 };	//함초롬바탕	5

					if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
						nFontFlag = f_HamChoromDotum_SameKind;
					else if(GetFontIndexByName(&pFaceName[2], wLocalFont2, nLen-3))
						nFontFlag = f_HamChoromBatang_SameKind;
				}
			}
			else if(nLen == 8)
			{
				if(pFaceName[1]==0xcd08 && pFaceName[2]==0xb86c)	//초롬
				{
					BrUSHORT wLocalFont[] = {0xb3cb, 0xc6c0, 0x20, 0xd655, 0xc7a5,0x00};	
					if (memcmp(wLocalFont, &pFaceName[3], 10) == 0)
						nFontFlag = f_HamChoromDotumHwakjang_SameKind;	 //함초롬돋움 확장 8
				}
			}
			break;
		case 0xD654:
			if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = { 0xC0B4, 0xD45C, 0x00 }; //화살표 3
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}			
			break;
		case 0xd6c8:	//훈
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0xBBFC, 0xACE0, 0xC5B4, 0xBA85, 0xC870, 0x00 }; //훈민고어명조 6
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}
			else if(nLen == 7)
			{
				BrUSHORT wLocalFont[] = { 0xBBFC, 0xC77C, 0xC5B4, 0xC911, 0xACE0, 0xB515, 0x00 }; //훈민일어중고딕 7
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0xBBFC, 0xC77C, 0xBCF8, 0xC5B4, 0x73, 0x6A, 0x69, 0x73, 0x00 }; //훈민일본어sJIS 9
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_CurlzMT_SameKind;
			}
			break;
		case 0xd734:	// 휴
			if(pFaceName[1] == 0xba3c)	// 먼
			{
				if(nLen == 4)
				{
					BrUSHORT wLocalFont[] = {  0xACE0, 0xB515, 0x00 }; 
					BrUSHORT wLocalFont1[] = {  0xba85, 0xc870, 0x00 }; 
					BrUSHORT wLocalFont2[] = {  0xc61b, 0xccb4, 0x00 }; 

					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_HyumeonGothic_SameKind;		//휴먼고딕 4
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont1, nLen-2))
						nFontFlag = f_HyumeonMyeongjo_SameKind;		//휴먼명조 4
					else if ( GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_HyumeonYetche_SameKind;		//휴먼옛체 4
				}
				else if ( nLen == 5)
				{
					BrUSHORT wLocalFont1[] = {  0xb9e4, 0xc9c1, 0xccb4, 0x00 }; 
					BrUSHORT wLocalFont2[] = {  0xbaa8, 0xc74c, 0x74, 0x00 }; 
					BrUSHORT wLocalFont3[] = {  0xc544, 0xbbf8, 0xccb4, 0x00 }; 
					BrUSHORT wLocalFont4[] = { 0xc5d1, 0xc2a4, 0xd3ec, 0x00 }; 
					BrUSHORT wLocalFont5[] = {  0xd3b8, 0xc9c0, 0xccb4, 0x00 }; 

					if(GetFontIndexByName(&pFaceName[1], wLocalFont1, nLen-2))
						nFontFlag = f_HyumeonMagicChe_SameKind;	//휴먼매직체 5
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_HyumeonMoeumT_SameKind;	//휴먼모음T 5
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))	
						nFontFlag = f_HyumeonAmiche_SameKind;	//휴먼아미체 5
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))	
						nFontFlag = f_HyumeonExpo_SameKind;	//휴먼엑스포 5
					else if (GetFontIndexByName(&pFaceName[1], wLocalFont5, nLen-2))	
						nFontFlag = f_HyumeonPyeonjiche_SameKind;	//휴먼편지체 5
				}	
				else if(nLen == 6)
				{
					BrUSHORT wLocalFont[] = { 0xAC00, 0xB294, 0xC0D8, 0xCCB4, 0x00 };	//휴먼가는샘체	6
					BrUSHORT wLocalFont2[] = { 0xAC00, 0xB294, 0xD338, 0xCCB4, 0x00 };	//휴먼가는팸체	6
					BrUSHORT wLocalFont3[] = { 0xC911, 0xAC04, 0xC0D8, 0xCCB4, 0x00 };	//휴먼중간샘체	6
					BrUSHORT wLocalFont4[] = { 0xC911, 0xAC04, 0xD338, 0xCCB4, 0x00 };	//휴먼중간팸체	6

					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag =  f_HyumeonGaneunSaemche_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag =  f_HyumeonGaneunPaemche_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))
						nFontFlag =  f_HyumeonJoongganSaemche_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))
						nFontFlag =  f_HyumeonJoongganPaemche_SameKind;
				}
				else if ( nLen == 8 )
				{
					BrUSHORT wLocalFont[] = { 0xb465, 0xadfc, 0xd5e4, 0xb4dc, 0xb77c, 0xc778, 0x00 }; 

					if (GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_HyumeonDunggeunHaedeuLine_SameKind;	//휴먼둥근헤드라인 8
				}
			}
			break;
		case 0x5b8b:			
			if(nLen == 2)
			{
				BrUSHORT wLocalFont[] = { 0x4f53, 0x00 }; //송체 2
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MTExtra_SameKind;
			}
			else if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0x4f53, 0x2d, 0x70, 0x75, 0x61, 0x00 }; //"宋体-PUA"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_SimSun_PAU_SameKind;
			}
			break;
		case 0x61:	// 'a'
			if ( nLen == 5 )
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x61, 0x6c, 0x00 }; 
				if (GetFontIndexByName(&pFaceName[0], wLocalFont, 4))
					nFontFlag = f_Arial_SameKind;	//Arial 5
			}
			else if ( nLen == 7 )
			{
				BrUSHORT wLocalFont1[] = { 0x68, 0x61, 0x72, 0x6f, 0x6e, 0x69, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x6e, 0x64, 0x61, 0x6c, 0x75, 0x73, 0x00 }; 
				BrUSHORT wLocalFont3[] = { 0x6c, 0x64, 0x68, 0x61, 0x62, 0x69, 0x00 }; 

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 6) )
					nFontFlag = f_Aharoni_SameKind;	//Aharoni 7
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 6) )
					nFontFlag = f_Andalus_SameKind;	//Andalus 7
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont3, 6) )
					nFontFlag = f_Aldhabi_SameKind;	//Aldhabi 7
			}
			else if ( nLen == 8 )
			{
				BrUSHORT wLocalFont[] = { 0x6c, 0x67, 0x65, 0x72, 0x69, 0x61, 0x6e, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 7) )
					nFontFlag = f_Algerian_SameKind;	//Algerian 8
			}
			else if ( nLen == 9 )
			{
				BrUSHORT wLocalFont1[] = { 0x67, 0x65, 0x6e, 0x63, 0x79, 0x20, 0x66, 0x62, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x70, 0x61, 0x72, 0x61, 0x6a, 0x69, 0x74, 0x61, 0x00 };

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 8) )
					nFontFlag = f_AgencyFB_SameKind;	//Agency FB 9
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 8) )
					nFontFlag = f_Aparajita_SameKind;	 //Aparajita 9
			}
			else if ( nLen == 10 )
			{
				BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x73, 0x61, 0x6e, 0x61, 0x75, 0x70, 0x63, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 9) )
					nFontFlag = f_AngsanaUPC_SameKind;	//AngsanaUPC 10
			}
			else if ( nLen == 11 )
			{
				BrUSHORT wLocalFont1[] = { 0x6e, 0x67, 0x73, 0x61, 0x6e, 0x61, 0x20, 0x6e, 0x65, 0x77, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x72, 0x69, 0x61, 0x6c, 0x20, 0x62, 0x6c, 0x61, 0x63, 0x6b, 0x00 }; 

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 10) )
					nFontFlag = f_AngsanaUPC_SameKind;	//Angsana New 11
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 10) )
					nFontFlag = f_ArialBlack_SameKind;	 //Arial Black 11
			}
			else if ( nLen == 12 )
			{
				if(pFaceName[1] == 0x72)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x61, 0x6c, 0x20, 0x6e, 0x61, 0x72, 0x72, 0x6f, 0x77, 0x00 }; 
					if ( GetFontIndexByName (&pFaceName[1], wLocalFont, nLen-2) )
						nFontFlag = f_ArialNarrow_SameKind;	//Arial Narrow 12
				}
				else if(pFaceName[1] == 0x6D)
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x72, 0x69, 0x63, 0x61, 0x6E, 0x61, 0x20, 0x62, 0x74, 0x00 };	// Americana BT	12
					if ( GetFontIndexByName (&pFaceName[1], wLocalFont, nLen-2) )
						nFontFlag = f_AmericanaBT_SameKind;
				}
			}
			else if ( nLen == 13 )
			{
				BrUSHORT wLocalFont[] = {0x6e,0x64,0x72,0x6f, 0x69, 0x64, 0x20, 0x65, 0x6d, 0x6f, 0x6a, 0x69, 0x00};		
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 12) )
					nFontFlag = f_AndroidEmoji_SameKind;	//Android Emoji
			}
			else if ( nLen == 16 )
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x61, 0x6c, 0x20, 0x75, 0x6e, 0x69, 0x63, 0x6f, 0x64, 0x65, 0x20, 0x6d, 0x73, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 15) )
					nFontFlag = f_ArialUnicodeMS_SameKind;	//Arial Unicode MS 16
			}
			else if ( nLen == 18)
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x61, 0x62, 0x69, 0x63, 0x20, 0x74, 0x79, 0x70, 0x65, 0x73, 0x65, 0x74, 0x74, 0x69, 0x6e, 0x67, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 17) )
					nFontFlag = f_ArabicTypesetting_SameKind;	//Arabic Typesetting 18
			}
			else if ( nLen == 21)
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x61, 0x6c, 0x20, 0x72, 0x6f, 0x75, 0x6e, 0x64, 0x65, 0x64, 0x20, 0x6d, 0x74, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; //Arial Rounded MT Bold 21
				if ( GetFontIndexByName (pFaceName, wLocalFont, nLen - 1) )
					nFontFlag = f_ArialRoundedMTBold_SameKind;	//Arial Rounded MT Bold 21
			}
			break;
		case 0x62:
			if(nLen == 6)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wBatang[] = {0x61, 0x74, 0x61, 0x6E, 0x67, 0x00};		//Batang
					if(GetFontIndexByName(pFaceName, wBatang, nLen -1))
						nFontFlag = f_Batang_SameKind;
				}				
			}
			else if ( nLen == 7 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x6c, 0x6c, 0x20, 0x6d, 0x74, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 6) )
					nFontFlag = f_BellMT_SameKind;	//Bell MT 7
			}
			else if ( nLen == 8 )
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x6f, 0x61, 0x64, 0x77, 0x61, 0x79, 0x00 };
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 7) )
					nFontFlag = f_Broadway_SameKind;	 //Broadway 8
			}
			else if ( nLen == 9 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x64, 0x6f, 0x6e, 0x69, 0x20, 0x6d, 0x74, 0x00 };
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 8) )
					nFontFlag = f_BodoniMT_SameKind;	  //Bodoni MT 9
			}
			else if ( nLen == 10 )
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x75, 0x68, 0x61, 0x75, 0x73, 0x20, 0x39, 0x33, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 9) )
					nFontFlag = f_Bauhaus93_SameKind;	  //Bauhaus 93 10
			}
			else if ( nLen == 12 )
			{
				if(BrToLower(pFaceName[1]) == 0x72)
				{
					BrUSHORT wLocalFont4[] = { 0x6f, 0x77, 0x61, 0x6c, 0x6c, 0x69, 0x61, 0x75, 0x70, 0x63, 0x00 }; 
					if ( GetFontIndexByName (&pFaceName[1], wLocalFont4, nLen -2))
						nFontFlag = f_BrowalliaUPC_SameKind;	 //BrowalliaUPC 12
				}
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
					if(BrToLower(pFaceName[2]) == 0x6f)
					{
						BrUSHORT wLocalFont3[] = { 0x6b, 0x20, 0x61, 0x6e, 0x74, 0x69, 0x71, 0x75, 0x61, 0x00 }; 
						if(GetFontIndexByName (&pFaceName[2], wLocalFont3, nLen - 3))
							nFontFlag = f_BookAntiqua_SameKind;	 //Book Antiqua 12		
					}					
				}
			}
			else if ( nLen == 13 )
			{
				BrUSHORT wLocalFont[] = { 0x6C, 0x69, 0x70, 0x70, 0x6F, 0x20, 0x62, 0x6C, 0x6B, 0x20, 0x62, 0x74, 0x00 };	// Blippo Blk BT		13
				BrUSHORT wLocalFont2[] = { 0x72, 0x6f, 0x77, 0x61, 0x6c, 0x6c, 0x69, 0x61, 0x20, 0x6e, 0x65, 0x77, 0x00 }; 
				
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 12) )
					nFontFlag = f_Castellar_SameKind;	
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 12) )
					nFontFlag = f_BrowalliaNew_SameKind;	//Browallia New 13
			}
			else if ( nLen == 14 )
			{
				BrUSHORT wLocalFont2[] = { 0x65, 0x72, 0x6c, 0x69, 0x6e, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x66, 0x62, 0x00 }; 
				BrUSHORT wLocalFont3[] = { 0x6c, 0x61, 0x63, 0x6b, 0x61, 0x64, 0x64, 0x65, 0x72, 0x20, 0x69, 0x74, 0x63, 0x00 }; 
				BrUSHORT wLocalFont4[] = { 0x72, 0x69, 0x74, 0x61, 0x6e, 0x6e, 0x69, 0x63, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; 
				BrUSHORT wLocalFont5[] = { 0x72, 0x75, 0x73, 0x68, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x20, 0x62, 0x74, 0x00 }; // BrushScript BT 14
				BrUSHORT wLocalFont6[] = { 0x61, 0x6C, 0x6C, 0x6F, 0x6F, 0x6E, 0x20, 0x78, 0x62, 0x64, 0x20, 0x62, 0x74, 0x00 };	// Balloon XBd BT 14

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 13) )
					nFontFlag = f_BerlinSansFB_SameKind;	//Berlin Sans FB 14
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont3, 13) )
					nFontFlag = f_BlackadderITC_SameKind;	 //Blackadder ITC 14
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont4, 13) )
					nFontFlag = f_BritannicBold_SameKind;	 //Britannic Bold 14
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont5, 13) )
					nFontFlag = f_BookAntiqua_SameKind;	 
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont6, 13) )
					nFontFlag = f_BalloonXBdBT_SameKind;	 
			}
			else if ( nLen == 15 )
			{
				BrUSHORT wLocalFont1[] = { 0x6f, 0x64, 0x6f, 0x6e, 0x69, 0x20, 0x6d, 0x74, 0x20, 0x62, 0x6c, 0x61, 0x63, 0x6b, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x72, 0x75, 0x73, 0x68, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x20, 0x6d, 0x74, 0x00 };	// Brush Script MT 15
				
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 14) )
					nFontFlag = f_BodoniMTBlack_SameKind;	//Bodoni MT Black 15
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, nLen-1) )
					nFontFlag = f_BrushScriptMT_SameKind;	
			}
			else if ( nLen == 16 )
			{
				if(pFaceName[1] == 0x72)
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x64, 0x6C, 0x65, 0x79, 0x20, 0x68, 0x61, 0x6E, 0x64, 0x20, 0x69, 0x74, 0x63, 0x00 }; 
					if ( GetFontIndexByName (&pFaceName[1], wLocalFont, nLen-2) )
						nFontFlag = f_BradleyHandITC_SameKind;	//Bradley Hand ITC 16
				}
				else if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6E, 0x6B, 0x67, 0x6F, 0x74, 0x68, 0x69, 0x63, 0x20, 0x6D, 0x64, 0x20, 0x62, 0x74, 0x00 };	// BankGothic Md BT	16
					if ( GetFontIndexByName (&pFaceName[1], wLocalFont, nLen-2) )
						nFontFlag = f_BankGothicMdBT_SameKind;
				}				
			}
			else if ( nLen == 17 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x6f, 0x6b, 0x6d, 0x61, 0x6e, 0x20, 0x6f, 0x6c, 0x64, 0x20, 0x73, 0x74, 0x79, 0x6c, 0x65, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 16) )
					nFontFlag = f_BookmanOldStyle_SameKind;	//Bookman Old Style 17
			}
			else if ( nLen == 18 )
			{
				BrUSHORT wLocalFont1[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x31, 0x00 };	// Bookshelf Symbol 1 18
				BrUSHORT wLocalFont2[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x32, 0x00 };	// Bookshelf Symbol 2 18
				BrUSHORT wLocalFont3[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x33, 0x00 };	// Bookshelf Symbol 3 18
				BrUSHORT wLocalFont4[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x34, 0x00 };	// Bookshelf Symbol 4 18
				BrUSHORT wLocalFont5[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x35, 0x00 };	// Bookshelf Symbol 5 18
				BrUSHORT wLocalFont6[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x36, 0x00 };	// Bookshelf Symbol 6 18
				BrUSHORT wLocalFont7[] = { 0x6F, 0x6F, 0x6B, 0x73, 0x68, 0x65, 0x6C, 0x66, 0x20, 0x73, 0x79, 0x6D, 0x62, 0x6F, 0x6C, 0x20, 0x37, 0x00 };	// Bookshelf Symbol 7 18
				
				//if ( GetFontIndexByName (&pFaceName[0], wLocalFont3, nLen-1) )
				//	nFontFlag = f_BrushScriptMT_SameKind;
				//else if ( GetFontIndexByName (&pFaceName[0], wLocalFont4, nLen-1) )
				//	nFontFlag = f_SnellBT_SameKind;
				//else if ( GetFontIndexByName (&pFaceName[0], wLocalFont6, nLen-1) )
				//	nFontFlag = f_BrushScriptMT_SameKind;
				
				if(pFaceName[17] == 0x31)
					nFontFlag = f_Arial_SameKind;
				else if(pFaceName[17] == 0x32)
					nFontFlag = f_Arial_SameKind;
				else if(pFaceName[17] == 0x33)
					nFontFlag = f_BrushScriptMT_SameKind;
				else if(pFaceName[17] == 0x34)
					nFontFlag = f_SnellBT_SameKind;
				else if(pFaceName[17] == 0x35)
					nFontFlag = f_BookshelfSymbol5_SameKind;
				else if(pFaceName[17] == 0x36)
					nFontFlag = f_BrushScriptMT_SameKind;
				else if(pFaceName[17] == 0x37)
					nFontFlag = f_Kartika_SameKind;

			}
			else if ( nLen == 19 )
			{
				BrUSHORT wLocalFont1[] = { 0x65, 0x72, 0x6c, 0x69, 0x6e, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x66, 0x62, 0x20, 0x64, 0x65, 0x6d, 0x69, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x6f, 0x64, 0x6f, 0x6e, 0x69, 0x20, 0x6d, 0x74, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; 
				BrUSHORT wLocalFont3[] = { 0x72, 0x6f, 0x61, 0x64, 0x77, 0x61, 0x79, 0x65, 0x6e, 0x67, 0x72, 0x61, 0x76, 0x65, 0x64, 0x20, 0x62, 0x74, 0x00 }; // BroadwayEngraved BT 19
				
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 18) )
					nFontFlag = f_BerlinSansFBDemi_SameKind;	//Berlin Sans FB Demi 19
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 18 ))
					nFontFlag = f_BodoniMTCondensed_SameKind;	 //Bodoni MT Condensed 19
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont3, 18 ))
					nFontFlag = f_BodoniMT_SameKind; 
			}
			else if ( nLen == 20 )
			{

				BrUSHORT wLocalFont1[] = { 0x61, 0x73, 0x6b, 0x65, 0x72, 0x76, 0x69, 0x6c, 0x6c, 0x65, 0x20, 0x6f, 0x6c, 0x64, 0x20, 0x66, 0x61, 0x63, 0x65, 0x00 };
				BrUSHORT wLocalFont2[] = { 0x65, 0x72, 0x6e, 0x61, 0x72, 0x64, 0x20, 0x6d, 0x74, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; 

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 19) )
					nFontFlag = f_BaskervilleOldFace_SameKind; //Baskerville Old Face 20
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 19 ) )
					nFontFlag = f_BernardMTCondensed_SameKind;	 //Bernard MT Condensed 20
			}
			else if ( nLen == 27 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x64, 0x6f, 0x6e, 0x69, 0x20, 0x6d, 0x74, 0x20, 0x70, 0x6f, 0x73, 0x74, 0x65, 0x72, 0x20, 0x63, 0x6f, 0x6d, 0x70, 0x72, 0x65, 0x73, 0x73, 0x65, 0x64, 0x00 }; 

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 26) )
					nFontFlag = f_BodoniMTPosterCompressed_SameKind; //Bodoni MT Poster Compressed 27
			}
			break;	
		case 0x63:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x72, 0x62, 0x65, 0x6c, 0x00 };			//Corbel 6
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Corbel_SameKind;								
			}
			else if(nLen == 7)
			{
				if(pFaceName[1] == 0x61)
				{
					if(pFaceName[2] == 0x6c)
					{
						BrUSHORT wLocalFont[] = { 0x69, 0x62, 0x72, 0x69, 0x00 };		//Calibri 7
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,4))
							nFontFlag = f_Calibri_SameKind;
					}
					else if(pFaceName[2] == 0x6d)
					{
						BrUSHORT wLocalFont[] = { 0x62, 0x72, 0x69, 0x61, 0x00 };		//Cambria 7
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,4))
							nFontFlag = f_Cambria_SameKind;
					}
					else if(pFaceName[2] == 0x6e)
					{
						BrUSHORT wLocalFont[] = { 0x64, 0x61, 0x72, 0x61, 0x00 };		//Candara 7
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,4))
							nFontFlag = f_Candara_SameKind;
					}					
				}
				else if(pFaceName[1] == 0x65)
				{
					if(pFaceName[2] == 0x6e && pFaceName[3] == 0x74)
					{
						if(pFaceName[4] == 0x61)
						{
							BrUSHORT wLocalFont[] = { 0x75, 0x72, 0x00 };
							if(GetFontIndexByName(&pFaceName[4],wLocalFont,2))			//Centaur 7
								nFontFlag = f_Centaur_SameKind;
						}
						else if(pFaceName[4] == 0x75)
						{
							BrUSHORT wLocalFont[] = { 0x72, 0x79, 0x00 };
							if(GetFontIndexByName(&pFaceName[4],wLocalFont,2))			//Century 7
								nFontFlag = f_Century_SameKind;
						}
					}

				}
				else if(pFaceName[1] == 0x68)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x6C, 0x6C, 0x65, 0x72, 0x00 };	// Chiller 7
					if(GetFontIndexByName(&pFaceName[1],wLocalFont, nLen-2))
						nFontFlag = f_Chiller_SameKind;
				}
				else if(pFaceName[1] == 0x6F)
				{
					BrUSHORT wLocalFont[] = { 0x75, 0x72, 0x69, 0x65, 0x72, 0x00 };	//Courier 7
					if(GetFontIndexByName(&pFaceName[1],wLocalFont, nLen-2 ))
						nFontFlag = f_CourierNew_SameKind;
				}
			}
			else if(nLen == 8)
			{
				if(pFaceName[1] == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x73, 0x6f, 0x6c, 0x61, 0x73, 0x00 };	//Consolas 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_Consolas_SameKind;
				}
				else if(pFaceName[1] == 0x75)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x6C, 0x7A, 0x20, 0x6D, 0x74, 0x00 };	//Curlz MT 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_CurlzMT_SameKind;
				}
			}
			else if(nLen == 9 )
			{
				if(pFaceName[1] == 0x61 )
				{
					BrUSHORT wLocalFont[] = { 0x73, 0x74, 0x65, 0x6c, 0x6c, 0x61, 0x72, 0x00 };	//Castellar 9 
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,7))
						nFontFlag = f_Castellar_SameKind;
				}
				else if(pFaceName[1] == 0x6f )
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x64, 0x69, 0x61, 0x75, 0x70, 0x63, 0x00 };	//CordiaUPC 9 
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,7))
						nFontFlag = f_CordiaUPC_SameKind;
				}
			}
			else if(nLen == 10)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x69, 0x73, 0x74, 0x6f, 0x20, 0x6d, 0x74, 0x00 };	 //Calisto MT 10
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,8))
						nFontFlag = f_CalistoMT_SameKind;
				}
				else if(pFaceName[1] == 0x6f)
				{
					if(pFaceName[2] == 0x6c)
					{
						BrUSHORT wLocalFont[] = { 0x6f, 0x6e, 0x6e, 0x61, 0x20, 0x6d, 0x74, 0x00 };	 //Colonna MT 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_ColonnaMT_SameKind;
					}
					else if(pFaceName[2] == 0x6e)
					{
						BrUSHORT wLocalFont[] = { 0x73, 0x74, 0x61, 0x6e, 0x74, 0x69, 0x61, 0x00 };	 //Constantia 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_Constantia_SameKind;
					}
					else if(pFaceName[2] == 0x72)
					{
						BrUSHORT wLocalFont[] = { 0x64, 0x69, 0x61, 0x20, 0x6e, 0x65, 0x77, 0x00 };	 //Cordia New 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_CordiaUPC_SameKind;
					}
				}
			}
			else if(nLen == 11)
			{
				BrUSHORT wCourierNew[] = {0x6F,0x75,0x72,0x69,0x65,0x72,0x20,0x6E,0x65,0x77,0x00};//Courier New				
				if(GetFontIndexByName(pFaceName, wCourierNew, nLen -1))
					nFontFlag = f_CourierNew_SameKind;
			}
			else if(nLen == 12)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6d, 0x62, 0x72, 0x69, 0x61, 0x20, 0x6d, 0x61, 0x74, 0x68, 0x00 }; //Cambria Math 12
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,10))
						nFontFlag = f_Cambria_SameKind;
				}
				else if(pFaceName[1] == 0x6f)
				{
					if(pFaceName[2] == 0x6f)
					{
						BrUSHORT wLocalFont[] = { 0x70, 0x65, 0x72, 0x20, 0x62, 0x6c, 0x61, 0x63, 0x6b, 0x00 }; //Cooper Black 12
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,nLen-3))
							nFontFlag = f_CooperBlack_SameKind;
					}
					else if(pFaceName[2] == 0x75)
					{
						BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x65, 0x72, 0x31, 0x30, 0x20, 0x62, 0x74, 0x00 };	// Courier10 BT	12
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,nLen-3))
							nFontFlag = f_AmericanaBT_SameKind;
					}
				}
			}
			else if(nLen == 13)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x69, 0x62, 0x72, 0x69, 0x20, 0x6c, 0x69, 0x67, 0x68, 0x74, 0x00 }; //Calibri Light 13
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,11))
						nFontFlag = f_CalibriLight_SameKind;
				}
				else if(pFaceName[1] == 0x6F)
				{			
					if(pFaceName[2] == 0x6F)
					{
						BrUSHORT wLocalFont[] = { 0x70, 0x65, 0x72, 0x20, 0x62, 0x6C, 0x6B, 0x20, 0x62, 0x74, 0x00 };	// Cooper Blk BT 13
						if(GetFontIndexByName(&pFaceName[2],wLocalFont, nLen-3))
							nFontFlag = f_Calibri_SameKind;
					}
					else if(pFaceName[2] == 0x6D)
					{
						BrUSHORT wLocalFont[] = { 0x69, 0x63, 0x20, 0x73, 0x61, 0x6E, 0x73, 0x20, 0x6D, 0x73, 0x00 };	// Comic Sans MS 13
						if(GetFontIndexByName(&pFaceName[2],wLocalFont, nLen-3))
							nFontFlag = f_ComicSansMS_SameKind;
					}
				}
			}
			else if(nLen == 14)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x69, 0x66, 0x6f, 0x72, 0x6e, 0x69, 0x61, 0x6e, 0x20, 0x66, 0x62, 0x00 }; //Californian FB 14
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,12))
						nFontFlag = f_CalifornianFB_SameKind;
				}
				else if(pFaceName[1] == 0x6F)
				{
					BrUSHORT wLocalFont[] = { 0x70, 0x70, 0x72, 0x70, 0x6C, 0x67, 0x6F, 0x74, 0x68, 0x20, 0x62, 0x74, 0x00 };	// CopprplGoth BT 14
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,nLen-2))
						nFontFlag = f_CopprpGothBT_SameKind;
				}
				else if(pFaceName[1] == 0x65)
				{
					if(pFaceName[2] == 0x6e && pFaceName[3] == 0x74)
					{					
						if(pFaceName[4] ==0x73)
						{
							BrUSHORT wLocalFont[] = { 0x63, 0x68, 0x62, 0x6f, 0x6f, 0x6b, 0x20, 0x62, 0x74, 0x00 }; //CentSchbook BT 14
							if(GetFontIndexByName(&pFaceName[4],wLocalFont,9))
								nFontFlag = f_Century_SameKind;
						}
						else if(pFaceName[4] ==0x75)
						{
							BrUSHORT wLocalFont[] = { 0x72, 0x79, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x00 }; //Century Gothic 14
							if(GetFontIndexByName(&pFaceName[4],wLocalFont,9))
								nFontFlag = f_CenturyGothic_SameKind;
						}
					}
				}
			}
			else if(nLen == 15)
			{
				BrUSHORT wLocalFont[] = { 0x6F, 0x6F, 0x70, 0x65, 0x72, 0x20, 0x62, 0x6C, 0x6B, 0x69, 0x74, 0x20, 0x62, 0x74, 0x00 };	// Cooper BlkIt BT 15				
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Calibri_SameKind;
			}
			else if(nLen == 18 )
			{
				BrUSHORT wCenturySchoolbook[] = {0x65, 0x6e, 0x74, 0x75, 0x72, 0x79, 0x20, 0x73, 0x63, 0x68, 0x6f, 0x6f, 0x6c, 0x62, 0x6f, 0x6f, 0x6b, 0x00};  //Century Schoolbook
				if(GetFontIndexByName(pFaceName, wCenturySchoolbook, nLen -1))
					nFontFlag = f_Century_SameKind;
			}
			else if(nLen == 23 )
			{
				BrUSHORT wLocalFont[] = { 0x6F, 0x70, 0x70, 0x65, 0x72, 0x70, 0x6C, 0x61, 0x74, 0x65, 0x20, 0x67, 0x6F, 0x74, 0x68, 0x69, 0x63, 0x20, 0x62, 0x6F, 0x6C, 0x64, 0x00 };	// Copperplate Gothic Bold	23
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_CopperplateGotBold_SameKind;
			}
			else if(nLen == 24 )
			{
				BrUSHORT wLocalFont[] = { 0x6F, 0x70, 0x70, 0x65, 0x72, 0x70, 0x6C, 0x61, 0x74, 0x65, 0x20, 0x67, 0x6F, 0x74, 0x68, 0x69, 0x63, 0x20, 0x6C, 0x69, 0x67, 0x68, 0x74, 0x00 };	// Copperplate Gothic Light	24
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BerlinSansFB_SameKind;
			}
			break;
		case 0x64:
			if(nLen == 5)
			{	
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x76, 0x69, 0x64, 0x00 }; //David 5
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,3))
						nFontFlag = f_TimesNewRoman_SameKind;						
				}
				else if(pFaceName[1] == 0x6F)
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x75, 0x6D, 0x00};  //Dutom
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,3))
						nFontFlag = f_Dotum_SameKind;
				}
			}
			else if(nLen == 8)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x75, 0x6e, 0x70, 0x65, 0x6e, 0x68, 0x00 }; //DaunPenh 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_DaunPenh_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x66)
				{
					BrUSHORT wLocalFont[] = { 0x6b, 0x61, 0x69, 0x2d, 0x73, 0x62, 0x00 }; //DFKai-SB 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_DFKai_SB_SameKind;
				}
			}
			else if(nLen == 9)
			{
				if(pFaceName[1] == 0x6f )
				{
					BrUSHORT wLocalFont[] = { 0x6b, 0x63, 0x68, 0x61, 0x6d, 0x70, 0x61, 0x00 }; //DokChampa 9
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,7))
						nFontFlag = f_DokChampa_SameKind;
				}
			}
			/*else if(nLen == 10)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x69, 0x64, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x00 }; //Droid Sans 10 
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,8))
						nFontFlag = f_DroidSans_SameKind;
				}
			}
			*/
			else if(nLen == 11)
			{	
				/*
				if(pFaceName[1] == 0x65 )
				{
					BrUSHORT wLocalFont[] = { 0x6a, 0x61, 0x76, 0x75, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x00 }; //DejaVu Sans 11
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,9))
						nFontFlag = f_DejaVuSans_SameKind;
				}
				else*/ if(pFaceName[1] == 0x69 )
				{
					if(pFaceName[2] == 0x6c)
					{
						BrUSHORT wLocalFont[] = { 0x6c, 0x65, 0x6e, 0x69, 0x61, 0x75, 0x70, 0x63, 0x00 }; //DilleniaUPC 11
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,8))
							nFontFlag = f_DilleniaUPC_SameKind;
					}					
				}
				else if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x69, 0x64, 0x20, 0x73, 0x65, 0x72, 0x69, 0x66, 0x00};  //Droid Serif
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,9))
						nFontFlag = f_DroidSerif_SameKind;
				}
			}
			else if(nLen == 14)
			{
				BrUSHORT wLocalFont[] = { 0x75, 0x74, 0x63, 0x68, 0x38, 0x30, 0x31, 0x20, 0x72, 0x6D, 0x20, 0x62, 0x74, 0x00 };	// Dutch801 Rm BT 14
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Impact_SameKind;
			}
			else if(nLen == 15)
			{
				BrUSHORT wLocalFont[] = { 0x75, 0x74, 0x63, 0x68, 0x38, 0x30, 0x31, 0x20, 0x78, 0x62, 0x64, 0x20, 0x62, 0x74, 0x00 };	// Dutch801 XBd BT	15
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Castellar_SameKind;
			}
			break;
		case 0x65:
			if(nLen == 6)
			{
				if(pFaceName[1] == 0x62 )
				{
					if(pFaceName[2] == 0x72)
					{
						BrUSHORT wLocalFont[] = { 0x69, 0x6d, 0x61, 0x00 }; //Ebrima 6
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,3))
							nFontFlag = f_Ebrima_SameKind;
					}
				}
			}
			else if(nLen == 8)
			{
				if(pFaceName[1] == 0x6c )
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x70, 0x68, 0x61, 0x6e, 0x74, 0x00 }; //Elephant 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_Elephant_SameKind;
				}
				else if(pFaceName[1] == 0x75 )
				{
					BrUSHORT wLocalFont[] = { 0x70, 0x68, 0x65, 0x6d, 0x69, 0x61, 0x00 }; //Euphemia 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_Euphemia_SameKind;
				}
			}
			else if(nLen == 10)
			{
				if(pFaceName[1] == 0x75 )
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x6F, 0x20, 0x64, 0x6F, 0x74, 0x75, 0x6D, 0x00 };	// Euro Dotum	10
					BrUSHORT wLocalFont2[] = { 0x72, 0x6F, 0x20, 0x67, 0x75, 0x6C, 0x69, 0x6D, 0x00 };	// Euro Gulim	10

					if(GetFontIndexByName(&pFaceName[1],wLocalFont,nLen-2))
						nFontFlag = f_Arial_SameKind;
					else if(GetFontIndexByName(&pFaceName[1],wLocalFont2,nLen-2))
						nFontFlag = f_Arial_SameKind;
				}
			}
			else if(nLen == 11)
			{
				if(pFaceName[1] == 0x75 )
				{
					BrUSHORT wLocalFont[] = { 0x63, 0x72, 0x6f, 0x73, 0x69, 0x61, 0x75, 0x70, 0x63, 0x00 }; //EucrosiaUPC 11
					BrUSHORT wLocalFont2[] = { 0x72, 0x6F, 0x20, 0x62, 0x61, 0x74, 0x61, 0x6E, 0x67, 0x00 };	// Euro Batang 11
					BrUSHORT wLocalFont3[] = { 0x72, 0x6F, 0x20, 0x67, 0x75, 0x6E, 0x67, 0x73, 0x6F, 0x00 };	// Euro Gungso 11
					
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,9))
						nFontFlag = f_EucrosiaUPC_SameKind;
					else if(GetFontIndexByName(&pFaceName[1],wLocalFont2,nLen-2))
						nFontFlag = f_Arial_SameKind;
					else if(GetFontIndexByName(&pFaceName[1],wLocalFont3,nLen-2))
						nFontFlag = f_Arial_SameKind;
				}
			}
			else if(nLen == 12)
			{
				if(pFaceName[1] == 0x6e )
				{
					BrUSHORT wLocalFont[] = { 0x67, 0x72, 0x61, 0x76, 0x65, 0x72, 0x73, 0x20, 0x6d, 0x74, 0x00 }; //Engravers MT 12
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,10))
						nFontFlag = f_EngraversMT_SameKind;
				}
			}
			else if(nLen == 13)
			{
				/*
				if(pFaceName[1] == 0x75 )
				{
					BrUSHORT wLocalFont[] = { 0x70 ,0x68 ,0x65 ,0x6D ,0x69 ,0x61 ,0x20 ,0x75 ,0x63 ,0x61 ,0x73, 0x00};	// Euphemia UCAS
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,11))
						nFontFlag = f_Euphemia_SameKind;
				}
				else if(pFaceName[1] == 0x72 && pFaceName[2] == 0x61 && pFaceName[3] == 0x73 && pFaceName[4] == 0x20)
				*/
				if(pFaceName[1] == 0x72 && pFaceName[2] == 0x61 && pFaceName[3] == 0x73 && pFaceName[4] == 0x20)
				{
					if(BrToLower(pFaceName[5]) == 0x62)
					{
						BrUSHORT wLocalFont[] = { 0x6f, 0x6c, 0x64, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Eras Bold ITC 13
						if(GetFontIndexByName(&pFaceName[5],wLocalFont,7))
							nFontFlag = f_ErasBoldITC_SameKind;
					}
					else if(BrToLower(pFaceName[5]) == 0x64)
					{
						BrUSHORT wLocalFont[] = { 0x65, 0x6d, 0x69, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Eras Demi ITC 13
						if(GetFontIndexByName(&pFaceName[5],wLocalFont,7))
							nFontFlag = f_ErasDemiITC_SameKind;
					}
				}				
			}
			else if(nLen == 14)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x73, 0x20, 0x6c, 0x69, 0x67, 0x68, 0x74, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Eras Light ITC 14
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,12))
						nFontFlag = f_ErasLightITC_SameKind;
				}
			}
			else if(nLen == 15)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x73, 0x20, 0x6d, 0x65, 0x64, 0x69, 0x75, 0x6d, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Eras Medium ITC 15
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,13))
						nFontFlag = f_ErasMediumITC_SameKind;
				}
			}
			else if(nLen == 16)
			{
				BrUSHORT wLocalFont[] = { 0x78, 0x6F, 0x74, 0x63, 0x33, 0x35, 0x30, 0x20, 0x64, 0x6D, 0x62, 0x64, 0x20, 0x62, 0x74, 0x00 };	// Exotc350 DmBd BT	16
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Cambria_SameKind;
			}
			else if(nLen == 17)
			{
				if(pFaceName[1] == 0x73 )
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x6c, 0x6f, 0x20, 0x65, 0x64, 0x65, 0x73, 0x73, 0x61, 0x00 }; //Estrangelo Edessa 17
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,15))
						nFontFlag = f_EstrangeloEdessa_SameKind;
				}
			}
			else if(nLen == 20)
			{
				BrUSHORT wLocalFont[] = { 0x64, 0x77, 0x61, 0x72, 0x64, 0x69, 0x61, 0x6E, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x20, 0x69, 0x74, 0x63, 0x00 };	// Edwardian Script ITC	20
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_LucidaBright_SameKind;
			}
			break;
		case 0x66:
			if(nLen == 5)
			{
				BrUSHORT wLocalFont[] = { 0x6F, 0x72, 0x74, 0x65, 0x00};		//Forte 5
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_Fences_SameKind;
			}
			else if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = {0x65, 0x6E, 0x63, 0x65, 0x73, 0x00};		//Fences 6
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_Fences_SameKind;
			}
			else if(nLen == 8)
			{
				if(pFaceName[1] == 0x61 )
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x73, 0x6f, 0x6e, 0x67, 0x00 }; //FangSong 8
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,6))
						nFontFlag = f_FangSong_SameKind;
				}
			}
			else if(nLen == 10)
			{
				if(pFaceName[1] == 0x72)
				{
					if(pFaceName[2] == 0x61)
					{
						BrUSHORT wLocalFont[] = { 0x6e, 0x6b, 0x72, 0x75, 0x65, 0x68, 0x6c, 0x00 }; //FrankRuehl 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_FrankRuehl_SameKind;
					}
					else if(pFaceName[2] == 0x65)
					{
						BrUSHORT wLocalFont[] = { 0x65, 0x73, 0x69, 0x61, 0x75, 0x70, 0x63, 0x00 }; //FreesiaUPC 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_FreesiaUPC_SameKind;
					}
				}
			}
			else if(nLen == 13)
			{
				if(pFaceName[1] == 0x65 )
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x69, 0x78, 0x20, 0x74, 0x69, 0x74, 0x6c, 0x69, 0x6e, 0x67, 0x00 }; //Felix Titling 13
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,11))
						nFontFlag = f_FelixTitling_SameKind;
				}
				else if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x65, 0x66, 0x72, 0x6D, 0x37, 0x32, 0x31, 0x20, 0x62, 0x74, 0x00 };	// Freefrm721 BT 13
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,11))
						nFontFlag = f_AgencyFB_SameKind;
				}
			}
			else if(nLen == 14)
			{
				if(BrToLower(pFaceName[1] == 0x72))
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x65, 0x68, 0x61, 0x6E, 0x64, 0x35, 0x39, 0x31, 0x20, 0x62, 0x74, 0x00 };	// Freehand591 BT 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Freehand591BT_SameKind;
				}
				else if(BrToLower(pFaceName[1] == 0x75))
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x75, 0x72, 0x61, 0x62, 0x6C, 0x61, 0x63, 0x6B, 0x20, 0x62, 0x74, 0x00 };	// FuturaBlack BT 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_BodoniMT_SameKind;
				}				
			}
			else if(nLen == 16)
			{
				if(BrToLower(pFaceName[1] == 0x72))
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x65, 0x73, 0x74, 0x79, 0x6C, 0x65, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x00 };	// Freestyle Script	16
					BrUSHORT wLocalFont2[] = { 0x65, 0x6E, 0x63, 0x68, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x20, 0x6D, 0x74, 0x00 };	// French Script MT	16
					
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_LucidaBright_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_Centaur_SameKind;
				}
				else if(BrToLower(pFaceName[1] == 0x6F))
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x6D, 0x61, 0x6C, 0x73, 0x63, 0x72, 0x70, 0x34, 0x32, 0x31, 0x20, 0x62, 0x74, 0x00 };	// FormalScrp421 BT	16
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_LucidaBright_SameKind;
				}				
			}
			else if(nLen == 18)
			{
				if(pFaceName[1] == 0x6f )
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x74, 0x6c, 0x69, 0x67, 0x68, 0x74, 0x20, 0x6d, 0x74, 0x20, 0x6c, 0x69, 0x67, 0x68, 0x74, 0x00 }; //Footlight MT Light 18
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,16))
						nFontFlag = f_FootlightMTLight_SameKind;
				}
			}
			else if(nLen == 20)
			{
				if(BrToLower(pFaceName[1]) == 0x72 && BrToLower(pFaceName[2]) == 0x61 && BrToLower(pFaceName[3]) == 0x6e && BrToLower(pFaceName[4]) == 0x6b
					&& BrToLower(pFaceName[5]) == 0x6c && BrToLower(pFaceName[6]) == 0x69 && BrToLower(pFaceName[7]) == 0x6e && BrToLower(pFaceName[8]) == 0x20
					&& BrToLower(pFaceName[9]) == 0x67 && BrToLower(pFaceName[10]) == 0x6f && BrToLower(pFaceName[11]) == 0x74 && BrToLower(pFaceName[12]) == 0x68
					&& BrToLower(pFaceName[13]) == 0x69 && BrToLower(pFaceName[14]) == 0x63 )
				{
					if(BrToLower(pFaceName[16]) == 0x62)
					{
						BrUSHORT wLocalFont[] = { 0x6f, 0x6f, 0x6b, 0x00 }; //Franklin Gothic Book 20
						if(GetFontIndexByName(&pFaceName[16],wLocalFont,3))
							nFontFlag = f_FranklinGothicBook_SameKind;
					}
					else if(BrToLower(pFaceName[16]) == 0x64)
					{
						BrUSHORT wLocalFont[] = { 0x65, 0x6d, 0x69, 0x00 }; //Franklin Gothic Demi 20
						if(GetFontIndexByName(&pFaceName[16],wLocalFont,3))
							nFontFlag = f_FranklinGothicDemi_SameKind;
					}
				}
			}
			else if(nLen == 21)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x6e, 0x6b, 0x6c, 0x69, 0x6e, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x20, 0x68, 0x65, 0x61, 0x76, 0x79, 0x00 }; //Franklin Gothic Heavy 21
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,19))
						nFontFlag = f_FranklinGothicHeavy_SameKind;
				}
			}
			else if(nLen == 22)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x6e, 0x6b, 0x6c, 0x69, 0x6e, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x20, 0x6d, 0x65, 0x64, 0x69, 0x75, 0x6d, 0x00 }; //Franklin Gothic Medium 22
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,20))
						nFontFlag = f_FranklinGothicMedium_SameKind;
				}
			}
			else if(nLen == 25)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x6e, 0x6b, 0x6c, 0x69, 0x6e, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x20, 0x64, 0x65, 0x6d, 0x69, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x00 }; //Franklin Gothic Demi Cond 25
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,nLen-2))
						nFontFlag = f_FranklinGothicDemiCond_SameKind;
				}
			}
			else if(nLen == 27)
			{
				if(pFaceName[1] == 0x72 )
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x6e, 0x6b, 0x6c, 0x69, 0x6e, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x20, 0x6d, 0x65, 0x64, 0x69, 0x75, 0x6d, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x00 }; //Franklin Gothic Medium Cond 27
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,25))
						nFontFlag = f_FranklinGothicMediumCond_SameKind;
				}
			}
			else if(nLen == 15)
			{
				if(pFaceName[1] == 0x61 )
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x73, 0x6f, 0x6e, 0x67, 0x5f, 0x67, 0x62,  0x32, 0x33, 0x31, 0x32}; //"FangSong_GB2312"

					if(GetFontIndexByName(&pFaceName[1],wLocalFont,nLen-2))
						nFontFlag = f_FangSong_GB2312_SameKind;
				}
			}
			break;			
		case 0x67:			
			if ( nLen == 5 )
			{				
				if(BrToLower(pFaceName[1] == 0x69))
				{
					BrUSHORT wGulim[] = {0x73, 0x68, 0x61, 0x00};		//Gisha
					if(GetFontIndexByName(&pFaceName[1], wGulim, nLen -2))
						nFontFlag = f_Gisha_SameKind;
				}
				else if(cNCode == 0x75)
				{
					BrUSHORT wGulim[] = {0x6C, 0x69, 0x6D, 0x00};		//Gulim
					if(GetFontIndexByName(&pFaceName[1], wGulim, nLen -2))
						nFontFlag = f_Gulim_SameKind;
				}
			}
			else if ( nLen == 7 )
			{
				BrUSHORT wLocalFont1[] = { 0x61, 0x75, 0x74, 0x61, 0x6d, 0x69, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x65, 0x6f, 0x72, 0x67, 0x69, 0x61, 0x00 }; 
				BrUSHORT wLocalFont3[] = { 0x75, 0x6E, 0x67, 0x73, 0x75, 0x68, 0x00 };

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 6) )
					nFontFlag = f_Gautami_SameKind; //Gautami 7
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 6) )
					nFontFlag = f_Georgia_SameKind; //Georgia 7
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont3, 6) )
					nFontFlag = f_Gungseo_SameKind; //Gungsuh 7

			}
			else if ( nLen == 8 )
			{
				BrUSHORT wLocalFont1[] = { 0x61, 0x62, 0x72, 0x69, 0x6f, 0x6c, 0x61, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x61, 0x72, 0x61, 0x6d, 0x6f, 0x6e, 0x64, 0x00 }; 

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 6) )
					nFontFlag = f_Gabriola_SameKind; //Gabriola 8
				else if ( GetFontIndexByName (&pFaceName[0], wLocalFont2, 6) )
					nFontFlag = f_Garamond_SameKind; //Garamond 8
			}
			else if ( nLen == 11 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x75, 0x64, 0x79, 0x20, 0x73, 0x74, 0x6f, 0x75, 0x74, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 10) )
					nFontFlag = f_GoudyStout_SameKind; //Goudy Stout 11
			}

			else if ( nLen == 12 )
			{
				BrUSHORT wLocalFont1[] = { 0x69, 0x6c, 0x6c, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x6d, 0x74, 0x00 }; 
				BrUSHORT wLocalFont2[] = { 0x6f, 0x75, 0x64, 0x79, 0x6f, 0x6c, 0x73, 0x74, 0x20, 0x62, 0x74, 0x00 }; 

				if ( GetFontIndexByName (&pFaceName[0], wLocalFont1, 11) )
					nFontFlag = f_GillSansMT_SameKind; //Gill Sans MT 12
			}
			else if ( nLen == 13 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x6F, 0x6D, 0x65, 0x74, 0x72, 0x32, 0x33, 0x31, 0x20, 0x62, 0x74, 0x00 };	// Geometr231 BT 13
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, nLen-1) )
					nFontFlag = f_Freehand591BT_SameKind;
			}
			/*
			else if ( nLen == 13 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x6e, 0x74, 0x69, 0x75, 0x6d, 0x20, 0x62, 0x61, 0x73, 0x69, 0x63, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 12) )
					nFontFlag = f_GentiumBasic_SameKind; //Gentium Basic 13
			}
			*/		
			else if ( nLen == 15 )
			{
				if(BrToLower(pFaceName[1]) == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x75, 0x64, 0x79, 0x20, 0x6f, 0x6c, 0x64, 0x20, 0x73, 0x74, 0x79, 0x6c, 0x65, 0x00 }; //Goudy Old Style 15
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_GoudyOldStyle_SameKind;  //Goudy Old Style 15		
				}
				else if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x61, 0x6D, 0x6F, 0x6E, 0x64, 0x20, 0x6D, 0x74, 0x20, 0x73, 0x74, 0x64, 0x00 }; //Garamond MT Std 15
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Garamond_SameKind; //Garamond MT Std 15
				}	
			}
			else if ( nLen == 16 )
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x6F, 0x6D, 0x65, 0x74, 0x72, 0x32, 0x33, 0x31, 0x20, 0x68, 0x76, 0x20, 0x62, 0x74, 0x00 };	// Geometr231 Hv BT	16
					BrUSHORT wLocalFont2[] = { 0x6F, 0x73, 0x6C, 0x61, 0x62, 0x37, 0x30, 0x33, 0x20, 0x6D, 0x64, 0x20, 0x62, 0x74, 0x00 };	// GeoSlab703 Md BT	16

					if ( GetFontIndexByName (&pFaceName[1], wLocalFont, nLen-2) )
						nFontFlag = f_Century_SameKind;
					else if ( GetFontIndexByName (&pFaceName[1], wLocalFont2, nLen-2) )
						nFontFlag = f_BodoniMT_SameKind;
				}			
			}
			else if ( nLen == 17 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x6F, 0x73, 0x6C, 0x61, 0x62, 0x37, 0x30, 0x33, 0x20, 0x78, 0x62, 0x64, 0x20, 0x62, 0x74, 0x00 };	// GeoSlab703 XBd BT 17
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, nLen-1) )
					nFontFlag = f_BodoniMT_SameKind;
			}
			else if ( nLen == 18 )
			{
				BrUSHORT wLocalFont[] = { 0x6F, 0x75, 0x64, 0x79, 0x68, 0x61, 0x6E, 0x64, 0x74, 0x6F, 0x6F, 0x6C, 0x65, 0x64, 0x20, 0x62, 0x74, 0x00 };	// GoudyHandtooled BT	18
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, nLen-1) )
					nFontFlag = f_BodoniMT_SameKind;
			}
			/*
			else if ( nLen == 18 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x6e, 0x74, 0x69, 0x75, 0x6d, 0x20, 0x62, 0x6f, 0x6f, 0x6b, 0x20, 0x62, 0x61, 0x73, 0x69, 0x63, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 17) )
					nFontFlag = f_GentiumBookBasic_SameKind;  //Gentium Book Basic 18
			}
			*/			
			else if ( nLen == 20 )
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6c, 0x6c, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x75, 0x6c, 0x74, 0x72, 0x61, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 19) )
					nFontFlag = f_GillSansUltraBold_SameKind;  //Gill Sans Ultra Bold 20
			}
			else if ( nLen == 22 )
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6c, 0x6c, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x6d, 0x74, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 21) )
					nFontFlag = f_GillSansMTCondensed_SameKind;  //Gill Sans MT Condensed 22
			}
			else if ( nLen == 29 )
			{
				BrUSHORT wLocalFont[] = { 0x6c, 0x6f, 0x75, 0x63, 0x65, 0x73, 0x74, 0x65, 0x72, 0x20, 0x6d, 0x74, 0x20, 0x65, 0x78, 0x74, 0x72, 0x61, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 28) )
					nFontFlag = f_GloucesterMTExtraCondensed_SameKind;  //Gloucester MT Extra Condensed 29
			}
			else if ( nLen == 30 )
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6c, 0x6c, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x75, 0x6c, 0x74, 0x72, 0x61, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; 
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, 29) )
					nFontFlag = f_GillSansUltraBoldCondensed_SameKind;  //Gill Sans Ultra Bold Condensed 30
			}
			else if ( nLen == 31 )
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6C, 0x6C, 0x20, 0x73, 0x61, 0x6E, 0x73, 0x20, 0x6D, 0x74, 0x20, 0x65, 0x78, 0x74, 0x20, 0x63, 0x6F, 0x6E, 0x64, 0x65, 0x6E, 0x73, 0x65, 0x64, 0x20, 0x62, 0x6F, 0x6C, 0x64, 0x00 };	// Gill Sans MT Ext Condensed Bold	31
				if ( GetFontIndexByName (&pFaceName[0], wLocalFont, nLen-1) )
					nFontFlag = f_NewsGothBT_SameKind;  
			}	
			break;
		case 0x68:
			if(nLen == 4)
			{
				cNCode = BrToLower(pFaceName[1]);
				if(cNCode == 0x79)
				{
					BrUSHORT wLocalFont[] = { 0xad81, 0xc11c, 0x00 }; //HY궁서
					BrUSHORT wLocalFont1[] = { 0xAD74, 0xB9BC, 0x00 }; //HY굴림
					BrUSHORT wLocalFont2[] = { 0xB3CB, 0xC6C0, 0x00 }; //HY돋움
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, 2))
						nFontFlag = f_HYGungseo_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont1, 2))
						nFontFlag = f_HYGulim_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, 2))
						nFontFlag = f_HYDotum_SameKind;
				}
			}
			if(nLen == 5)
			{
				cNCode = BrToLower(pFaceName[1]);
				if(cNCode == 0x70)
				{
					cNCode = BrToLower(pFaceName[2]);
					if(cNCode == 0x63)
					{
						BrUSHORT wLocalFont[] = { 0x6f, 0x62, 0x00 };
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, 2))
							nFontFlag = f_HPCOB_SameKind;		// HPCOB
					}
					else if(cNCode == 0x6c)
					{
						BrUSHORT wLocalFont[] = { 0x74, 0x68, 0x00 };
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, 2))
							nFontFlag = f_HPLTH_SameKind;		// HPLTH
					}
				}
				else if(cNCode == 0x79)
				{
					cNCode = BrToLower(pFaceName[2]);
					if(cNCode == 0xacac)
					{
						BrUSHORT wLocalFont[] = { 0xace0, 0xb515, 0x00 };
						BrUSHORT wLocalFont2[] = { 0xba85, 0xc870, 0x00 };

						if(memcmp(wLocalFont, &pFaceName[3], 4) == 0)
							nFontFlag = f_HYGyeonGodik_SameKind;	// HY견고딕
						else if(memcmp(wLocalFont2, &pFaceName[3], 4) == 0)
							nFontFlag = f_HYGyeonMyeongjo_SameKind;	// HY견명조
					}								
					else if(cNCode == 0xad81)
					{
						BrUSHORT wLocalFont[] = { 0xc11c, 0x62, 0x00 }; //HY궁서B
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, 2))
							nFontFlag = f_HYGungseo_SameKind;
					}				
					else if(cNCode == 0xc5fd && pFaceName[3] == 0xc11c)
					{
						if(BrToLower(pFaceName[4]) == 0x6c)
							nFontFlag = f_HYYeopseoL_SameKind;	//HY엽서L
						else if(BrToLower(pFaceName[4]) == 0x6d)
							nFontFlag = f_HYYeopseoM_SameKind;	//HY엽서M
					}
					else if(cNCode == 0xc2e0)
					{
						BrUSHORT wLocalFont[] = { 0xba85, 0xc870, 0x00 }; //HY신명조
						if(memcmp(wLocalFont, &pFaceName[3], 4) == 0)
							nFontFlag = f_HYSinMyeongjo_SameKind;
					}
					else if(cNCode == 0xc911)
					{
						BrUSHORT wLocalFont[] = { 0xace0, 0xb515, 0x00 }; //HY중고딕
						if(memcmp(wLocalFont, &pFaceName[3], 4) == 0)
							nFontFlag = f_HYJungGodik_SameKind;
					}
				}			
			}
			else if(nLen == 6)
			{
				cNCode = BrToLower(pFaceName[1]);
				if(cNCode == 0x70)
				{
					cNCode = BrToLower(pFaceName[2]);
					if(cNCode == 0x63 && BrToLower(pFaceName[3]) == 0x6f && BrToLower(pFaceName[4]) == 0x62)
					{
						if(BrToLower(pFaceName[5]) == 0x32)		//HPCOB2
							nFontFlag = f_HPCOB2_SameKind;
						else if(BrToLower(pFaceName[5]) == 0x62)	//HPCOBB
							nFontFlag = f_HPCOBB_SameKind;
						else if(BrToLower(pFaceName[5]) == 0x69)	//HPCOBI
							nFontFlag = f_HPCOBI_SameKind;						
					}
					else if(cNCode == 0x6c && BrToLower(pFaceName[3]) == 0x74 && BrToLower(pFaceName[4]) == 0x68)
					{
						if(BrToLower(pFaceName[5]) == 0x62)		//HPLTHB
							nFontFlag = f_HPLTHB_SameKind;
						else if(BrToLower(pFaceName[5]) == 0x69)	//HPLTHI
							nFontFlag = f_HPLTHI_SameKind;
					}
				}
				else if(cNCode == 0x79)
				{
					BrUSHORT wLocalFont[] = { 0xC6B8, 0xB989, 0xB3C4, 0x00 };
					BrUSHORT wLocalFont2[] = { 0xadf8, 0xb798, 0xd53d, 0x00 };

					if(memcmp(wLocalFont, &pFaceName[2], 6) == 0)	//HY 울릉도
					{
						nFontFlag = f_HYUlleungdo_SameKind;		//HY울릉도 Same...(L,B,M)
						//if(BrToLower(pFaceName[5]) == 0x6d)
						//	nFontFlag = f_HYUlleungdo_SameKind;		//HY울릉도M
					}
					else if(memcmp(wLocalFont2, &pFaceName[2], 6) == 0)
					{
						if(BrToLower(pFaceName[5]) == 0x6d)
							nFontFlag = f_HYGraphicM_SameKind;		//HY그래픽M
					}
				}	
			}
			else if(nLen == 7)
			{
				cNCode = BrToLower(pFaceName[1]);
				if(cNCode == 0x79)
				{
					BrUSHORT wLocalFont[] = { 0xbaa9, 0xac01, 0xd30c, 0xc784, 0x00 };
					BrUSHORT wLocalFont2[] = { 0xc595, 0xc740, 0xc0d8, 0xbb3c, 0x00 };
					BrUSHORT wLocalFont4[] = { 0xd5e4, 0xb4dc, 0xb77c, 0xc778, 0x00 };

					if(memcmp(wLocalFont, &pFaceName[2], 8) == 0)
					{
						if(BrToLower(pFaceName[6]) == 0x62)
							nFontFlag = f_HYMokgakPaimB_SameKind;		//HY목각파임B
					}
					else if(memcmp(wLocalFont2, &pFaceName[2], 8) == 0)
					{
						if(BrToLower(pFaceName[6]) == 0x6d)
							nFontFlag = f_HYYateunSammulM_SameKind;	//HY얕은샘물M
					}
					else if(memcmp(wLocalFont4, &pFaceName[2], 8) == 0)
					{
						if(BrToLower(pFaceName[6]) == 0x6d)
							nFontFlag = f_HYHaedeuLineM_SameKind;		//HY헤드라인M
					}
				}
				else if(cNCode == 0x5F)
				{
					BrUSHORT wLocalFont[] = { 0x6B, 0x65, 0x79, 0x62, 0x64, 0x00 };	// H_KEYBD	7
					if ( GetFontIndexByName( &pFaceName[1], wLocalFont, nLen-2 ))
						nFontFlag = f_Kartika_SameKind;
				}
			}
			else if(nLen == 8)
			{
				cNCode = BrToLower(pFaceName[1]);
				if(cNCode == 0x5F)
				{
					cNCode = BrToLower(pFaceName[2]);

					if(cNCode == 0x63)
					{
						BrUSHORT wLocalFont[] = { 0x69, 0x72, 0x6E, 0x75, 0x6D, 0x00 };	// H_CIRNUM	8
						if ( GetFontIndexByName( &pFaceName[2], wLocalFont, nLen-3 ))
							nFontFlag = f_Kartika_SameKind;
					}
					else if(cNCode == 0x65)
					{
						BrUSHORT wLocalFont[] = { 0x71, 0x73, 0x79, 0x6D, 0x31, 0x00 };	// H_EQSYM1	8
						BrUSHORT wLocalFont2[] = { 0x71, 0x73, 0x79, 0x6D, 0x32, 0x00 };	// H_EQSYM2	8
						
						cNCode = BrToLower(pFaceName[7]);

						if(cNCode == 0x31 || cNCode == 0x32)
							nFontFlag = f_Kartika_SameKind;						
					}
					else if(cNCode == 0x68)
					{
						BrUSHORT wLocalFont[] = { 0x65, 0x62, 0x72, 0x65, 0x77, 0x00 };	// H_HEBREW	8
						if ( GetFontIndexByName( &pFaceName[2], wLocalFont, nLen-3 ))
							nFontFlag = f_Kartika_SameKind;
					}
					else if(cNCode == 0x6D)
					{
						BrUSHORT wLocalFont[] = { 0x75, 0x6C, 0x74, 0x69, 0x31, 0x00 };	// H_MULTI1	8
						BrUSHORT wLocalFont2[] = { 0x75, 0x6C, 0x74, 0x69, 0x32, 0x00 };	// H_MULTI2	8

						cNCode = BrToLower(pFaceName[7]);

						if(cNCode == 0x31)
							nFontFlag = f_H_MULT1_SameKind;						
						else if(cNCode == 0x32) 
							nFontFlag = f_HMULTI2_SameKind;
					}
					else if(cNCode == 0x70)
					{
						BrUSHORT wLocalFont[] = { 0x72, 0x6F, 0x73, 0x79, 0x6D, 0x00 };	// H_PROSYM	8
						if ( GetFontIndexByName( &pFaceName[2], wLocalFont, nLen-3 ))
							nFontFlag = f_H_PROSYM_SameKind;
					}
				}
			}
			else if(nLen == 9)
			{
				if ( BrToLower(pFaceName[1]) == 0x65) 
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x76, 0x65, 0x74, 0x69, 0x63, 0x61, 0x00};	//Helvetica
					if ( GetFontIndexByName( &pFaceName[1], wLocalFont, nLen-2 ))
						nFontFlag = f_Helvetica_SameKind;
				}
				else if (BrToLower(pFaceName[1]) == 0x63)
				{
					BrUSHORT wLocalFont[] = {0x69, 0x20, 0x70, 0x6f, 0x70, 0x70, 0x79, 0x00};	//HCI Poppy
					if ( GetFontIndexByName( &pFaceName[1], wLocalFont, nLen-2 ))
						nFontFlag = f_HCIPoppy_SameKind;
				}
			}
			else if(nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x72, 0x72, 0x69, 0x6e, 0x67, 0x74, 0x6f, 0x6e, 0x00 }; //Harrington
				if(GetFontIndexByName(pFaceName, wLocalFont, 9))
					nFontFlag = f_Harrington_SameKind;
			}
			else if(nLen == 11)
			{
				BrUSHORT wLocalFont[] = { 0x5F, 0x65, 0x73, 0x70, 0x65, 0x72, 0x61, 0x6E, 0x74, 0x6F, 0x00 };	// H_ESPERANTO 11
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_HESPERANTO_SameKind;
			}
			else if(nLen == 12)
			{
				BrUSHORT wLocalFont[] = { 0x6F, 0x6C, 0x69, 0x64, 0x61, 0x79, 0x70, 0x69, 0x20, 0x62, 0x74, 0x00 };	// HolidayPi BT	12
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BernardMTCon_SameKind; 
			}
			else if(nLen == 15)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x67, 0x68, 0x20, 0x74, 0x6f, 0x77, 0x65, 0x72, 0x20, 0x74, 0x65, 0x78, 0x74, 0x00 }; //High Tower Text
				if(GetFontIndexByName(pFaceName, wLocalFont, 14))
					nFontFlag = f_HighTowerText_SameKind;
			}
			else if(nLen == 16)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x65, 0x74, 0x74, 0x65, 0x6e, 0x73, 0x63, 0x68, 0x77, 0x65, 0x69, 0x6c, 0x65, 0x72, 0x00 }; //Haettenschweiler
				if(GetFontIndexByName(pFaceName, wLocalFont, 15))
					nFontFlag = f_Haettenschweiler_SameKind;
			}
			else if(nLen == 19)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x72, 0x6C, 0x6F, 0x77, 0x20, 0x73, 0x6F, 0x6C, 0x69, 0x64, 0x20, 0x69, 0x74, 0x61, 0x6C, 0x69, 0x63, 0x00 };	// Harlow Solid Italic		19
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_HarlowSolidItalic_SameKind;
			}
			break;			
		case 0x69:
			if ( nLen == 6 )
			{
				BrUSHORT wLocalFont[] = { 0x6d, 0x70, 0x61, 0x63, 0x74, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Impact_SameKind; //Impact 6
			}
			else if ( nLen == 7 )
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x73, 0x75, 0x70, 0x63, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_IrisUPC_SameKind; //IrisUPC 7
			}
			else if ( nLen == 9 )
			{
				BrUSHORT wLocalFont[] = { 0x6D, 0x70, 0x75, 0x6C, 0x73, 0x20, 0x62, 0x74, 0x00 };	// Impuls BT 9 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_CalifornianFB_SameKind;
			}
			else if ( nLen == 12 )
			{
				BrUSHORT wLocalFont[] = { 0x73, 0x6b, 0x6f, 0x6f, 0x6c, 0x61, 0x20, 0x70, 0x6f, 0x74, 0x61, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_IskoolaPota_SameKind; //Iskoola Pota 12
			}
			else if ( nLen == 14 )
			{
				BrUSHORT wLocalFont[] = { 0x6E, 0x66, 0x6F, 0x72, 0x6D, 0x61, 0x6C, 0x20, 0x72, 0x6F, 0x6D, 0x61, 0x6E, 0x00 };	// Informal Roman		14
				BrUSHORT wLocalFont2[] = { 0x6E, 0x66, 0x6F, 0x72, 0x6D, 0x61, 0x6C, 0x30, 0x31, 0x31, 0x20, 0x62, 0x74, 0x00 };	// Informal011 BT		14
				
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_BodoniMT_SameKind;
				else if ( GetFontIndexByName( &pFaceName[0], wLocalFont2, nLen-1 ))
					nFontFlag = f_BodoniMT_SameKind;
			}
			else if ( nLen == 16 )
			{
				BrUSHORT wLocalFont[] = { 0x6E, 0x63, 0x69, 0x73, 0x65, 0x64, 0x39, 0x30, 0x31, 0x20, 0x63, 0x74, 0x20, 0x62, 0x74, 0x00 };	// Incised901 Ct BT	16
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_BodoniMT_SameKind;
			}
			else if ( nLen == 17 )
			{
				BrUSHORT wLocalFont[] = { 0x6d, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x20, 0x6d, 0x74, 0x20, 0x73, 0x68, 0x61, 0x64, 0x6f, 0x77, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_ImprintMTShadow_SameKind; //Imprint MT Shadow 17
			}
			break;
		case 0x6a:
			if ( nLen == 8 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x6b, 0x65, 0x72, 0x6d, 0x61, 0x6e, 0x00 }; //Jokerman 8
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Jokerman_SameKind; //Jokerman 8
			}
			else if ( nLen == 9 )
			{
				BrUSHORT wLocalFont[] = { 0x75, 0x69, 0x63, 0x65, 0x20, 0x69, 0x74, 0x63, 0x00 };	// Juice ITC 9
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_BernardMTCon_SameKind;
			}
			else if ( nLen == 10 )
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x73, 0x6d, 0x69, 0x6e, 0x65, 0x75, 0x70, 0x63, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_JasmineUPC_SameKind; //JasmineUPC 10
			}
			break;
		case 0x6b:
			if ( nLen == 5 )
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x69, 0x74, 0x69, 0x00 }; //KaiTi 5
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_KaiTi_SameKind;  //KaiTi 5
			}
			else if ( nLen == 6 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x6b, 0x69, 0x6c, 0x61, 0x00 }; //Kokila 6
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Kokila_SameKind;  //Kokila 6
			}
			else if ( nLen == 7 )
			{
				if ( BrToLower(pFaceName[2]) == 0x6c && BrToLower(pFaceName[1]) == 0x61 ) 
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x6e, 0x67, 0x61, 0x00 }; 
					if ( GetFontIndexByName( &pFaceName[2], wLocalFont, nLen-3 ))
						nFontFlag = f_Kalinga_SameKind;  //Kalinga 7
				}
				else if (BrToLower(pFaceName[2]) == 0x72 && BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x69, 0x6b, 0x61, 0x00 }; 
					if ( GetFontIndexByName( &pFaceName[2], wLocalFont, nLen-3 ))
						nFontFlag = f_Kartika_SameKind;   //Kartika 7
				}
			}
			else if ( nLen == 8 )
			{
				BrUSHORT wLocalFont[] = { 0x68, 0x6d, 0x65, 0x72, 0x20, 0x75, 0x69, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_KhmerUI_SameKind;  //Khmer UI 8
			}
			else if ( nLen == 11 )
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x73, 0x74, 0x65, 0x6e, 0x20, 0x69, 0x74, 0x63, 0x00 };
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_KristenITC_SameKind;   //Kristen ITC 11
			}
			else if ( nLen == 12 )
			{
				if ( BrToLower(pFaceName[1]) == 0x6f ) 
				{
					BrUSHORT wLocalFont[] = { 0x64, 0x63, 0x68, 0x69, 0x61, 0x6e, 0x67, 0x75, 0x70, 0x63, 0x00 };
					if ( GetFontIndexByName( &pFaceName[1], wLocalFont, nLen-2 ))
						nFontFlag = f_KodchiangUPC_SameKind;    //KodchiangUPC 12
				}
				else if ( BrToLower(pFaceName[1]) == 0x61 ) 
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x74, 0x69, 0x5f, 0x67, 0x62, 0x32, 0x33, 0x31, 0x32, 0x00 };		// "Kaiti_GB2312"
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen -2))
						nFontFlag = f_KaiTi_SameKind;
				}
			}
			else if ( nLen == 15 )
			{
				BrUSHORT wLocalFont[] = { 0x75, 0x6E, 0x73, 0x74, 0x6C, 0x65, 0x72, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x00 };	// Kunstler Script 15
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_KunstlerScript_SameKind;
			}
			break;
		case 0x6C:
			if(nLen == 5)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x68, 0x61, 0x00 }; //Latha 5
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,3))
						nFontFlag = f_Latha_SameKind;
				}
			}
			else if(nLen == 6)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x20, 0x75, 0x69, 0x00 }; //Lao UI 6
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,4))
						nFontFlag = f_LaoUI_SameKind;
				}
			}
			else if(nLen == 7)
			{
				if(pFaceName[1] == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x79, 0x75, 0x70, 0x63, 0x00 }; //LilyUPC 7
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,5))
						nFontFlag = f_LilyUPC_SameKind;
				}
			}
			else if(nLen == 10)
			{
				if(pFaceName[1] == 0x65)
				{
					if(pFaceName[2] == 0x65)
					{
						BrUSHORT wLocalFont[] = { 0x6c, 0x61, 0x77, 0x61, 0x64, 0x65, 0x65, 0x00 }; //Leelawadee 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_Leelawadee_SameKind;
					}
					else if(pFaceName[2] == 0x76)
					{
						BrUSHORT wLocalFont[] = { 0x65, 0x6e, 0x69, 0x6d, 0x20, 0x6d, 0x74, 0x00 }; //Levenim MT 10
						if(GetFontIndexByName(&pFaceName[2],wLocalFont,7))
							nFontFlag = f_LevenimMT_SameKind;
					}					
				}
				else if(pFaceName[1] == 0x75)
				{
					BrUSHORT wLocalFont[] = { 0x63, 0x69, 0x64, 0x61, 0x20, 0x66, 0x61, 0x78, 0x00 }; //Lucida Fax 10
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,8))
						nFontFlag = f_LucidaFax_SameKind;
				}
			}	
			else if(nLen == 11)
			{
				if(pFaceName[1] == 0x75)
				{
					BrUSHORT wLocalFont[] = { 0x63, 0x69, 0x64, 0x61, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x00 }; //Lucida Sans 11
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,nLen-2))
						nFontFlag = f_LucidaSans_SameKind;
				}
			}
			else if(nLen == 12)
			{
				if(pFaceName[1] == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x68, 0x61, 0x20, 0x62, 0x72, 0x69, 0x67, 0x68, 0x74, 0x00 };	// Latha Bright	12
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,nLen-2))
						nFontFlag = f_LucidaBright_SameKind;
				}
			}
			else if(nLen == 13)
			{
				if(pFaceName[1] == 0x75)
				{
					BrUSHORT wLocalFont[] = { 0x63, 0x69, 0x64, 0x61, 0x20, 0x62, 0x72, 0x69, 0x67, 0x68, 0x74, 0x00 }; //Lucida Bright 13
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,11))
						nFontFlag = f_LucidaBright_SameKind;
				}
			}
			else if( nLen == 14 )
			{
				BrUSHORT wLucidaConsole[] = {0x75, 0x63, 0x69, 0x64, 0x61, 0x20, 0x63, 0x6F, 0x6E, 0x73, 0x6F, 0x6C, 0x65, 0x00};  //Lucida Console
				if(GetFontIndexByName(pFaceName, wLucidaConsole, nLen - 1) )
					nFontFlag = f_LucidaConsole_SameKind;
			}
			else if( nLen == 18 )
			{
				if(pFaceName[1] == 0x75 && pFaceName[2] == 0x63 && pFaceName[3] == 0x69 && pFaceName[4] == 0x64 && pFaceName[5] == 0x61)
				{
					if(BrToLower(pFaceName[7]) == 0x63)
					{
						BrUSHORT wLocalFont[] = { 0x61, 0x6c, 0x6c, 0x69, 0x67, 0x72, 0x61, 0x70, 0x68, 0x79, 0x00 }; //Lucida Calligraphy 18
						if(GetFontIndexByName(&pFaceName[7],wLocalFont,10))
							nFontFlag = f_LucidaCalligraphy_SameKind;
					}
					else if(BrToLower(pFaceName[7]) == 0x68)
					{
						BrUSHORT wLocalFont[] = { 0x61, 0x6e, 0x64, 0x77, 0x72, 0x69, 0x74, 0x69, 0x6e, 0x67, 0x00 }; //Lucida Handwriting 18
						if(GetFontIndexByName(&pFaceName[7],wLocalFont,10))
							nFontFlag = f_LucidaHandwriting_SameKind;
					}
				}
			}			
			else if( nLen == 19 )
			{
				BrUSHORT wLocalFont[] = { 0x75, 0x63, 0x69, 0x64, 0x61, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x75, 0x6e, 0x69, 0x63, 0x6f, 0x64, 0x65, 0x00 }; //Lucida Sans Unicode 19
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen - 1) )
					nFontFlag = f_LucidaSansUnicode_SameKind;
			}
			else if(nLen == 22)
			{
				/*
				if(pFaceName[1] == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x62, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x6e, 0x61, 0x72, 0x72, 0x6f, 0x77, 0x00 }; //Liberation Sans Narrow 22
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,20))
						nFontFlag = f_LiberationSansNarrow_SameKind;
				}
				else*/ if(pFaceName[1] == 0x75)
				{
					BrUSHORT wLocalFont[] = { 0x63, 0x69, 0x64, 0x61, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x74, 0x79, 0x70, 0x65, 0x77, 0x72, 0x69, 0x74, 0x65, 0x72, 0x00 }; //Lucida Sans Typewriter 22
					if(GetFontIndexByName(&pFaceName[1],wLocalFont,20))
						nFontFlag = f_LucidaSansTypewriter_SameKind;
				}
			}
			break;
		case 0x6d:		
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0x64, 0xC194, 0xCCB4, 0x00 };	//MD솔체	4
				if(GetFontIndexByName(&pFaceName[0], wLocalFont, nLen-1))
					nFontFlag = f_MDSolche_SameKind; 
			}
			else if(nLen == 5)
			{
				if(BrToLower(pFaceName[1]) == 0x64)
				{
					BrUSHORT wLocalFont[] = { 0xAC1C, 0xC131, 0xCCB4, 0x00 };	//MD개성체	5
					BrUSHORT wLocalFont2[] = { 0xC544, 0xB871, 0xCCB4, 0x00 };	//MD아롱체	5
					BrUSHORT wLocalFont3[] = { 0xC544, 0xD2B8, 0xCCB4, 0x00 };	//MD아트체	5
					BrUSHORT wLocalFont4[] = { 0xC774, 0xC19D, 0xCCB4, 0x00 };	//MD이솝체	5

					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MDGaesungche_SameKind; 
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_MDArongche_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont3, nLen-2))
						nFontFlag = f_MDArtche_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont4, nLen-2))
						nFontFlag = f_MDIsopche_SameKind;
				}
			}
			else if(nLen == 7)
			{			
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					if(BrToLower(pFaceName[2]) == 0x67)
					{
						BrUSHORT wLocalFont[] = { 0x6E, 0x65, 0x74, 0x6F, 0x00 };	// Magneto 7
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_Magneto_SameKind; 
					}
					else if(BrToLower(pFaceName[2]) == 0x72)
					{
						BrUSHORT wLocalFont[] = { 0x6C, 0x65, 0x74, 0x74, 0x00 };	// Marlett 7
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_Kartika_SameKind; 
					}
				}
				else if(BrToLower(pFaceName[1]) == 0x69)
				{
					if(BrToLower(pFaceName[2]) == 0x6e)
					{
						BrUSHORT wLocalFont[] = { 0x67, 0x6c, 0x69, 0x75, 0x00 }; //MingLiU 7
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_MingLiU_SameKind;
					}
					else if(BrToLower(pFaceName[2]) == 0x73)
					{
						BrUSHORT wLocalFont[] = { 0x74, 0x72, 0x61, 0x6C, 0x00 };	// Mistral		7
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_Impact_SameKind;
					}
				}
				else if(BrToLower(pFaceName[1]) == 0x76)
				{
					BrUSHORT wLocalFont[] = { 0x20, 0x62, 0x6f, 0x6c, 0x69, 0x00 }; //MV Boli 7
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MVBoli_SameKind;
				}
			}
			else if(nLen == 10)
			{
				if(BrToLower(pFaceName[1]) == 0x73)
				{
					if(BrToLower(pFaceName[3]) == 0x6f)
					{
						BrUSHORT wLocalFont[] = { 0x75, 0x74, 0x6c, 0x6f, 0x6f, 0x6b, 0x00 }; //MS Outlook 10
						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_MSOutlook_SameKind;
					}
					else if(BrToLower(pFaceName[3]) == 0x70)
					{
						if(BrToLower(pFaceName[4]) == 0x67)
						{
							BrUSHORT wLocalFont[] = { 0x6f, 0x74, 0x68, 0x69, 0x63, 0x00 }; //MS PGothic 10
							if(GetFontIndexByName(&pFaceName[4], wLocalFont, nLen-5))
								nFontFlag = f_MSPGothic_SameKind;
						}
						else if(BrToLower(pFaceName[4]) == 0x6d)
						{
							BrUSHORT wLocalFont[] = { 0x69, 0x6e, 0x63, 0x68, 0x6f, 0x00 }; //MS PMincho 10
							if(GetFontIndexByName(&pFaceName[4], wLocalFont, nLen-5))
								nFontFlag = f_MSPMincho_SameKind;
						}						
					}					
				}
			}
			else if(nLen == 11)
			{
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x61, 0x6e, 0x64, 0x72, 0x61, 0x20, 0x67, 0x64, 0x00 }; //Maiandra GD 11
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MaiandraGD_SameKind;
				}
				/*
				else if(BrToLower(pFaceName[1]) == 0x6F)
				{
					BrUSHORT wLocalFont[] = { 0x74, 0x6f, 0x79, 0x61, 0x6c, 0x6d, 0x61, 0x72, 0x75, 0x00 }; //MotoyaLMaru 11
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MotoyaLMaru_SameKind;
				}
				*/
			}
			else if(nLen == 6)
			{
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x61, 0x6c, 0x00 }; //Mangal 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Mangal_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x72, 0x79, 0x6f, 0x00 }; //Meiryo 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Meiryo_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x61, 0x6d, 0x00 }; //Miriam 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Miriam_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x64, 0x65, 0x72, 0x6e, 0x00 }; //Modern 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_ModernNo20_SameKind;
				}				
			}
			else if(nLen == 9)
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x72, 0x79, 0x6f, 0x20, 0x75, 0x69, 0x00 }; //Meiryo UI 9
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Meiryo_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x6c, 0x62, 0x6f, 0x72, 0x61, 0x6e, 0x00 }; //MoolBoran 9
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MoolBoran_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x73)
				{
					if(BrToLower(pFaceName[2]) == 0x20)
					{
						if(BrToLower(pFaceName[3]) == 0x67)
						{
							BrUSHORT wLocalFont[] = { 0x6f, 0x74, 0x68, 0x69, 0x63, 0x00 }; //MS Gothic 9
							if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
								nFontFlag = f_MSGothic_SameKind;
						}
						else if(BrToLower(pFaceName[3]) == 0x6d)
						{
							BrUSHORT wLocalFont[] = { 0x69, 0x6e, 0x63, 0x68, 0x6f, 0x00 }; //MS Mincho 9
							if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
								nFontFlag = f_MSGothic_SameKind;
						}
					}
				}
			}
			else if(nLen == 18)
			{
				if(BrToLower(pFaceName[1]) == 0x69)
				{
					if(BrToLower(pFaceName[2]) == 0x6e)
					{
						BrUSHORT wLocalFont[] = { 0x67, 0x6c, 0x69, 0x75, 0x5f, 0x68, 0x6b, 0x73, 0x63, 0x73, 0x2d, 0x65, 0x78, 0x74, 0x62, 0x00 }; //MingLiU_HKSCS-ExtB 18
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_MingLiU_SameKind;
					}
					else if(BrToLower(pFaceName[2]) == 0x63)
					{
						BrUSHORT wPre[] = {0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x00};
						if(GetFontIndexByName(&pFaceName[2], wPre, 6))
						{
							if(BrToLower(pFaceName[10]) == 0x68)
							{
								BrUSHORT wLocalFont[] = { 0x69, 0x6d, 0x61, 0x6c, 0x61, 0x79, 0x61, 0x00 }; //Microsoft Himalaya 18
								if(GetFontIndexByName(&pFaceName[10], wLocalFont, nLen-11))
									nFontFlag = f_MicrosoftHimalaya_SameKind;
							}
							else if(BrToLower(pFaceName[10]) == 0x6a)
							{
								BrUSHORT wLocalFont[] = { 0x68, 0x65, 0x6e, 0x67, 0x68, 0x65, 0x69, 0x00 }; //Microsoft JhengHei 18
								if(GetFontIndexByName(&pFaceName[10], wLocalFont, nLen-11))
									nFontFlag = f_MicrosoftJhengHei_SameKind;
							}
							else if(BrToLower(pFaceName[10]) == 0x79)
							{
								if (BrToLower(pFaceName[11]) == 0x69)
								{
									BrUSHORT wLocalFont[] = { 0x20, 0x62, 0x61, 0x69, 0x74, 0x69, 0x00 }; //Microsoft Yi Baiti 18
									if(GetFontIndexByName(&pFaceName[11], wLocalFont, nLen-12))
										nFontFlag = f_MicrosoftYiBaiti_SameKind;
								}
								else if(BrToLower(pFaceName[11]) == 0x61)	// XPD-16909
								{
									BrUSHORT wLocalFont[] = { 0x68, 0x65, 0x69, 0x20, 0x75, 0x69, 0x00 }; //Microsoft YaHei UI 18
									if(GetFontIndexByName(&pFaceName[11], wLocalFont, nLen-12))
										nFontFlag = f_MicrosoftYaHeiUI_SameKind;
								}
							}						
						}
					}					
				}				
			}
			else if(nLen == 17)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x63, 0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x20, 0x70, 0x68, 0x61, 0x67, 0x73, 0x70, 0x61, 0x00 }; //Microsoft PhagsPa 17
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MicrosoftPhagsPa_SameKind;
			}
			else if(nLen == 19)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x72, 0x69, 0x74, 0x69, 0x6D, 0x65, 0x72, 0x65, 0x76, 0x65, 0x72, 0x73, 0x65, 0x64, 0x20, 0x62, 0x74, 0x00 };	// MaritimeReversed BT 19
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;
			}
			else if(nLen == 21)
			{
				if(BrToLower(pFaceName[10]) == 0x6e)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x63, 0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x20, 0x6e, 0x65, 0x77, 0x20, 0x74, 0x61, 0x69, 0x20, 0x6c, 0x75, 0x65, 0x00 }; //Microsoft New Tai Lue 21
					if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
						nFontFlag = f_MicrosoftNewTaiLue_SameKind;
				}
				else if(BrToLower(pFaceName[10]) == 'y')
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x63, 0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x20, 'y', 'a', 'h', 'e', 'i', 0x20, 'l', 'i', 'g', 'h', 't', 0x00 }; //Microsoft YaHei Light
					if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
						nFontFlag = f_MicrosoftYaHeiUI_SameKind;
				}
			}
			else if(nLen == 20)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x63, 0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x73, 0x65, 0x72, 0x69, 0x66, 0x00 }; //Microsoft Sans Serif 20
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MicrosoftSansSerif_SameKind;				
			}
			else if(nLen == 16)
			{
				if(BrToLower(pFaceName[1]) == 0x6f) 
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x6f, 0x74, 0x79, 0x70, 0x65, 0x20, 0x63, 0x6f, 0x72, 0x73, 0x69, 0x76, 0x61, 0x00 }; //Monotype Corsiva 16
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MonotypeCorsiva_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x69) 
				{
					BrUSHORT wPre[] = { 0x63, 0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x00 };
					if(GetFontIndexByName(&pFaceName[1], wPre, 7))
					{
						if(BrToLower(pFaceName[10]) == 0x74)
						{
							BrUSHORT wLocalFont[] = { 0x61, 0x69, 0x20, 0x6c, 0x65, 0x00 }; //Microsoft Tai Le 16
							if(GetFontIndexByName(&pFaceName[10], wLocalFont, nLen-11))
								nFontFlag = f_MicrosoftTaiLe_SameKind;
						}	
						else if(BrToLower(pFaceName[10]) == 0x75)
						{
							BrUSHORT wLocalFont[] = { 0x69, 0x67, 0x68, 0x75, 0x72, 0x00 }; //Microsoft Uighur 16
							if(GetFontIndexByName(&pFaceName[10], wLocalFont, nLen-11))
								nFontFlag = f_MicrosoftUighur_SameKind;
						}		
					}
				}
			}
			else if(nLen == 15)
			{
				if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x63, 0x72, 0x6f, 0x73, 0x6f, 0x66, 0x74, 0x20, 0x79, 0x61, 0x68, 0x65, 0x69, 0x00 }; //Microsoft YaHei 15
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MicrosoftYaHei_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x6f, 0x6c, 0x69, 0x61, 0x6e, 0x20, 0x62, 0x61, 0x69, 0x74, 0x69, 0x00 }; //Mongolian Baiti 15
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MongolianBaiti_SameKind;
				}
			}
			else if(nLen == 12)
			{
				if(BrToLower(pFaceName[1]) == 0x69)
				{
					if(BrToLower(pFaceName[2]) == 0x6e)
					{
						BrUSHORT wLocalFont[] = { 0x67, 0x6c, 0x69, 0x75, 0x2d, 0x65, 0x78, 0x74, 0x62, 0x00 }; //MingLiU-ExtB 12
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_MingLiU_SameKind;
					}
					else if(BrToLower(pFaceName[2]) == 0x72)
					{
						BrUSHORT wLocalFont[] = { 0x69, 0x61, 0x6d, 0x20, 0x66, 0x69, 0x78, 0x65, 0x64, 0x00 }; //Miriam Fixed 12
						if(GetFontIndexByName(&pFaceName[2], wLocalFont, nLen-3))
							nFontFlag = f_MiriamFixed_SameKind;
					}
				}
				else if(BrToLower(pFaceName[1]) == 0x73)
				{
					BrUSHORT wLocalFont[] = { 0x20, 0x75, 0x69, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x00 }; //MS UI Gothic 12
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MSUIGothic_SameKind;
				}
			}
			else if(nLen == 13)
			{
				if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x6c, 0x69, 0x75, 0x5f, 0x68, 0x6b, 0x73, 0x63, 0x73, 0x00 }; //MingLiU_HKSCS 13
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MingLiU_SameKind;
				}				
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x64, 0x65, 0x72, 0x6e, 0x20, 0x6e, 0x6f, 0x2e, 0x20, 0x32, 0x30, 0x00 }; //Modern No. 20 13
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_ModernNo20_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6C, 0x67, 0x75, 0x6E, 0x20, 0x67, 0x6F, 0x74, 0x68, 0x69, 0x63, 0x00 }; //Malgun Gothic 13
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_MakeunGodik_SameKind;
				}
			}			
			else if(nLen == 23)
			{
				BrUSHORT wLocalFont[] = { 0x73, 0x20, 0x72, 0x65, 0x66, 0x65, 0x72, 0x65, 0x6e, 0x63, 0x65, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x73, 0x65, 0x72, 0x69, 0x66, 0x00 }; //MS Reference Sans Serif 23
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MSReferenceSansSerif_SameKind;
			}
			
			else if(nLen == 22)
			{
				BrUSHORT wLocalFont[] = { 0x73, 0x20, 0x72, 0x65, 0x66, 0x65, 0x72, 0x65, 0x6e, 0x63, 0x65, 0x20, 0x73, 0x70, 0x65, 0x63, 0x69, 0x61, 0x6c, 0x74, 0x79, 0x00 }; //MS Reference Specialty 22
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BrushScriptMT_SameKind;
			}
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0x74, 0x20, 0x65, 0x78, 0x74, 0x72, 0x61, 0x00 }; //MT Extra 8
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MTExtra_SameKind;
			}
			else if(nLen == 14)
			{
				BrUSHORT wLocalFont[] = { 0x73, 0x20, 0x73, 0x68, 0x65, 0x6C, 0x6C, 0x20, 0x64, 0x6C, 0x67, 0x20, 0x32, 0x00 }; //MS Shell Dlg 2 14
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_MSReferenceSansSerif_SameKind;
			}
			break; 				
		case 0x6e:
			if ( nLen == 4 )
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6E, 0x61, 0x00 };	// Nina	4
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Castellar_SameKind;
			}
			else if ( nLen == 5 )
			{
				BrUSHORT wLocalFont[] = { 0x79, 0x61, 0x6c, 0x61, 0x00 };
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Nyala_SameKind;  //Nyala 5
			}
			else if ( nLen == 7 )
			{
				BrUSHORT wLocalFont[] = { 0x73, 0x69, 0x6d, 0x73, 0x75, 0x6e, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_NSimSun_SameKind;  //NSimSun 7
			}
			else if ( nLen == 8 )
			{
				if ( BrToLower(pFaceName[1]) == 0x61 ) 
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x6b, 0x69, 0x73, 0x69, 0x6d, 0x00 }; 
					if ( GetFontIndexByName( &pFaceName[1], wLocalFont, nLen-2 ))
						nFontFlag = f_Narkisim_SameKind;  //Narkisim 8
				}
			}
			else if ( nLen == 11 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x77, 0x73, 0x67, 0x6F, 0x74, 0x68, 0x20, 0x62, 0x74, 0x00 };	// NewsGoth BT	11
				//[19.01.25][sglee1206] 근본적인 해결방안은 아니나 NanumGothic인 경우 추가[PIE-1099]
				BrUSHORT wLocalFont2[] = { 0x61, 0x6E, 0x75, 0x6D, 0x67, 0x6F, 0x74, 0x68, 0x69, 0x63, 0x00 };	// NanumGothic	11
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_NewsGothBT_SameKind;
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont2, nLen-1 ))
					nFontFlag = f_NaNumGodik_SameKind;
			}
			else if ( nLen == 13 )
			{
				if (BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x67, 0x61, 0x72, 0x61, 0x20, 0x73, 0x6f, 0x6c, 0x69, 0x64, 0x00 }; 
					if ( GetFontIndexByName( &pFaceName[1], wLocalFont, nLen-2 ))
						nFontFlag = f_NiagaraEngraved_SameKind;   //Niagara Solid 13
				}
			}
			else if ( nLen == 14 )
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x77, 0x73, 0x70, 0x61, 0x70, 0x65, 0x72, 0x70, 0x69, 0x20, 0x62, 0x74, 0x00 };	// NewspaperPi BT 14
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_PTBarnumBT_SameKind;
			}
			else if ( nLen == 16 )
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x61, 0x67, 0x61, 0x72, 0x61, 0x20, 0x65, 0x6e, 0x67, 0x72, 0x61, 0x76, 0x65, 0x64, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_NiagaraEngraved_SameKind;   //Niagara Engraved 16
			}
			else if ( nLen == 17 )
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x74, 0x6f, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x6b, 0x61, 0x6e, 0x6e, 0x61, 0x64, 0x61, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_NotoSansKannada_SameKind;   //Noto Sans Kannada, XPD-17139
			}
			else if ( nLen == 25 )
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x74, 0x75, 0x72, 0x61, 0x20, 0x6D, 0x74, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x20, 0x63, 0x61, 0x70, 0x69, 0x74, 0x61, 0x6C, 0x73, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_CurlzMT_SameKind;   //Matura MT Script Capitals 25
			}
			else if ( nLen == 10 )
			{
				BrUSHORT wLocalFont[] = { 'i', 'r', 'm', 'a', 'l', 'a', 0x20, 'u', 'i', 0x00 };	// Nirmala UI 10
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Nirmala_UI_SameKind;
			}
			break;
		case 0x6f:
			if ( nLen == 4 )
			{
				BrUSHORT wLocalFont[] = { 0x6e, 0x79, 0x78, 0x00 }; 
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Onyx_SameKind;   //Onyx 4
			}
			else if (nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x62, 0x69, 0x74, 0x2D, 0x62, 0x20, 0x62, 0x74, 0x00 };	// Orbit-B BT 10
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_GillSansMT_SameKind;
			}
			else if (nLen == 14)
			{
				BrUSHORT wLocalFont[] = { 0x63, 0x72, 0x20, 0x61, 0x20, 0x65, 0x78, 0x74, 0x65, 0x6e, 0x64, 0x65, 0x64, 0x00 };
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_OCRAExtended_SameKind;   //OCR A Extended 14
			}
			else if (nLen == 17)
			{
				BrUSHORT wLocalFont[] = { 0x6C, 0x64, 0x64, 0x72, 0x65, 0x61, 0x64, 0x66, 0x75, 0x6C, 0x6E, 0x6F, 0x37, 0x20, 0x62, 0x74, 0x00 };
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Algerian_SameKind;   //OldDreadfulNo7 BT 17
			}
			else if (nLen == 19)
			{
				BrUSHORT wLocalFont[] = { 0x6C, 0x64, 0x20, 0x65, 0x6E, 0x67, 0x6C, 0x69, 0x73, 0x68, 0x20, 0x74, 0x65, 0x78, 0x74, 0x20, 0x6D, 0x74, 0x00 };	// Old English Text MT 19
				if ( GetFontIndexByName( &pFaceName[0], wLocalFont, nLen-1 ))
					nFontFlag = f_Impact_SameKind;
			}
			break;		
		case 0x70:
			if(nLen == 6)
			{
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x64, 0x61, 0x75, 0x6b, 0x73, 0x00 }; //Padauk 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Padauk_SameKind;
				}
			}
			else if(nLen == 7)
			{
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x70, 0x79, 0x72, 0x75, 0x73, 0x00 }; //Papyrus 7
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Papyrus_SameKind;
				}
				/*
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
				BrUSHORT wLocalFont[] = { 0x6f, 0x73, 0x74, 0x6e, 0x65, 0x74, 0x00 }; //POSTNET 7
				if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
				nFontFlag = f_POSTNET_SameKind;
				}
				*/
			}
			else if(nLen == 8)
			{	
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6C, 0x61, 0x74, 0x69, 0x6E, 0x6F, 0x00 };	// Palatino	8
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Castellar_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x70, 0x65, 0x74, 0x75, 0x61, 0x00 }; //Perpetua 8
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Perpetua_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x6c)
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x79, 0x62, 0x69, 0x6c, 0x6c, 0x00 }; //Playbill 8
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Playbill_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x6d)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x6e, 0x67, 0x6c, 0x69, 0x75, 0x00 }; //PMingLiU 8
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_PMingLiU_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x72)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x73, 0x74, 0x69, 0x6E, 0x61, 0x00 }; //Pristina 8
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Pristina_SameKind;
				}
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x72, 0x63, 0x68, 0x6D, 0x65, 0x6E, 0x74, 0x00 };	// Parchment 9
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Parchment_SameKind;
			}
			else if(nLen == 11)
			{
				BrUSHORT wLocalFont[] = { 0x74, 0x62, 0x61, 0x72, 0x6E, 0x75, 0x6D, 0x20, 0x62, 0x74, 0x00 };	// PTBarnum BT	11
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PTBarnumBT_SameKind;
			}
			else if(nLen == 12)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x6f, 0x72, 0x20, 0x72, 0x69, 0x63, 0x68, 0x61, 0x72, 0x64, 0x00 }; //Poor Richard 12
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PoorRichard_SameKind;
			}
			else if(nLen == 13)
			{
				if(BrToLower(pFaceName[1]) == 0x6d)
				{
					BrUSHORT wLocalFont[] = {0x69, 0x6e, 0x67, 0x6c, 0x69, 0x75, 0x2d, 0x65, 0x78, 0x74, 0x62, 0x00 }; //PMingLiU-ExtB 13
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_PMingLiU_SameKind;
				}	
				else if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6C, 0x61, 0x74, 0x69, 0x6E, 0x6F, 0x20, 0x62, 0x6F, 0x6C, 0x64, 0x00 };	// Palatino Bold 13
					BrUSHORT wLocalFont2[] = { 0x72, 0x6B, 0x61, 0x76, 0x65, 0x6E, 0x75, 0x65, 0x20, 0x62, 0x74, 0x00 };	// ParkAvenue BT 13
					
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_BookAntiqua_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_Castellar_SameKind;
				}	
			}
			else if(nLen == 16)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x6c, 0x61, 0x63, 0x65, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x20, 0x6d, 0x74, 0x00 }; //Palace Script MT 16
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PalaceScriptMT_SameKind;
			}
			else if(nLen == 17)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x6c, 0x61, 0x74, 0x69, 0x6e, 0x6f, 0x20, 0x6c, 0x69, 0x6e, 0x6f, 0x74, 0x79, 0x70, 0x65, 0x00 }; //Palatino Linotype 17
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PalatinoLinotype_SameKind;
			}
			else if(nLen == 19)
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x72, 0x70, 0x65, 0x74, 0x75, 0x61, 0x20, 0x74, 0x69, 0x74, 0x6c, 0x69, 0x6e, 0x67, 0x20, 0x6d, 0x74, 0x00 }; //Perpetua Titling MT 19
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PerpetuaTitlingMT_SameKind;
			}
			else if(nLen == 20)
			{
				BrUSHORT wLocalFont[] = { 0x6c, 0x61, 0x6e, 0x74, 0x61, 0x67, 0x65, 0x6e, 0x65, 0x74, 0x20, 0x63, 0x68, 0x65, 0x72, 0x6f, 0x6b, 0x65, 0x65, 0x00 }; //Plantagenet Cherokee 20
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PlantagenetCherokee_SameKind;
			}
			break;
		case 0x72:
			if(nLen == 3)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x64, 0x00 }; //Rod 3
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Rod_SameKind;				
			}	
			else if(nLen == 5 )
			{
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					if(BrToLower(pFaceName[2]) == 0x61)
					{
						if(BrToLower(pFaceName[3]) == 0x76 && BrToLower(pFaceName[4]) == 0x69)							
							nFontFlag = f_Raavi_SameKind;	//Raavi 5
					}
					else if(BrToLower(pFaceName[2]) == 0x76)
					{
						if(BrToLower(pFaceName[3]) == 0x69 && BrToLower(pFaceName[4]) == 0x65)							
							nFontFlag = f_CurlzMT_SameKind;	//Ravie 5
					}
				}
				/*
				else if(BrToLower(pFaceName[1]) == 0x6f)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x6f, 0x6d, 0x61, 0x6e, 0x00 }; //Roman 5
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Roman_SameKind;					
				}
				*/
			}
			else if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x62, 0x6f, 0x74, 0x6f, 0x00};	//Roboto
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Roboto_SameKind;
			}
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x63, 0x6b, 0x77, 0x65, 0x6c, 0x6c, 0x00 }; //Rockwell 8
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Rockwell_SameKind;
			}
			else if(nLen == 11)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x67, 0x65, 0x20, 0x69, 0x74, 0x61, 0x6C, 0x69, 0x63, 0x00 }; // Rage Italic 11
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_RageItalic_SameKind;
			}
			else if(nLen == 15)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x62, 0x62, 0x6F, 0x6E, 0x31, 0x33, 0x31, 0x20, 0x62, 0x64, 0x20, 0x62, 0x74, 0x00 };	// Ribbon131 Bd BT 15
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_GillSansMT_SameKind;
			}
			else if(nLen == 18)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x63, 0x6b, 0x77, 0x65, 0x6c, 0x6c, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; //Rockwell Condensed 18
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_RockwellCondensed_SameKind;
			}
			else if(nLen == 19)
			{
				BrUSHORT wLocalFont[] = { 0x6f, 0x63, 0x6b, 0x77, 0x65, 0x6c, 0x6c, 0x20, 0x65, 0x78, 0x74, 0x72, 0x61, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; //Rockwell Extra Bold 19
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_RockwellExtraBold_SameKind;
			}			
			break;			
		case 0x73:
			if(nLen == 14)
			{
				if(BrToLower(pFaceName[1]) == 0x61)
				{
					BrUSHORT wLocalFont[] = { 0x6b, 0x6b, 0x61, 0x6c, 0x20, 0x6d, 0x61, 0x6a, 0x61, 0x6c, 0x6c, 0x61, 0x00 }; //Sakkal Majalla 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SakkalMajalla_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x63)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x70, 0x74, 0x20, 0x6d, 0x74, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; //Script MT Bold 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_ScriptMTBold_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x67, 0x6f, 0x65, 0x20, 0x75, 0x69, 0x20, 0x6c, 0x69, 0x67, 0x68, 0x74, 0x00 }; //Segoe UI Light 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SegoeUILight_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x77)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x73, 0x37, 0x32, 0x31, 0x20, 0x62, 0x6C, 0x6B, 0x20, 0x62, 0x74, 0x00 };	// Swis721 Blk BT 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_BodoniMT_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x74)
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x63, 0x63, 0x61, 0x74, 0x6F, 0x35, 0x35, 0x35, 0x20, 0x62, 0x74, 0x00 };	// Staccato555 BT 14
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_LucidaBright_SameKind;
				}
			}
			else if(nLen == 6)
			{
				if(BrToLower(pFaceName[1]) == 0x63)
				{
					BrUSHORT wLocalFont[] = {0x72, 0x69, 0x70, 0x74, 0x00 }; //Script 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_ScriptMTBold_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x68)
				{
					BrUSHORT wLocalFont[] = {0x72, 0x75, 0x74, 0x69, 0x00 }; //Shruti 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Shruti_SameKind;										
				}
				else if(BrToLower(pFaceName[1]) == 0x79)
				{
					BrUSHORT wLocalFont[] = { 0x6D, 0x62, 0x6F, 0x6C, 0x00 };	// Symbol 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_BrushScriptMT_SameKind; 									
				}
				else if(BrToLower(pFaceName[1]) == 0x69 && BrToLower(pFaceName[2]) == 0x6d)
				{
					if(BrToLower(pFaceName[3]) == 0x68 )
					{
						BrUSHORT wLocalFont[] = { 0x65, 0x69, 0x00 }; //SimHei 6
						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_SimSun_SameKind;
					}
					else if(BrToLower(pFaceName[3]) == 0x73)
					{
						BrUSHORT wLocalFont[] = { 0x75, 0x6e, 0x00 }; //SimSun 6
						if(GetFontIndexByName(&pFaceName[3], wLocalFont, nLen-4))
							nFontFlag = f_SimSun_SameKind;					
					}
				}				
			}
			else if(nLen == 7)
			{
				if(BrToLower(pFaceName[1]) == 0x74)
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x6e, 0x63, 0x69, 0x6c, 0x00 }; //Stencil 7
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Stencil_SameKind;
				}				
				else if(BrToLower(pFaceName[1]) == 0x79)
				{
					BrUSHORT wLocalFont[] = { 0x6c, 0x66, 0x61, 0x65, 0x6e, 0x00 }; //Sylfaen 7
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Sylfaen_SameKind;
				}				
			}			
			else if(nLen == 8)
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x67, 0x6f, 0x65, 0x20, 0x75, 0x69, 0x00 }; //Segoe UI 8
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SegoeUI_SameKind;
				}				
				else if(BrToLower(pFaceName[1]) == 0x6e)
				{
					BrUSHORT wLocalFont[] = { 0x61, 0x70, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Snap ITC 8
					BrUSHORT wLocalFont2[] = { 0x65, 0x6C, 0x6C, 0x20, 0x62, 0x74, 0x00 };	// Snell BT	8

					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SnapITC_SameKind;
					else if(GetFontIndexByName(&pFaceName[1], wLocalFont2, nLen-2))
						nFontFlag = f_SnellBT_SameKind;
				}
			}
			else if(nLen == 15)
			{
				if(BrToLower(pFaceName[1]) == 0x68)
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x77, 0x63, 0x61, 0x72, 0x64, 0x20, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x00 }; //Showcard Gothic 15				
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_ShowcardGothic_SameKind;								
				}
				else
				{
					if(BrToLower(pFaceName[1]) == 0x65 && BrToLower(pFaceName[2]) == 0x67 && BrToLower(pFaceName[3]) == 0x6f && BrToLower(pFaceName[4]) == 0x65)
					{
						if(BrToLower(pFaceName[6]) == 0x75)
						{
							BrUSHORT wLocalFont[] = { 0x69, 0x20, 0x73, 0x79, 0x6d, 0x62, 0x6f, 0x6c, 0x00 }; //Segoe UI Symbol 15
							if(GetFontIndexByName(&pFaceName[6], wLocalFont, nLen-7))
								nFontFlag = f_SegoeUISymbol_SameKind;
						}
					}				
					else if(BrToLower(pFaceName[1]) == 0x6f && BrToLower(pFaceName[2]) == 0x75 && BrToLower(pFaceName[3]) == 0x72 && BrToLower(pFaceName[4]) == 0x63 && BrToLower(pFaceName[5]) == 0x65)
					{
						if(BrToLower(pFaceName[6]) == 0x20)
						{
							BrUSHORT wLocalFont[] = { 's', 'a', 'n', 's', 0x20, 'p', 'r', 'o', 0x00 }; //Source Sans Pro
							if(GetFontIndexByName(&pFaceName[6], wLocalFont, nLen-7))
								nFontFlag = f_Source_Sans_Pro_SameKind;
						}
					}				
				}
			}
			else if(nLen == 10)
			{
				if(BrToLower(pFaceName[1]) == 0x77)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x73, 0x37, 0x32, 0x31, 0x20, 0x62, 0x74, 0x00 }; //Swis721 BT 10
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_BodoniMT_SameKind;								
				}
				else if(BrToLower(pFaceName[1]) == 0x74)
				{
					BrUSHORT wLocalFont[] = { 0x65, 0x6E, 0x63, 0x69, 0x6C, 0x20, 0x62, 0x74, 0x00 };	// Stencil BT 10
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Century_SameKind;								
				}	
				else if(BrToLower(pFaceName[1]) == 0x6e)
				{
					BrUSHORT wLocalFont[] = { 0x6F, 0x77, 0x63, 0x61, 0x70, 0x20, 0x62, 0x74, 0x00 };	// SnowCap BT 10
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Impact_SameKind;								
				}
				else if(BrToLower(pFaceName[1]) == 0x68)
				{
					BrUSHORT wLocalFont[] = { 0x6F, 0x74, 0x67, 0x75, 0x6E, 0x20, 0x62, 0x74, 0x00 };	// Shotgun BT 10
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_NewsGothBT_SameKind;								
				}
			}
			else if(nLen == 11)
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x67, 0x6f, 0x65, 0x20, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x00 }; //Segoe Print 11
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SegoePrint_SameKind;								
				}
				else if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = {  0x6d, 0x73, 0x75, 0x6e, 0x2d, 0x65, 0x78, 0x74, 0x62, 0x00 }; //SimSun-ExtB 11
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SimSun_SameKind;								
				}
			}
			else if(nLen == 12)
			{
				BrUSHORT wLocalFont[] = { 0x65, 0x67, 0x6f, 0x65, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x00 }; //Segoe Script 12
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_SegoeScript_SameKind;								
			}			
			else if(nLen == 17)
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x67, 0x6f, 0x65, 0x20, 0x75, 0x69, 0x20, 0x73, 0x65, 0x6d, 0x69, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; //Segoe UI Semibold 17
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SegoeUISemibold_SameKind;							
				}
				else if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x6d, 0x70, 0x6c, 0x69, 0x66, 0x69, 0x65, 0x64, 0x20, 0x61, 0x72, 0x61, 0x62, 0x69, 0x63, 0x00 }; //Simplified Arabic 17
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_SimplifiedArabic_SameKind;							
				}
			}
			else if(nLen == 13)
			{
				if(BrToLower(pFaceName[1]) == 0x68)
				{
					BrUSHORT wLocalFont[] = { 0x6f, 0x6e, 0x61, 0x72, 0x20, 0x62, 0x61, 0x6e, 0x67, 0x6c, 0x61, 0x00 }; //Shonar Bangla 13
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_ShonarBangla_SameKind;							
				}
				else if(BrToLower(pFaceName[1]) == 0x77)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x73, 0x37, 0x32, 0x31, 0x20, 0x6C, 0x74, 0x20, 0x62, 0x74, 0x00 };	// Swis721 Lt BT 13
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_BodoniMT_SameKind;							
				}
			}
			else if(nLen == 23)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6d, 0x70, 0x6c, 0x69, 0x66, 0x69, 0x65, 0x64, 0x20, 0x61, 0x72, 0x61, 0x62, 0x69, 0x63, 0x20, 0x66, 0x69, 0x78, 0x65, 0x64, 0x00 }; //Simplified Arabic Fixed 23
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_SimplifiedArabicFixed_SameKind;										
			}			
			else if(nLen == 9)	// XPD-17459
			{
				BrUSHORT wLocalFont[] = { 0x74, 0x78, 0x69, 0x6e, 0x67, 0x6b, 0x61, 0x69, 0x00 }; //STXingKai 9
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_STXingKai_SameKind;										
			}			
			else if(nLen == 24)
			{
				if(BrToLower(pFaceName[1]) == 0x6f && BrToLower(pFaceName[2]) == 0x75 && BrToLower(pFaceName[3]) == 0x72 && BrToLower(pFaceName[4]) == 0x63 && BrToLower(pFaceName[5]) == 0x65)
				{
					if(BrToLower(pFaceName[6]) == 0x20)
					{
						BrUSHORT wLocalFont[] = { 's', 'a', 'n', 's', 0x20, 'p', 'r', 'o', 0x20, 's', 'e', 'm', 'i', 'b', 'o', 'l', 'd', 0x00 }; //Source Sans Pro Semibold
						if(GetFontIndexByName(&pFaceName[6], wLocalFont, nLen-7))
							nFontFlag = f_Source_Sans_Pro_SameKind;
					}
				}				
			}			
			break;
		case 0x74:
			if(nLen == 5)
			{
				if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x6d, 0x65, 0x73, 0x00 }; //Times 5
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_TimesNewRoman_SameKind;				
				}
				else if(BrToLower(pFaceName[1]) == 0x75)
				{
					BrUSHORT wLocalFont[] = { 0x6e, 0x67, 0x61, 0x00 }; //Tunga 5
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Tunga_SameKind;													
				}
			}
			else if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x68, 0x6f, 0x6d, 0x61, 0x00 }; //Tahoma 6
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Tahoma_SameKind;										
			}
			/*
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x78, 0x6c, 0x64, 0x72, 0x61, 0x77, 0x00 }; //Taxldraw 8
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_TaxldrawFont_SameKind;										
			}		
			*/
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0x77, 0x20, 0x63, 0x65, 0x6e, 0x20, 0x6d, 0x74, 0x00 }; //Tw Cen MT 9
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_TwCenMT_SameKind;										
			}					
			else if(nLen == 15)
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x6d, 0x70, 0x75, 0x73, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Tempus Sans ITC 15
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_TempusSansITC_SameKind;				
				}
				else if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x6d, 0x65, 0x73, 0x20, 0x6e, 0x65, 0x77, 0x20, 0x72, 0x6f, 0x6d, 0x61, 0x6e, 0x00 }; //Times New Roman 15
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_TimesNewRoman_SameKind;				
				}				
			}
			else if(nLen == 18)
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x61, 0x64, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x61, 0x6c, 0x20, 0x61, 0x72, 0x61, 0x62, 0x69, 0x63, 0x00 }; //Traditional Arabic 18
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_TraditionalArabic_SameKind;
			}
			else if(nLen == 19)
			{
				BrUSHORT wLocalFont[] = { 0x77, 0x20, 0x63, 0x65, 0x6e, 0x20, 0x6d, 0x74, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x00 }; //Tw Cen MT Condensed 19
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_TwCenMTCondensed_SameKind;
			}			
			else if(nLen == 12)
			{
				BrUSHORT wLocalFont[] = { 0x72, 0x65, 0x62, 0x75, 0x63, 0x68, 0x65, 0x74, 0x20, 0x6d, 0x73, 0x00 }; //Trebuchet MS 12
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_TrebuchetMS_SameKind;
			}
			else if(nLen == 30)
			{
				BrUSHORT wLocalFont[] = { 0x77, 0x20, 0x63, 0x65, 0x6e, 0x20, 0x6d, 0x74, 0x20, 0x63, 0x6f, 0x6e, 0x64, 0x65, 0x6e, 0x73, 0x65, 0x64, 0x20, 0x65, 0x78, 0x74, 0x72, 0x61, 0x20, 0x62, 0x6f, 0x6c, 0x64, 0x00 }; //Tw Cen MT Condensed Extra Bold 30
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_TwCenMTCondensedExtraBold_SameKind;
			}
			break;
		case 0x75:
			if(nLen == 6)
			{
				BrUSHORT wLocalFont[] = { 0x74, 0x73, 0x61, 0x61, 0x68, 0x00 }; //Utsaah 6
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Utsaah_SameKind;
			}
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0x6D, 0x62, 0x72, 0x61, 0x20, 0x62, 0x74, 0x00 }; //Umbra BT 8
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BlackadderITC_SameKind;
			}	
			else if(nLen == 16)
			{
				BrUSHORT wLocalFont[] = { 0x6E, 0x69, 0x76, 0x72, 0x73, 0x74, 0x79, 0x72, 0x6F, 0x6D, 0x61, 0x6E, 0x20, 0x62, 0x74, 0x00 };	// UnivrstyRoman BT	16
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BrushScriptMT_SameKind;
			}	
			break;
		case 0x76:
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x6e, 0x69, 0x00 }; //Vani 4
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Vani_SameKind;
			}
			else if(nLen == 6)
			{
				if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x6a, 0x61, 0x79, 0x61, 0x00 }; //Vijaya 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Vijaya_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x72)
				{
					BrUSHORT wLocalFont[] = { 0x69, 0x6e, 0x64, 0x61, 0x00 }; //Vrinda 6
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Vrinda_SameKind;
				}								
			}			
			else if(nLen == 7)
			{
				if(BrToLower(pFaceName[1]) == 0x65)
				{
					BrUSHORT wLocalFont[] = { 0x72, 0x64, 0x61, 0x6e, 0x61, 0x00 }; //Verdana 7
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Verdana_SameKind;
				}
				else if(BrToLower(pFaceName[1]) == 0x69)
				{
					BrUSHORT wLocalFont[] = { 0x76, 0x61, 0x6C, 0x64, 0x69, 0x00 };	// Vivaldi 7
					if(GetFontIndexByName(&pFaceName[1], wLocalFont, nLen-2))
						nFontFlag = f_Impact_SameKind;
				}
			}
			else if(nLen == 8)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x73, 0x75, 0x61, 0x6C, 0x75, 0x69, 0x00 };	// VisualUI	8
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Kartika_SameKind;			
			}
			else if(nLen == 9)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6E, 0x65, 0x74, 0x61, 0x20, 0x62, 0x74, 0x00 }; //Vineta BT 9
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_PalatinoLinotype_SameKind;			
			}
			else if(nLen == 13)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x67, 0x72, 0x6F, 0x75, 0x6E, 0x64, 0x65, 0x64, 0x20, 0x62, 0x74, 0x00 };	// VAGRounded BT 13
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BrushScriptMT_SameKind;			
			}
			else if(nLen == 14)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x6e, 0x65, 0x72, 0x20, 0x68, 0x61, 0x6e, 0x64, 0x20, 0x69, 0x74, 0x63, 0x00 }; //Viner Hand ITC 14
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_VinerHandITC_SameKind;			
			}
			else if(nLen == 15)
			{
				BrUSHORT wLocalFont[] = { 0x6C, 0x61, 0x64, 0x69, 0x6D, 0x69, 0x72, 0x20, 0x73, 0x63, 0x72, 0x69, 0x70, 0x74, 0x00 };	// Vladimir Script	15
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_Magneto_SameKind;			
			}
			break;
		case 0x77:
			if(nLen == 9)
			{
				BrUSHORT wWingding[] = {0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x00};		//Wingdings
				if(GetFontIndexByName(pFaceName, wWingding, nLen -1))
					nFontFlag = f_Wingdings_SameKind;
			}
			else if( nLen == 8 )
			{
				BrUSHORT wWebding[] = {0x65, 0x62, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x00};		//Webdings
				if(GetFontIndexByName(pFaceName, wWebding, nLen -1))
					nFontFlag = f_Webding_SameKind;
			}
			else if(nLen == 10)
			{
				BrUSHORT wLocalFont[] = { 0x69, 0x64, 0x65, 0x20, 0x6c, 0x61, 0x74, 0x69, 0x6e, 0x00 }; //Wide Latin 10
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_WideLatin_SameKind;			
			}	
			if(nLen == 11)
			{
				if(BrToLower(pFaceName[10]) == 0x32)
				{
					BrUSHORT wLocalFont[] = {0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x20, 0x32, 0x00};		//Wingdings 2
					if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
						nFontFlag = f_Wingdings2_SameKind;
				}
				else if(BrToLower(pFaceName[10]) == 0x33)
				{
					BrUSHORT wLocalFont[] = {0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x20, 0x33, 0x00};		//Wingdings 3
					if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
						nFontFlag = f_Wingdings3_SameKind;
				}
			}
			break;
		case 0x79:
			if (nLen == 9)
			{
				BrUSHORT wYuMincho[] = { 0x75, 0x20, 0x6D, 0x69, 0x6E, 0x63, 0x68, 0x6F, 0x00 };	// YuMincho
				if (GetFontIndexByName(pFaceName, wYuMincho, nLen - 1))
					nFontFlag = f_YuMincho_SameKind;
			}
			break;
		case 0x7a:	
			if( nLen == 7 )
			{
				BrUSHORT wZapfino[] = { 0x61, 0x70, 0x66, 0x69, 0x6E, 0x6F, 0x00};	// Zapfino
				if (GetFontIndexByName(pFaceName, wZapfino, nLen -1)) 
					nFontFlag = f_Zapfino_SameKind;
			}
			else if(nLen == 14)
			{
				BrUSHORT wLocalFont[] = { 0x61, 0x70, 0x66, 0x63, 0x61, 0x6C, 0x6C, 0x69, 0x67, 0x72, 0x20, 0x62, 0x74, 0x00 };	// ZapfCalligr BT	14
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
					nFontFlag = f_BookAntiqua_SameKind;			
			}
			//else if(nLen == 8)
			//{
			//	BrUSHORT wLocalFont[] = { 0x77, 0x61, 0x64, 0x6f, 0x62, 0x65, 0x66, 0x00 }; //ZWAdobeF 8
			//	if(GetFontIndexByName(pFaceName, wLocalFont, nLen-1))
			//		nFontFlag = f_ZWAdobeFFont_SameKind;			
			//}
			break;		
		case 0x5FAE:	// XPD-14448
			if(nLen == 4)
			{
				BrUSHORT wLocalFont[] = {0x8f6f, 0x96c5, 0x9ed1, 0x00};
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_MicrosoftYaHei_SameKind;
			}
			else if(nLen == 10)		// XPD-17033
			{
				BrUSHORT wLocalFont[] = {0x8f6f, 0x96c5, 0x9ed1, 0x20, 0x6c, 0x69, 0x67, 0x68, 0x74, 0x00};	// "微软雅黑 Light"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_MicrosoftYaHeiUI_SameKind;
			}
			break;
		//case 0x601d:
		//	if(nLen == 14)		// XPD-17033
		//	{
		//		BrUSHORT wLocalFont[] = {0x6e90, 0x9ed1, 0x4f53, 0x20, 'c', 'n', 0x20, 'n', 'o', 'r', 'm', 'a', 'l'};	// "思源黑体 CN Normal"
		//		if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
		//			nFontFlag = f_MicrosoftYaHei_SameKind;
		//	}
		//	break;
		case 0x4EFF:
			if ( nLen==2 )			// XPD-17348
			{
				BrUSHORT wLocalFont[] = {0x5b8b, 0x00};		// "仿宋"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_BangSong_SameKind;
			}
			else if ( nLen==9 )			//XPD-16862
			{
				BrUSHORT wLocalFont[] = {0x5b8b, 0x5f, 0x67, 0x62, 0x32, 0x33, 0x31, 0x32, 0x00};		// "仿宋_GB2312"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_FangSong_GB2312_SameKind;
			}
			break;
		case 0x534E:
			if ( nLen==4 )
			{
				BrUSHORT wLocalFont[] = {0x6587, 0x884c, 0x6977, 0x00};		// "华文行楷"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_STXingKai_SameKind;
			}
			break;
		case 0x6977:
			if ( nLen==2 )
			{
				BrUSHORT wLocalFont[] = {0x4f53, 0x00};		// "楷体"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_SimKai_SameKind;
			}
			else if ( nLen==9 )
			{
				BrUSHORT wLocalFont[] = {0x4f53, 0x5f, 0x67, 0x62, 0x32, 0x33, 0x31, 0x32, 0x00};		// "楷体_GB2312"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_KaiTi_SameKind;
			}
			break;
		case 0x9ed1 :
			if ( nLen==2 )
			{
				if( pFaceName[1] == 0x4f53 )			// "黑体"
					nFontFlag = f_SimSun_SameKind;
			}
			break;
		case 0x65b9 :
			if ( nLen==7 )
			{
				BrUSHORT wLocalFont[] = {0x6b63, 0x5c0f, 0x6807, 0x5b8b, 0x7b80, 0x4f53, 0x00};		// "方正小标宋简体"
				if(GetFontIndexByName(pFaceName, wLocalFont, nLen -1))
					nFontFlag = f_SimKai_SameKind;
			}
			break;
		case 0x02ce :
			if ( nLen==2 )
			{
				if ( pFaceName[1]==0x0325 )
					nFontFlag = f_Unknown1_SameKind;
			}
			break;
		case 0x6e38:
			if (nLen == 3)
			{
				BrUSHORT wLocalFont[] = { 0x660e, 0x671d, 0x00 };		// "游明朝"
				if (GetFontIndexByName(pFaceName, wLocalFont, nLen - 1))
					nFontFlag = f_YuMincho_SameKind;
			}
			else if (nLen == 11)
			{
				BrUSHORT wLocalFont[] = { 0x30B4, 0x30B7, 0x30C3, 0x30AF, 0x20, 0x6C, 0x69, 0x67, 0x68, 0x74, 0x00 };		// "游ゴシック Light"
				if (GetFontIndexByName(pFaceName, wLocalFont, nLen - 1))
					nFontFlag = f_YuGothic_SameKind;
			}
			break;
		case 0xff2d:
			if (nLen == 5)
			{
				BrUSHORT wLocalFont1[] = { 0xff33, 0x0020, 0x660e, 0x671d, 0x00 };		// "ＭＳ 明朝"
				if (GetFontIndexByName(pFaceName, wLocalFont1, nLen - 1))
					nFontFlag = f_MSPMincho_SameKind;

			}
			else if (nLen == 7)
			{
				BrUSHORT wLocalFont1[] = { 0xff33, 0x0020, 0x30b4, 0x30b7, 0x30c3, 0x30af, 0x00 };		// "ＭＳ ゴシック"
				if (GetFontIndexByName(pFaceName, wLocalFont1, nLen - 1))
					nFontFlag = f_MSGothic_SameKind;

			}
			else if (nLen == 8)
			{
				BrUSHORT wLocalFont1[] = { 0xff33, 0x0020, 0xff30, 0x30b4, 0x30b7, 0x30c3, 0x30af, 0x00 };		// "ＭＳ Ｐゴシック"
				if (GetFontIndexByName(pFaceName, wLocalFont1, nLen - 1))
					nFontFlag = f_MSPGothic_SameKind;

			}
			break;
	}

#if defined (USE_NEWFONT_LINESP) || defined (USE_NEWFONT_LINESP_PT) || defined (USE_NEWFONT_LINESP_CURRENT)
	// 새로운 FontLine Space layout이 맞다면 CheckDefaultFlag()를 없애자
#else
	//CheckDefaultFlag 인 추후 없어져야 할 임시 함수임.
	// 상단 새로운 폰트 Flag 내 해당 값을 매핑시켜 확장해야 됨.
	nFontFlag = CheckDefaultFlag(nFontFlag, wCode);
#endif //USE_NEWFONT_LINESP


	return nFontFlag; 
}

#if defined(USE_NEWFONT_LINESP)
double	CUtil::getDefaultLineSp(BrINT32 nFontFlag)
{
	BrDOUBLE nDfLineSp = 115;
	switch(nFontFlag)
	{
	case f_AmericanaBT_SameKind:          nDfLineSp = 0; break;
	case f_Ansangsoo2006Ganeun_SameKind:          nDfLineSp = 0; break;
	case f_Ansangsoo2006Gukeun_SameKind:          nDfLineSp = 0; break;
	case f_Ansangsoo2006Joonggan_SameKind:          nDfLineSp = 0; break;
	case f_AgencyFB_SameKind:         nDfLineSp = 117.92; break;
	case f_Aharoni_SameKind:          nDfLineSp = 99.64; break;
	case f_Algerian_SameKind:         nDfLineSp = 131.53; break;
	case f_Andalus_SameKind:          nDfLineSp = 152.5; break;
	case f_AndroidEmoji_SameKind:         nDfLineSp = 145.28; break;
	case f_AngsanaUPC_SameKind:         nDfLineSp = 134.79; break;
	case f_Aparajita_SameKind:          nDfLineSp = 117.92;  break;
	case f_ArabicTypesetting_SameKind:          nDfLineSp = 114.52;  break;
	case f_Arial_SameKind:          nDfLineSp = 114.94;  break;
	case f_ArialBlack_SameKind:         nDfLineSp = 140.88; break;
	case f_ArialNarrow_SameKind:          nDfLineSp = 114.52;  break;
	case f_ArialRoundedMTBold_SameKind:         nDfLineSp = 115.65; break;
	case f_ArialUnicodeMS_SameKind:         nDfLineSp = 174.19; break;
	case f_BalloonXBdBT_SameKind:         nDfLineSp = 0;  break;
	case f_BankGothicMdBT_SameKind:         nDfLineSp = 0;  break;
	case f_BaskervilleOldFace_SameKind:         nDfLineSp = 0;  break;
	case f_Batang_SameKind:         nDfLineSp = 129.97; break;
	case f_Batangche_SameKind:          nDfLineSp = 129.97;  break;
	case f_Bauhaus93_SameKind:          nDfLineSp = 145.7; break;
	case f_BellMT_SameKind:         nDfLineSp = 111.15; break;
	case f_BernardMTCon_SameKind:         nDfLineSp = 118.77; break;
	case f_BerlinSansFB_SameKind:         nDfLineSp = 109.7;  break;
	case f_BerlinSansFBDemi_SameKind:         nDfLineSp = 112.68; break;
	case f_BernardMTCondensed_SameKind:         nDfLineSp = 118.77; break;
	case f_BlackadderITC_SameKind:          nDfLineSp = 128.13;  break;
	case f_BodoniMT_SameKind:         nDfLineSp = 119.76; break;
	case f_BodoniMTBlack_SameKind:          nDfLineSp = 116.5; break;
	case f_BodoniMTCondensed_SameKind:          nDfLineSp = 117.64;  break;
	case f_BodoniMTPosterCompressed_SameKind:         nDfLineSp = 114.52; break;
	case f_BookAntiqua_SameKind:          nDfLineSp = 124.02;  break;
	case f_BookmanOldStyle_SameKind:          nDfLineSp = 117.21;  break;
	case f_BookshelfSymbol5_SameKind:         nDfLineSp = 0;  break;
	case f_BradleyHandITC_SameKind:         nDfLineSp = 124.72; break;
	case f_BritannicBold_SameKind:          nDfLineSp = 110.41;  break;
	case f_Broadway_SameKind:         nDfLineSp = 113.1;  break;
	case f_BrowalliaNew_SameKind:         nDfLineSp = 124.87; break;
	case f_BrowalliaUPC_SameKind:         nDfLineSp = 124.72; break;
	case f_BrushScriptMT_SameKind:          nDfLineSp = 122.46;  break;
	case f_Calibri_SameKind:          nDfLineSp = 122.03;  break;
	case f_CalibriLight_SameKind:         nDfLineSp = 122.03; break;
	case f_CalifornianFB_SameKind:          nDfLineSp = 113.53;  break;
	case f_CalistoMT_SameKind:          nDfLineSp = 115.37;  break;
	case f_Cambria_SameKind:          nDfLineSp = 117.21;  break;
	case f_Candara_SameKind:          nDfLineSp = 122.03;  break;
	case f_Castellar_SameKind:          nDfLineSp = 120.4;  break;
	case f_Centaur_SameKind:          nDfLineSp = 113.81;  break;
	case f_Century_SameKind:          nDfLineSp = 120.19;  break;
	case f_CenturyGothic_SameKind:          nDfLineSp = 122.46;  break;
	case f_Chiller_SameKind:          nDfLineSp = 115.37;  break;
	case f_ColonnaMT_SameKind:          nDfLineSp = 105.59;  break;
	case f_ComicSansMS_SameKind:          nDfLineSp = 139.32;  break;
	case f_Consolas_SameKind:         nDfLineSp = 116.79; break;
	case f_Constantia_SameKind:         nDfLineSp = 122.03; break;
	case f_CooperBlack_SameKind:          nDfLineSp = 114.52;  break;
	case f_CopperplateGotBold_SameKind:         nDfLineSp = 111.26; break;
	case f_CopprpGothBT_SameKind:         nDfLineSp = 0;  break;
	case f_Corbel_SameKind:         nDfLineSp = 122.03; break;
	case f_CordiaUPC_SameKind:          nDfLineSp = 138.61;  break;
	case f_CourierNew_SameKind:         nDfLineSp = 113.1;  break;
	case f_CurlzMT_SameKind:          nDfLineSp = 132.52;  break;
	case f_DaunPenh_SameKind:         nDfLineSp = 0;  break;
	case f_DFKai_SB_SameKind:         nDfLineSp = 129.97; break;
	case f_DilleniaUPC_SameKind:          nDfLineSp = 130.39;  break;
	case f_DokChampa_SameKind:          nDfLineSp = 134.5; break;
	case f_Dotum_SameKind:          nDfLineSp = 129.97;  break;
	case f_Dotumche_SameKind:         nDfLineSp = 129.97; break;
	case f_DroidSerif_SameKind:         nDfLineSp = 116.08; break;
	case f_Ebrima_SameKind:         nDfLineSp = 135.64; break;
	case f_Elephant_SameKind:         nDfLineSp = 128.83; break;
	case f_EngraversMT_SameKind:          nDfLineSp = 116.5; break;
	case f_ErasBoldITC_SameKind:          nDfLineSp = 115.65;  break;
	case f_ErasDemiITC_SameKind:          nDfLineSp = 114.52;  break;
	case f_ErasLightITC_SameKind:         nDfLineSp = 113.1;  break;
	case f_ErasMediumITC_SameKind:          nDfLineSp = 113.81;  break;
	case f_EstrangeloEdessa_SameKind:         nDfLineSp = 111.54; break;
	case f_EucrosiaUPC_SameKind:          nDfLineSp = 122.03;  break;
	case f_Euphemia_SameKind:         nDfLineSp = 135.21; break;
	case f_FangSong_SameKind:         nDfLineSp = 129.54; break;
	case f_FelixTitling_SameKind:         nDfLineSp = 116.79; break;
	case f_Fences_SameKind:         nDfLineSp = 0;  break;
	case f_FootlightMTLight_SameKind:         nDfLineSp = 105.59; break;
	case f_FranklinGothicBook_SameKind:         nDfLineSp = 113.1;  break;
	case f_FranklinGothicDemi_SameKind:         nDfLineSp = 113.1;  break;
	case f_FranklinGothicDemiCond_SameKind:         nDfLineSp = 113.1;  break;
	case f_FranklinGothicHeavy_SameKind:          nDfLineSp = 113.1; break;
	case f_FranklinGothicMedium_SameKind:         nDfLineSp = 113.1;  break;
	case f_FranklinGothicMediumCond_SameKind:         nDfLineSp = 113.1;  break;
	case f_FrankRuehl_SameKind:         nDfLineSp = 99.92;  break;
	case f_Freehand591BT_SameKind:          nDfLineSp = 123.59;  break;
	case f_FreesiaUPC_SameKind:         nDfLineSp = 119.76; break;
	case f_Gabriola_SameKind:         nDfLineSp = 169.65; break;
	case f_GaneunAnsangsooche_SameKind:         nDfLineSp = 130.39; break;
	case f_Garamond_SameKind:         nDfLineSp = 112.39; break;
	case f_Gautami_SameKind:          nDfLineSp = 190.35;  break;
	case f_Georgia_SameKind:          nDfLineSp = 113.53;  break;
	case f_GillSansMT_SameKind:         nDfLineSp = 115.65; break;
	case f_GillSansMTCondensed_SameKind:          nDfLineSp = 120.19;  break;
	case f_GillSansUltraBold_SameKind:          nDfLineSp = 124.3; break;
	case f_GillSansUltraBoldCondensed_SameKind:         nDfLineSp = 124.3;  break;
	case f_Gisha_SameKind:          nDfLineSp = 117.21;  break;
	case f_GloucesterMTExtraCondensed_SameKind:         nDfLineSp = 116.08; break;
	case f_GoudyOldStyle_SameKind:          nDfLineSp = 119.76;  break;
	case f_GoudyStout_SameKind:         nDfLineSp = 136.77; break;
	case f_GukeunAnsangsooche_SameKind:         nDfLineSp = 130.39; break;
	case f_Gulim_SameKind:          nDfLineSp = 129.97;  break;
	case f_Gullimche_SameKind:          nDfLineSp = 129.97;  break;
	case f_Gungseo_SameKind:          nDfLineSp = 130.05;  break;
	case f_Gungseoche_SameKind:         nDfLineSp = 129.97; break;
	case f_H_MULT1_SameKind:          nDfLineSp = 0; break;
	case f_H_PROSYM_SameKind:         nDfLineSp = 0;  break;
	case f_Haettenschweiler_SameKind:         nDfLineSp = 106.72; break;
	case f_HamChoromDotum_SameKind:         nDfLineSp = 168.94; break;
	case f_HamChoromBatang_SameKind:         nDfLineSp = 168.52; break;
	case f_HamChoromDotumHwakjang_SameKind:         nDfLineSp = 168.94; break;
	case f_HanComBargainsaleB_SameKind:         nDfLineSp = 166.39; break;
	case f_HanComBargainsaleM_SameKind:         nDfLineSp = 164.41; break;
	case f_HanComBaekjeB_SameKind:          nDfLineSp = 174.19;  break;
	case f_HanComBaekjeM_SameKind:          nDfLineSp = 170.5; break;
	case f_HanComSomangB_SameKind:          nDfLineSp = 188.08;  break;
	case f_HanComSomangM_SameKind:          nDfLineSp = 188.5; break;
	case f_HanComSolipB_SameKind:         nDfLineSp = 180.14; break;
	case f_HanComSolipM_SameKind:         nDfLineSp = 180.14; break;
	case f_HanComYoonGodik230_SameKind:         nDfLineSp = 182.41; break;
	case f_HanComYoonGodik240_SameKind:         nDfLineSp = 184.68; break;
	case f_HanComYoonGodik250_SameKind:         nDfLineSp = 187.65; break;
	case f_HanComYooncheB_SameKind:         nDfLineSp = 180.99; break;
	case f_HanComYooncheL_SameKind:         nDfLineSp = 176.88; break;
	case f_HanComYooncheM_SameKind:         nDfLineSp = 177.59; break;
	case f_HanComCooljazzB_SameKind:          nDfLineSp = 138.19;  break;
	case f_HanComCooljazzL_SameKind:          nDfLineSp = 134.08;  break;
	case f_HanComCooljazzM_SameKind:          nDfLineSp = 142.02;  break;
	case f_HanComBatang_SameKind:			nDfLineSp = 130.03;  break;
	case f_HanComBatangExt_SameKind:          nDfLineSp = 165.97;  break;
	case f_HarlowSolidItalic_SameKind:          nDfLineSp = 126.14;  break;
	case f_Harrington_SameKind:         nDfLineSp = 117.64; break;
	case f_HCIPoppy_SameKind:         nDfLineSp = 0;  break;
	case f_Helvetica_SameKind:          nDfLineSp = 114.94;  break;
	case f_HESPERANTO_SameKind:         nDfLineSp = 0;  break;
	case f_HighTowerText_SameKind:          nDfLineSp = 116.08;  break;
	case f_HMULTI2_SameKind:          nDfLineSp = 0; break;
	case f_HPCOB_SameKind:          nDfLineSp = 115.65;  break;
	case f_HPCOB2_SameKind:         nDfLineSp = 120.61; break;
	case f_HPCOBB_SameKind:         nDfLineSp = 129.26; break;
	case f_HPCOBI_SameKind:         nDfLineSp = 115.65; break;
	case f_HPLTH_SameKind:          nDfLineSp = 131.53;  break;
	case f_HPLTHB_SameKind:         nDfLineSp = 127.7;  break;
	case f_HPLTHI_SameKind:         nDfLineSp = 124.72; break;
	case f_HYGyeonGodik_SameKind:         nDfLineSp = 129.97; break;
	case f_HYGyeonMyeongjo_SameKind:          nDfLineSp = 129.97;  break;
	case f_HYGungseo_SameKind:         nDfLineSp = 129.97; break;
	case f_HYGulim_SameKind:	nDfLineSp = 129.97; break;
	case f_HYDotum_SameKind:	nDfLineSp = 129.97; break;
	case f_HYGraphicM_SameKind:         nDfLineSp = 129.97; break;
	case f_HYMokgakPaimB_SameKind:          nDfLineSp = 129.97;  break;
	case f_HYSinMyeongjo_SameKind:          nDfLineSp = 129.97;  break;
	case f_HYUlleungdo_SameKind:          nDfLineSp = 129.97;  break;
	case f_HyumeonAmiche_SameKind:          nDfLineSp = 140.03;  break;
	case f_HyumeonExpo_SameKind:          nDfLineSp = 144.99;  break;
	case f_HyumeonDunggeunHaedeuLine_SameKind:          nDfLineSp = 135.21;  break;
	case f_HyumeonMagicChe_SameKind:          nDfLineSp = 130.39;  break;
	case f_HyumeonMoeumT_SameKind:          nDfLineSp = 144.99;  break;
	case f_HyumeonPyeonjiche_SameKind:          nDfLineSp = 150.94;  break;
	case f_HyumeonYetche_SameKind:          nDfLineSp = 137.48;  break;
	case f_HyumeonGaneunSaemche_SameKind:         nDfLineSp = 130.39; break;
	case f_HyumeonGaneunPaemche_SameKind:         nDfLineSp = 130.39; break;
	case f_HyumeonJoongganSaemche_SameKind:         nDfLineSp = 130.39; break;
	case f_HyumeonJoongganPaemche_SameKind:         nDfLineSp = 130.39; break;
	case f_HYYateunSammulM_SameKind:          nDfLineSp = 129.97;  break;
	case f_HYYeopseoL_SameKind:         nDfLineSp = 129.97; break;
	case f_HYYeopseoM_SameKind:         nDfLineSp = 129.97; break;
	case f_HYJungGodik_SameKind:          nDfLineSp = 129.97;  break;
	case f_HYHaedeuLineM_SameKind:          nDfLineSp = 129.97;  break;
	case f_Impact_SameKind:         nDfLineSp = 121.75; break;
	case f_ImprintMTShadow_SameKind:          nDfLineSp = 117.64;  break;
	case f_IrisUPC_SameKind:          nDfLineSp = 126.14;  break;
	case f_IskoolaPota_SameKind:          nDfLineSp = 113.53;  break;
	case f_JasmineUPC_SameKind:         nDfLineSp = 105.59; break;
	case f_Jokerman_SameKind:         nDfLineSp = 150.94; break;
	case f_KaiTi_SameKind:          nDfLineSp = 129.54;  break;
	case f_Kalinga_SameKind:          nDfLineSp = 158.03;  break;
	case f_Kartika_SameKind:          nDfLineSp = 142.3; break;
	case f_KhmerUI_SameKind:          nDfLineSp = 113.1; break;
	case f_KodchiangUPC_SameKind:         nDfLineSp = 98.08;  break;
	case f_Kokila_SameKind:         nDfLineSp = 114.94; break;
	case f_KristenITC_SameKind:         nDfLineSp = 135.92; break;
	case f_KunstlerScript_SameKind:         nDfLineSp = 109.28; break;
	case f_LaoUI_SameKind:          nDfLineSp = 132.94;  break;
	case f_Latha_SameKind:          nDfLineSp = 165.97;  break;
	case f_Leelawadee_SameKind:         nDfLineSp = 119.48; break;
	case f_LevenimMT_SameKind:          nDfLineSp = 139.75;  break;
	case f_LilyUPC_SameKind:          nDfLineSp = 95.1;  break;
	case f_LucidaBright_SameKind:         nDfLineSp = 117.64; break;
	case f_LucidaCalligraphy_SameKind:          nDfLineSp = 135.92;  break;
	case f_LucidaConsole_SameKind:          nDfLineSp = 99.92; break;
	case f_LucidaFax_SameKind:          nDfLineSp = 117.64;  break;
	case f_LucidaHandwriting_SameKind:          nDfLineSp = 137.76;  break;
	case f_LucidaSans_SameKind:         nDfLineSp = 117.64; break;
	case f_LucidaSansTypewriter_SameKind:         nDfLineSp = 117.21; break;
	case f_LucidaSansUnicode_SameKind:          nDfLineSp = 153.64;  break;
	case f_Magneto_SameKind:          nDfLineSp = 120.9; break;
	case f_MaiandraGD_SameKind:         nDfLineSp = 119.76; break;
	case f_MakeunGodik_SameKind:          nDfLineSp = 172.77;  break;
	case f_Mangal_SameKind:         nDfLineSp = 167.81; break;
	case f_MDGaesungche_SameKind:         nDfLineSp = 129.97; break;
	case f_MDSolche_SameKind:         nDfLineSp = 129.97; break;
	case f_MDArongche_SameKind:         nDfLineSp = 129.97; break;
	case f_MDArtche_SameKind:         nDfLineSp = 129.97; break;
	case f_MDIsopche_SameKind:          nDfLineSp = 129.97;  break;
	case f_Meiryo_SameKind:         nDfLineSp = 194.88; break;
	case f_MicrosoftHimalaya_SameKind:          nDfLineSp = 99.92; break;
	case f_MicrosoftJhengHei_SameKind:          nDfLineSp = 172.77;  break;
	case f_MicrosoftNewTaiLue_SameKind:         nDfLineSp = 130.68; break;
	case f_MicrosoftPhagsPa_SameKind:         nDfLineSp = 127.7;  break;
	case f_MicrosoftSansSerif_SameKind:         nDfLineSp = 113.1;  break;
	case f_MicrosoftTaiLe_SameKind:         nDfLineSp = 126.99; break;
	case f_MicrosoftUighur_SameKind:          nDfLineSp = 107.86;  break;
	case f_MicrosoftYaHei_SameKind:         nDfLineSp = 171.21; break;
	case f_MicrosoftYiBaiti_SameKind:         nDfLineSp = 102.61; break;
	case f_MingLiU_SameKind:          nDfLineSp = 129.97;  break;
	case f_Miriam_SameKind:         nDfLineSp = 101.91; break;
	case f_MiriamFixed_SameKind:          nDfLineSp = 99.92; break;
	case f_ModernNo20_SameKind:         nDfLineSp = 106.72; break;
	case f_MongolianBaiti_SameKind:         nDfLineSp = 106.3;  break;
	case f_MonotypeCorsiva_SameKind:          nDfLineSp = 111.97;  break;
	case f_MoolBoran_SameKind:          nDfLineSp = 135.64;  break;
	case f_MSGothic_SameKind:         nDfLineSp = 129.54; break;
	case f_MSOutlook_SameKind:          nDfLineSp = 103.75;  break;
	case f_MSPGothic_SameKind:          nDfLineSp = 129.54;  break;
	case f_MSPMincho_SameKind:          nDfLineSp = 129.54;  break;
	case f_MSReferenceSansSerif_SameKind:         nDfLineSp = 121.32; break;
	case f_MSUIGothic_SameKind:         nDfLineSp = 129.54; break;
	case f_MTExtra_SameKind:          nDfLineSp = 129.54;  break;
	case f_MunchebugungcheJungjache_SameKind:         nDfLineSp = 129.97; break;
	case f_MunchebugungcheHeulrimche_SameKind:          nDfLineSp = 129.97;  break;
	case f_MunchebuDotumche_SameKind:         nDfLineSp = 129.97; break;
	case f_MunchebuBatangche_SameKind:          nDfLineSp = 129.97;  break;
	case f_MunchebuSseugijungche_SameKind:          nDfLineSp = 129.97;  break;
	case f_MunchebuJemokDotumche_SameKind:          nDfLineSp = 129.97;  break;
	case f_MunchebuJemokBatangche_SameKind:         nDfLineSp = 129.97; break;
	case f_MunchebuHunminjungeumche_SameKind:         nDfLineSp = 129.97; break;
	case f_MVBoli_SameKind:         nDfLineSp = 161.15; break;
	case f_Narkisim_SameKind:         nDfLineSp = 99.92;  break;
	case f_NewsGothBT_SameKind:         nDfLineSp = 0;  break;
	case f_NiagaraEngraved_SameKind:          nDfLineSp = 107.15;  break;
	case f_NSimSun_SameKind:          nDfLineSp = 129.54;  break;
	case f_Nyala_SameKind:          nDfLineSp = 104.46;  break;
	case f_OCRAExtended_SameKind:         nDfLineSp = 103.32; break;
	case f_Onyx_SameKind:         nDfLineSp = 114.52; break;
	case f_Padauk_SameKind:         nDfLineSp = 147.26; break;
	case f_PalaceScriptMT_SameKind:         nDfLineSp = 92.41;  break;
	case f_PalatinoLinotype_SameKind:         nDfLineSp = 134.79; break;
	case f_Papyrus_SameKind:          nDfLineSp = 157.32;  break;
	case f_Parchment_SameKind:          nDfLineSp = 106.72;  break;
	case f_Penheulrim_SameKind:         nDfLineSp = 129.97; break;
	case f_Perpetua_SameKind:         nDfLineSp = 114.52; break;
	case f_PerpetuaTitlingMT_SameKind:          nDfLineSp = 117.92;  break;
	case f_PlantagenetCherokee_SameKind:          nDfLineSp = 131.53;  break;
	case f_Playbill_SameKind:         nDfLineSp = 101.06; break;
	case f_PMingLiU_SameKind:         nDfLineSp = 129.97; break;
	case f_PoorRichard_SameKind:          nDfLineSp = 112.39;  break;
	case f_Pristina_SameKind:         nDfLineSp = 131.1;  break;
	case f_PTBarnumBT_SameKind:         nDfLineSp = 0;  break;
	case f_Raavi_SameKind:          nDfLineSp = 178.3; break;
	case f_RageItalic_SameKind:         nDfLineSp = 125.43; break;
	case f_Roboto_SameKind:         nDfLineSp = 119.76; break;
	case f_Rockwell_SameKind:         nDfLineSp = 117.21; break;
	case f_RockwellCondensed_SameKind:          nDfLineSp = 117.64;  break;
	case f_RockwellExtraBold_SameKind:          nDfLineSp = 117.21;  break;
	case f_Rod_SameKind:          nDfLineSp = 99.92; break;
	case f_SaeGulim_SameKind:         nDfLineSp = 129.97; break;
	case f_SakkalMajalla_SameKind:          nDfLineSp = 139.32;  break;
	case f_ScriptMTBold_SameKind:         nDfLineSp = 120.19; break;
	case f_SegoePrint_SameKind:         nDfLineSp = 176.46; break;
	case f_SegoeScript_SameKind:          nDfLineSp = 158.03;  break;
	case f_SegoeUI_SameKind:          nDfLineSp = 132.94;  break;
	case f_SegoeUILight_SameKind:         nDfLineSp = 132.94; break;
	case f_SegoeUISemibold_SameKind:          nDfLineSp = 132.94;  break;
	case f_SegoeUISymbol_SameKind:          nDfLineSp = 132.94;  break;
	case f_ShonarBangla_SameKind:         nDfLineSp = 129.26; break;
	case f_ShowcardGothic_SameKind:         nDfLineSp = 123.59; break;
	case f_Shruti_SameKind:         nDfLineSp = 183.26; break;
	case f_SimplifiedArabic_SameKind:         nDfLineSp = 165.54; break;
	case f_SimplifiedArabicFixed_SameKind:          nDfLineSp = 108.99;  break;
	case f_SimSun_SameKind:         nDfLineSp = 129.54; break;
	case f_SnapITC_SameKind:          nDfLineSp = 128.41;  break;
	case f_SnellBT_SameKind:          nDfLineSp = 0; break;
	case f_Stencil_SameKind:          nDfLineSp = 118.35;  break;
	case f_Sylfaen_SameKind:          nDfLineSp = 131.53;  break;
	case f_Taenamoo_SameKind:         nDfLineSp = 129.97; break;
	case f_Tahoma_SameKind:         nDfLineSp = 120.61; break;
	case f_TempusSansITC_SameKind:          nDfLineSp = 130.39;  break;
	case f_TimesNewRoman_SameKind:          nDfLineSp = 114.94;  break;
	case f_TraditionalArabic_SameKind:          nDfLineSp = 149.39;  break;
	case f_TrebuchetMS_SameKind:          nDfLineSp = 116.08;  break;
	case f_Tunga_SameKind:          nDfLineSp = 176.88;  break;
	case f_TwCenMT_SameKind:          nDfLineSp = 108.57;  break;
	case f_TwCenMTCondensed_SameKind:         nDfLineSp = 106.72; break;
	case f_TwCenMTCondensedExtraBold_SameKind:          nDfLineSp = 108.14;  break;
	case f_Utsaah_SameKind:         nDfLineSp = 111.54; break;
	case f_Vani_SameKind:         nDfLineSp = 168.24; break;
	case f_Verdana_SameKind:          nDfLineSp = 121.32;  break;
	case f_Vijaya_SameKind:         nDfLineSp = 100.35; break;
	case f_VinerHandITC_SameKind:         nDfLineSp = 161.15; break;
	case f_Vrinda_SameKind:         nDfLineSp = 140.46; break;
	case f_WideLatin_SameKind:          nDfLineSp = 122.88;  break;
	case f_Wingdings_SameKind:          nDfLineSp = 110.83;  break;
	case f_Wingdings2_SameKind:         nDfLineSp = 105.17; break;
	case f_Wingdings3_SameKind:         nDfLineSp = 113.81; break;
	case f_Webding_SameKind:          nDfLineSp = 99.92; break;
	case f_YangjaeKkaebicheB_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeKkotgecheM_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeNanchocheM_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeDaunMyeongjoM_SameKind:         nDfLineSp = 129.97; break;
	case f_YangjaeMaehwacheS_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeBaekdoocheB_SameKind:         nDfLineSp = 129.97; break;
	case f_YangjaeBelracheM_SameKind:         nDfLineSp = 129.97; break;
	case f_YangjaeBonmokgakcheM_SameKind:         nDfLineSp = 129.97; break;
	case f_YangjaeButkkotcheL_SameKind:         nDfLineSp = 129.97; break;
	case f_YangjaeSoseulcheS_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeWadangcheM_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeInitialche_SameKind:          nDfLineSp = 129.97;  break;
	case f_YangjaeChamsutcheB_SameKind:         nDfLineSp = 129.97; break;
	case f_YangjaeTeunteuncheB_SameKind:          nDfLineSp = 129.97;  break;
	case f_JoongganAnsangsooche_SameKind:         nDfLineSp = 130.39; break;
	case f_YunDesignWeb_SameKind:         nDfLineSp = 0;  break;
	case f_YuMincho_SameKind:         nDfLineSp = 119.6;  break;
	case f_YuGothic_SameKind:         nDfLineSp = 160.2;  break;
	case f_Zapfino_SameKind:          nDfLineSp = 0; break;
	}

	return nDfLineSp;
}
#elif defined(USE_NEWFONT_LINESP_PT)
double	CUtil::getDefaultLineSp(BrINT32 nFontFlag)
{
	BrDOUBLE nDfLineSp = 115;
	switch(nFontFlag)
	{
	case f_AmericanaBT_SameKind:	nDfLineSp = 0;  break;
	case f_Ansangsoo2006Ganeun_SameKind:	nDfLineSp = 0;  break;
	case f_Ansangsoo2006Gukeun_SameKind:	nDfLineSp = 0;  break;
	case f_Ansangsoo2006Joonggan_SameKind:	nDfLineSp = 0;  break;
	case f_AgencyFB_SameKind:	nDfLineSp = 118.425;  break;
	case f_Aharoni_SameKind:	nDfLineSp = 99.975; break;
	case f_Algerian_SameKind:	nDfLineSp = 132;  break;
	case f_Andalus_SameKind:	nDfLineSp = 152.625;  break;
	case f_AndroidEmoji_SameKind:	nDfLineSp = 145.575;  break;
	case f_AngsanaUPC_SameKind:	nDfLineSp = 135.075;  break;
	case f_Aparajita_SameKind:	nDfLineSp = 118.2;  break;
	case f_ArabicTypesetting_SameKind:	nDfLineSp = 114.675;  break;
	case f_Arial_SameKind:	nDfLineSp = 115.025;  break;
	case f_ArialBlack_SameKind:	nDfLineSp = 141;  break;
	case f_ArialNarrow_SameKind:	nDfLineSp = 114.75; break;
	case f_ArialRoundedMTBold_SameKind:	nDfLineSp = 115.725;  break;
	case f_ArialUnicodeMS_SameKind:	nDfLineSp = 174.225;  break;
	case f_BalloonXBdBT_SameKind:	nDfLineSp = 0;  break;
	case f_BankGothicMdBT_SameKind:	nDfLineSp = 0;  break;
	case f_BaskervilleOldFace_SameKind:	nDfLineSp = 0;  break;
	case f_Batang_SameKind:	nDfLineSp = 130.05; break;
	case f_Batangche_SameKind:	nDfLineSp = 130.05; break;
	case f_Bauhaus93_SameKind:	nDfLineSp = 146.025;  break;
	case f_BellMT_SameKind:	nDfLineSp = 111.15; break;
	case f_BernardMTCon_SameKind:	nDfLineSp = 118.725;  break;
	case f_BerlinSansFB_SameKind:	nDfLineSp = 109.875;  break;
	case f_BerlinSansFBDemi_SameKind:	nDfLineSp = 112.875;  break;
	case f_BernardMTCondensed_SameKind:	nDfLineSp = 118.725;  break;
	case f_BlackadderITC_SameKind:	nDfLineSp = 128.25; break;
	case f_BodoniMT_SameKind:	nDfLineSp = 119.925;  break;
	case f_BodoniMTBlack_SameKind:	nDfLineSp = 116.775;  break;
	case f_BodoniMTCondensed_SameKind:	nDfLineSp = 117.675;  break;
	case f_BodoniMTPosterCompressed_SameKind:	nDfLineSp = 114.75; break;
	case f_BookAntiqua_SameKind:	nDfLineSp = 124.275;  break;
	case f_BookmanOldStyle_SameKind:	nDfLineSp = 117.375;  break;
	case f_BookshelfSymbol5_SameKind:	nDfLineSp = 0;  break;
	case f_BradleyHandITC_SameKind:	nDfLineSp = 124.725;  break;
	case f_BritannicBold_SameKind:	nDfLineSp = 110.775;  break;
	case f_Broadway_SameKind:	nDfLineSp = 113.25; break;
	case f_BrowalliaNew_SameKind:	nDfLineSp = 124.95; break;
	case f_BrowalliaUPC_SameKind:	nDfLineSp = 124.95; break;
	case f_BrushScriptMT_SameKind:	nDfLineSp = 122.625;  break;
	case f_Calibri_SameKind:	nDfLineSp = 122.1;  break;
	case f_CalibriLight_SameKind:	nDfLineSp = 122.1;  break;
	case f_CalifornianFB_SameKind:	nDfLineSp = 113.55; break;
	case f_CalistoMT_SameKind:	nDfLineSp = 115.425;  break;
	case f_Cambria_SameKind:	nDfLineSp = 117.225;  break;
	case f_Candara_SameKind:	nDfLineSp = 122.1;  break;
	case f_Castellar_SameKind:	nDfLineSp = 120.6;  break;
	case f_Centaur_SameKind:	nDfLineSp = 114;  break;
	case f_Century_SameKind:	nDfLineSp = 120.225;  break;
	case f_CenturyGothic_SameKind:	nDfLineSp = 122.625;  break;
	case f_Chiller_SameKind:	nDfLineSp = 115.35; break;
	case f_ColonnaMT_SameKind:	nDfLineSp = 105.75; break;
	case f_ComicSansMS_SameKind:	nDfLineSp = 139.35; break;
	case f_Consolas_SameKind:	nDfLineSp = 117.075;  break;
	case f_Constantia_SameKind:	nDfLineSp = 122.1;  break;
	case f_CooperBlack_SameKind:	nDfLineSp = 114.675;  break;
	case f_CopperplateGotBold_SameKind:	nDfLineSp = 111.3;  break;
	case f_CopprpGothBT_SameKind:	nDfLineSp = 0;  break;
	case f_Corbel_SameKind:	nDfLineSp = 122.1;  break;
	case f_CordiaUPC_SameKind:	nDfLineSp = 138.6;  break;
	case f_CourierNew_SameKind:	nDfLineSp = 113.25; break;
	case f_CurlzMT_SameKind:	nDfLineSp = 132.675;  break;
	case f_DaunPenh_SameKind:	nDfLineSp = 0;  break;
	case f_DFKai_SB_SameKind:	nDfLineSp = 130.05; break;
	case f_DilleniaUPC_SameKind:	nDfLineSp = 130.5;  break;
	case f_DokChampa_SameKind:	nDfLineSp = 134.475;  break;
	case f_Dotum_SameKind:	nDfLineSp = 130.05; break;
	case f_Dotumche_SameKind:	nDfLineSp = 130.05; break;
	case f_DroidSerif_SameKind:	nDfLineSp = 116.4;  break;
	case f_Ebrima_SameKind:	nDfLineSp = 135.825;  break;
	case f_Elephant_SameKind:	nDfLineSp = 128.925;  break;
	case f_EngraversMT_SameKind:	nDfLineSp = 116.475;  break;
	case f_ErasBoldITC_SameKind:	nDfLineSp = 115.8;  break;
	case f_ErasDemiITC_SameKind:	nDfLineSp = 114.9;  break;
	case f_ErasLightITC_SameKind:	nDfLineSp = 113.4;  break;
	case f_ErasMediumITC_SameKind:	nDfLineSp = 114.075;  break;
	case f_EstrangeloEdessa_SameKind:	nDfLineSp = 111.825;  break;
	case f_EucrosiaUPC_SameKind:	nDfLineSp = 122.4;  break;
	case f_Euphemia_SameKind:	nDfLineSp = 135.45; break;
	case f_FangSong_SameKind:	nDfLineSp = 129.675;  break;
	case f_FelixTitling_SameKind:	nDfLineSp = 116.925;  break;
	case f_Fences_SameKind:	nDfLineSp = 0;  break;
	case f_FootlightMTLight_SameKind:	nDfLineSp = 105.6;  break;
	case f_FranklinGothicBook_SameKind:	nDfLineSp = 113.4;  break;
	case f_FranklinGothicDemi_SameKind:	nDfLineSp = 113.4;  break;
	case f_FranklinGothicDemiCond_SameKind:	nDfLineSp = 113.4;  break;
	case f_FranklinGothicHeavy_SameKind:	nDfLineSp = 113.4;  break;
	case f_FranklinGothicMedium_SameKind:	nDfLineSp = 113.4;  break;
	case f_FranklinGothicMediumCond_SameKind:	nDfLineSp = 113.4;  break;
	case f_FrankRuehl_SameKind:	nDfLineSp = 99.975; break;
	case f_Freehand591BT_SameKind:	nDfLineSp = 123.9;  break;
	case f_FreesiaUPC_SameKind:	nDfLineSp = 119.925;  break;
	case f_Gabriola_SameKind:	nDfLineSp = 170.025;  break;
	case f_GaneunAnsangsooche_SameKind:	nDfLineSp = 130.5;  break;
	case f_Garamond_SameKind:	nDfLineSp = 112.5;  break;
	case f_Gautami_SameKind:	nDfLineSp = 190.65; break;
	case f_Georgia_SameKind:	nDfLineSp = 113.625;  break;
	case f_GillSansMT_SameKind:	nDfLineSp = 115.95; break;
	case f_GillSansMTCondensed_SameKind:	nDfLineSp = 120.375;  break;
	case f_GillSansUltraBold_SameKind:	nDfLineSp = 124.575;  break;
	case f_GillSansUltraBoldCondensed_SameKind:	nDfLineSp = 124.575;  break;
	case f_Gisha_SameKind:	nDfLineSp = 117.225;  break;
	case f_GloucesterMTExtraCondensed_SameKind:	nDfLineSp = 116.325;  break;
	case f_GoudyOldStyle_SameKind:	nDfLineSp = 120;  break;
	case f_GoudyStout_SameKind:	nDfLineSp = 136.8;  break;
	case f_GukeunAnsangsooche_SameKind:	nDfLineSp = 130.5;  break;
	case f_Gulim_SameKind:	nDfLineSp = 130.05; break;
	case f_Gullimche_SameKind:	nDfLineSp = 130.05; break;
	case f_Gungseo_SameKind:	nDfLineSp = 130.05; break;
	case f_Gungseoche_SameKind:	nDfLineSp = 130.05; break;
	case f_H_MULT1_SameKind:	nDfLineSp = 0;  break;
	case f_H_PROSYM_SameKind:	nDfLineSp = 0;  break;
	case f_Haettenschweiler_SameKind:	nDfLineSp = 106.725;  break;
	case f_HamChoromDotum_SameKind:	nDfLineSp = 168.975;  break;
	case f_HamChoromBatang_SameKind:	nDfLineSp = 168.9;  break;
	case f_HamChoromDotumHwakjang_SameKind:	nDfLineSp = 168.975;  break;
	case f_HanComBargainsaleB_SameKind:	nDfLineSp = 166.575;  break;
	case f_HanComBargainsaleM_SameKind:	nDfLineSp = 164.775;  break;
	case f_HanComBaekjeB_SameKind:	nDfLineSp = 174.3;  break;
	case f_HanComBaekjeM_SameKind:	nDfLineSp = 170.625;  break;
	case f_HanComSomangB_SameKind:	nDfLineSp = 188.325;  break;
	case f_HanComSomangM_SameKind:	nDfLineSp = 188.625;  break;
	case f_HanComSolipB_SameKind:	nDfLineSp = 180.525;  break;
	case f_HanComSolipM_SameKind:	nDfLineSp = 180.225;  break;
	case f_HanComYoonGodik230_SameKind:	nDfLineSp = 182.775;  break;
	case f_HanComYoonGodik240_SameKind:	nDfLineSp = 184.875;  break;
	case f_HanComYoonGodik250_SameKind:	nDfLineSp = 187.8;  break;
	case f_HanComYooncheB_SameKind:	nDfLineSp = 180.975;  break;
	case f_HanComYooncheL_SameKind:	nDfLineSp = 177.075;  break;
	case f_HanComYooncheM_SameKind:	nDfLineSp = 177.825;  break;
	case f_HanComCooljazzB_SameKind:	nDfLineSp = 138.375;  break;
	case f_HanComCooljazzL_SameKind:	nDfLineSp = 134.4;  break;
	case f_HanComCooljazzM_SameKind:	nDfLineSp = 142.2;  break;
	case f_HanComBatang_SameKind:		nDfLineSp = 130.03;  break;
	case f_HanComBatangExt_SameKind:	nDfLineSp = 166.05; break;
	case f_HarlowSolidItalic_SameKind:	nDfLineSp = 126.3;  break;
	case f_Harrington_SameKind:	nDfLineSp = 117.6;  break;
	case f_HCIPoppy_SameKind:	nDfLineSp = 0;  break;
	case f_Helvetica_SameKind:	nDfLineSp = 114.975;  break;
	case f_HESPERANTO_SameKind:	nDfLineSp = 0;  break;
	case f_HighTowerText_SameKind:	nDfLineSp = 116.325;  break;
	case f_HMULTI2_SameKind:	nDfLineSp = 0;  break;
	case f_HPCOB_SameKind:	nDfLineSp = 115.725;  break;
	case f_HPCOB2_SameKind:	nDfLineSp = 120.9;  break;
	case f_HPCOBB_SameKind:	nDfLineSp = 129.3;  break;
	case f_HPCOBI_SameKind:	nDfLineSp = 115.725;  break;
	case f_HPLTH_SameKind:	nDfLineSp = 131.625;  break;
	case f_HPLTHB_SameKind:	nDfLineSp = 127.8;  break;
	case f_HPLTHI_SameKind:	nDfLineSp = 124.875;  break;
	case f_HYGyeonGodik_SameKind:	nDfLineSp = 130.05; break;
	case f_HYGyeonMyeongjo_SameKind:	nDfLineSp = 130.05; break;
	case f_HYGungseo_SameKind:	nDfLineSp = 130.03; break;
	case f_HYGulim_SameKind:	nDfLineSp = 130.03; break;
	case f_HYDotum_SameKind:	nDfLineSp = 130.03; break;
	case f_HYGraphicM_SameKind:	nDfLineSp = 130.05; break;
	case f_HYMokgakPaimB_SameKind:	nDfLineSp = 130.05; break;
	case f_HYSinMyeongjo_SameKind:	nDfLineSp = 130.05; break;
	case f_HYUlleungdo_SameKind:	nDfLineSp = 130.05;  break;
	case f_HyumeonAmiche_SameKind:	nDfLineSp = 140.4;  break;
	case f_HyumeonExpo_SameKind:	nDfLineSp = 145.125;  break;
	case f_HyumeonDunggeunHaedeuLine_SameKind:	nDfLineSp = 135.525;  break;
	case f_HyumeonMagicChe_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonMoeumT_SameKind:	nDfLineSp = 145.125;  break;
	case f_HyumeonPyeonjiche_SameKind:	nDfLineSp = 151.2;  break;
	case f_HyumeonYetche_SameKind:	nDfLineSp = 137.475;  break;
	case f_HyumeonGaneunSaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonGaneunPaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonJoongganSaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonJoongganPaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HYYateunSammulM_SameKind:	nDfLineSp = 130.05; break;
	case f_HYYeopseoL_SameKind:	nDfLineSp = 130.05; break;
	case f_HYYeopseoM_SameKind:	nDfLineSp = 130.05; break;
	case f_HYJungGodik_SameKind:	nDfLineSp = 130.05; break;
	case f_HYHaedeuLineM_SameKind:	nDfLineSp = 130.05; break;
	case f_Impact_SameKind:	nDfLineSp = 121.95; break;
	case f_ImprintMTShadow_SameKind:	nDfLineSp = 117.825;  break;
	case f_IrisUPC_SameKind:	nDfLineSp = 126.525;  break;
	case f_IskoolaPota_SameKind:	nDfLineSp = 113.55; break;
	case f_JasmineUPC_SameKind:	nDfLineSp = 105.75; break;
	case f_Jokerman_SameKind:	nDfLineSp = 151.2;  break;
	case f_KaiTi_SameKind:	nDfLineSp = 129.675;  break;
	case f_Kalinga_SameKind:	nDfLineSp = 158.175;  break;
	case f_Kartika_SameKind:	nDfLineSp = 142.65; break;
	case f_KhmerUI_SameKind:	nDfLineSp = 113.175;  break;
	case f_KodchiangUPC_SameKind:	nDfLineSp = 98.325; break;
	case f_Kokila_SameKind:	nDfLineSp = 115.275;  break;
	case f_KristenITC_SameKind:	nDfLineSp = 135.975;  break;
	case f_KunstlerScript_SameKind:	nDfLineSp = 109.35; break;
	case f_LaoUI_SameKind:	nDfLineSp = 132.975;  break;
	case f_Latha_SameKind:	nDfLineSp = 166.05; break;
	case f_Leelawadee_SameKind:	nDfLineSp = 119.55; break;
	case f_LevenimMT_SameKind:	nDfLineSp = 140.025;  break;
	case f_LilyUPC_SameKind:	nDfLineSp = 95.325; break;
	case f_LucidaBright_SameKind:	nDfLineSp = 117.75; break;
	case f_LucidaCalligraphy_SameKind:	nDfLineSp = 136.125;  break;
	case f_LucidaConsole_SameKind:	nDfLineSp = 99.975; break;
	case f_LucidaFax_SameKind:	nDfLineSp = 117.75; break;
	case f_LucidaHandwriting_SameKind:	nDfLineSp = 137.925;  break;
	case f_LucidaSans_SameKind:	nDfLineSp = 117.75; break;
	case f_LucidaSansTypewriter_SameKind:	nDfLineSp = 117.45; break;
	case f_LucidaSansUnicode_SameKind:	nDfLineSp = 153.675;  break;
	case f_Magneto_SameKind:	nDfLineSp = 121.125;  break;
	case f_MaiandraGD_SameKind:	nDfLineSp = 119.85; break;
	case f_MakeunGodik_SameKind:	nDfLineSp = 172.95; break;
	case f_Mangal_SameKind:	nDfLineSp = 168;  break;
	case f_MDGaesungche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDSolche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDArongche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDArtche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDIsopche_SameKind:	nDfLineSp = 130.05; break;
	case f_Meiryo_SameKind:	nDfLineSp = 195;  break;
	case f_MicrosoftHimalaya_SameKind:	nDfLineSp = 99.975; break;
	case f_MicrosoftJhengHei_SameKind:	nDfLineSp = 172.95; break;
	case f_MicrosoftNewTaiLue_SameKind:	nDfLineSp = 130.8;  break;
	case f_MicrosoftPhagsPa_SameKind:	nDfLineSp = 127.95; break;
	case f_MicrosoftSansSerif_SameKind:	nDfLineSp = 113.175;  break;
	case f_MicrosoftTaiLe_SameKind:	nDfLineSp = 127.125;  break;
	case f_MicrosoftUighur_SameKind:	nDfLineSp = 108.075;  break;
	case f_MicrosoftYaHei_SameKind:	nDfLineSp = 171.525;  break;
	case f_MicrosoftYiBaiti_SameKind:	nDfLineSp = 102.675;  break;
	case f_MingLiU_SameKind:	nDfLineSp = 130.05; break;
	case f_Miriam_SameKind:	nDfLineSp = 102;  break;
	case f_MiriamFixed_SameKind:	nDfLineSp = 100.275;  break;
	case f_ModernNo20_SameKind:	nDfLineSp = 107.025;  break;
	case f_MongolianBaiti_SameKind:	nDfLineSp = 106.35; break;
	case f_MonotypeCorsiva_SameKind:	nDfLineSp = 112.2;  break;
	case f_MoolBoran_SameKind:	nDfLineSp = 135.675;  break;
	case f_MSGothic_SameKind:	nDfLineSp = 129.675;  break;
	case f_MSOutlook_SameKind:	nDfLineSp = 103.725;  break;
	case f_MSPGothic_SameKind:	nDfLineSp = 129.675;  break;
	case f_MSPMincho_SameKind:	nDfLineSp = 129.675;  break;
	case f_MSReferenceSansSerif_SameKind:	nDfLineSp = 121.5;  break;
	case f_MSUIGothic_SameKind:	nDfLineSp = 129.675;  break;
	case f_MTExtra_SameKind:	nDfLineSp = 129.825;  break;
	case f_MunchebugungcheJungjache_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebugungcheHeulrimche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebuDotumche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebuBatangche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebuSseugijungche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebuJemokDotumche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebuJemokBatangche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MunchebuHunminjungeumche_SameKind:	nDfLineSp = 129.975;  break;
	case f_MVBoli_SameKind:	nDfLineSp = 161.1;  break;
	case f_Narkisim_SameKind:	nDfLineSp = 99.975; break;
	case f_NewsGothBT_SameKind:	nDfLineSp = 0;  break;
	case f_NiagaraEngraved_SameKind:	nDfLineSp = 107.1;  break;
	case f_NSimSun_SameKind:	nDfLineSp = 129.675;  break;
	case f_Nyala_SameKind:	nDfLineSp = 104.475;  break;
	case f_OCRAExtended_SameKind:	nDfLineSp = 103.5;  break;
	case f_Onyx_SameKind:	nDfLineSp = 114.75; break;
	case f_Padauk_SameKind:	nDfLineSp = 147.45; break;
	case f_PalaceScriptMT_SameKind:	nDfLineSp = 92.625; break;
	case f_PalatinoLinotype_SameKind:	nDfLineSp = 134.925;  break;
	case f_Papyrus_SameKind:	nDfLineSp = 157.35; break;
	case f_Parchment_SameKind:	nDfLineSp = 106.8;  break;
	case f_Penheulrim_SameKind:	nDfLineSp = 129.975;  break;
	case f_Perpetua_SameKind:	nDfLineSp = 114.6;  break;
	case f_PerpetuaTitlingMT_SameKind:	nDfLineSp = 118.275;  break;
	case f_PlantagenetCherokee_SameKind:	nDfLineSp = 131.775;  break;
	case f_Playbill_SameKind:	nDfLineSp = 101.175;  break;
	case f_PMingLiU_SameKind:	nDfLineSp = 130.05; break;
	case f_PoorRichard_SameKind:	nDfLineSp = 112.575;  break;
	case f_Pristina_SameKind:	nDfLineSp = 131.1;  break;
	case f_PTBarnumBT_SameKind:	nDfLineSp = 0;  break;
	case f_Raavi_SameKind:	nDfLineSp = 178.5;  break;
	case f_RageItalic_SameKind:	nDfLineSp = 125.7;  break;
	case f_Roboto_SameKind:	nDfLineSp = 120;  break;
	case f_Rockwell_SameKind:	nDfLineSp = 117.45; break;
	case f_RockwellCondensed_SameKind:	nDfLineSp = 117.6;  break;
	case f_RockwellExtraBold_SameKind:	nDfLineSp = 117.45; break;
	case f_Rod_SameKind:	nDfLineSp = 99.975; break;
	case f_SaeGulim_SameKind:	nDfLineSp = 130.05; break;
	case f_SakkalMajalla_SameKind:	nDfLineSp = 139.65; break;
	case f_ScriptMTBold_SameKind:	nDfLineSp = 120.375;  break;
	case f_SegoePrint_SameKind:	nDfLineSp = 176.55; break;
	case f_SegoeScript_SameKind:	nDfLineSp = 158.4;  break;
	case f_SegoeUI_SameKind:	nDfLineSp = 132.975;  break;
	case f_SegoeUILight_SameKind:	nDfLineSp = 132.975;  break;
	case f_SegoeUISemibold_SameKind:	nDfLineSp = 132.975;  break;
	case f_SegoeUISymbol_SameKind:	nDfLineSp = 132.975;  break;
	case f_ShonarBangla_SameKind:	nDfLineSp = 129.45; break;
	case f_ShowcardGothic_SameKind:	nDfLineSp = 123.75; break;
	case f_Shruti_SameKind:	nDfLineSp = 183.375;  break;
	case f_SimplifiedArabic_SameKind:	nDfLineSp = 165.75; break;
	case f_SimplifiedArabicFixed_SameKind:	nDfLineSp = 109.2;  break;
	case f_SimSun_SameKind:	nDfLineSp = 129.675;  break;
	case f_SnapITC_SameKind:	nDfLineSp = 128.55; break;
	case f_SnellBT_SameKind:	nDfLineSp = 0;  break;
	case f_Stencil_SameKind:	nDfLineSp = 118.5;  break;
	case f_Sylfaen_SameKind:	nDfLineSp = 131.7;  break;
	case f_Taenamoo_SameKind:	nDfLineSp = 129.975;  break;
	case f_Tahoma_SameKind:	nDfLineSp = 120.739;  break;
	case f_TempusSansITC_SameKind:	nDfLineSp = 130.5;  break;
	case f_TimesNewRoman_SameKind:	nDfLineSp = 114.975;  break;
	case f_TraditionalArabic_SameKind:	nDfLineSp = 149.475;  break;
	case f_TrebuchetMS_SameKind:	nDfLineSp = 116.1;  break;
	case f_Tunga_SameKind:	nDfLineSp = 176.925;  break;
	case f_TwCenMT_SameKind:	nDfLineSp = 108.9;  break;
	case f_TwCenMTCondensed_SameKind:	nDfLineSp = 106.8;  break;
	case f_TwCenMTCondensedExtraBold_SameKind:	nDfLineSp = 108.3;  break;
	case f_Utsaah_SameKind:	nDfLineSp = 111.9;  break;
	case f_Vani_SameKind:	nDfLineSp = 168.375;  break;
	case f_Verdana_SameKind:	nDfLineSp = 121.57;  break;
	case f_Vijaya_SameKind:	nDfLineSp = 100.65; break;
	case f_VinerHandITC_SameKind:	nDfLineSp = 161.4;  break;
	case f_Vrinda_SameKind:	nDfLineSp = 140.55; break;
	case f_WideLatin_SameKind:	nDfLineSp = 123.075;  break;
	case f_Wingdings_SameKind:	nDfLineSp = 111;  break;
	case f_Wingdings2_SameKind:	nDfLineSp = 105.45; break;
	case f_Wingdings3_SameKind:	nDfLineSp = 113.85; break;
	case f_Webding_SameKind:	nDfLineSp = 99.975; break;
	case f_YangjaeKkaebicheB_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeKkotgecheM_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeNanchocheM_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeDaunMyeongjoM_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeMaehwacheS_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeBaekdoocheB_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeBelracheM_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeBonmokgakcheM_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeButkkotcheL_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeSoseulcheS_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeWadangcheM_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeInitialche_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeChamsutcheB_SameKind:	nDfLineSp = 129.975;  break;
	case f_YangjaeTeunteuncheB_SameKind:	nDfLineSp = 129.975;  break;
	case f_JoongganAnsangsooche_SameKind:	nDfLineSp = 130.5;  break;
	case f_YunDesignWeb_SameKind:	nDfLineSp = 0;  break;
	case f_YuMincho_SameKind:         nDfLineSp = 119.6;  break;
	case f_YuGothic_SameKind:         nDfLineSp = 160.2;  break;
	case f_Zapfino_SameKind:	nDfLineSp = 0;  break;
	}

	return nDfLineSp;
}
#elif defined(USE_NEWFONT_LINESP_CURRENT)
double	CUtil::getDefaultLineSp(BrINT32 nFontFlag)
{
	BrDOUBLE nDfLineSp = 115;
	switch(nFontFlag)
	{
	case f_AmericanaBT_SameKind:	nDfLineSp = 115.415;  break;
	case f_Ansangsoo2006Ganeun_SameKind:	nDfLineSp = 130.05;  break;
	case f_Ansangsoo2006Gukeun_SameKind:	nDfLineSp = 130.05;  break;
	case f_Ansangsoo2006Joonggan_SameKind:	nDfLineSp = 130.05;  break;
	case f_AgencyFB_SameKind:	nDfLineSp = 118.444;  break;
	case f_Aharoni_SameKind:	nDfLineSp = 100.03; break;
	case f_Algerian_SameKind:	nDfLineSp = 132.022;  break;
	case f_Aldhabi_SameKind:	nDfLineSp = 175.18;  break;
	case f_Andalus_SameKind:	nDfLineSp = 152.683;  break;
	case f_AndroidEmoji_SameKind:	nDfLineSp = 145.45;  break;
	case f_AngsanaUPC_SameKind:	nDfLineSp = 135.075;  break;
	case f_Aparajita_SameKind:	nDfLineSp = 118.2;  break;
	case f_ArabicTypesetting_SameKind:	nDfLineSp = 114.732;  break;
	case f_Arial_SameKind:	nDfLineSp = 115.025;  break;
	case f_ArialBlack_SameKind:	nDfLineSp = 141.058;  break;
	case f_ArialNarrow_SameKind:	nDfLineSp = 114.781; break;
	case f_ArialRoundedMTBold_SameKind:	nDfLineSp = 115.758;  break;
	case f_ArialUnicodeMS_SameKind:	nDfLineSp = 174.225;  break;
	case f_BalloonXBdBT_SameKind:	nDfLineSp = 117.99;  break;
	case f_BankGothicMdBT_SameKind:	nDfLineSp = 104.719;  break;
	case f_BaskervilleOldFace_SameKind:	nDfLineSp = 113.99;  break;
	case f_Batang_SameKind:	nDfLineSp = 130.05; break;
	case f_Batangche_SameKind:	nDfLineSp = 130.05; break;
	case f_Bauhaus93_SameKind:	nDfLineSp = 146.089;  break;
	case f_BellMT_SameKind:	nDfLineSp = 111.215; break;
	case f_BernardMTCon_SameKind:	nDfLineSp = 118.786;  break;
	case f_BerlinSansFB_SameKind:	nDfLineSp = 109.945;  break;
	case f_BerlinSansFBDemi_SameKind:	nDfLineSp = 112.925;  break;
	case f_BernardMTCondensed_SameKind:	nDfLineSp = 118.786;  break;
	case f_BlackadderITC_SameKind:	nDfLineSp = 128.25; break;
	case f_BodoniMT_SameKind:	nDfLineSp = 119.958;  break;
	case f_BodoniMTBlack_SameKind:	nDfLineSp = 116.832;  break;
	case f_BodoniMTCondensed_SameKind:	nDfLineSp = 117.711;  break;
	case f_BodoniMTPosterCompressed_SameKind:	nDfLineSp = 114.781; break;
	case f_BookAntiqua_SameKind:	nDfLineSp = 124.299;  break;
	case f_BookmanOldStyle_SameKind:	nDfLineSp = 117.418;  break;
	case f_BookshelfSymbol5_SameKind:	nDfLineSp = 111.752;  break;
	case f_BradleyHandITC_SameKind:	nDfLineSp = 124.745;  break;
	case f_BritannicBold_SameKind:	nDfLineSp = 110.775;  break;
	case f_Broadway_SameKind:	nDfLineSp = 113.267; break;
	case f_BrowalliaNew_SameKind:	nDfLineSp = 124.95; break;
	case f_BrowalliaUPC_SameKind:	nDfLineSp = 124.95; break;
	case f_BrushScriptMT_SameKind:	nDfLineSp = 122.693;  break;
	case f_Calibri_SameKind:	nDfLineSp = 122.107;  break;
	case f_CalibriLight_SameKind:	nDfLineSp = 122.107;  break;
	case f_CalifornianFB_SameKind:	nDfLineSp = 113.609; break;
	case f_CalistoMT_SameKind:	nDfLineSp = 115.465;  break;
	case f_Cambria_SameKind:	nDfLineSp = 117.272;  break;
	case f_Candara_SameKind:	nDfLineSp = 122.107;  break;
	case f_Castellar_SameKind:	nDfLineSp = 120.6;  break;
	case f_Centaur_SameKind:	nDfLineSp = 113.952;  break;
	case f_Century_SameKind:	nDfLineSp = 120.251;  break;
	case f_CenturyGothic_SameKind:	nDfLineSp = 122.645;  break;
	case f_Chiller_SameKind:	nDfLineSp = 115.416; break;
	case f_ColonnaMT_SameKind:	nDfLineSp = 105.9; break;
	case f_ComicSansMS_SameKind:	nDfLineSp = 139.398; break;
	case f_Consolas_SameKind:	nDfLineSp = 117.125;  break;
	case f_Constantia_SameKind:	nDfLineSp = 122.107;  break;
	case f_CooperBlack_SameKind:	nDfLineSp = 114.732;  break;
	case f_CopperplateGotBold_SameKind:	nDfLineSp = 111.264;  break;
	case f_CopprpGothBT_SameKind:	nDfLineSp = 104.328;  break;
	case f_Corbel_SameKind:	nDfLineSp = 122.1;  break;
	case f_CordiaUPC_SameKind:	nDfLineSp = 138.6;  break;
	case f_CourierNew_SameKind:	nDfLineSp = 113.316; break;
	case f_CurlzMT_SameKind:	nDfLineSp = 132.675;  break;
	case f_DaunPenh_SameKind:	nDfLineSp = 135.734;  break;
	case f_DFKai_SB_SameKind:	nDfLineSp = 130.05; break;
	case f_DilleniaUPC_SameKind:	nDfLineSp = 130.5;  break;
	case f_DokChampa_SameKind:	nDfLineSp = 134.5;  break;
	case f_Dotum_SameKind:	nDfLineSp = 130.05; break;
	case f_Dotumche_SameKind:	nDfLineSp = 130.05; break;
	case f_DroidSerif_SameKind:	nDfLineSp = 116.441;  break;
	case f_Ebrima_SameKind:	nDfLineSp = 135.832;  break;
	case f_Elephant_SameKind:	nDfLineSp = 128.925;  break;
	case f_EngraversMT_SameKind:	nDfLineSp = 116.49;  break;
	case f_ErasBoldITC_SameKind:	nDfLineSp = 115.807;  break;
	case f_ErasDemiITC_SameKind:	nDfLineSp = 114.927;  break;
	case f_ErasLightITC_SameKind:	nDfLineSp = 113.413;  break;
	case f_ErasMediumITC_SameKind:	nDfLineSp = 113.9;  break;
	case f_EstrangeloEdessa_SameKind:	nDfLineSp = 111.85;  break;
	case f_EucrosiaUPC_SameKind:	nDfLineSp = 123.621;  break;
	case f_Euphemia_SameKind:	nDfLineSp = 135.49; break;
	case f_FangSong_SameKind:	nDfLineSp = 129.675;  break;
	case f_FelixTitling_SameKind:	nDfLineSp = 116.979;  break;
	case f_Fences_SameKind:	nDfLineSp = 115.025;  break;
	case f_FootlightMTLight_SameKind:	nDfLineSp = 105.6;  break;
	case f_FranklinGothicBook_SameKind:	nDfLineSp = 113.413;  break;
	case f_FranklinGothicDemi_SameKind:	nDfLineSp = 113.413;  break;
	case f_FranklinGothicDemiCond_SameKind:	nDfLineSp = 113.413;  break;
	case f_FranklinGothicHeavy_SameKind:	nDfLineSp = 113.413;  break;
	case f_FranklinGothicMedium_SameKind:	nDfLineSp = 113.413;  break;
	case f_FranklinGothicMediumCond_SameKind:	nDfLineSp = 113.413;  break;
	case f_FrankRuehl_SameKind:	nDfLineSp = 100.03; break;
	case f_Freehand591BT_SameKind:	nDfLineSp = 123.9;  break;
	case f_FreesiaUPC_SameKind:	nDfLineSp = 119.925;  break;
	case f_Gabriola_SameKind:	nDfLineSp = 170.025;  break;
	case f_GaneunAnsangsooche_SameKind:	nDfLineSp = 130.5;  break;
	case f_Garamond_SameKind:	nDfLineSp = 112.5;  break;
	case f_Gautami_SameKind:	nDfLineSp = 190.683; break;
	case f_Georgia_SameKind:	nDfLineSp = 113.657;  break;
	case f_GillSansMT_SameKind:	nDfLineSp = 115.95; break;
	case f_GillSansMTCondensed_SameKind:	nDfLineSp = 120.447;  break;
	case f_GillSansUltraBold_SameKind:	nDfLineSp = 124.647;  break;
	case f_GillSansUltraBoldCondensed_SameKind:	nDfLineSp = 124.44;  break;
	case f_Gisha_SameKind:	nDfLineSp = 117.223;  break;
	case f_GloucesterMTExtraCondensed_SameKind:	nDfLineSp = 116.344;  break;
	case f_GoudyOldStyle_SameKind:	nDfLineSp = 119.76;  break;
	case f_GoudyStout_SameKind:	nDfLineSp = 136.858;  break;
	case f_GukeunAnsangsooche_SameKind:	nDfLineSp = 130.5;  break;
	case f_Gulim_SameKind:	nDfLineSp = 130.05; break;	// ODT : 115.024
	case f_Gullimche_SameKind:	nDfLineSp = 130.05; break;
	case f_Gungseo_SameKind:	nDfLineSp = 130.05; break;
	case f_Gungseoche_SameKind:	nDfLineSp = 130.05; break;
	case f_H_MULT1_SameKind:	nDfLineSp = 0;  break;
	case f_H_PROSYM_SameKind:	nDfLineSp = 0;  break;
	case f_Haettenschweiler_SameKind:	nDfLineSp = 106.722;  break;
	case f_HamChoromDotum_SameKind:	nDfLineSp = 168.975;  break;
	case f_HamChoromBatang_SameKind:	nDfLineSp = 168.9;  break;
	case f_HamChoromDotumHwakjang_SameKind:	nDfLineSp = 168.975;  break;
	case f_HanComBargainsaleB_SameKind:	nDfLineSp = 166.575;  break;
	case f_HanComBargainsaleM_SameKind:	nDfLineSp = 164.775;  break;
	case f_HanComBaekjeB_SameKind:	nDfLineSp = 174.3;  break;
	case f_HanComBaekjeM_SameKind:	nDfLineSp = 170.625;  break;
	case f_HanComSomangB_SameKind:	nDfLineSp = 188.325;  break;
	case f_HanComSomangM_SameKind:	nDfLineSp = 188.625;  break;
	case f_HanComSolipB_SameKind:	nDfLineSp = 180.525;  break;
	case f_HanComSolipM_SameKind:	nDfLineSp = 179.9;  break;
	case f_HanComYoonGodik230_SameKind:	nDfLineSp = 182.775;  break;
	case f_HanComYoonGodik240_SameKind:	nDfLineSp = 184.875;  break;
	case f_HanComYoonGodik250_SameKind:	nDfLineSp = 187.8;  break;
	case f_HanComYooncheB_SameKind:	nDfLineSp = 180.975;  break;
	case f_HanComYooncheL_SameKind:	nDfLineSp = 177.075;  break;
	case f_HanComYooncheM_SameKind:	nDfLineSp = 177.825;  break;
	case f_HanComCooljazzB_SameKind:	nDfLineSp = 138.375;  break;
	case f_HanComCooljazzL_SameKind:	nDfLineSp = 134.5;  break;
	case f_HanComCooljazzM_SameKind:	nDfLineSp = 142.2;  break;
	case f_HanComBatang_SameKind:	nDfLineSp = 130.03; break;
	case f_HanComBatangExt_SameKind:	nDfLineSp = 166.05; break;
	case f_HarlowSolidItalic_SameKind:	nDfLineSp = 126.357;  break;
	case f_Harrington_SameKind:	nDfLineSp = 117.614;  break;
	case f_HCIPoppy_SameKind:	nDfLineSp = 0;  break;
	case f_Helvetica_SameKind:	nDfLineSp = 114.975;  break;
	case f_HESPERANTO_SameKind:	nDfLineSp = 0;  break;
	case f_HighTowerText_SameKind:	nDfLineSp = 116.393;  break;
	case f_HMULTI2_SameKind:	nDfLineSp = 0;  break;
	case f_HPCOB_SameKind:	nDfLineSp = 115.725;  break;
	case f_HPCOB2_SameKind:	nDfLineSp = 120.9;  break;
	case f_HPCOBB_SameKind:	nDfLineSp = 129.5;  break;
	case f_HPCOBI_SameKind:	nDfLineSp = 115.725;  break;
	case f_HPLTH_SameKind:	nDfLineSp = 131.625;  break;
	case f_HPLTHB_SameKind:	nDfLineSp = 127.8;  break;
	case f_HPLTHI_SameKind:	nDfLineSp = 124.875;  break;
	case f_HYGyeonGodik_SameKind:	nDfLineSp = 130.05; break;
	case f_HYGyeonMyeongjo_SameKind:	nDfLineSp = 130.05; break;
	case f_HYGungseo_SameKind:	nDfLineSp = 130.03; break;
	case f_HYGulim_SameKind:	nDfLineSp = 130.03; break;
	case f_HYDotum_SameKind:	nDfLineSp = 130.03; break;
	case f_HYGraphicM_SameKind:	nDfLineSp = 130.05; break;
	case f_HYMokgakPaimB_SameKind:	nDfLineSp = 130.05; break;
	case f_HYSinMyeongjo_SameKind:	nDfLineSp = 130.05; break;
	case f_HYUlleungdo_SameKind:	nDfLineSp = 130.05;  break;
	case f_HyumeonAmiche_SameKind:	nDfLineSp = 140.4;  break;
	case f_HyumeonExpo_SameKind:	nDfLineSp = 145.125;  break;
	case f_HyumeonDunggeunHaedeuLine_SameKind:	nDfLineSp = 135.525;  break;
	case f_HyumeonMagicChe_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonMoeumT_SameKind:	nDfLineSp = 145.125;  break;
	case f_HyumeonPyeonjiche_SameKind:	nDfLineSp = 151.2;  break;
	case f_HyumeonYetche_SameKind:	nDfLineSp = 137.475;  break;
	case f_HyumeonGaneunSaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonGaneunPaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonJoongganSaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonJoongganPaemche_SameKind:	nDfLineSp = 130.5;  break;
	case f_HyumeonGothic_SameKind:		nDfLineSp = 137.06;  break;
	case f_HyumeonMyeongjo_SameKind:	nDfLineSp = 137.06;  break;
	case f_HYYateunSammulM_SameKind:	nDfLineSp = 130.05; break;
	case f_HYYeopseoL_SameKind:	nDfLineSp = 130.05; break;
	case f_HYYeopseoM_SameKind:	nDfLineSp = 130.05; break;
	case f_HYJungGodik_SameKind:	nDfLineSp = 130.05; break;
	case f_HYHaedeuLineM_SameKind:	nDfLineSp = 130.05; break;
	case f_Impact_SameKind:	nDfLineSp = 122.01; break;
	case f_ImprintMTShadow_SameKind:	nDfLineSp = 117.858;  break;
	case f_IrisUPC_SameKind:	nDfLineSp = 126.525;  break;
	case f_IskoolaPota_SameKind:	nDfLineSp = 113.56; break;
	case f_JasmineUPC_SameKind:	nDfLineSp = 106; break;
	case f_Jokerman_SameKind:	nDfLineSp = 151.266;  break;
	case f_KaiTi_SameKind:	nDfLineSp = 129.675;  break;
	case f_Kalinga_SameKind:	nDfLineSp = 158.251;  break;
	case f_Kartika_SameKind:	nDfLineSp = 142.4; break;
	case f_KhmerUI_SameKind:	nDfLineSp = 113.218;  break;
	case f_KodchiangUPC_SameKind:	nDfLineSp = 97.8; break;
	case f_Kokila_SameKind:	nDfLineSp = 115.318;  break;
	case f_KristenITC_SameKind:	nDfLineSp = 136.028;  break;
	case f_KunstlerScript_SameKind:	nDfLineSp = 109.408; break;
	case f_LaoUI_SameKind:	nDfLineSp = 133.048;  break;
	case f_Latha_SameKind:	nDfLineSp = 166.066; break;
	case f_Leelawadee_SameKind:	nDfLineSp = 119.616; break;
	case f_LevenimMT_SameKind:	nDfLineSp = 140.033;  break;
	case f_LilyUPC_SameKind:	nDfLineSp = 95.325; break;
	case f_LucidaBright_SameKind:	nDfLineSp = 117.809; break;
	case f_LucidaCalligraphy_SameKind:	nDfLineSp = 136.174;  break;
	case f_LucidaConsole_SameKind:	nDfLineSp = 100.03; break;
	case f_LucidaFax_SameKind:	nDfLineSp = 117.809; break;
	case f_LucidaHandwriting_SameKind:	nDfLineSp = 137.981;  break;
	case f_LucidaSans_SameKind:	nDfLineSp = 117.809; break;
	case f_LucidaSansTypewriter_SameKind:	nDfLineSp = 117.516; break;
	case f_LucidaSansUnicode_SameKind:	nDfLineSp = 153.709;  break;
	case f_Magneto_SameKind:	nDfLineSp = 121.179;  break;
	case f_MaiandraGD_SameKind:	nDfLineSp = 119.909; break;
	case f_MakeunGodik_SameKind:	nDfLineSp = 173; break;	// ODT : 133.019
	case f_Mangal_SameKind:	nDfLineSp = 168.02;  break;
	case f_MDGaesungche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDSolche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDArongche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDArtche_SameKind:	nDfLineSp = 130.05; break;
	case f_MDIsopche_SameKind:	nDfLineSp = 130.05; break;
	case f_Meiryo_SameKind:	nDfLineSp = 195;  break;
	case f_MicrosoftHimalaya_SameKind:	nDfLineSp = 100.03; break;
	case f_MicrosoftJhengHei_SameKind:	nDfLineSp = 172.95; break;
	case f_MicrosoftNewTaiLue_SameKind:	nDfLineSp = 130.85;  break;
	case f_MicrosoftPhagsPa_SameKind:	nDfLineSp = 127.968; break;
	case f_MicrosoftSansSerif_SameKind:	nDfLineSp = 113.175;  break;
	case f_MicrosoftTaiLe_SameKind:	nDfLineSp = 127.178;  break;
	case f_MicrosoftUighur_SameKind:	nDfLineSp = 108.138;  break;
	case f_MicrosoftYaHei_SameKind:	nDfLineSp = 171.525;  break;
	case f_MicrosoftYaHeiUI_SameKind:	nDfLineSp = 165.048;  break;	// XPD-16915
	case f_MicrosoftYiBaiti_SameKind:	nDfLineSp = 102.717;  break;
	case f_MingLiU_SameKind:	nDfLineSp = 130.05; break;
	case f_Miriam_SameKind:	nDfLineSp = 102.033;  break;
	case f_MiriamFixed_SameKind:	nDfLineSp = 100.274;  break;
	case f_ModernNo20_SameKind:	nDfLineSp = 106.72;  break;
	case f_MongolianBaiti_SameKind:	nDfLineSp = 106.38; break;
	case f_MonotypeCorsiva_SameKind:	nDfLineSp = 112.241;  break;
	case f_MoolBoran_SameKind:	nDfLineSp = 135.734;  break;
	case f_MSGothic_SameKind:	nDfLineSp = 129.675;  break;
	case f_MSOutlook_SameKind:	nDfLineSp = 103.742;  break;
	case f_MSPGothic_SameKind:	nDfLineSp = 129.675;  break;
	case f_MSPMincho_SameKind:	nDfLineSp = 129.675;  break;
	case f_MSReferenceSansSerif_SameKind:	nDfLineSp = 121.57;  break;
	case f_MSUIGothic_SameKind:	nDfLineSp = 129.675;  break;
	case f_MTExtra_SameKind:	nDfLineSp = 129.825;  break;
	case f_MunchebugungcheJungjache_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebugungcheHeulrimche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebuDotumche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebuBatangche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebuSseugijungche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebuJemokDotumche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebuJemokBatangche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MunchebuHunminjungeumche_SameKind:	nDfLineSp = 130.05;  break;
	case f_MVBoli_SameKind:	nDfLineSp = 161.182;  break;
	case f_NaNumGodik_SameKind:	nDfLineSp = 150; break;
	case f_NaNumMyeongjo_SameKind:	nDfLineSp = 150; break;
	case f_Narkisim_SameKind:	nDfLineSp = 100.03; break;
	case f_NewsGothBT_SameKind:	nDfLineSp = 119.616;  break;
	case f_NiagaraEngraved_SameKind:	nDfLineSp = 107.112;  break;
	case f_NSimSun_SameKind:	nDfLineSp = 129.675;  break;
	case f_Nyala_SameKind:	nDfLineSp = 104.524;  break;
	case f_OCRAExtended_SameKind:	nDfLineSp = 103.498;  break;
	case f_Onyx_SameKind:	nDfLineSp = 114.75; break;
	case f_Padauk_SameKind:	nDfLineSp = 147.45; break;
	case f_PalaceScriptMT_SameKind:	nDfLineSp = 92.655; break;
	case f_PalatinoLinotype_SameKind:	nDfLineSp = 134.953;  break;
	case f_Papyrus_SameKind:	nDfLineSp = 157.421; break;
	case f_Parchment_SameKind:	nDfLineSp = 106.819;  break;
	case f_Penheulrim_SameKind:	nDfLineSp = 130.05;  break;
	case f_Perpetua_SameKind:	nDfLineSp = 114.634;  break;
	case f_PerpetuaTitlingMT_SameKind:	nDfLineSp = 118.346;  break;
	case f_PlantagenetCherokee_SameKind:	nDfLineSp = 132;  break;
	case f_Playbill_SameKind:	nDfLineSp = 101.175;  break;
	case f_PMingLiU_SameKind:	nDfLineSp = 130.05; break;
	case f_PoorRichard_SameKind:	nDfLineSp = 112.632;  break;
	case f_Pristina_SameKind:	nDfLineSp = 131.1;  break;
	case f_PTBarnumBT_SameKind:	nDfLineSp = 119.323;  break;
	case f_Raavi_SameKind:	nDfLineSp = 178.57;  break;
	case f_RageItalic_SameKind:	nDfLineSp = 125.673;  break;
	case f_Roboto_SameKind:	nDfLineSp = 119.76;  break;
	case f_Rockwell_SameKind:	nDfLineSp = 117.467; break;
	case f_RockwellCondensed_SameKind:	nDfLineSp = 117.614;  break;
	case f_RockwellExtraBold_SameKind:	nDfLineSp = 117.467; break;
	case f_Rod_SameKind:	nDfLineSp = 100.03; break;
	case f_SaeGulim_SameKind:	nDfLineSp = 130.05; break;
	case f_SakkalMajalla_SameKind:	nDfLineSp = 139.691; break;
	case f_ScriptMTBold_SameKind:	nDfLineSp = 120.447;  break;
	case f_SegoePrint_SameKind:	nDfLineSp = 176.567; break;
	case f_SegoeScript_SameKind:	nDfLineSp = 158.03;  break;
	case f_SegoeUI_SameKind:	nDfLineSp = 133.048;  break;
	case f_SegoeUILight_SameKind:	nDfLineSp = 133.048;  break;
	case f_SegoeUISemibold_SameKind:	nDfLineSp = 133.048;  break;
	case f_SegoeUISymbol_SameKind:	nDfLineSp = 133.048;  break;
	case f_ShonarBangla_SameKind:	nDfLineSp = 129.9; break;
	case f_ShowcardGothic_SameKind:	nDfLineSp = 123.817; break;
	case f_Shruti_SameKind:	nDfLineSp = 183.454;  break;
	case f_SimplifiedArabic_SameKind:	nDfLineSp = 165.822; break;
	case f_SimplifiedArabicFixed_SameKind:	nDfLineSp = 109.213;  break;
	case f_SimSun_SameKind:	nDfLineSp = 129.675;  break;
	case f_SnapITC_SameKind:	nDfLineSp = 128.555; break;
	case f_SnellBT_SameKind:	nDfLineSp = 126.649;  break;
	case f_Stencil_SameKind:	nDfLineSp = 118.5;  break;
	case f_Sylfaen_SameKind:	nDfLineSp = 131.729;  break;
	case f_Taenamoo_SameKind:	nDfLineSp = 130.05;  break;
	case f_Tahoma_SameKind:	nDfLineSp = 120.74;  break;
	case f_TempusSansITC_SameKind:	nDfLineSp = 130.508;  break;
	case f_TimesNewRoman_SameKind:	nDfLineSp = 115.025;  break;
	case f_TraditionalArabic_SameKind:	nDfLineSp = 149.508;  break;
	case f_TrebuchetMS_SameKind:	nDfLineSp = 116.148;  break;
	case f_Tunga_SameKind:	nDfLineSp = 177.007;  break;
	case f_TwCenMT_SameKind:	nDfLineSp = 109;  break;
	case f_TwCenMTCondensed_SameKind:	nDfLineSp = 106.868;  break;
	case f_TwCenMTCondensedExtraBold_SameKind:	nDfLineSp = 108.334;  break;
	case f_Utsaah_SameKind:	nDfLineSp = 111.82;  break;
	case f_UnBatang_SameKind:	nDfLineSp = 158.598;  break;
	case f_Vani_SameKind:	nDfLineSp = 168.459;  break;
	case f_Verdana_SameKind:	nDfLineSp = 121.57;  break;
	case f_Vijaya_SameKind:	nDfLineSp = 100.714; break;
	case f_VinerHandITC_SameKind:	nDfLineSp = 161.475;  break;
	case f_Vrinda_SameKind:	nDfLineSp = 140.619; break;
	case f_WideLatin_SameKind:	nDfLineSp = 123.075;  break;
	case f_Wingdings_SameKind:	nDfLineSp = 111.02;  break;
	case f_Wingdings2_SameKind:	nDfLineSp = 105.7; break;
	case f_Wingdings3_SameKind:	nDfLineSp = 113.85; break;
	case f_Webding_SameKind:	nDfLineSp = 100.03; break;
	case f_YangjaeKkaebicheB_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeKkotgecheM_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeNanchocheM_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeDaunMyeongjoM_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeMaehwacheS_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeBaekdoocheB_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeBelracheM_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeBonmokgakcheM_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeButkkotcheL_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeSoseulcheS_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeWadangcheM_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeInitialche_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeChamsutcheB_SameKind:	nDfLineSp = 130.05;  break;
	case f_YangjaeTeunteuncheB_SameKind:	nDfLineSp = 130.05;  break;
	case f_JoongganAnsangsooche_SameKind:	nDfLineSp = 130.5;  break;
	case f_YunDesignWeb_SameKind:	nDfLineSp = 0;  break;
	case f_YuMincho_SameKind:         nDfLineSp = 119.6;  break;
	case f_YuGothic_SameKind:         nDfLineSp = 160.2;  break;
	case f_Zapfino_SameKind:	nDfLineSp = 151.795;  break;
	case f_NotoSansKannada_SameKind:	nDfLineSp = 134.787;  break;
	case f_BangSong_SameKind:	nDfLineSp = 129.651;  break; // 174.163;	// XPD-22522
	case f_STXingKai_SameKind:	nDfLineSp = 136.569;  break;	// XPD-17474
	case f_SimKai_SameKind: nDfLineSp = 174.166;  break;	// XPD-17439
	case f_FangSong_GB2312_SameKind: nDfLineSp = 129.651;  break;
	case f_SimSun_PAU_SameKind : nDfLineSp = 174.189;  break;
	case f_Unknown1_SameKind : nDfLineSp = 114.967;  break;
	case f_Source_Sans_Pro_SameKind : nDfLineSp = 125.746;  break;	// MQP-11733
	case f_Nirmala_UI_SameKind : nDfLineSp = 133.029;  break;	// WPD-1301
	}

	return nDfLineSp;
}
#else
double	CUtil::getDefaultLineSp(BrINT32 nFontFlag)
{
	BrDOUBLE nDfLineSp = 115;
	switch(nFontFlag)
	{
	case f_MicrosoftJhengHei_SameKind:	nDfLineSp = 173.50;		break;
	case f_YunDesignWeb_SameKind:		nDfLineSp = 213.30;		break; //32

	case f_ArialUnicodeMS_SameKind:		nDfLineSp = 175.50;		break; //39	
	case f_MakeunGodik_SameKind:		nDfLineSp = 172.14;		break; //39	
	case f_MicrosoftYaHei_SameKind:					nDfLineSp = 173.30;		break;

	case f_HanComBatangExt_SameKind:	nDfLineSp = 167.80;		break; //41

	case f_VinerHandITC_SameKind: 		nDfLineSp = 162.30;		break; //42

	case f_Papyrus_SameKind:			nDfLineSp = 158.50;		break; //43

	case f_LucidaSansUnicode_SameKind:	nDfLineSp = 155.00;		break; //44

	case f_Jokerman_SameKind:			nDfLineSp = 152.00;		break; //45

	case f_Padauk_SameKind:				nDfLineSp = 148.00;		break; //46-			
	case f_Bauhaus93_SameKind:			nDfLineSp = 147.30;		break; //46

	case f_HyumeonExpo_SameKind:			nDfLineSp = 145.50;		break;//47

	case f_ArialBlack_SameKind:			nDfLineSp = 141.50;		break; //48
	case f_HyumeonAmiche_SameKind:			nDfLineSp = 141.00;		break; //48

	case f_ComicSansMS_SameKind:		nDfLineSp = 139.45;		break; //49
	case f_LucidaHandwriting_SameKind:	nDfLineSp = 138.70;		break; //49
	case f_HyumeonYetche_SameKind:		nDfLineSp = 137.90;		break; //49

	case f_GoudyStout_SameKind:			nDfLineSp = 136.90;		break; //50 
	case f_KristenITC_SameKind:			nDfLineSp = 136.70;		break; //50 
	case f_Fences_SameKind:				nDfLineSp = 136.00;		break; //50 
	case f_PalatinoLinotype_SameKind:	nDfLineSp = 135.70;		break; //50 

	case f_CurlzMT_SameKind:			nDfLineSp = 133.50;		break; //51 
	case f_Algerian_SameKind:			nDfLineSp = 132.50;		break; //51 

	case f_Sylfaen_SameKind:			nDfLineSp = 132.00;		break; //52 
	case f_Pristina_SameKind:			nDfLineSp = 131.50;		break; //52
	case f_Batang_SameKind:				nDfLineSp = 130.00;		break; //52
	case f_MTExtra_SameKind:			nDfLineSp = 130.40;		break; //52

	case f_SnapITC_SameKind:			nDfLineSp = 128.70;		break; //53
	case f_BlackadderITC_SameKind:		nDfLineSp = 128.50;		break; //53

	case f_SnellBT_SameKind:			nDfLineSp = 126.60;		break; //54
	case f_HarlowSolidItalic_SameKind:	nDfLineSp = 126.23;		break; //54
	case f_RageItalic_SameKind:			nDfLineSp = 125.70;		break; //54
	case f_BradleyHandITC_SameKind:		nDfLineSp = 124.75;		break; //54

	case f_GillSansUltraBoldCondensed_SameKind:  nDfLineSp = 124.50;		break; //55 
	case f_BookAntiqua_SameKind:		nDfLineSp = 124.00;		break; //55 
	case f_Freehand591BT_SameKind:		nDfLineSp = 123.50;		break; //55
	case f_WideLatin_SameKind:			nDfLineSp = 123.00;		break; //55
	case f_BrushScriptMT_SameKind:		nDfLineSp = 122.75;		break; //55

	case f_Calibri_SameKind:			nDfLineSp = 122.00;		break; //56 
	case f_Impact_SameKind:				nDfLineSp = 121.70;		break; //56 
	case f_Verdana_SameKind:			nDfLineSp = 121.30;		break; //56
	case f_Magneto_SameKind:			nDfLineSp = 121.00;		break; //56 
	case f_Castellar_SameKind:			nDfLineSp = 120.50;		break; //56 
	case f_Century_SameKind:			nDfLineSp = 120.25;		break; //56

	case f_BodoniMT_SameKind:			nDfLineSp = 120.00;		break; //57 
	case f_NewsGothBT_SameKind:			nDfLineSp = 119.50;		break; //57 
	case f_PTBarnumBT_SameKind:			nDfLineSp = 119.00;		break; //57
	case f_BernardMTCon_SameKind:		nDfLineSp = 118.73;		break; //57 
	case f_AgencyFB_SameKind:			nDfLineSp = 118.25;		break; //57

	case f_BalloonXBdBT_SameKind:		nDfLineSp = 118.00;		break; //58 
	case f_LucidaBright_SameKind:		nDfLineSp = 117.50;		break; //58 
	case f_Cambria_SameKind:			nDfLineSp = 117.20;		break; //58 
	case f_BodoniMTBlack_SameKind:		nDfLineSp = 116.70;		break; //58
	case f_HighTowerText_SameKind:		nDfLineSp = 116.25;		break; //58

	case f_GillSansMT_SameKind:			nDfLineSp = 115.70;		break; //59 	
	case f_AmericanaBT_SameKind:		nDfLineSp = 115.20;		break; //59 	
	case f_Chiller_SameKind:			nDfLineSp = 115.00;		break; //59 	
	case f_Arial_SameKind:				nDfLineSp = 114.70;		break; //59	
	case f_Onyx_SameKind:				nDfLineSp = 114.30;		break; //59 

	case f_ErasMediumITC_SameKind:		nDfLineSp = 114.00;		break; //60 
	case f_Centaur_SameKind:			nDfLineSp = 113.70;		break; //60 
	case f_CalifornianFB_SameKind:		nDfLineSp = 113.20;		break; //60 
	case f_ErasLightITC_SameKind:		nDfLineSp = 112.80;		break; //60 
	case f_CourierNew_SameKind:			nDfLineSp = 112.60;		break; //60
	case f_BerlinSansFBDemi_SameKind:	nDfLineSp = 112.40;		break; //60
	case f_PoorRichard_SameKind:		nDfLineSp = 112.35;		break; //60
	case f_Garamond_SameKind:			nDfLineSp = 112.25;		break; //60

	case f_MonotypeCorsiva_SameKind:	nDfLineSp = 112.00;		break; //61
	case f_BookshelfSymbol5_SameKind:	nDfLineSp = 111.70;		break; //61
	case f_CopperplateGotBold_SameKind:	nDfLineSp = 111.20;		break; //61
	case f_BellMT_SameKind:				nDfLineSp = 111.00;		break; //61
	case f_Wingdings_SameKind:			nDfLineSp = 110.70;		break; //61
	case f_BritannicBold_SameKind:		nDfLineSp = 110.25;		break; //61

	case f_BerlinSansFB_SameKind:		nDfLineSp = 109.70;		break; //62
	case f_HMULTI2_SameKind:			nDfLineSp = 109.20;		break; //62
	case f_KunstlerScript_SameKind:		nDfLineSp = 108.70;		break; //62
	case f_TwCenMT_SameKind:			nDfLineSp = 108.25;		break; //62

	case f_TwCenMTCondensedExtraBold_SameKind:		nDfLineSp = 107.70;		break; //63
	case f_H_MULT1_SameKind:			nDfLineSp = 107.30;		break; //63
	case f_H_PROSYM_SameKind:			nDfLineSp = 107.00;		break; //63
	case f_NiagaraEngraved_SameKind:		nDfLineSp = 106.75;		break; //63

	case f_ModernNo20_SameKind:			nDfLineSp = 106.50;		break; //64 FULL
	case f_TwCenMTCondensed_SameKind:	nDfLineSp = 106.25;		break; //64
	case f_Parchment_SameKind:			nDfLineSp = 106.00;		break; //64
	case f_Haettenschweiler_SameKind:	nDfLineSp = 105.80;		break; //64
	case f_HESPERANTO_SameKind:			nDfLineSp = 105.60;		break; //64 
	case f_ColonnaMT_SameKind:			nDfLineSp = 105.30;		break; //64 

	case f_BankGothicMdBT_SameKind:		nDfLineSp = 104.00;		break; //65 
	case f_CopprpGothBT_SameKind:		nDfLineSp = 103.70;		break; //65 

	case f_MSOutlook_SameKind:			nDfLineSp = 103.10;		break; //66 FULL
	case f_OCRAExtended_SameKind:		nDfLineSp = 102.70;		break; //66 

	case f_Vrinda_SameKind:				nDfLineSp = 101.20;		break; //67
	case f_Playbill_SameKind:			nDfLineSp = 100.30;		break; //67

	case f_Kartika_SameKind:			nDfLineSp = 99.00;			break; //68

	case f_PalaceScriptMT_SameKind:		nDfLineSp = 91.50;			break; //73
	case f_Gulim_SameKind:				nDfLineSp = 130.00;			break;
	}

	return nDfLineSp;
}
#endif //USE_NEWFONT_LINESP

BrBOOL CUtil::IsSaveAS(const BString& strSaveName)
{
	BrAutoChar temp = convertBStringToChar(&strSaveName, CP_UTF8);
	if(!temp.get())
		return BrFALSE;

	if( 0 == strcmp(temp.get(), getDocFileName()))
		return BrFALSE;

	return BrTRUE;
}

BString CUtil::makeCurrentDateString(bool bPPT)
{
	int nYear = 0, nMonth = 0, nDay = 0, nWday = 0, nHour = 0, nMinute = 0, nSecond = 0;
	BrGetSystemTime(&nYear, &nMonth, &nDay, &nWday, &nHour, &nMinute, &nSecond);
	nMonth++;// month는 0이 1월

	BString s = getDateStringFromTime( nYear, nMonth, nDay, nHour, nMinute, nSecond , bPPT);

	// TEST CODE
	//int nYear1 = 0, nMonth1 = 0, nDay1 = 0, nHour1 = 0, nMinute1 = 0, nSecond1 = 0;
	//getTimeFromString( s, nYear1, nMonth1, nDay1, nHour1, nMinute1, nSecond1);


	return s;
}

//리턴값에 유의
BrBOOL CUtil::getTimeFromDateString( BString timeStr , int &nYear, int &nMonth, int &nDay,  int &nHour, int &nMinute, int &nSecond )
{
	// 2013-05-22T18:04:59Z
	//timeStr.lower();
	int t = timeStr.find( 'T' , 0 , false );
	if( t != -1 )
	{
		BString date = timeStr.left( t );
		BString time = timeStr.mid( t+1 );

		int dash1 = date.find( '-' );
		if( dash1 != -1 )
		{
			int dash2 = date.find( '-' , dash1+2 );
			if( dash2 != -1 )
			{
				int colon1 = time.find( ':' );
				if( colon1 != -1 )
				{
					int colon2 = time.find( ':' , colon1+1 );
					if( colon2 != -1 )
					{
						BString year = date.left( dash1 );
						BString month = date.mid( dash1+1 , dash2-dash1 );
						BString day = date.mid( dash2+1 );

						BString hour = time.left( colon1 );
						BString min = time.mid( colon1+1 , colon2-colon1 );
						BString sec = time.mid( colon2+1 );

						nYear = BrAtoi( (const BrCHAR*)year );
						if( nYear > 999 && nYear < 10000 )
						{
							nMonth = BrAtoi( (const BrCHAR*) month );
							if( nMonth > 0 && nMonth < 13 )
							{
								nDay = BrAtoi( (const BrCHAR*) day );
								if( nDay > 0 && nDay < 32 )
								{
									nHour = BrAtoi( (const BrCHAR*) hour );
									if( nHour == 0 && hour != "00" )
										return BrFALSE;
									if( nHour >= 0 && nHour < 24 )
									{
										nMinute = BrAtoi( (const BrCHAR*) min );
										if( nMinute == 0 && min != "00" )
											return BrFALSE;
										if( nMinute >= 0 && nMinute < 60 )
										{
											nSecond = BrAtoi( (const BrCHAR*) sec );
											if( nSecond == 0 && sec.left(2) != "00" )
												return BrFALSE;
											if( nSecond >= 0 && nSecond < 60 )
											{
												return BrTRUE;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	return BrFALSE;

}

BString CUtil::getDateStringFromTime( int nYear, int nMonth, int nDay,  int nHour, int nMinute, int nSecond, bool bPPT )
{
	BString s;

	BrCHAR buf[50];
	BrItoa( nYear , buf , 10 );
	s+=buf;
	s+="-";
	BrItoa( nMonth , buf , 10 );
	if( nMonth < 10 )
		s+="0";
	s+=buf;
	s+="-";
	BrItoa( nDay , buf , 10 );
	if( nDay < 10 )
		s+="0";
	s+=buf;
	s+="T";
	BrItoa( nHour , buf , 10 );
	if( nHour < 10 )
		s+="0";
	s+=buf;
	s+=":";
	BrItoa( nMinute , buf , 10 );
	if( nMinute < 10 )
		s+="0";
	s+=buf;
	s+=":";
	BrItoa( nSecond , buf , 10 );
	if( nSecond < 10 )
		s+="0";
	s+=buf;
	if( bPPT )
		s+= ".000";//초단위 까지만 생성.
	else
		s+="Z";

	return s;
}

// 2:05 AM 
BString CUtil::getDateStringFromAmPmTime()
{

	int nYear = 0, nMonth = 0, nDay = 0, nWday = 0, nHour = 0, nMinute = 0, nSecond = 0;
	BrGetSystemTime(&nYear, &nMonth, &nDay, &nWday, &nHour, &nMinute, &nSecond);
	nMonth++;// month는 0이 1월

	BString strRet;

	BrCHAR buf[50];
	BrBOOL bAM = nHour <= 12 ? BrTRUE : BrFALSE;

	BrItoa( nHour%13 , buf , 10 );
	strRet+=buf;
	strRet+=":";

	BrItoa( nMinute , buf , 10 );
	if( nMinute < 10 )
		strRet+="0";
	strRet+=buf;
	strRet+=" ";

	if( bAM )
		strRet+="AM";
	else
		strRet+="PM";
	
	return strRet;
}


static BrINT16 DocumentTypeToDocType(HwpSignature::document_type type)
{
	switch (type) {
		case HwpSignature::document_type::eBinaryRTF:  return BORA_DOCTYPE_RTF;
		case HwpSignature::document_type::eTextTxt:    return BORA_DOCTYPE_ASCI;
		case HwpSignature::document_type::eBinaryPpt:  return BORA_DOCTYPE_PPT;
		case HwpSignature::document_type::eXMLPptx:    return BORA_DOCTYPE_PPTX;
		case HwpSignature::document_type::eXMLHtml:    return BORA_DOCTYPE_HTML;
		case HwpSignature::document_type::eXMLDocxml:  return BORA_DOCTYPE_XML;
		case HwpSignature::document_type::eXMLDocx:    return BORA_DOCTYPE_DOCX;
		case HwpSignature::document_type::eBinaryDoc:  return BORA_DOCTYPE_DOC;
		case HwpSignature::document_type::eXMLXlsx:    return BORA_DOCTYPE_XLSX;
		case HwpSignature::document_type::eBinaryXls:  return BORA_DOCTYPE_XLS;
		case HwpSignature::document_type::eXMLOdt:     return BORA_DOCTYPE_ODT;
		case HwpSignature::document_type::eXMLOdp:     return BORA_DOCTYPE_ODP;
		case HwpSignature::document_type::eXMLOds:     return BORA_DOCTYPE_ODS;
		case HwpSignature::document_type::eBinaryHwp30:
			if(g_pBInterfaceHandle->getDocumentValidattionMode())
				SET_ERROR(kPoWarnHwp30Format,"Hwp30 Format");
			return BORA_DOCTYPE_HWP;
		case HwpSignature::document_type::eBinaryHwp50:return BORA_DOCTYPE_HWP;
		case HwpSignature::document_type::eXMLHwpx:    return BORA_DOCTYPE_HWP;
	}
	return BORA_DOCTYPE_NONE;
}


BrINT16 CUtil::getFileSignatureFormat(const BString& fileName)
{
#ifdef USE_BWP_INTERFACE//common에서 bwp를 호출한 경우로 확인 필요
	using namespace HwpSignature;
	HwpSignatureIdentifier identifier(fileName);
	document_type type = identifier.ProbeFormat<
		ProbeXML<ProbeXMLStandAlone, ProbeXMLOpenOfficeXML, ProbeXMLOpenDocument>,
		ProbeBinary<ProbeBinaryStandAlone, ProbeBinaryCFB> 
		 >();
	BrINT16 result = DocumentTypeToDocType(type);
	setDocContentType(result);
	return result;
#else
	return BORA_DOCTYPE_NONE;
#endif
}


/*
*	@author Andrew
*	@modifier Anesin
*	@date  	2017.07.28
*	@params BString $filename : 파일명
*	@params BrLPCSTR $backupext : 확장자
*	@return BString  : 백업 파일명
*	@brief  .qbk등 임시 파일을 temp path에 $backupext를 적용하여 리턴한다. 
*/
BString CUtil::getBackupFilePathInTempPath(const BString& filename, BrLPCSTR backupext/*=".qbk"*/, BrBOOL a_bIncludeFile/* = BrFALSE*/)
{
	BString qbkFileName;
	if(g_pBInterfaceHandle->getQBKPathName() && 
		strlen(g_pBInterfaceHandle->getQBKPathName()) > 0 && 
		!a_bIncludeFile)
	{
		qbkFileName = UTF8ToBString(g_pBInterfaceHandle->getQBKPathName());
	}
	else
	{
		qbkFileName = UTF8ToBString((char*)BrGetTempPath());
		//if( qbkFileName.findRev('/') != qbkFileName.length()-1)
		//	qbkFileName.append('/');
		BString strFileName = filename.mid(filename.findRev("/")+1);
		qbkFileName += strFileName;
		qbkFileName += backupext;
		qbkFileName = BFile::getNotExistFileName(qbkFileName);
	}

	return qbkFileName;
}

/*
*	@author Andrew
*	@date  	2017.09.21
*	@params const BrWCHAR* $pStr : input string
*	@return int : unicode length
*	@brief  check 4byte unicode length
*/
int CUtil::getUnicodeLength(const BrWCHAR* pStr)
{
	int nLen = 0;
	if ( pStr )
	{
		int nSize = BrWcsLen(pStr);
		for (int n=0;n<nSize;n++)
		{
			//check 4byte unicode
			if ( pStr[n]>=0xDC00 && pStr[n]<= 0xDFFF )
				continue;
			nLen++;
		}
	}
	return nLen;
}


BrBOOL CUtil::isLatinSmallLetter(unsigned short code)
{
	if ( (code > LATIN_LETTER_MIN1 && code <= LATIN_LETTER_MAX1) || (code > LATIN_LETTER_MIN3 && code <= LATIN_LETTER_MAX3) )
	{
		// small letter
		if ( (code%2)==1 )	return BrTRUE;
	}
	else if ( (code > LATIN_LETTER_MIN2 && code <= LATIN_LETTER_MAX2) )
	{
		// small letter
		if ( (code%2)==0 )	return BrTRUE;
	}

	return BrFALSE;
}

BrBOOL CUtil::CheckImageTmp(BString imgPath)
{
	if (imgPath.isEmpty())
		return BrFALSE;

	BrINT32 nExtPos = imgPath.findRev(".");

	if (imgPath.length() - nExtPos <= 0)
		return BrFALSE;

	BString ext = imgPath.right(imgPath.length() - nExtPos);
	if (strcmp(".png", ext.data()) != 0 && strcmp(".jpg", ext.data()) != 0 && strcmp(".jpeg", ext.data()) != 0 && strcmp(".wdp", ext.data()) != 0)
		return BrFALSE;

	BrINT32 nPos = imgPath.findRev("/");
	BString fileName = imgPath.right(imgPath.length() - nPos);

	if (imgPath.length() - nPos <= 0)
		return BrFALSE;

	BString pStrImage = UTF8ToBString((BrCHAR*)BrGetTempPath());
	pStrImage.append("ImageTmp");
	pStrImage.append(fileName);

	BrAutoChar src = convertBStringToChar(&pStrImage, CP_UTF8);
	BrCHAR* pPath = (BrCHAR*)src.get();

	if (_BrFileExist(pPath))
		return BrTRUE;
	else
		return BrFALSE;

	return BrFALSE;
}

BrBOOL CUtil::isSupportableFile(const BString& fileName)
{
	BrBOOL supportResult = BrTRUE;
	BrINT32 nDocumentContentType = getFileSignatureFormat(fileName);
	switch (nDocumentContentType)
	{
	case BORA_DOCTYPE_RTF:
	case BORA_DOCTYPE_PPT:
	case BORA_DOCTYPE_PPTX:
	case BORA_DOCTYPE_HTML:
	case BORA_DOCTYPE_XML:
	case BORA_DOCTYPE_DOCX:
	case BORA_DOCTYPE_DOC:
	case BORA_DOCTYPE_XLSX:
	case BORA_DOCTYPE_XLS:
		break;
	case BORA_DOCTYPE_ASCI:
		{
			BFile file;
			if(!file.Open(fileName, BMV_READ_ONLY))
				return SetErrorFReturn(CPublicError(kPoErrFileOpen));
			BrCHAR ckeckZero[minSignatureSize];
			memset(ckeckZero, 0, minSignatureSize);
			BrCHAR readBuffer[minSignatureSize];
			memset(readBuffer, 0, minSignatureSize);
			file.Read(readBuffer, minSignatureSize);
			if(memcmp(readBuffer, ckeckZero, minSignatureSize) == 0)
				return SetErrorFReturn(CPublicError(kPoErrFileFillWithZero));
		}
	}
	return supportResult;
}

//----------------------------------------------------
/**
 * @brief	2007이상 계열의 문서의 상태 확인
 * @date	2019-08-14
 * @param	pFileName : 확인할 파일 이름
 * @return	파일에 문제가 있는 경우 false
 */
//-------------------------------------------------
BrBOOL CUtil::checkFileValidation(const char* pFileName)
{
	//암호문서는 추후에...
	LoadOleFile cOleFile;
	cOleFile.Open(UTF8ToBString(pFileName));
	if (cOleFile.openStream("EncryptedPackage")) {
		cOleFile.Close();
		return BrTRUE;
	}
#ifdef SUPPORT_XML_PARSER	
	ftXMLStorage* pFtXMLStorage = BrNEW ftXMLStorage();
	pFtXMLStorage->SetFilePath(pFileName);

	//Zip File이 정상적으로 오픈되는지 확인 및 Zip 내 파일 리스트 생성
	//[CSP-6241] 오픈이 되지 않는 경우가 있어 저장 시 확인
	if (!pFtXMLStorage->GetZipInfo())
	{
		pFtXMLStorage->CloseZipFile();
		BR_SAFE_DELETE(pFtXMLStorage);
		return BrFALSE;
	}

	//ContentTypes.xml이 존재하는지 확인
	//[CSP-6753] 파일에 xml 이 없는 경우가 있어 저장 시 확인 
	//Sheet의 경우 ContentTyps.xml을 제일 마지막에 생성
	BrINT32 nXmlIndex = pFtXMLStorage->GetIndex(CONTENT_TYPES_PART_NAME);
	if (nXmlIndex == -1)
		return BrFALSE;

	pFtXMLStorage->CloseZipFile();
	BR_SAFE_DELETE(pFtXMLStorage);
	return BrTRUE;
#endif//#ifdef SUPPORT_XML_PARSER	
	return BrFALSE;
}

//파일 경로에서 확장자만
BString CUtil::getFileExtension(BString strFilePath)
{
	int nStart = strFilePath.findRev('/');
	if (nStart > -1) {
		BString name = strFilePath.mid(nStart + 1);
		int nEnd = name.findRev('.');
		if (nEnd > -1) {
			name = name.mid(nEnd + 1);
			name.utf8();
			return name;
		}
	}

	return BrNULL;
}

void CUtil::AdjustPathSeparator(BString& filePath)
{
	if (filePath.length() < 0)
		return;

	auto it = filePath.beginUnicode();
	do {
		if (*it == '\\')
			*it = '/';
		++it;
	} while (it != filePath.endUnicode());
}

#include "OfficePreComp.hpp"

#include <openssl/err.h>
#include "openssl/hmac.h"
#include <openssl/crypto.h>
#include <openssl/err.h>
#include "openssl/rand.h"
#include "openssl/rc4.h"
#include "openssl/evp.h"

#include "OpensslCryptoInterface.h"

#include "BFile.h"
#include "butil.h"
#include "svstream.h"
#include "../Bwp/Filter/hwp/Hwp50/Common/Stream/Hwp50ByteStream.h"

#if OPENSSL_VERSION_NUMBER >= 0x30000000L
#include <openssl/param_build.h>
#endif

#include <boost/uuid/uuid.hpp>            // uuid class
#include <boost/uuid/uuid_generators.hpp> // generators
#include <boost/uuid/uuid_io.hpp>         // streaming operators etc.

#ifndef USE_OPENSSL_LIB
#define USE_OPENSSL_LIB 0
#endif

static OpensslCryptoInterface* g_pOpensslCryptoInterface = NULL;
OpensslCryptoInterface::OpensslCryptoInterface(void)
{
#if USE_OPENSSL_LIB
//Andrew C.Lee Android�� ���� ���������� ����ϴ� ���� �ƴ� java app������ ȣ���� �� �־ �ʱ�ȭ/������ ���� �ʴ´�.
//#ifndef __ANDROID__
//	OpenSSL_add_all_algorithms();
//	ERR_load_crypto_strings();
//#endif

  /*  Azur: Android ���� ��ȣ���� ���½� ũ���� ���� ����. EVP_cleanup() �� Android������ ���������� �������� �ʽ��ϴ� */
  const char* openSSL_version_text = OPENSSL_VERSION_TEXT;
  BTrace("OpenSSL Version : %s",openSSL_version_text);

#if OPENSSL_VERSION_NUMBER >= 0x30000000L
  /* Load Multiple providers into the default (NULL) library context */
	_legacy = OSSL_PROVIDER_load(NULL, "legacy");
	_deflt = OSSL_PROVIDER_load(NULL, "default");
#endif

#if !defined(OPENSSL_API_COMPAT) || OPENSSL_API_COMPAT < 0x10100000L
  OpenSSL_add_all_algorithms();
  ERR_load_crypto_strings();
#else
#  ifdef OPENSSL_LOAD_CONF
	OPENSSL_init_crypto(OPENSSL_INIT_ADD_ALL_CIPHERS | OPENSSL_INIT_ADD_ALL_DIGESTS | OPENSSL_INIT_LOAD_CONFIG, NULL);
#  else
	OPENSSL_init_crypto(OPENSSL_INIT_ADD_ALL_CIPHERS | OPENSSL_INIT_ADD_ALL_DIGESTS, NULL);
#  endif
	OPENSSL_init_crypto(OPENSSL_INIT_LOAD_CRYPTO_STRINGS, NULL);
#endif   
#endif   
}


OpensslCryptoInterface::~OpensslCryptoInterface(void)
{
  //Andrew high level api�� ����ϴ� ��� �����ڿ��� �ε��� �˰������� ������ �ϳ� libcrypto�� �ܺο��� ����� ��츦 ������ ȣ������ �ʴ´�.
#if USE_OPENSSL_LIB
//  EVP_cleanup();

	//[sglee1206] ���� ���� ������ ȣ������ ����.
#if 0//OPENSSL_VERSION_NUMBER >= 0x30000000L
	if (_legacy)
	{
		OSSL_PROVIDER_unload(_legacy);
		_legacy = NULL;
	}
	if (_deflt)
	{
		OSSL_PROVIDER_unload(_deflt);
		_deflt = NULL;
	}
#endif
#endif
}

OpensslCryptoInterface * OpensslCryptoInterface::GetInstance()
{
	if ( g_pOpensslCryptoInterface == BrNULL)
	{
		g_pOpensslCryptoInterface = BrNEW OpensslCryptoInterface();
	}
	return g_pOpensslCryptoInterface;
}

void OpensslCryptoInterface::Release()
{	
	if ( g_pOpensslCryptoInterface )
		BR_SAFE_DELETE(g_pOpensslCryptoInterface);
}

char* OpensslCryptoInterface::GetErrorMessage(const char* _func)
{
	static char pErrMsg[1024] = {0,};
	memset(pErrMsg, 0, sizeof(pErrMsg));
#if USE_OPENSSL_LIB	
	int err = ERR_get_error();
	if ( err != 0 ) 
		_snprintf_s(pErrMsg, sizeof(pErrMsg), "ERR : EVP_Encrypt() - lib[%s] func[%s] reason[%s]", ERR_lib_error_string(err), _func, ERR_reason_error_string(err));
#endif	
	return pErrMsg;
}

bool OpensslCryptoInterface::updateValidateCheck(EVP_CIPHER_CTX* ctx, int inl)
{
	int buf_len, block_mask;

	int bl = EVP_CIPHER_CTX_block_size(ctx);	//16
#if !defined(OPENSSL_API_COMPAT) || OPENSSL_API_COMPAT < 0x10100000L
	unsigned long flags = EVP_CIPHER_CTX_flags(ctx);
#else
	unsigned long flags = EVP_CIPHER_flags(EVP_CIPHER_CTX_cipher(ctx));
#endif
	

#if OPENSSL_VERSION_NUMBER < 0x10100000L
	buf_len = ctx->buf_len;
	block_mask = ctx->block_mask;
#else
	buf_len = 0;
	block_mask = bl - 1;
#endif

	int i = buf_len;

	if (flags & EVP_CIPH_FLAG_CUSTOM_CIPHER)
		return true;

	if (buf_len == 0 && (inl & (block_mask)) == 0)
		return true;

	if (i != 0)
	{
		if (bl - i > inl)
			return true;

		int j = bl - i;
		/*
		 * Once we've processed the first j bytes from in, the amount of
		 * data left that is a multiple of the block length is:
		 * (inl - j) & ~(bl - 1)
		 * We must ensure that this amount of data, plus the one block that
		 * we process from ctx->buf does not exceed INT_MAX
		 */
		if (((inl - j) & ~(bl - 1)) > INT_MAX - bl)
			return false;
	}

	return true;
}

std::vector<BrBYTE> OpensslCryptoInterface::ComputeSHA(const BrCHAR* sha_name, const BrBYTE* data, BrINT32 data_len)
{
  std::vector<BrBYTE> sha;

  if ( !sha_name || !data )
    return sha;
#if USE_OPENSSL_LIB
  const EVP_MD *md;
  md = EVP_get_digestbyname(sha_name);
  if(!md) {
    SET_ERROR_LOG(kPoErrUnknownMessageDigestInOpenSSL, GetErrorMessage("EVP_get_digestbyname"), false);
    return sha;
  }

  //allocates, initializes and returns a digest context.
  EVP_MD_CTX *mdctx = EVP_MD_CTX_create();
  if ( mdctx )
  {
    // If impl is NULL then the default implementation of digest type is used.
    if ( EVP_DigestInit_ex(mdctx, md, NULL) == 1 ) {
      if ( EVP_DigestUpdate(mdctx, data,data_len) == 1 ) {
        unsigned int md_len;

        //  allocate max possible length  
		int md_size = EVP_MD_size(md);
        sha.resize(md_size);

        if ( EVP_DigestFinal_ex(mdctx, sha.data(), &md_len) != 1 ) {
          SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DigestFinal_ex"), false);
          sha.resize(0);
        }
        else {
          // shrink number of bytes of data written
          sha.resize(md_len);
        }
      }
      else {
        SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DigestUpdate"), false);
      }
    }
    else
      SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DigestInit_ex"), false);
    EVP_MD_CTX_destroy(mdctx);
  }
  else {
    SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_MD_CTX_create"), false);
  }
#endif
  return sha;
}

std::vector<BrBYTE> OpensslCryptoInterface::EncryptRC4(BrBYTE* a_pSrcData, BrINT32 a_nSrcDataLen, BrBYTE* a_pRC4KeyData, BrINT32 a_nRC4KeyDataLen, BrBYTE* iv)
{
	std::vector<BrBYTE> enc_data;
#if USE_OPENSSL_LIB
	EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();

	if (ctx)
	{
		if (1 == EVP_EncryptInit_ex(ctx, EVP_rc4(), NULL, a_pRC4KeyData, iv))	//iv???
		{
			int outlen, tmplen;
			enc_data.resize(a_nSrcDataLen);
			bool result = updateValidateCheck(ctx, a_nSrcDataLen);
			if (result && EVP_EncryptUpdate(ctx, enc_data.data(), &outlen, a_pSrcData, a_nSrcDataLen) == 1)
			{
				/* Finalise the encryption. Further ciphertext bytes may be written at
				* this stage.
				*/
				if (EVP_EncryptFinal_ex(ctx, enc_data.data(), &outlen) != 1)
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptFinal_ex"), false);
				}
			}
			else
			{
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptUpdate"), false);
			}
		}

		EVP_CIPHER_CTX_free(ctx);
	}
	else
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);

#endif
	return enc_data;
}

std::vector<BrBYTE> OpensslCryptoInterface::DecryptRC4(BrBYTE* key, BrINT32 key_len, BrBYTE* enc_data, BrINT32 enc_data_len)
{
  std::vector<BrBYTE> decrypted_data;
#if USE_OPENSSL_LIB
  EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
  if ( ctx )
  {
    EVP_CIPHER_CTX_set_flags(ctx, EVP_CIPH_FLAG_NON_FIPS_ALLOW);
    int decryptResult = EVP_DecryptInit_ex(ctx, EVP_rc4(), NULL, (unsigned char*)key, NULL);
    if (decryptResult != 1)
    {
      SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptInit_ex"), false);
    }
    else
    {
      int outlen, tmplen;
      decrypted_data.resize(enc_data_len);
	  bool result = updateValidateCheck(ctx, enc_data_len);
      if(result && EVP_DecryptUpdate(ctx, decrypted_data.data(), &outlen, enc_data, enc_data_len) == 1)
      {				
        /* Buffer passed to EVP_EncryptFinal() must be after data just
        * encrypted to avoid overwriting it.
        */
        if( EVP_DecryptFinal_ex(ctx, decrypted_data.data() + outlen, &tmplen) == 1 )
          outlen += tmplen;
        else
        {
          SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptFinal_ex"), false);
        }
      }
      else
      {
        SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptUpdate"), false);
      }
    }

    EVP_CIPHER_CTX_free(ctx);
    /* Need binary mode for fopen because encrypted data is
    * binary data. Also cannot use strlen() on it because
    * it won't be null terminated and may contain embedded
    * nulls.
    */
  }
  else
    SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
#endif
	return decrypted_data;
}

std::vector<BrBYTE> OpensslCryptoInterface::EncryptAES(const BrBYTE* dec_data, BrINT32 dec_data_len,BrBYTE* key, BrBYTE* iv, BrINT32 aes_key_len)
{
  std::vector<BrBYTE> encrypted_data;
#if USE_OPENSSL_LIB  
	const EVP_CIPHER *cipher = EVP_aes_128_cbc();
	if(aes_key_len == 256)
		cipher = EVP_aes_256_cbc();

	EVP_CIPHER_CTX *aes_ctx;

	aes_ctx = EVP_CIPHER_CTX_new();

	if (aes_ctx)
	{
		if (EVP_EncryptInit_ex(aes_ctx, cipher, 0, key, (const unsigned char*)iv) == 1)
		{
			EVP_CIPHER_CTX_set_padding(aes_ctx, 0);

			int nOutLen = 0;
			encrypted_data.resize(dec_data_len);

			bool result = updateValidateCheck(aes_ctx, dec_data_len);
			if (result && EVP_EncryptUpdate(aes_ctx, encrypted_data.data(), &nOutLen, (const unsigned char*)dec_data, dec_data_len) == 1)
			{
				if (EVP_EncryptFinal_ex(aes_ctx, encrypted_data.data(), &nOutLen) != 1)
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptFinal_ex"), false);
				}
			}
			else
			{
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptUpdate"), false);
			}
		}
		else
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptInit_ex"), false);

		/* Clean up */
		EVP_CIPHER_CTX_free(aes_ctx);
	}
	else
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
		BRTHREAD_ASSERT(0);
	}
	
#endif
	return encrypted_data;
}


std::vector<BrBYTE> OpensslCryptoInterface::DecryptAES(const BrBYTE* enc_data, BrINT32 enc_data_len,
                                                       const BrBYTE* key, const BrBYTE* iv, BrINT32 aes_key_len)
{
#if USE_OPENSSL_LIB
  const EVP_CIPHER* cipher = (256 == aes_key_len)? EVP_aes_256_cbc(): EVP_aes_128_cbc();
#else
  const EVP_CIPHER* cipher = BrNULL;
#endif  // USE_OPENSSL_LIB
  return Decrypt(cipher, enc_data, enc_data_len, key, iv);
}


std::vector<BrBYTE> OpensslCryptoInterface::DecryptBlowfishCFB(const BrBYTE* enc_data, BrINT32 enc_data_len,
                                                               const BrBYTE* key, const BrBYTE* iv)
{
#if USE_OPENSSL_LIB && !defined(OPENSSL_NO_BF)
  const EVP_CIPHER* cipher = EVP_bf_cfb64();
#else
  const EVP_CIPHER* cipher = BrNULL;
#endif  // USE_OPENSSL_LIB
  return Decrypt(cipher, enc_data, enc_data_len, key, iv);
}


std::vector<BrBYTE> OpensslCryptoInterface::Decrypt(const EVP_CIPHER* cipher,
                                                    const BrBYTE* enc_data, BrINT32 enc_data_len,
                                                    const BrBYTE* key, const BrBYTE* iv)
{
  std::vector<BrBYTE> dec_data;

#if USE_OPENSSL_LIB
  EVP_CIPHER_CTX* ctx;

  ctx = EVP_CIPHER_CTX_new();

  if (ctx)
  {
	  if (1 == EVP_DecryptInit_ex(ctx, cipher, 0, key, iv)) {
		  EVP_CIPHER_CTX_set_padding(ctx, 0);
		  int dec_data_len = 0;
		  dec_data.resize(enc_data_len);
		  bool result = updateValidateCheck(ctx, enc_data_len);	//16
		  if (result && 1 != EVP_DecryptUpdate(ctx, dec_data.data(), &dec_data_len, enc_data, enc_data_len))
			  SET_ERROR_LOG(kPoErrCryptoDecryptionFailure, GetErrorMessage("EVP_DecryptUpdate"), false);
	  }
	  else {
		  SET_ERROR_LOG(kPoErrCryptoDecryptionFailure, GetErrorMessage("EVP_DecryptInit_ex"), false);
	  }

	  EVP_CIPHER_CTX_free(ctx);
  }
  else
	  SET_ERROR_LOG(kPoErrCryptoDecryptionFailure, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
  
#endif  // USE_OPENSSL_LIB

  return dec_data;
}


std::vector<BrBYTE> OpensslCryptoInterface::ComputeHMAC(BrCHAR* hash_name, 
                                                        BrBYTE* data, BrINT32 data_len, 
                                                        BrBYTE* key, BrINT32 key_len) {
  std::vector<BrBYTE> hmac;

  if(!data || !hash_name)
    return hmac;
#if USE_OPENSSL_LIB	
  const EVP_MD *evp_md;
  evp_md = EVP_get_digestbyname(hash_name);
  if(!evp_md) {
    SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_get_digestbyname"), false);
    return hmac;	
  }

  BrUINT32 out_len = 0;
  std::vector<BrBYTE> out_digest;

  int md_size = EVP_MD_size(evp_md);
  out_digest.resize(md_size);
  HMAC(evp_md, key, key_len, data, data_len, out_digest.data(), (unsigned int*)&out_len);

  if (out_len) {
    hmac.resize(out_len);
    memcpy(hmac.data(), out_digest.data(), out_len);  
  }
  else {
    SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("HMAC"), false);
  }
#endif
  return hmac;
}


std::vector<BrBYTE> OpensslCryptoInterface::AppendHash(BrCHAR* a_pHashAlgorithm, BrINT32 a_nHashSize,BrBYTE* a_HashBuf, BrUINT32 a_nHashBufSize, BrUINT32 i)
{
	std::vector<BrBYTE> IV;
#if USE_OPENSSL_LIB		
	BrINT32 nBufferSize = a_nHashBufSize + 4;
	BrBYTE* pnHash = (BrBYTE*) BrCalloc(nBufferSize, sizeof(BrBYTE));

	memcpy(pnHash,a_HashBuf,a_nHashBufSize);
	memcpy(pnHash+a_nHashBufSize,&i,BrSizeOf(BrUINT32));

	auto pDecryptedHash = ComputeSHA(a_pHashAlgorithm,pnHash,nBufferSize);

    IV.resize(a_nHashBufSize);
	memcpy(IV.data(), pDecryptedHash.data(), a_nHashBufSize);
#endif
	return IV;
}

void OpensslCryptoInterface::WriteDecriptData(int keybits, char* algorithm, int hashsize, SvStream* pIncPackageStream, BFile *pFile, BrBYTE* pDecryptedKeyValue, BrBYTE* pDecodedKeyDataSalt, BrINT32 nDecodedKeyDataSaltSize)
{
#if USE_OPENSSL_LIB			
	BrINT32 nInLen = 0;
	BrINT32 nOutLen = 0 ;

	BrBYTE pnInBuffer[ 4096 ];
	BrBYTE pnOutBuffer[ 4096 ];
	BrINT32 decryptCount =0;

	//IV = H(keyDataSaltBytes(IV) + i);
	EVP_CIPHER_CTX* aes_ctx;
	const EVP_CIPHER* cipher = EVP_aes_128_cbc();
	if(keybits == 256)
		cipher = EVP_aes_256_cbc();
	
	aes_ctx = EVP_CIPHER_CTX_new();

	if (aes_ctx)
	{
		while ((nInLen = pIncPackageStream->Read((char*)pnInBuffer, BrSizeOf(pnInBuffer))) > 0)
		{
			auto IV = AppendHash(algorithm, hashsize, pDecodedKeyDataSalt, nDecodedKeyDataSaltSize, decryptCount); //key ���� ���� IV���� 4096 ������ ����(+i) ��

			if (EVP_DecryptInit_ex(aes_ctx, cipher, 0, pDecryptedKeyValue, IV.data()) == 1)
			{
				EVP_CIPHER_CTX_set_padding(aes_ctx, 0);
				bool result = updateValidateCheck(aes_ctx, nInLen);
				if (result && EVP_DecryptUpdate(aes_ctx, pnOutBuffer, &nOutLen, pnInBuffer, nInLen) == 1)
				{
					pFile->Write((char*)pnOutBuffer, nOutLen);
					decryptCount++;
				}
				else
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptUpdate"), false);
					break;
				}
			}
			else
			{
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptInit_ex"), false);
				break;
			}
		}

		if (EVP_DecryptFinal_ex(aes_ctx, pnOutBuffer, &nOutLen) != 1)
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptFinal_ex"), false);
		else
			pFile->Write((char*)pnOutBuffer, nOutLen);
		EVP_CIPHER_CTX_free(aes_ctx);
	}
	else
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
	}
#endif	
}

static const BrBYTE RandomArrayForKey[32] = { 0x9a, 0x96, 0x22, 0x7f, 0xa3, 0x98, 0x6a, 0x26, 0xba, 0x95, 0x5a, 0xab, 0x41, 0xe9, 0x2c, 0x30,
	0xca, 0xc5, 0x77, 0x81, 0xfb, 0xad, 0x98, 0x34, 0x84, 0x14, 0xac, 0x4c, 0xbd, 0x10, 0xb8, 0xc4 };

BrBOOL OpensslCryptoInterface::WriteEncriptData(int keybits, char* algorithm, int hashsize, BFile* pEncryptedPackageFile, BFile *pDecryptedPackageFile, BrBYTE* pDecodedKeyDataSalt, BrINT32 nSaltSize)
{
	BrBOOL bRet = BrTRUE;
#if USE_OPENSSL_LIB			
	//��ȣȭ(AES-128)
	EVP_CIPHER_CTX* aes_ctx;
	BrINT32	nEncryptCount =0;

	int nInLen = 0;
	int nOutLen = 0;

	BrUCHAR pInBuffer[ 4096	];
	BrUCHAR pOutBuffer[ 4096 ];	
	BrINT32 nOutputSize = 0;
	int nPadding = 0;

	aes_ctx = EVP_CIPHER_CTX_new();
	if (aes_ctx)
	{
		while ((nInLen = pDecryptedPackageFile->Read((char*)pInBuffer, BrSizeOf(pInBuffer))) > 0)
		{
			auto IV = AppendHash(algorithm, hashsize, pDecodedKeyDataSalt, nSaltSize, nEncryptCount);
			if (EVP_EncryptInit_ex(aes_ctx, EVP_aes_256_cbc(), 0, RandomArrayForKey, IV.data()) == 1)
			{
				//���� ���� ����� 16byte�� ������ �������� padding�� �ٿ��� �ʿ����.
				if (0 == nInLen % 16)
					nPadding = 0;
				else
					nPadding = 1;

				EVP_CIPHER_CTX_set_padding(aes_ctx, nPadding);
				bool result = updateValidateCheck(aes_ctx, nInLen);
				if (result && EVP_EncryptUpdate(aes_ctx, pOutBuffer, &nOutLen, pInBuffer, nInLen) == 1)//block(256bit)�� ���� ������ �´� ��ŭ�� ��ȣȭ �ȴ�.	
				{
					nOutputSize += pEncryptedPackageFile->Write((char*)pOutBuffer, nOutLen);
					nEncryptCount++;
				}
				else
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptUpdate"), false);
					break;
				}
			}
			else
			{
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptInit_ex"), false);
				break;
			}
		}

		//result���� ���� ��ȣȭ ���� �Ǻ�, ������ block��ȣȭ ����
		if (EVP_EncryptFinal_ex(aes_ctx, pOutBuffer, &nOutLen) == 1)
			nOutputSize += pEncryptedPackageFile->Write((char*)pOutBuffer, nOutLen);//block(128bit) ���� �ʴ� ������� padding�� �ٿ��־ ���߾��ش�.
		else
		{
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptFinal_ex"), false);
			BR_SAFE_FREE(pDecodedKeyDataSalt);
			bRet = BrFALSE;
		}

		EVP_CIPHER_CTX_free(aes_ctx);
	}
	else
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
	}
#endif	
	return bRet;
}

int OpensslCryptoInterface::decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,	unsigned char *iv, unsigned char *plaintext)
{
	int plaintext_len = 0;	
#if USE_OPENSSL_LIB
	EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();	

	/* Create and initialise the context */
	if( ctx )
	{
		/* Initialise the decryption operation. IMPORTANT - ensure you use a key
		* and IV size appropriate for your cipher
		* In this example we are using 256 bit AES (i.e. a 256 bit key). The
		* IV size for *most* modes is the same as the block size. For AES this
		* is 128 bits */
		if(1 == EVP_DecryptInit_ex(ctx, EVP_aes_256_cfb(), NULL, key, iv))
		{
			/* Provide the message to be decrypted, and obtain the plaintext output.
			* EVP_DecryptUpdate can be called multiple times if necessary
			*/
			int len;
			bool result = updateValidateCheck(ctx, ciphertext_len);
			if(result && 1 == EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
			{
				plaintext_len = len;

				/* Finalise the decryption. Further plaintext bytes may be written at
				* this stage.
				*/
				if(1 == EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
					plaintext_len += len;
				else
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptFinal_ex"), false);
					BRTHREAD_ASSERT(0);
				}				
			}
			else
			{
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptUpdate"), false);
				BRTHREAD_ASSERT(0);
			}			
		}
		else
		{
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptInit_ex"), false);
			BRTHREAD_ASSERT(0);
		}		

		/* Clean up */
		EVP_CIPHER_CTX_free(ctx);
	}
	else
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
		BRTHREAD_ASSERT(0);
	}
#endif
	return plaintext_len;
}

int OpensslCryptoInterface::BytesToKey_aes_256_cfb_sha1(const unsigned char *salt, const unsigned char *data, int datal, int count, unsigned char *key, unsigned char *iv)
{
	int key_len = 0;
#if USE_OPENSSL_LIB
	key_len = EVP_BytesToKey(EVP_aes_256_cfb(), EVP_sha1(), salt, data, datal, count, key, iv);
#endif	
	return key_len;
}

int OpensslCryptoInterface::encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, unsigned char *ciphertext)
{
	int ciphertext_len = 0;		
#if USE_OPENSSL_LIB
	EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

	int len;


	/* Create and initialise the context */
	if( ctx )
	{
		/* Initialise the encryption operation. IMPORTANT - ensure you use a key
		* and IV size appropriate for your cipher
		* In this example we are using 256 bit AES (i.e. a 256 bit key). The
		* IV size for *most* modes is the same as the block size. For AES this
		* is 128 bits */
		if(1 == EVP_EncryptInit_ex(ctx, EVP_aes_256_cfb(), NULL, key, iv))
		{
			/* Provide the message to be encrypted, and obtain the encrypted output.
			* EVP_EncryptUpdate can be called multiple times if necessary
			*/
			bool result = updateValidateCheck(ctx, plaintext_len);
			if(result && 1 == EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
			{
				ciphertext_len = len;

				/* Finalise the encryption. Further ciphertext bytes may be written at
				* this stage.
				*/
				if(1 == EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
					ciphertext_len += len;
				else
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptFinal_ex"), false);
					BRTHREAD_ASSERT(0);
				}
			}
			else
			{
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptUpdate"), false);
				BRTHREAD_ASSERT(0);
			}
		}
		else
		{
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_EncryptInit_ex"), false);
			BRTHREAD_ASSERT(0);
		}

		/* Clean up */
		EVP_CIPHER_CTX_free(ctx);
	}
	else
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
		BRTHREAD_ASSERT(0);
	}
#endif
	return ciphertext_len;
}


int OpensslCryptoInterface::decrypt_aes_128_ecb(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,	unsigned char *iv, unsigned char *plaintext)
{
	int nOutLen = 0;	
#if USE_OPENSSL_LIB	
	// check password
	EVP_CIPHER_CTX* aes_ctx;

	aes_ctx = EVP_CIPHER_CTX_new();
	if (aes_ctx)
	{
		if (EVP_DecryptInit_ex(aes_ctx, EVP_aes_128_ecb(), 0, key, 0) == 1)
		{
			EVP_CIPHER_CTX_set_padding(aes_ctx, 0);
			bool result = updateValidateCheck(aes_ctx, ciphertext_len);
			if (result && EVP_DecryptUpdate(aes_ctx, plaintext, &nOutLen, (const unsigned char*)ciphertext, ciphertext_len) != 1)
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptUpdate"), false);
		}
		else
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptInit_ex"), false);
		EVP_CIPHER_CTX_free(aes_ctx);
	}
	else
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
#endif
	return nOutLen;
}

BrBOOL	OpensslCryptoInterface::WriteEncryptedPackage(void* a_pDecryptedPackageStream, void*  a_pEncryptedPackageStream, const unsigned char *key)
{
#if USE_OPENSSL_LIB		
	SvStream* pIncPackageStream = reinterpret_cast<SvStream*> (a_pEncryptedPackageStream);
	pIncPackageStream->Seek(0);

	EVP_CIPHER_CTX* aes_ctx;
	aes_ctx = EVP_CIPHER_CTX_new();

	if (aes_ctx)
	{
		if (EVP_DecryptInit_ex(aes_ctx, EVP_aes_128_ecb(), 0, key, 0) == 1)
		{
			EVP_CIPHER_CTX_set_padding(aes_ctx, 0);

			int nInLen = 0;
			int nOutLen = 0;
			BrUINT32 nSkip;
			*pIncPackageStream >> nSkip >> nSkip; // 8byte skip

			BrUCHAR pnInBuffer[1024];
			BrUCHAR pnOutBuffer[1024];
			BFile* pFile = (BFile*)a_pDecryptedPackageStream;

			while ((nInLen = pIncPackageStream->Read((char*)pnInBuffer, BrSizeOf(pnInBuffer))) > 0)
			{
				bool result = updateValidateCheck(aes_ctx, nInLen);
				if (result && EVP_DecryptUpdate(aes_ctx, pnOutBuffer, &nOutLen, pnInBuffer, nInLen) == 1)
					pFile->Write((char*)pnOutBuffer, nOutLen);
				else
				{
					SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptUpdate"), false);
					break;
				}
			}

			if (EVP_DecryptFinal_ex(aes_ctx, pnOutBuffer, &nOutLen) == 1)
				pFile->Write((char*)pnOutBuffer, nOutLen);
			else
				SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptFinal_ex"), false);
		}
		else
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DecryptInit_ex"), false);
		EVP_CIPHER_CTX_free(aes_ctx);
	}
	else
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
#endif
	return BrTRUE;
}

BrBOOL OpensslCryptoInterface::DecryptViewText(BrBYTE* a_pSectionStream, BrINT32 a_nStreamLen, Hwp50ByteStream& a_rPlainTextStream, BrBYTE* pSymmetricKey, BrBYTE* pCipherText, int nCipherTextSize)
{
	BrBOOL bRet = BrFALSE;
#if USE_OPENSSL_LIB		
	EVP_CIPHER_CTX* stAES_ctx;
	stAES_ctx = EVP_CIPHER_CTX_new();

	if (!stAES_ctx)
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
		return BrFALSE;
	}

	BrINT32 nPaddingLen = 0;
	BrINT32 nReadPlainTextPos = 0;

	int nCipherInit = EVP_CipherInit(stAES_ctx, EVP_aes_128_ecb(), pSymmetricKey, 0, 0);
	if (nCipherInit != 1) {
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherInit"), false);
		goto END_PROCESS;
	}

	if (EVP_CIPHER_CTX_set_padding( stAES_ctx, 0) != 1) {
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_set_padding"), false);
		goto END_PROCESS;
	}

    BrINT32 idx;
	for (idx = 0; idx < nCipherTextSize; idx += 16) {  // coverity 93392 Expression with no effect
		bool result = updateValidateCheck(stAES_ctx, 16);
		if (result && EVP_CipherUpdate(stAES_ctx, a_rPlainTextStream[idx], &nReadPlainTextPos, pCipherText+idx, 16) != 1) {
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherUpdate"), false);
			goto END_PROCESS;
		}
	}

#ifdef H50_DEBUG_DECRYPT_REMOVE_PADDING
	Hwp50ByteStream::Byte16 arrBuf16;
	for (BrINT32 nPaddingBlockIdx = 0; nPaddingBlockIdx < 3; nPaddingBlockIdx++) {
		bool result = updateValidateCheck(stAES_ctx, VIEWTEXT_AES_BLOCK_SIZE);
		if (result && EVP_CipherUpdate(stAES_ctx, arrBuf16, &nReadPlainTextPos, pCipherText+idx, VIEWTEXT_AES_BLOCK_SIZE) != 1) {
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherUpdate"), false);
			goto END_PROCESS;
		}
		a_rPlainTextStream << arrBuf16;
		idx += VIEWTEXT_AES_BLOCK_SIZE;
	}
#endif

	bRet = BrTRUE;

END_PROCESS:
	if (bRet && nCipherInit == 1) {
		if (EVP_CipherFinal(stAES_ctx, a_rPlainTextStream[nReadPlainTextPos], &nPaddingLen) != 1) {
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherFinal"), false);
			bRet = BrFALSE;
			goto END_PROCESS;
		}

		nReadPlainTextPos += nPaddingLen;
	}	
#if !defined(OPENSSL_API_COMPAT) || OPENSSL_API_COMPAT < 0x10100000L
	if (EVP_CIPHER_CTX_cleanup(stAES_ctx) != 1) {
#else
	if (EVP_CIPHER_CTX_reset(stAES_ctx) != 1) {
#endif
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_cleanup"), false);
		return BrFALSE;
	}
#endif
	return bRet;
}

BrBOOL OpensslCryptoInterface::EncryptViewText(BrBYTE* a_pData, BrINT32 a_nStreamLen, BrBYTE* pSymmetricKey)
{
	BrBOOL bRet = BrFALSE;
#if USE_OPENSSL_LIB		
	//1. ��ĪŰ�� Ȱ���� AES-128 ECB ��ȣȭ ��ƾ ����
	BrINT32 nRet = -1;

	EVP_CIPHER_CTX* stAES_ctx;
	stAES_ctx = EVP_CIPHER_CTX_new();
	if (!stAES_ctx)
	{
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_new"), false);
		return BrFALSE;
	}

	BrINT32 nPaddingLen = 0;
	BrINT32 nReadPlainTextPos = 0;

	//�ʱ�ȭ �� ECB�� iv������� ����
	int nCipherInit = EVP_CipherInit(stAES_ctx, EVP_aes_128_ecb(), pSymmetricKey, 0, 1);
	if (nCipherInit != 1) {
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherInit"), false);
		goto END_PROCESS;
	}

	if (EVP_CIPHER_CTX_set_padding(stAES_ctx, 0) != 1) {
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_set_padding"), false);
		goto END_PROCESS;
	}

	//�� ������ 16����Ʈ ������ ��ȣ�� ���۷� ���� - ���� ���� Ȱ��
    BrINT32 idx;
	for (idx = 0; idx < a_nStreamLen; idx += 16) {  // coverity 93393 Expression with no effect
		bool result = updateValidateCheck(stAES_ctx, 16);
		if (result && EVP_CipherUpdate(stAES_ctx, a_pData + idx, &nReadPlainTextPos, a_pData + idx, 16) != 1) {
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherUpdate"), false);
			goto END_PROCESS;
		}
	}

#ifdef H50_DEBUG_DECRYPT_REMOVE_PADDING
	Hwp50ByteStream::Byte16 arrBuf16;
	for (BrINT32 nPaddingBlockIdx = 0; nPaddingBlockIdx < 3; nPaddingBlockIdx++) {
		bool result = updateValidateCheck(stAES_ctx, VIEWTEXT_AES_BLOCK_SIZE);
		if(result && EVP_CipherUpdate(stAES_ctx, arrBuf16, &nReadPlainTextPos, pCipherText+idx, VIEWTEXT_AES_BLOCK_SIZE) != 1) {
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherUpdate"), false);
			goto END_PROCESS;
		}
		a_rPlainTextStream << arrBuf16;
		idx += VIEWTEXT_AES_BLOCK_SIZE;
	}
#endif

	bRet = BrTRUE;

END_PROCESS:
	if (bRet && nCipherInit == 1) {
		if (EVP_CipherFinal(stAES_ctx, a_pData + nReadPlainTextPos, &nPaddingLen) != 1) {
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CipherFinal"), false);
			bRet = BrFALSE;
			goto END_PROCESS;
		}
		nReadPlainTextPos += nPaddingLen;
	}
	
#if !defined(OPENSSL_API_COMPAT) || OPENSSL_API_COMPAT < 0x10100000L
	if (EVP_CIPHER_CTX_cleanup( stAES_ctx ) != 1) {
#else
	if (EVP_CIPHER_CTX_reset(stAES_ctx) != 1) {
#endif
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_CIPHER_CTX_cleanup"), false);
		return BrFALSE;
	}
#endif
	return bRet;
}

void OpensslCryptoInterface::asn1_put_obj(unsigned char** pp, int constructed, int length, int tag, int xclass)
{
#if USE_OPENSSL_LIB	
	ASN1_put_object(pp, constructed, length, tag, xclass);
#endif
}

int OpensslCryptoInterface::asn1_get_obj(const unsigned char** pp, long* plength, int* ptag, int* pclass, long omax)
{
#if USE_OPENSSL_LIB	
	return ASN1_get_object(pp, plength, ptag, pclass, omax);
#else
	return 0;
#endif
}

//Andrew C.Lee openssl-fips��� �׽�Ʈ�� ���� �ڵ�
//fips������ ���̳ʸ��� include�� ����ؾ� �Ʒ� �ڵ尡 �����ǰ� �׽�Ʈ ������
void OpensslCryptoInterface::FIPS_MDOE_SET(bool bSet)
{
#if USE_OPENSSL_LIB	
#ifdef OPENSSL_FIPS
#if OPENSSL_VERSION_NUMBER >= 0x30000000L
	// ���� �׽�Ʈ ��
	EVP_set_default_properties(NULL, "fips=yes");
	OSSL_PROVIDER* fips;

	fips = OSSL_PROVIDER_load(NULL, "fips");
	if (fips == NULL) {
		printf("FIPS_mode_set failed");
	}

	/*������ ���� ���α׷� */

	OSSL_PROVIDER_unload(fips);
#else
	int mode = FIPS_mode(), ret = 0; unsigned long err = 0;
	BTrace("%s FIPS_mode=%d", __FUNCTION__, mode);
	/* Toggle FIPS mode */
	if(mode == 0)
	{
		ret = FIPS_mode_set(1 /*on*/);
		if(ret != 1)
		{
			err = ERR_get_error();
		}
	}
	else
	{
		ret = FIPS_mode_set(0 /*off*/);
		if(ret != 1)
		{
			err = ERR_get_error();
		}
	}

	if(ret != 1)
		BTrace("%s FIPS_mode_set(%s) failed: %lx.", __FUNCTION__, (mode==0)?"1":"0", err);
	else
		BTrace("%s FIPS_mode_set(%s) succeeded : %d", __FUNCTION__, (mode==0)?"1":"0", ret);	
#endif
#endif
#endif
}

int OpensslCryptoInterface::RAND_BYTES(unsigned char *buf, int num)
{
#ifdef __EMSCRIPTEN__
	boost::uuids::uuid uuid = boost::uuids::random_generator()();
	memcpy(buf, uuid.data, num);
	return 1;
#else
#if USE_OPENSSL_LIB
	return RAND_bytes(buf, num);
#else
	return 0;
#endif
#endif
}

#ifdef SUPPORT_DIGITAL_SIGNATURE
void OpensslCryptoInterface::RAND_SEED(const void* buf, int num)
{
#if USE_OPENSSL_LIB
	RAND_seed(buf, num);
#endif
}
#endif

#ifdef SUPPORT_DIGITAL_SIGNATURE

#include "po_applink.c"

// PDF DigitalSigniture
#include "openssl/cms.h"
#include "openssl/pkcs12.h"
#include "openssl/pem.h"

BrBOOL OpensslCryptoInterface::CMS_VERIFY(unsigned char* certDump, int certLen, const void* buf, int bufLen, const void* fileDump, int dumpLength)
{
#if USE_OPENSSL_LIB
	BrBOOL veriFlag = TRUE;

	BIO* bin, * cin;//, *bout;
	CMS_ContentInfo* cms = nullptr;
	STACK_OF(X509)* additional_certs = NULL;
	X509* cert = nullptr;
	X509_STORE* st = nullptr;
	unsigned int flags = CMS_NOVERIFY | CMS_BINARY;

	cin = BIO_new_mem_buf(certDump, certLen);
	d2i_X509_bio(cin, &cert);
	st = X509_STORE_new();
	X509_STORE_add_cert(st, cert);
	additional_certs = sk_X509_new_null();

	sk_X509_push(additional_certs, cert);

	bin = BIO_new_mem_buf(buf, bufLen);
	d2i_CMS_bio(bin, &cms);
	BIO_free(bin);

	bin = BIO_new_mem_buf(fileDump, dumpLength);

	if (!CMS_verify(cms, NULL, st, bin, NULL, flags))
	{
		//char* erST = GetErrorMessage("CMS_verify");
		//char *erST = ERR_error_string(ERR_get_error(), NULL);
		veriFlag = FALSE;
	}
	BIO_free(bin);

	return veriFlag;
#else
	retrun BrFALSE;
#endif
}

BrBOOL OpensslCryptoInterface::CMS_WRITE(void* pFileBuffer, unsigned int bufLen, const char* sigDumpName, const char* sigPath, char* password)
{
#if USE_OPENSSL_LIB
	BIO* in = nullptr, * out = nullptr, * tbio = nullptr;// , * out2;
	X509* scert = nullptr;
	EVP_PKEY* skey = nullptr;
	CMS_ContentInfo* cms = NULL;
	PKCS12* p12 = nullptr;
	STACK_OF(X509)* additional_certs = NULL;
	int pout = 0;
	int flags = CMS_DETACHED | CMS_NOSMIMECAP | CMS_BINARY | CMS_PARTIAL;
	const EVP_MD* sign_md = EVP_get_digestbyname("SHA256");

	//read pfx
	tbio = BIO_new_file(sigPath, "r");
	d2i_PKCS12_bio(tbio, &p12);
	//divide pem/key
	pout = PKCS12_parse(p12, password, &skey, &scert, &additional_certs);

	//cut data using offset
	in = BIO_new(BIO_s_mem());
	BIO_write(in, pFileBuffer, bufLen);

	// Signing
	cms = CMS_sign(NULL, NULL, nullptr, NULL, flags);
	CMS_add1_signer(cms, scert, skey, sign_md, flags);
	CMS_final(cms, in, nullptr, flags ^ CMS_PARTIAL);

	//file write
	out = BIO_new_file(sigDumpName, "w");

	/* Write out S/MIME message */
	i2d_CMS_bio(out, cms);

	BIO_free(out);
	CMS_ContentInfo_free(cms);
	X509_free(scert);
	EVP_PKEY_free(skey);
	BIO_free(in);

	BIO_free(tbio);

	return BrTRUE;
#else
	retrun BrFALSE;
#endif
}

X509* OpensslCryptoInterface::CreateX509Crt(EVP_PKEY* pkey, LPBoraDigitalIDInfo input_data)
{
	X509* x509 = NULL;
#if USE_OPENSSL_LIB
	x509 = X509_new();

	ASN1_INTEGER_set(X509_get_serialNumber(x509), 1);

	X509_gmtime_adj(X509_get_notBefore(x509), 0);
	X509_gmtime_adj(X509_get_notAfter(x509), 31536000L);

	X509_set_pubkey(x509, pkey);

	X509_NAME* name;
	name = X509_get_subject_name(x509);

	X509_NAME_add_entry_by_txt(name, "C", MBSTRING_ASC,
		(unsigned char*)input_data->nation_code, -1, -1, 0);
	X509_NAME_add_entry_by_txt(name, "O", MBSTRING_ASC,
		(unsigned char*)input_data->organization, -1, -1, 0);
	X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
		(unsigned char*)input_data->name, -1, -1, 0);
	X509_NAME_add_entry_by_txt(name, "emailAddress", MBSTRING_ASC,
		(unsigned char*)input_data->email, -1, -1, 0);
	X509_NAME_add_entry_by_txt(name, "ST", MBSTRING_ASC,
		(unsigned char*)input_data->address, -1, -1, 0);

	X509_set_issuer_name(x509, name);

	X509_sign(x509, pkey, EVP_sha256());

	FILE* f = NULL;
	fopen_s(&f, "cert.pem", "wb");
	PEM_write_X509(
		f,   /* write the certificate to the file we've opened */
		x509 /* our certificate */
	);
	fclose(f);
#endif 
	return x509;
}

char* OpensslCryptoInterface::GetX509Name(char* path, EVP_PKEY* pkey, X509* x509, char* pass)
{
	char* dump = NULL;
#if USE_OPENSSL_LIB
	PKCS12* p12_cert;
	pkey = NULL;
	x509 = NULL;

	STACK_OF(X509)* additional_certs = NULL;
	FILE* fp_p12 = NULL;
	fopen_s(&fp_p12, path, "r");

	p12_cert = d2i_PKCS12_fp(fp_p12, NULL);

	if (!PKCS12_parse(p12_cert, pass, &pkey, &x509, &additional_certs)) {
		GetErrorMessage("PKCS12_parse");
		BoraDigitalIDInfo error = { 0, };
		return dump;
	}
	PKCS12_free(p12_cert);

	dump = X509_NAME_oneline(X509_get_subject_name(x509), NULL, 0);

#endif
	return dump;
}

EVP_PKEY* OpensslCryptoInterface::Get_PKEY_assign_RSA(int bit)
{
	EVP_PKEY* pkey = NULL;
#if USE_OPENSSL_LIB
	unsigned int bits = bit;
	unsigned int exp = RSA_F4;     //      RSA_3

	RSA* r;
	BIGNUM* bne = NULL;

	bne = BN_new();

	if(bne == NULL)
		return pkey;

	if (BN_set_word(bne, exp) != 1)
	{
		BN_free(bne);
		return pkey;
	}

#if OPENSSL_VERSION_NUMBER >= 0x30000000L
	unsigned int primes = 2;

	if (bit < 1024)
		primes = 2;
	else if (bit < 4096)
		primes = 3;
	else if (bit < 8192)
		primes = 4;
	else
		primes = 5;

	OSSL_PARAM params[4];
	EVP_PKEY_CTX* pctx = EVP_PKEY_CTX_new_from_name(NULL, "RSA", NULL);

	EVP_PKEY_keygen_init(pctx);

	params[0] = OSSL_PARAM_construct_uint("bits", &bits);
	params[1] = OSSL_PARAM_construct_uint("e", &exp);
	params[2] = OSSL_PARAM_construct_uint("primes", &primes);
	params[3] = OSSL_PARAM_construct_end();
	EVP_PKEY_CTX_set_params(pctx, params);

	EVP_PKEY_generate(pctx, &pkey);

#if 0

	// ���� �׽�Ʈ ��
	OSSL_PARAM_BLD* bld = OSSL_PARAM_BLD_new();
	BIGNUM* p, * q;  /* both prime */
	BIGNUM* n;      /* = p * q */
	unsigned int e; /* exponent, usually 65537 */
	BIGNUM* d;      /* e^-1 */
	OSSL_PARAM* params;

	if (bld == NULL
		|| !OSSL_PARAM_BLD_push_BN(bld, "p", p)
		|| !OSSL_PARAM_BLD_push_BN(bld, "q", q)
		|| !OSSL_PARAM_BLD_push_uint(bld, "e", e)
		|| !OSSL_PARAM_BLD_push_BN(bld, "n", n)
		|| !OSSL_PARAM_BLD_push_BN(bld, "d", d)
		|| (params = OSSL_PARAM_BLD_to_param(bld)) == NULL)
	{
		;

	}
#endif
#else
	r = RSA_new();
	if (RSA_generate_key_ex(r, bits, bne, NULL) != 1)
	{
		RSA_free(r);
		BN_free(bne);
		return pkey;
	}

	if (RSA_check_key(r) != 1)
	{
		RSA_free(r);
		BN_free(bne);
		return pkey;
	}

	//Create EVP to save to file.
	pkey = EVP_PKEY_new();
	EVP_PKEY_assign_RSA(pkey, r);

#endif
	BN_free(bne);

#endif
	return pkey;
}

void OpensslCryptoInterface::Release_PKEY(EVP_PKEY* pKey)
{
	if (pKey)
	{
#if OPENSSL_VERSION_NUMBER >= 0x30000000L

#else
		EVP_PKEY_free(pKey);
#endif
	}
}

void OpensslCryptoInterface::PEM_write_Key(LPBoraDigitalIDInfo input_data, EVP_PKEY* pkey, const char* keyName, BrBOOL bPrivate)
{
#if USE_OPENSSL_LIB
	FILE* fp = NULL;
	fopen_s(&fp, keyName, "w");

	int ret = 0;

	if(bPrivate)
		ret = PEM_write_PrivateKey(fp, pkey, EVP_aes_256_cbc(), NULL, 0, NULL, input_data->password);
	else
		ret = PEM_write_PUBKEY(fp, pkey);

	fclose(fp);
#endif
}

void OpensslCryptoInterface::Save_PKCS12_fp(LPBoraDigitalIDInfo input_data, EVP_PKEY* pkey, char* path)
{
#if USE_OPENSSL_LIB
	X509* x509 = NULL;
	PKCS12* p12_cert = NULL;

	//������ ���� ����
	x509 = CreateX509Crt(pkey, input_data);

	//PKCS#12 ��ȯ �� ����
	p12_cert = PKCS12_create(input_data->password, "PolarisDigitalID", pkey, x509, NULL, 0, 0, 0, 0, 0);

	FILE* fp_p12 = NULL;
	fopen_s(&fp_p12, path, "w+");

	i2d_PKCS12_fp(fp_p12, p12_cert);
	fclose(fp_p12);
	PKCS12_free(p12_cert);
#endif
}

#endif

SecureHashValue::SecureHashValue()
{
	if (!OpensslCryptoInterface::GetInstance())
	{
		SET_ERROR_LOG(kPoErrInternal, "OpensslCryptoInterface::GetInstance() failed", false);
		return;
	}		
	md = BrNULL;
	ctx = BrNULL;
}
SecureHashValue::~SecureHashValue()
{
#if USE_OPENSSL_LIB
	if ( ctx )
		EVP_MD_CTX_destroy(ctx);
#endif
}

BrBOOL SecureHashValue::CopyCTX(const SecureHashValue* a_hash)
{
	BrBOOL bRet = BrFALSE;
#if USE_OPENSSL_LIB
	md = (EVP_MD*)a_hash->getMD();

	EVP_MD_CTX_copy(ctx, a_hash->getCTX());
#endif
	return bRet;
}

BrBOOL SecureHashValue::CreateSHA(const char* algorithm)
{
	BrBOOL bRet = BrFALSE;
#if USE_OPENSSL_LIB
	md = (EVP_MD*)EVP_get_digestbyname(algorithm);
	if(!md) {
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_get_digestbyname"), false);
		return bRet;	
	}

	ctx = EVP_MD_CTX_create();
	if(!ctx) {
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_MD_CTX_create"), false);
		return bRet;	
	}

	if ( EVP_DigestInit_ex(ctx, md, NULL) == 1 )
		bRet = BrTRUE;
	else
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DigestInit_ex"), false);
#endif
	return bRet;
}
BrBOOL SecureHashValue::DigestUpdate(void* data, int data_len)
{
	BrBOOL bRet = BrFALSE;
#if USE_OPENSSL_LIB
	if (ctx && EVP_DigestUpdate(ctx, data, data_len) == 1 )
		bRet = BrTRUE;
	else
		SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DigestUpdate"), false);
#endif
	return bRet;
}
BrBOOL SecureHashValue::GenerateToHash() 
{
	BrBOOL bRet = BrFALSE;
#if USE_OPENSSL_LIB
	if ( md && ctx )
	{
		unsigned int md_len;
		int md_size = EVP_MD_size(md);
		hash.resize(md_size);

		if ( EVP_DigestFinal_ex(ctx, hash.data(), &md_len) == 1 )
			bRet = BrTRUE;
		else
			SET_ERROR_LOG(kPoErrInternal, GetErrorMessage("EVP_DigestFinal_ex"), false);
	}
#endif
	return bRet;
}

std::vector<BrBYTE>& SecureHashValue::GetHashValue()
{
	return hash;
}

std::vector<BrBYTE> SecureHashValue::GetHashHexaString()
{
	std::vector<BrBYTE> hexastring;
	int nLen = hash.size();
	if( nLen > 0 )
	{		
		hexastring.resize(nLen*2+1);
		
		char* pBuf = (char*)hexastring.data();
		for (int i = 0; i < nLen; i++)
			sprintf_s(((char*)pBuf) + i * 2, hexastring.size() - (i * 2), "%02x", (char*)hash.at(i));

		hexastring.resize(nLen * 2);
	}
	return hexastring;	
}

EVP_MD* SecureHashValue::getMD() const
{
	return md;
}

EVP_MD_CTX* SecureHashValue::getCTX() const
{
	return ctx;
}

char* SecureHashValue::GetErrorMessage(const char* _func)
{
	static char pErrMsg[1024] = {0,};
	memset(pErrMsg, 0, sizeof(pErrMsg));
#if USE_OPENSSL_LIB	
	int err = ERR_get_error();
	if ( err != 0 ) 
		_snprintf_s(pErrMsg, sizeof(pErrMsg), "ERR : EVP_Encrypt() - lib[%s] func[%s] reason[%s]", ERR_lib_error_string(err), _func, ERR_reason_error_string(err));
#endif	
	return pErrMsg;
}

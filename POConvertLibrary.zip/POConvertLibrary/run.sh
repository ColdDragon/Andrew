#!/bin/bash
java -jar ./PolarisConverter8.jar PNG ./guide.docx ./result 1280 1280 ./temp